from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import itertools
import json
from html.parser import HTMLParser
import math
import os
import re
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import webbrowser
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Any, Callable, Iterable, NoReturn

from .layout_overlays import (
    Box, color_visible as overlay_color_visible, html_regions, image_region,
    polygon_area, polygon_box, polygon_overlap, transformed_region,
)

SCHEMA_VERSION = "1"


def _positive_float_env(name: str, default: float) -> float:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if value > 0 else default


def _retry_count_env(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return value if 0 <= value <= 10 else default


# 真实项目里一次 timeline add 的服务端耗时会随 clip 数增长;5 秒的
# 默认超时把慢响应误判成服务死亡,还诱发盲重试造成重复放置。默认放宽,
# 并允许按环境覆盖。
DEFAULT_TIMEOUT_SECONDS = _positive_float_env("OC_TIMEOUT_SECONDS", 30.0)
# 超时后,携带幂等键的请求可以安全地原样重发(服务端按键去重),
# GET 天然可重发。默认自动补发 2 次。
TIMEOUT_RETRIES = _retry_count_env("OC_TIMEOUT_RETRIES", 2)
PROJECT_LIFECYCLE_TIMEOUT_SECONDS = 120.0
IMPORT_TIMEOUT_SECONDS = 120.0
EXPORT_START_TIMEOUT_SECONDS = 600.0
JOB_TIMEOUT_SECONDS = 300.0
DISCOVERY_TIMEOUT_SECONDS = 0.75
# 快探超时判死之后、决定拉起之前的第二次机会。忙碌的服务(几条导出 job
# 同时跑)在 0.75s 里答不上话再正常不过,而误判的代价是整条拉起链:白起
# 一个见到 SERVICE_ALREADY_RUNNING 立刻自杀的进程,还在流水里记一笔
# "重启"。实测一晚 73 秒里被这样误拉了 7 次。
PATIENT_DISCOVERY_TIMEOUT_SECONDS = 5.0
# 两次自动拉起之间的最小间隔。刚拉起过(不管谁拉的)服务多半在冷启动或
# 忙碌,这时该等它,不该再叠一个进程上去抢同一个数据根。
AUTOSTART_MIN_INTERVAL_SECONDS = 20.0
MAX_DESCRIPTOR_BYTES = 64 * 1024
MAX_DISCOVERY_DESCRIPTORS = 64
# ---- 自动拉起本地服务 ----------------------------------------------------
# 与 Electron 宿主认同一个环境变量(host-electron/main.js):服务二进制在哪
# 是一台机器的属性,不该让宿主和 CLI 各记一份、各自过期。
SERVICE_BINARY_ENV = "ORANGECUT_SERVICE_BINARY"
# 打包版把二进制改名成 orangecut-service(host-electron/package-app.js),
# 源码构建叫 orangecut-desktop。两个名字都得认。
SERVICE_BINARY_NAMES = ("orangecut-service", "orangecut-desktop")
# 服务要建 runtime、开渲染器、恢复上次的 Project 才写下注册文件,冷启动
# 比一次握手慢得多;给足时间好过让批处理在启动慢的机器上碎在第一条命令。
AUTOSTART_READY_TIMEOUT_SECONDS = 25.0
AUTOSTART_POLL_INTERVAL_SECONDS = 0.25
# 持锁者自己崩了的话,锁不能永久挡住后来者。取值比就绪超时略长,这样一次
# 正常的拉起绝不会被别人当成陈旧锁抢走。
AUTOSTART_LOCK_STALE_SECONDS = AUTOSTART_READY_TIMEOUT_SECONDS + 5.0
AUTOSTART_LOG_TAIL_BYTES = 2048
# 拉起流水保留多久、几次算不正常。取值对着 Windows 那台的实测形态:服务在
# 三天里崩了十几次,聚集在导出前后——不是几分钟内的紧密循环,所以短窗口
# 阈值根本不会响。一天里要救三次,就已经不是"顺手救一下"了。
AUTOSTART_HISTORY_WINDOW_SECONDS = 24 * 60 * 60
AUTOSTART_HISTORY_MAX_ENTRIES = 64
AUTOSTART_LOOP_THRESHOLD = 3
# 连着这么多次拉起,每一次都接的是一个没能干净退出的服务,而且全都挤在这段
# 时间里——那不是"偶尔崩一次",是崩溃循环。再自动救下去只是把故障磨成静默:
# 真实故障里它每 36 秒死一次、连救 64 回,而每条命令都显示成功,唯一的出口
# 是 warnings 里那一行。到这个地步就该停下来让人看见。
AUTOSTART_CRASH_LOOP_THRESHOLD = 5
AUTOSTART_CRASH_LOOP_WINDOW_SECONDS = 10 * 60
STUCK_SERVICE_PROBE_TIMEOUT_SECONDS = 5.0
# 杀进程前要连着这么多次拿到"连接被拒绝"。删注册文件那条判据(0.4 秒握不上手
# 就算死)对这里太松:一次导出会同时压着十个截帧进程,健康服务照样握不上。
STUCK_SERVICE_CONFIRMATIONS = 3
STUCK_SERVICE_CONNECT_TIMEOUT_SECONDS = 2.0
STUCK_SERVICE_RECHECK_SECONDS = 1.0
MAX_DISCOVERY_WORKERS = 8
MAX_DISCOVERY_RESPONSE_BYTES = 1024 * 1024
MAX_CONTROL_REQUEST_BYTES = 4 * 1024 * 1024
MAX_CONTROL_RESPONSE_BYTES = 64 * 1024 * 1024
MAX_STRICT_JSON_DEPTH = 128
MAX_SAFE_INTEGER = 9_007_199_254_740_991
WINDOWS_REPARSE_POINT = 0x400

EXIT_OPERATION_FAILED = 2
EXIT_SERVICE_UNAVAILABLE = 3
EXIT_INVALID_INPUT = 4
V0_ERROR_STAGES = frozenset(
    {
        "decode",
        "schema",
        "preconditions",
        "capability",
        "command",
        "validation",
        "transaction",
        "store",
        "serialization",
        "job",
        "migration",
    }
)
ERROR_CODE_PATTERN = re.compile(r"^[A-Z][A-Z0-9_]{0,127}$")
MAX_ERROR_MESSAGE_CHARS = 2048
JOB_STATES = frozenset(
    {"queued", "running", "cancelling", "succeeded", "failed", "cancelled", "interrupted"}
)
TEXT_STICKER_ANIMATIONS = (
    "soft_rise",
    "mask_reveal",
    "focus",
    "none",
    "fade",
    "pop",
    "bounce",
    "zoom",
    "slide_up",
    "slide_down",
    "slide_left",
    "slide_right",
)
_MISSING = object()


def wire_error_stage(stage: str) -> str:
    return stage if stage in V0_ERROR_STAGES else "serialization"


@dataclass(frozen=True)
class CliFailure(Exception):
    code: str
    stage: str
    message: str
    retryable: bool = False
    remediation: str | None = None
    current_revision: int | None = None
    exit_code: int = EXIT_OPERATION_FAILED
    details: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "stage", wire_error_stage(self.stage))

    def wire(self) -> dict[str, Any]:
        error: dict[str, Any] = {
            "code": self.code,
            "stage": self.stage,
            "message": self.message,
            "details": dict(self.details or {}),
            "retryable": self.retryable,
        }
        if self.current_revision is not None:
            error["currentRevision"] = self.current_revision
        if self.remediation is not None:
            error["remediation"] = self.remediation
        return {"schemaVersion": SCHEMA_VERSION, "ok": False, "error": error}


class StructuredArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> NoReturn:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            message,
            remediation=f"run `{self.prog} --help` and retry with supported arguments",
            exit_code=EXIT_INVALID_INPUT,
        )


def invalid_descriptor() -> CliFailure:
    return CliFailure(
        "HTTP_DESCRIPTOR_INVALID",
        "serialization",
        "a OrangeCut service descriptor is not a bounded regular UTF-8 JSON object",
        retryable=True,
        remediation="restart OrangeCut and retry",
        exit_code=EXIT_SERVICE_UNAVAILABLE,
    )


def descriptor_boolean(payload: dict[str, Any], key: str) -> bool:
    value = payload.get(key)
    if not isinstance(value, bool):
        raise invalid_descriptor()
    return value


@dataclass(frozen=True)
class Descriptor:
    instance_id: str
    base_url: str
    token: str
    headless: bool
    gui_open: bool
    # 保留下来只为回收陈旧注册文件:服务被 kill -9 或崩溃时来不及自己删,
    # 留下的 descriptor 会一直堆积,而每次发现都要对它并发探活一次。
    process_id: int = 0
    source_path: Path | None = None

    @classmethod
    def read(cls, path: Path) -> "Descriptor":
        try:
            metadata = path.lstat()
            if path_is_link(path, metadata) or not stat.S_ISREG(metadata.st_mode):
                raise invalid_descriptor()
            flags = os.O_RDONLY
            for flag_name in ("O_BINARY", "O_CLOEXEC", "O_NOFOLLOW", "O_NONBLOCK"):
                flags |= getattr(os, flag_name, 0)
            descriptor_fd = os.open(path, flags)
            with os.fdopen(descriptor_fd, "rb") as descriptor_file:
                opened_metadata = os.fstat(descriptor_file.fileno())
                if not stat.S_ISREG(opened_metadata.st_mode):
                    raise invalid_descriptor()
                raw = descriptor_file.read(MAX_DESCRIPTOR_BYTES + 1)
        except CliFailure:
            raise
        except OSError as error:
            raise invalid_descriptor() from error
        if len(raw) > MAX_DESCRIPTOR_BYTES:
            raise invalid_descriptor()
        try:
            payload = strict_json_loads(raw.decode("utf-8"))
        except (UnicodeError, ValueError, RecursionError) as error:
            raise invalid_descriptor() from error
        if not isinstance(payload, dict) or set(payload) != {
            "schemaVersion",
            "instanceId",
            "baseUrl",
            "token",
            "processId",
            "headless",
            "guiOpen",
        }:
            raise invalid_descriptor()
        if payload.get("schemaVersion") != SCHEMA_VERSION:
            raise CliFailure(
                "HTTP_PROTOCOL_UNSUPPORTED",
                "schema",
                "the running OrangeCut service uses an unsupported protocol version",
                remediation="update OrangeCut and the oc CLI together",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
            )
        base_url = require_text(payload, "baseUrl")
        parsed = urllib.parse.urlsplit(base_url)
        if (
            parsed.scheme != "http"
            or parsed.hostname != "127.0.0.1"
            or parsed.username is not None
            or parsed.password is not None
            or parsed.path not in ("", "/")
            or parsed.query
            or parsed.fragment
        ):
            raise CliFailure(
                "HTTP_DESCRIPTOR_UNSAFE",
                "capability",
                "the OrangeCut service descriptor does not point to IPv4 loopback",
                remediation="restart the official local OrangeCut application",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
            )
        try:
            port = parsed.port
        except ValueError as error:
            raise CliFailure(
                "HTTP_DESCRIPTOR_INVALID",
                "serialization",
                "the OrangeCut service descriptor contains an invalid port",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
            ) from error
        if port is None:
            raise CliFailure(
                "HTTP_DESCRIPTOR_INVALID",
                "serialization",
                "the OrangeCut service descriptor does not contain a port",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
            )
        process_id = payload.get("processId")
        if (
            not isinstance(process_id, int)
            or isinstance(process_id, bool)
            or process_id <= 0
            or process_id > 0xFFFF_FFFF
        ):
            raise invalid_descriptor()
        return cls(
            instance_id=require_text(payload, "instanceId"),
            base_url=base_url.rstrip("/"),
            token=require_text(payload, "token"),
            headless=descriptor_boolean(payload, "headless"),
            gui_open=descriptor_boolean(payload, "guiOpen"),
            process_id=process_id,
            source_path=path,
        )


class Client:
    def __init__(self, descriptor: Descriptor, timeout: float = DEFAULT_TIMEOUT_SECONDS):
        self.descriptor = descriptor
        self.timeout = timeout

    # 服务不认识某条语义命令时,它只会说"这个请求对该端点不合法"——
    # 那读起来像调用方拼错了 JSON,实际是这个 OrangeCut 比源码/文件旧。
    # 只在真的失败之后才去查能力表:成功路径零额外请求。
    _SHAPE_REJECTION_CODES = frozenset({"HTTP_INVALID_JSON", "HTTP_RESPONSE_INVALID"})

    def explain_unsupported_commands(
        self,
        failure: CliFailure,
        method: str,
        path: str,
        payload: dict[str, Any] | None,
    ) -> CliFailure:
        if getattr(self, "_probing_capabilities", False):
            return failure
        if method != "POST" or not path.endswith("/commands"):
            return failure
        if failure.code not in self._SHAPE_REJECTION_CODES:
            return failure
        commands = (payload or {}).get("commands")
        if not isinstance(commands, list) or not commands:
            return failure
        self._probing_capabilities = True
        try:
            capabilities = (
                self.request("GET", f"/v1/capabilities{project_query(_RESOLVED_PROJECT)}").get("data") or {}
            )
        except CliFailure:
            # 查不到能力表就别猜,把服务原本的错误原样抛回去。
            return failure
        finally:
            self._probing_capabilities = False
        try:
            assert_commands_supported(commands, capabilities, context="this CommandBatch")
        except CliFailure as unsupported:
            return unsupported
        return failure

    def request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        *,
        response_limit: int | None = None,
        timeout_seconds: float | None = None,
        timeout_cap: float | None = None,
    ) -> dict[str, Any]:
        if response_limit is None:
            response_limit = MAX_CONTROL_RESPONSE_BYTES
        # 已知的长任务端点(如 transcribe)按任务规模抬高超时;
        # 用户显式设置的 OC_TIMEOUT_SECONDS 更大时仍然生效。
        effective_timeout = (
            self.timeout if timeout_seconds is None else max(timeout_seconds, self.timeout)
        )
        if timeout_cap is not None:
            effective_timeout = min(effective_timeout, timeout_cap)
        body = None
        headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {self.descriptor.token}",
        }
        if payload is not None:
            try:
                body = json.dumps(
                    payload,
                    ensure_ascii=False,
                    allow_nan=False,
                    separators=(",", ":"),
                ).encode("utf-8")
            except (TypeError, ValueError, UnicodeError, RecursionError) as error:
                raise CliFailure(
                    "CLI_REQUEST_INVALID",
                    "validation",
                    "the OrangeCut control request is not strict UTF-8 JSON",
                    exit_code=EXIT_INVALID_INPUT,
                ) from error
            if len(body) > MAX_CONTROL_REQUEST_BYTES:
                raise CliFailure(
                    "CLI_REQUEST_TOO_LARGE",
                    "validation",
                    f"the OrangeCut control request exceeds the {MAX_CONTROL_REQUEST_BYTES}-byte limit",
                    remediation="reduce the request below 4 MiB without truncating its JSON",
                    exit_code=EXIT_INVALID_INPUT,
                )
            headers["Content-Type"] = "application/json"
        # 超时重发的安全性判定:GET 无副作用;带幂等键的变更由服务端按键
        # 去重,原样重发不会产生第二份提交。其余请求超时不自动重发。
        replayable = method == "GET" or (
            isinstance(payload, dict) and bool(payload.get("idempotencyKey"))
        )
        attempts = 1 + (TIMEOUT_RETRIES if replayable and timeout_cap is None else 0)
        timeout_error: BaseException | None = None
        for attempt in range(attempts):
            request = urllib.request.Request(
                f"{self.descriptor.base_url}{path}",
                data=body,
                headers=headers,
                method=method,
            )
            try:
                with urllib.request.urlopen(request, timeout=effective_timeout) as response:
                    envelope = decode_response(read_response_body(response, response_limit))
                    if envelope["ok"] is not True:
                        raise self.explain_unsupported_commands(
                            decode_server_failure(
                                envelope.get("error"),
                                invalid_code="HTTP_RESPONSE_INVALID",
                                invalid_message="OrangeCut returned an invalid success response envelope",
                            ),
                            method,
                            path,
                            payload,
                        )
                    return envelope
            except urllib.error.HTTPError as error:
                # 404 有两种:未注册的路由(版本错配,body 通常不是信封),和
                # **带着正常错误信封的业务 404**——PROJECT_NOT_OPEN 就走 404。
                # 先解码 body,是信封就报信封里的真实错误;此前一切 404 都被
                # 拦成 SERVICE_ENDPOINT_UNKNOWN"服务比 CLI 旧",服务重启踢掉
                # 项目后每条命令都在喊"重建服务",把人引去查完全错误的方向
                # (真实事故:贴纸更新被误报成服务缺端点,实为项目没开)。
                if error.code == 404:
                    envelope_failure = None
                    try:
                        decoded = decode_response(read_response_body(error, response_limit))
                    except CliFailure:
                        decoded = None
                    if isinstance(decoded, dict) and decoded.get("ok") is False:
                        envelope_failure = decode_server_failure(
                            decoded.get("error"),
                            invalid_code="HTTP_RESPONSE_INVALID",
                            invalid_message="OrangeCut returned an invalid error envelope",
                        )
                    if envelope_failure is not None:
                        raise self.explain_unsupported_commands(
                            envelope_failure, method, path, payload
                        ) from error
                    raise CliFailure(
                        "SERVICE_ENDPOINT_UNKNOWN",
                        "preconditions",
                        f"the running OrangeCut does not know {method} {path}",
                        remediation=(
                            "this service is older than the CLI — rebuild and restart "
                            "OrangeCut, then retry"
                        ),
                        exit_code=EXIT_SERVICE_UNAVAILABLE,
                    ) from error
                try:
                    failure = decode_response(read_response_body(error, response_limit))
                except CliFailure as response_error:
                    if response_error.code == "HTTP_RESPONSE_TOO_LARGE":
                        raise response_error from error
                    raise CliFailure(
                        "HTTP_RESPONSE_INVALID",
                        "serialization",
                        f"OrangeCut returned HTTP {error.code} without a valid error envelope",
                        retryable=error.code >= 500,
                    ) from error
                raise self.explain_unsupported_commands(
                    decode_server_failure(
                        failure.get("error"),
                        invalid_code="HTTP_RESPONSE_INVALID",
                        invalid_message=f"OrangeCut returned HTTP {error.code} without a valid error envelope",
                        invalid_retryable=error.code >= 500,
                    ),
                    method,
                    path,
                    payload,
                ) from error
            except (urllib.error.URLError, TimeoutError, OSError) as error:
                reason = getattr(error, "reason", None)
                is_timeout = isinstance(error, TimeoutError) or isinstance(
                    reason, TimeoutError
                ) or "timed out" in str(error).lower()
                if not is_timeout:
                    raise CliFailure(
                        "ORANGECUT_SERVICE_UNAVAILABLE",
                        "preconditions",
                        "the local OrangeCut service did not respond",
                        retryable=True,
                        remediation="start OrangeCut, keep exactly one target Project open, and retry",
                        exit_code=EXIT_SERVICE_UNAVAILABLE,
                    ) from error
                timeout_error = error
                if attempt + 1 < attempts:
                    continue
        # 超时不等于服务死亡:变更可能已在服务端提交。给出独立错误码,
        # 并把恢复身份放进 details,让调用方能用同一 key 安全重试。
        details: dict[str, Any] = {
            "timeoutSeconds": effective_timeout,
            "attempts": attempts,
        }
        if isinstance(payload, dict):
            if payload.get("idempotencyKey"):
                details["idempotencyKey"] = payload["idempotencyKey"]
            if payload.get("baseRevision") is not None:
                details["baseRevision"] = payload["baseRevision"]
        raise CliFailure(
            "REQUEST_TIMEOUT",
            "transport",
            f"the OrangeCut request did not complete within {effective_timeout:g}s"
            f" after {attempts} attempt(s); a mutation may already be committed",
            retryable=True,
            remediation=(
                "retry the exact same command with the identical --base-revision"
                " and --idempotency-key (OrangeCut deduplicates by key), or raise"
                " OC_TIMEOUT_SECONDS for slow operations"
            ),
            details=details,
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        ) from timeout_error

    def download(self, path: str, destination: Path) -> int:
        """Write an image response straight to disk and return its byte count.

        A frame sheet is megabytes of PNG. Routing it through the JSON envelope
        would mean base64 in memory on both sides for a payload whose only
        destination is a file."""
        request = urllib.request.Request(
            f"{self.descriptor.base_url}{path}",
            headers={
                "Accept": "image/png",
                "Authorization": f"Bearer {self.descriptor.token}",
            },
            method="GET",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                payload = read_response_body(response, MAX_CONTROL_RESPONSE_BYTES)
        except urllib.error.HTTPError as error:
            try:
                failure = decode_response(
                    read_response_body(error, MAX_CONTROL_RESPONSE_BYTES)
                )
            except CliFailure as response_error:
                raise CliFailure(
                    "HTTP_RESPONSE_INVALID",
                    "serialization",
                    f"OrangeCut returned HTTP {error.code} without a valid error envelope",
                    retryable=error.code >= 500,
                ) from response_error
            raise decode_server_failure(
                failure.get("error"),
                invalid_code="HTTP_RESPONSE_INVALID",
                invalid_message=f"OrangeCut returned HTTP {error.code} without a valid error envelope",
                invalid_retryable=error.code >= 500,
            ) from error
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            raise CliFailure(
                "ORANGECUT_SERVICE_UNAVAILABLE",
                "preconditions",
                "the local OrangeCut service did not respond",
                retryable=True,
                remediation="start OrangeCut, keep exactly one target Project open, and retry",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
            ) from error
        try:
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(payload)
        except OSError as error:
            raise CliFailure(
                "READ_OUTPUT_UNWRITABLE",
                "output",
                f"cannot write the frame sheet to {destination}",
                remediation="pass --output under a directory this user can write",
                exit_code=EXIT_INVALID_INPUT,
            ) from error
        return len(payload)

    def watch_events(
        self,
        count: int,
        timeout_seconds: float,
        cursor: str | None,
        project: str | None = None,
    ) -> dict[str, Any]:
        events: list[dict[str, Any]] = []
        reconnect_cursor = cursor
        deadline = time.monotonic() + timeout_seconds
        parameters: dict[str, str] = {}
        headers = {
            "Accept": "text/event-stream",
            "Authorization": f"Bearer {self.descriptor.token}",
        }
        if cursor:
            parameters["cursor"] = cursor
            headers["Last-Event-ID"] = cursor
        if project:
            parameters["project"] = project
        query = "?" + urllib.parse.urlencode(parameters) if parameters else ""
        request = urllib.request.Request(
            f"{self.descriptor.base_url}/v1/events{query}",
            headers=headers,
            method="GET",
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
                current_id: str | None = None
                current_type = "message"
                data_lines: list[str] = []
                event_bytes = 0
                stream_bytes = 0
                while len(events) < count:
                    if time.monotonic() >= deadline:
                        raise event_stream_timeout(len(events), reconnect_cursor)
                    raw = response.readline(MAX_CONTROL_RESPONSE_BYTES + 1)
                    if not raw:
                        break
                    if time.monotonic() >= deadline:
                        raise event_stream_timeout(len(events), reconnect_cursor)
                    event_bytes += len(raw)
                    stream_bytes += len(raw)
                    if event_bytes > MAX_CONTROL_RESPONSE_BYTES:
                        raise CliFailure(
                            "EVENT_STREAM_ENVELOPE_TOO_LARGE",
                            "serialization",
                            "one OrangeCut event exceeds the bounded control-response limit",
                            remediation="do not use a partial snapshot; reduce the Project or update OrangeCut",
                            details=event_stream_progress_details(
                                None, len(events), reconnect_cursor
                            ),
                        )
                    if stream_bytes > MAX_CONTROL_RESPONSE_BYTES:
                        raise CliFailure(
                            "EVENT_STREAM_RESPONSE_TOO_LARGE",
                            "serialization",
                            "the accumulated OrangeCut event response exceeds the bounded client limit",
                            remediation="reconnect with the returned cursor and request fewer updates",
                            details=event_stream_progress_details(
                                None, len(events), reconnect_cursor
                            ),
                        )
                    try:
                        line = raw.decode("utf-8").rstrip("\r\n")
                    except UnicodeError as error:
                        raise CliFailure(
                            "EVENT_STREAM_INVALID",
                            "serialization",
                            "OrangeCut returned a non-UTF-8 event stream",
                            retryable=True,
                            details=event_stream_progress_details(
                                None, len(events), reconnect_cursor
                            ),
                        ) from error
                    if not line:
                        if data_lines:
                            try:
                                envelope = decode_response(
                                    "\n".join(data_lines).encode("utf-8")
                                )
                            except CliFailure as error:
                                raise add_event_stream_progress(
                                    error, len(events), reconnect_cursor
                                ) from error
                            if envelope.get("ok") is not True:
                                raise add_event_stream_progress(
                                    decode_server_failure(
                                        envelope.get("error"),
                                        invalid_code="EVENT_STREAM_INVALID",
                                        invalid_message="OrangeCut returned a malformed event-stream failure",
                                        invalid_retryable=True,
                                    ),
                                    len(events),
                                    reconnect_cursor,
                                )
                            events.append(
                                {
                                    "id": current_id,
                                    "event": current_type,
                                    "data": envelope.get("data"),
                                }
                            )
                            if current_id is not None:
                                reconnect_cursor = current_id
                        current_id = None
                        current_type = "message"
                        data_lines = []
                        event_bytes = 0
                        continue
                    if line.startswith(":"):
                        continue
                    field, _, value = line.partition(":")
                    value = value[1:] if value.startswith(" ") else value
                    if field == "id":
                        current_id = value
                    elif field == "event":
                        current_type = value
                    elif field == "data":
                        data_lines.append(value)
                if len(events) < count:
                    raise CliFailure(
                        "EVENT_STREAM_CLOSED",
                        "preconditions",
                        "the event stream closed before the requested update count arrived",
                        retryable=True,
                        remediation="reconnect with the returned cursor and start from the next canonical snapshot",
                        details=event_stream_progress_details(
                            None, len(events), reconnect_cursor
                        ),
                    )
                return {
                    "schemaVersion": SCHEMA_VERSION,
                    "ok": True,
                    "data": {
                        "events": events,
                        "reconnectCursor": reconnect_cursor,
                    },
                }
        except urllib.error.HTTPError as error:
            try:
                failure = decode_response(read_response_body(error))
            except CliFailure as response_error:
                if response_error.code == "HTTP_RESPONSE_TOO_LARGE":
                    raise response_error from error
                raise CliFailure(
                    "HTTP_RESPONSE_INVALID",
                    "serialization",
                    f"OrangeCut returned HTTP {error.code} without a valid error envelope",
                    retryable=error.code >= 500,
                ) from error
            raise decode_server_failure(
                failure.get("error"),
                invalid_code="HTTP_RESPONSE_INVALID",
                invalid_message=f"OrangeCut returned HTTP {error.code} without a valid error envelope",
                invalid_retryable=error.code >= 500,
            ) from error
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            raise event_stream_timeout(len(events), reconnect_cursor) from error


def app_data_root() -> Path:
    explicit = os.environ.get("ORANGECUT_DATA_ROOT")
    if explicit:
        return Path(explicit)
    if sys.platform == "win32":
        root = os.environ.get("LOCALAPPDATA")
        if root:
            return Path(root) / "dev.orangecut.desktop"
    elif sys.platform == "darwin":
        home = os.environ.get("HOME")
        if home:
            return Path(home) / "Library" / "Application Support" / "dev.orangecut.desktop"
    else:
        root = os.environ.get("XDG_DATA_HOME")
        if root:
            return Path(root) / "dev.orangecut.desktop"
        home = os.environ.get("HOME")
        if home:
            return Path(home) / ".local" / "share" / "dev.orangecut.desktop"
    raise CliFailure(
        "APP_DATA_ROOT_UNKNOWN",
        "preconditions",
        "the OrangeCut app-private data directory could not be resolved",
        remediation="set ORANGECUT_DATA_ROOT to the directory used by OrangeCut",
        exit_code=EXIT_SERVICE_UNAVAILABLE,
    )


PROJECT_ENV = "ORANGECUT_PROJECT"

# `--project <id>` 与 `--json` 一样在 argparse 之前剥掉(它能写在子命令后面),
# 落到这里;环境变量 ORANGECUT_PROJECT 是会话级的同一件事,参数优先。
_REQUESTED_PROJECT: str | None = None
# 这条命令最终打到了哪个工程,信封回显用。
_RESOLVED_PROJECT: str | None = None
# 服务是多工程的、且这条命令点了名(或隐式选中)时,工程外路由要带的 `?project=`。
# 老服务不认这个参数,所以单工程服务上它保持 None。
_NAMED_PROJECT: str | None = None


def resolve_look(client: "Client", look_id: str) -> dict[str, Any]:
    """Find one entry of the service's built-in look catalog by id."""
    catalog = require_object(client.request("GET", "/v1/looks"), "data")
    looks = catalog.get("looks")
    entries = [entry for entry in looks if isinstance(entry, dict)] if isinstance(looks, list) else []
    for entry in entries:
        if entry.get("id") == look_id:
            kind = entry.get("kind")
            if kind == "preset" and isinstance(entry.get("presetId"), str):
                return entry
            if kind == "lut" and isinstance(entry.get("assetId"), str):
                return entry
            break
    raise CliFailure(
        "GRADE_LOOK_UNKNOWN",
        "validation",
        f"no built-in look is called {look_id!r}",
        remediation="run `oc canvas looks --json` and pick an id from the list",
        exit_code=EXIT_INVALID_INPUT,
        details={"available": [entry.get("id") for entry in entries]},
    )


def resolve_lut_asset(
    client: "Client",
    project_id: str,
    project: dict[str, Any],
    lut: str,
    base_revision: int,
) -> tuple[str, int]:
    """Turn `--lut` into a Data asset id.

    An asset id of the open Project is used as is. Anything ending in `.cube`
    is a file: imported as a Data asset (which moves the revision, so the
    returned base revision is the post-import one), or reused when the same
    bytes are already in the Project — the service says so with the id.
    """
    assets = project.get("assets")
    if isinstance(assets, list):
        for asset in assets:
            if isinstance(asset, dict) and asset.get("id") == lut:
                if asset.get("kind") != "data":
                    raise CliFailure(
                        "GRADE_LUT_NOT_DATA",
                        "validation",
                        "--lut names an asset that is not a .cube Data asset",
                        remediation="pass the .cube file path, or the id of an imported .cube asset",
                        exit_code=EXIT_INVALID_INPUT,
                        details={"assetId": lut, "kind": asset.get("kind")},
                    )
                return lut, base_revision
    path = Path(lut)
    if path.suffix.lower() != ".cube":
        raise CliFailure(
            "GRADE_LUT_UNKNOWN",
            "validation",
            "--lut is neither a .cube file path nor an asset id of this Project",
            remediation="pass an absolute path to a 3D .cube LUT, or an imported asset id",
            exit_code=EXIT_INVALID_INPUT,
            details={"lut": lut},
        )
    if not path.is_absolute():
        raise CliFailure(
            "ASSET_PATH_NOT_ABSOLUTE",
            "validation",
            "the .cube path must be absolute",
            remediation="pass an absolute local file path",
            exit_code=EXIT_INVALID_INPUT,
        )
    payload: dict[str, Any] = {
        "baseRevision": base_revision,
        "paths": [str(path)],
        "expectedKind": "data",
        "intent": "导入 LUT",
        "idempotencyKey": f"canvas-grade-lut:{uuid.uuid4()}",
    }
    previous_timeout = client.timeout
    client.timeout = IMPORT_TIMEOUT_SECONDS
    try:
        imported = client.request(
            "POST", f"/v1/projects/{quote(project_id)}/assets/import", payload
        )
    except CliFailure as failure:
        existing = (failure.details or {}).get("assetId")
        if failure.code == "ASSET_ALREADY_IMPORTED" and isinstance(existing, str):
            return existing, base_revision
        raise
    finally:
        client.timeout = previous_timeout
    data = require_object(imported, "data")
    imported_assets = data.get("assets")
    if not isinstance(imported_assets, list) or not imported_assets:
        raise CliFailure(
            "HTTP_RESPONSE_INVALID",
            "connect",
            "the LUT import returned no asset",
        )
    asset_id = imported_assets[0].get("assetId") if isinstance(imported_assets[0], dict) else None
    if not isinstance(asset_id, str) or not asset_id:
        raise CliFailure(
            "HTTP_RESPONSE_INVALID",
            "connect",
            "the LUT import returned no asset id",
        )
    revision = data.get("revision")
    return asset_id, revision if isinstance(revision, int) else base_revision


def requested_project() -> str | None:
    if _REQUESTED_PROJECT:
        return _REQUESTED_PROJECT
    value = os.environ.get(PROJECT_ENV, "").strip()
    return value or None


def open_project_ids(status: dict[str, Any]) -> list[str] | None:
    """服务报的"打开着的工程"。老服务没有 `openProjects`,退回 `activeProjectId`;
    两者都没有就是 None——"不知道"与"零个"是两回事,老服务只会说前者。"""
    data = status.get("data") if isinstance(status, dict) else None
    if not isinstance(data, dict):
        return None
    listed = data.get("openProjects")
    if isinstance(listed, list):
        return [
            item["projectId"]
            for item in listed
            if isinstance(item, dict) and isinstance(item.get("projectId"), str)
        ]
    active = data.get("activeProjectId")
    if isinstance(active, str) and active:
        return [active]
    if data.get("projectOpen") is False:
        return []
    return None


def service_is_multi_project(status: dict[str, Any]) -> bool:
    data = status.get("data") if isinstance(status, dict) else None
    return isinstance(data, dict) and data.get("multiProject") is True


def resolve_project_id(status: dict[str, Any]) -> str:
    """ADR 0043 的四条规则:0 个打开 PROJECT_NOT_OPEN;1 个隐式选中;多个未点名
    PROJECT_AMBIGUOUS 并列出候选;点名的必须在打开集合里。绝不替用户猜。"""
    global _RESOLVED_PROJECT
    requested = requested_project()
    open_ids = open_project_ids(status)
    data = status.get("data") if isinstance(status, dict) else {}
    listed = data.get("openProjects") if isinstance(data, dict) else None
    candidates = [
        {"projectId": item.get("projectId"), "title": item.get("title")}
        for item in (listed if isinstance(listed, list) else [])
        if isinstance(item, dict)
    ]
    if requested is not None:
        if open_ids is None or requested in open_ids:
            _RESOLVED_PROJECT = requested
            return requested
        raise CliFailure(
            "PROJECT_NOT_OPEN",
            "preconditions",
            f"Project {requested} is not open in the OrangeCut service",
            remediation="open it with `oc project open <id>`, or name one of the open Projects",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
            details={"projectId": requested, "openProjectIds": open_ids or []},
        )
    if not open_ids:
        raise CliFailure(
            "PROJECT_NOT_OPEN",
            "preconditions",
            "no Project is open in the OrangeCut service",
            remediation="open or create a Project in OrangeCut and retry",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )
    if len(open_ids) > 1:
        raise CliFailure(
            "PROJECT_AMBIGUOUS",
            "preconditions",
            f"{len(open_ids)} Projects are open; name one",
            remediation=(
                f"pass --project <id> or set {PROJECT_ENV}=<id> "
                "(oc status --json lists openProjects)"
            ),
            exit_code=EXIT_SERVICE_UNAVAILABLE,
            details={"openProjects": candidates or [{"projectId": pid} for pid in open_ids]},
        )
    _RESOLVED_PROJECT = open_ids[0]
    return open_ids[0]


def project_query(project_id: str | None) -> str:
    """工程外入口(events/capabilities)点名工程的查询串。"""
    if not project_id:
        return ""
    return "?" + urllib.parse.urlencode({"project": project_id})


# 只有 `--no-autostart` 会把它翻过来。环境变量单独读,免得库调用方(没走
# argparse 的那些)拿不到开关。
_AUTOSTART_SUPPRESSED = False


def suppress_autostart() -> None:
    global _AUTOSTART_SUPPRESSED
    _AUTOSTART_SUPPRESSED = True


def autostart_allowed() -> bool:
    if _AUTOSTART_SUPPRESSED:
        return False
    return os.environ.get("ORANGECUT_NO_AUTOSTART", "").strip().lower() not in {
        "1",
        "true",
        "yes",
        "on",
    }


def executable_file(path: Path) -> Path | None:
    try:
        if path.is_file() and os.access(path, os.X_OK):
            return path
    except OSError:
        return None
    return None


def own_executable_paths() -> set[Path]:
    """本进程自己的可执行文件。

    `oc` 和服务常常装在同一个 PATH 目录下。真把 CLI 自己当成服务拉起来,
    就是一条自我 fork 的路——宁可当作没找到。
    """
    paths: set[Path] = set()
    for raw in (sys.argv[0] if sys.argv else "", sys.executable):
        if not raw:
            continue
        try:
            paths.add(Path(raw).resolve())
        except OSError:
            continue
    return paths


def service_binary_in(root: Path) -> Path | None:
    suffix = ".exe" if sys.platform == "win32" else ""
    for name in SERVICE_BINARY_NAMES:
        found = executable_file(root / f"{name}{suffix}")
        if found is not None:
            return found
    return None


def install_search_roots() -> list[Path]:
    """发行包会把服务放在哪。

    结构见 host-electron/package-app.js:macOS 落在
    `OrangeCut.app/Contents/Resources/bin/`,Windows/Linux 落在可执行文件旁边
    的 `resources/bin/`。那边的 `installTarget()` 打印的就是这里第一条路径,
    两边改动必须成对——它们分开过一次,代价是渲染机上一个手工摆的目录被删掉
    之后,再没有任何东西能把它重建出来。
    """
    roots: list[Path] = []
    home = os.environ.get("HOME") or os.environ.get("USERPROFILE")
    if sys.platform == "darwin":
        bundle = Path("OrangeCut.app") / "Contents" / "Resources" / "bin"
        roots.append(Path("/Applications") / bundle)
        if home:
            roots.append(Path(home) / "Applications" / bundle)
    elif sys.platform == "win32":
        for variable in ("LOCALAPPDATA", "PROGRAMFILES", "PROGRAMW6432"):
            base = os.environ.get(variable)
            if not base:
                continue
            roots.append(Path(base) / "Programs" / "OrangeCut" / "resources" / "bin")
            roots.append(Path(base) / "OrangeCut" / "resources" / "bin")
    else:
        roots.append(Path("/opt/OrangeCut/resources/bin"))
        roots.append(Path("/usr/lib/orangecut/bin"))
    return roots


def installed_service_binary() -> Path | None:
    for root in install_search_roots():
        found = service_binary_in(root)
        if found is not None:
            return found
    return None


def neighbouring_service_binary() -> Path | None:
    """跟 `oc` 装在一起的服务。

    发行包如果把 CLI 和服务一起发出去,`oc` 自己在哪就说明服务在哪。这条
    比任何写死的安装路径都准:用户把 App 拖到哪里都跟着走。
    """
    own = sys.argv[0] if sys.argv else ""
    if not own:
        return None
    try:
        current = Path(own).resolve().parent
    except OSError:
        return None
    for directory in (current, *list(current.parents)[:3]):
        for relative in (Path("."), Path("bin"), Path("Resources") / "bin"):
            found = service_binary_in(directory / relative)
            if found is not None:
                return found
    return None


def spotlight_service_binary() -> Path | None:
    """问系统:OrangeCut.app 到底装在哪。

    用户把 App 拖到桌面、Downloads 或者别的卷上都是常事,写死 /Applications
    就会漏。macOS 自己记着这件事,不必让用户去配环境变量。Spotlight 可能被
    关掉或索引不到,所以这是最后一档,查不动就当没有。
    """
    if sys.platform != "darwin":
        return None
    try:
        found = subprocess.run(
            [
                "/usr/bin/mdfind",
                "kMDItemCFBundleIdentifier == 'dev.orangecut.desktop'",
            ],
            capture_output=True,
            timeout=3.0,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    for line in found.stdout.decode("utf-8", "replace").splitlines():
        bundle = line.strip()
        if not bundle.endswith(".app"):
            continue
        candidate = service_binary_in(Path(bundle) / "Contents" / "Resources" / "bin")
        if candidate is not None:
            return candidate
    return None


def repository_service_binary() -> Path | None:
    """从工作目录往上找源码构建出来的服务。

    只认带标记文件的仓库根,免得在随便哪个目录下捡起一个同名的可执行文件。
    找到仓库就到此为止:仓库里没有构建产物,答案是"还没构建",继续往上翻只会
    翻出别的仓库。
    """
    marker = Path("apps") / "desktop" / "src-tauri" / "Cargo.toml"
    suffix = ".exe" if sys.platform == "win32" else ""
    try:
        current = Path.cwd().resolve()
    except OSError:
        return None
    for directory in (current, *current.parents):
        if not (directory / marker).is_file():
            continue
        # 构建产物不一定落在 target/:CARGO_TARGET_DIR 是 Rust 认的那个开关,
        # 实测有机器就靠它把产物挪去别处(避开占着 target 的另一份构建)。
        override = os.environ.get("CARGO_TARGET_DIR", "").strip()
        roots = [Path(override)] if override else []
        roots.append(directory / "target")
        for root in roots:
            for profile in ("release", "debug"):
                for name in SERVICE_BINARY_NAMES:
                    found = executable_file(root / profile / f"{name}{suffix}")
                    if found is not None:
                        return found
        return None
    return None


def service_binary() -> Path | None:
    explicit = os.environ.get(SERVICE_BINARY_ENV, "").strip()
    if explicit:
        # 显式配错了不该悄悄回落去猜:那样拉起来的会是另一个二进制,而调用方
        # 还以为自己指定的那个在跑。
        found = executable_file(Path(explicit))
        if found is None:
            raise CliFailure(
                "SERVICE_BINARY_INVALID",
                "preconditions",
                f"{SERVICE_BINARY_ENV} does not name an executable file",
                remediation=(
                    f"point {SERVICE_BINARY_ENV} at the OrangeCut service binary, or unset it"
                ),
                exit_code=EXIT_SERVICE_UNAVAILABLE,
                details={"path": explicit},
            )
        return found
    own = own_executable_paths()
    for name in SERVICE_BINARY_NAMES:
        candidate = shutil.which(name)
        if candidate is None:
            continue
        try:
            resolved = Path(candidate).resolve()
        except OSError:
            continue
        if resolved in own:
            continue
        found = executable_file(resolved)
        if found is not None:
            return found
    # 顺序即优先级:跟 oc 装在一起的 > 装在标准位置的 > 系统记着的那个
    # bundle > 源码构建产物。前三档覆盖装了发行包的用户,让他们永远不必知道
    # 有 ORANGECUT_SERVICE_BINARY 这么个东西;最后一档只对开着仓库的人生效。
    for source in (
        neighbouring_service_binary,
        installed_service_binary,
        spotlight_service_binary,
        repository_service_binary,
    ):
        found = source()
        if found is not None:
            return found
    return None


def autostart_lock_path(root: Path) -> Path:
    # 放在 runtime/ 下而不是注册表目录里:那个目录的内容有严格约定,
    # 多一个非 descriptor 文件只会给每个读它的人添一次例外。
    return root / "runtime" / "autostart.lock"


def acquire_autostart_lock(path: Path) -> int | None:
    """拿到返回文件描述符,没拿到返回 None——None 的含义是"别人正在拉"。"""
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    for attempt in range(2):
        try:
            return os.open(path, flags, 0o600)
        except FileExistsError:
            if attempt:
                return None
            try:
                age = time.time() - path.stat().st_mtime
            except OSError:
                return None
            if age < AUTOSTART_LOCK_STALE_SECONDS:
                return None
            # 持锁者自己死了,锁得回收。抢不到就当"别人正在拉"接着等——
            # 多等一轮远好过两个进程同时去拉同一个服务。
            try:
                path.unlink()
            except OSError:
                return None
        except OSError:
            return None
    return None


def spawn_service(binary: Path, root: Path, log: Path) -> "subprocess.Popen[bytes]":
    keywords: dict[str, Any] = {}
    if sys.platform == "win32":
        keywords["creationflags"] = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(
            subprocess, "CREATE_NO_WINDOW", 0
        )
    else:
        # 服务必须活得比这条 oc 命令长:自立会话组,免得对 oc 按 Ctrl-C
        # 顺手把刚拉起来的服务一起带走。
        keywords["start_new_session"] = True
    with open(log, "ab") as handle:
        return subprocess.Popen(
            [str(binary), "--data-root", str(root)],
            stdin=subprocess.DEVNULL,
            stdout=handle,
            stderr=handle,
            close_fds=True,
            **keywords,
        )


def log_tail_since(path: Path, offset: int) -> str:
    """只读这次拉起写进去的那一段。

    日志是追加的,读整个尾巴会把上一次的失败当成这一次的呈上去——错误信息
    里的假线索比没有线索更贵。
    """
    try:
        with open(path, "rb") as handle:
            handle.seek(0, os.SEEK_END)
            end = handle.tell()
            start = max(offset, end - AUTOSTART_LOG_TAIL_BYTES)
            if start >= end:
                return ""
            handle.seek(start)
            raw = handle.read(end - start)
    except OSError:
        return ""
    return raw.decode("utf-8", "replace").strip()


def responsive_services(
    registry: Path,
    timeout_seconds: float = DISCOVERY_TIMEOUT_SECONDS,
) -> list[tuple[Client, dict[str, Any]]]:
    descriptors: list[Descriptor] = []
    for path in descriptor_candidates(registry):
        try:
            descriptors.append(Descriptor.read(path))
        except CliFailure:
            continue
    if not descriptors:
        return []
    responsive: list[tuple[Client, dict[str, Any]]] = []
    with concurrent.futures.ThreadPoolExecutor(
        max_workers=min(MAX_DISCOVERY_WORKERS, len(descriptors))
    ) as executor:
        for candidate in executor.map(
            lambda descriptor: probe_descriptor(descriptor, timeout_seconds),
            descriptors,
        ):
            if candidate is not None:
                responsive.append(candidate)
    return responsive


def wait_for_responsive_service(
    registry: Path, process: "subprocess.Popen[bytes] | None"
) -> bool:
    deadline = time.monotonic() + AUTOSTART_READY_TIMEOUT_SECONDS
    while True:
        try:
            if responsive_services(registry):
                return True
        except CliFailure:
            return False
        # 进程已经退了就别再等满超时:它的退出码和日志现在就能说清原因。
        if process is not None and process.poll() is not None:
            return False
        if time.monotonic() >= deadline:
            return False
        time.sleep(AUTOSTART_POLL_INTERVAL_SECONDS)


# 见过的几个:服务带着这些码退出时,叫得出名字就能一眼分清"崩了"和"配置不对"。
# 光看 3221225477 谁也看不出那是访问违例。
WINDOWS_EXIT_STATUS_NAMES = {
    0xC0000005: "access violation",
    0xC0000374: "heap corruption",
    0xC0000409: "stack buffer overrun (a Rust abort looks like this)",
    0xC0000354: "no debugger attached to a process being debugged",
}


def describe_exit_code(code: int) -> str:
    """把退出码渲染成人看得懂的样子。

    Windows 的异常状态码以无符号大整数的形式回来,十进制形态毫无线索;十六进制
    才是所有崩溃资料里用的那个写法。
    """
    if sys.platform != "win32" or not 0 <= code <= 0xFFFFFFFF or code < 0x40000000:
        return str(code)
    status = f"0x{code:08X}"
    name = WINDOWS_EXIT_STATUS_NAMES.get(code)
    return f"{status} ({name})" if name else status


def autostart_failed(
    binary: Path,
    process: "subprocess.Popen[bytes]",
    log: Path,
    offset: int,
) -> CliFailure:
    details: dict[str, Any] = {"binary": str(binary), "log": str(log)}
    code = process.poll()
    if code is not None:
        details["exitCode"] = code
        described = describe_exit_code(code)
        if described != str(code):
            details["exitStatus"] = described
    # 服务把状态 JSON 打在 stdout 上,两条流又落在同一个文件里,所以这段内容
    # 并不都是 stderr。按它实际的样子叫——错标的字段名会让人往错的方向找。
    tail = log_tail_since(log, offset)
    if tail:
        details["logTail"] = tail
    return CliFailure(
        "SERVICE_AUTOSTART_FAILED",
        "preconditions",
        "the local OrangeCut service was started but never became ready",
        retryable=True,
        remediation=f"read {log} for why it did not come up, then start OrangeCut manually",
        exit_code=EXIT_SERVICE_UNAVAILABLE,
        details=details,
    )


def autostart_history_path(root: Path) -> Path:
    return root / "runtime" / "autostart-history.json"


def read_autostart_history(root: Path) -> list[dict[str, Any]]:
    try:
        raw = autostart_history_path(root).read_bytes()
    except OSError:
        return []
    try:
        entries = strict_json_loads(raw.decode("utf-8"))
    except (UnicodeError, ValueError, RecursionError):
        return []
    if not isinstance(entries, list):
        return []
    kept: list[dict[str, Any]] = []
    for entry in entries:
        if isinstance(entry, dict) and isinstance(entry.get("at"), (int, float)):
            kept.append(entry)
    return kept


def record_autostart(root: Path, *, unclean: bool) -> list[dict[str, Any]]:
    """把这一次拉起记进流水,返回窗口内的全部记录。

    写失败一律无视:这是给人看的线索,不该让一条本来能成的命令死在记账上。
    """
    now = time.time()
    entries = [
        entry
        for entry in read_autostart_history(root)
        # 时钟被调过的话未来时间戳会永远留在窗口里,一并丢掉。
        if 0 <= now - float(entry["at"]) <= AUTOSTART_HISTORY_WINDOW_SECONDS
    ]
    entries.append({"at": now, "afterUncleanExit": unclean})
    entries = entries[-AUTOSTART_HISTORY_MAX_ENTRIES:]
    try:
        autostart_history_path(root).write_text(
            json.dumps(entries, ensure_ascii=False), encoding="utf-8"
        )
    except OSError:
        pass
    return entries


def autostart_loop_warning(entries: list[dict[str, Any]]) -> dict[str, Any] | None:
    """反复救活同一个服务,就不再是便利,而是症状。

    自动拉起本来是为了让批处理不因为服务崩了就整批作废;但它同时也把崩溃
    变得无声了——每条命令都悄悄把服务接回来,表面一路绿灯。这里就是那个
    "我又救了它一次"的出口,免得真正的故障躲在便利后面没人去查。
    """
    if len(entries) < AUTOSTART_LOOP_THRESHOLD:
        return None
    stamps = sorted(float(entry["at"]) for entry in entries)
    unclean = sum(1 for entry in entries if entry.get("afterUncleanExit"))
    span = max(1, round(stamps[-1] - stamps[0]))
    warning: dict[str, Any] = {
        "code": "SERVICE_RESTART_LOOP",
        "message": (
            f"the local OrangeCut service needed starting {len(entries)} times in the "
            f"last {span // 60 or 1} minutes"
        ),
        "starts": len(entries),
        "spanSeconds": span,
        "afterUncleanExit": unclean,
    }
    if unclean:
        warning["message"] += (
            f"; {unclean} of them followed a service that exited without shutting down cleanly"
        )
    return warning


# 本次进程里检出的拉起循环。命令成功也要把它顶到信封上——不然它永远只在
# 失败路径上现身,而这个问题的症状恰恰是"一切看起来都成功"。
_AUTOSTART_WARNING: dict[str, Any] | None = None


def note_autostart_history(root: Path) -> None:
    """每次成功连上服务都从流水里重算一遍,不是只在刚拉起的那一次报。

    崩溃可能整天零星发生,而报出它的那条命令多半不是拉起它的那条。窗口过完
    自己就消停了。
    """
    global _AUTOSTART_WARNING
    _AUTOSTART_WARNING = autostart_loop_warning(
        [
            entry
            for entry in read_autostart_history(root)
            if 0 <= time.time() - float(entry["at"]) <= AUTOSTART_HISTORY_WINDOW_SECONDS
        ]
    )


def attach_autostart_warning(payload: dict[str, Any]) -> dict[str, Any]:
    if _AUTOSTART_WARNING is not None:
        payload.setdefault("warnings", []).append(_AUTOSTART_WARNING)
    return payload


def _load_glossary_terms(path: Path) -> list:
    """读词表 JSON:接受 {"terms": [...]} (video-dom 习惯) 或裸数组。"""
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID", "validation",
            f"cannot read glossary file: {error}",
        )
    terms = raw.get("terms") if isinstance(raw, dict) else raw
    if not isinstance(terms, list) or not terms:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID", "validation",
            'glossary must be {"terms": [{"canonical", "aliases"}]} or a bare array',
        )
    return terms


SCRIPT_MAX_BYTES = 2 * 1024 * 1024


def read_script_file(path: Path) -> str:
    """稿子文本:UTF-8(带不带 BOM 都行),不收空文件;编码不对时如实报错,不去猜 GBK。"""
    resolved = path.expanduser().resolve()
    try:
        raw = resolved.read_bytes()
    except OSError as error:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", f"cannot read script file: {error}", exit_code=EXIT_INVALID_INPUT)
    if len(raw) > SCRIPT_MAX_BYTES:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "script file is larger than 2 MB; that is not a narration script", exit_code=EXIT_INVALID_INPUT)
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID", "validation", "script file is not UTF-8",
            remediation="save the script as UTF-8 and retry", exit_code=EXIT_INVALID_INPUT,
        )
    if not text.strip():
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "script file is empty", exit_code=EXIT_INVALID_INPUT)
    return text


def plugin_invoke(name: str, request: dict, timeout: int):
    """语义化插件命令的共同通道:POST /v1/plugins/<name>/run。

    服务端负责解析插件、spawn entry、错误面(未安装即 PLUGIN_NOT_INSTALLED
    并附 `oc plugin add` 指引);CLI 只做参数到请求的翻译。"""
    client, _ = discover_client(require_project=False, allow_multiple_idle=True)
    return client.request(
        "POST",
        f"/v1/plugins/{name}/run",
        {"request": request, "timeoutSeconds": timeout},
        timeout_seconds=timeout + 60,
    )


def plugin_name(value: str) -> str:
    """插件名进 URL 路径,白名单校验挡住路径注入,也顺手挡住手误。"""
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,63}", value):
        raise argparse.ArgumentTypeError(
            f"{value!r} is not a plugin name (lowercase letters, digits and dashes)"
        )
    return value


def envelope(payload: dict[str, Any]) -> dict[str, Any]:
    """把任何处理器的结果套进统一信封。

    多数命令直接把服务端的应答原样交出去,而它本来就是信封;自己拼结果的那些
    (`timeline place` 是其中之一)交出的却是裸字典。失败永远是信封,于是
    "按信封解析"的调用方会把成功判成失败,重跑一次就多出一条重复轨道——
    真踩过两次。一个通道只该有一种形状,这里补齐。
    """
    if payload.get("schemaVersion") is not None and "ok" in payload:
        return payload
    # 有些处理器已经自己套了半个信封(只有 `data`),再包一层就成了
    # `data.data`。认这一半,补上缺的那一半。
    if "data" in payload:
        return {"schemaVersion": SCHEMA_VERSION, "ok": True, **payload}
    wrapped: dict[str, Any] = {"schemaVersion": SCHEMA_VERSION, "ok": True}
    warnings = payload.pop("warnings", None)
    wrapped["data"] = payload
    if warnings:
        wrapped["warnings"] = warnings
    return wrapped


def crash_loop_entries(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """历史尾部那一串"接的都是没干净退出的服务"的记录。

    只看**连续**的那一段:中间但凡有一次是干净启动,前面的就是旧账,不该
    算进这一轮。
    """
    now = time.time()
    streak: list[dict[str, Any]] = []
    for entry in reversed(entries):
        at = float(entry.get("at", 0))
        if not entry.get("afterUncleanExit"):
            break
        if now - at > AUTOSTART_CRASH_LOOP_WINDOW_SECONDS:
            break
        streak.append(entry)
    return list(reversed(streak))


def refuse_autostart_in_a_crash_loop(root: Path) -> None:
    """崩溃循环里不再自动救,直接把故障顶到调用方面前。

    自动拉起是为了让批处理别因为服务崩一次就整批作废,但它同时把崩溃变得
    无声:每条命令都悄悄接回来,一路绿灯,导出却一帧都没渲。救到第五次还是
    接一个没能干净退出的服务,就该承认这不是偶发,继续拉只是消耗时间。

    留一个出口:`ORANGECUT_AUTOSTART_FORCE=1` 照旧拉起——判断是我们做的,
    但最终决定权在使用者手上。
    """
    if os.environ.get("ORANGECUT_AUTOSTART_FORCE") == "1":
        return
    streak = crash_loop_entries(read_autostart_history(root))
    if len(streak) < AUTOSTART_CRASH_LOOP_THRESHOLD:
        return
    span = max(1, round(time.time() - float(streak[0]["at"])))
    raise CliFailure(
        "SERVICE_CRASH_LOOP",
        "preconditions",
        (
            f"the local OrangeCut service crashed and was restarted {len(streak)} times in "
            f"the last {span // 60 or 1} minutes; it is not being started again"
        ),
        remediation=(
            "查 runtime/autostart.log 里最后一段服务输出找崩溃原因;确认没有卡住的实例后,"
            "用 ORANGECUT_AUTOSTART_FORCE=1 再试一次"
        ),
        exit_code=EXIT_SERVICE_UNAVAILABLE,
        details={
            "starts": len(streak),
            "spanSeconds": span,
            "logPath": str(root / "runtime" / "autostart.log"),
            "historyPath": str(autostart_history_path(root)),
        },
    )


def note_service_death_in_log(log: Path) -> None:
    """在服务日志里标出"上一个服务是死掉的,这里是接班点"。

    这个文件本来只记拉起结果,崩溃现场混在服务自己的输出里、没有任何分界,
    事后翻它看不出哪一行属于哪一条命,更看不出中间死过。回收掉陈旧注册文件
    与僵住进程时留一行,崩溃才有据可查。写失败一律无视——这是线索不是主线。
    """
    if not _REAPED_STALE_DESCRIPTORS and not _TERMINATED_STUCK_SERVICES:
        return
    stamp = time.strftime("%Y-%m-%dT%H:%M:%S")
    note = (
        f"==== oc autostart {stamp}: reaped {len(_REAPED_STALE_DESCRIPTORS)} stale "
        f"descriptor(s) {','.join(_REAPED_STALE_DESCRIPTORS) or '-'}; terminated stuck "
        f"pid(s) {','.join(str(pid) for pid in _TERMINATED_STUCK_SERVICES) or '-'}; "
        f"the service above did not shut down cleanly ====\n"
    )
    try:
        with open(log, "ab") as handle:
            handle.write(note.encode("utf-8"))
    except OSError:
        pass


def autostart_service(registry: Path) -> bool:
    """一个活服务都没有时,自己把 headless 服务拉起来。

    服务端已经会在启动时恢复崩溃前打开的 Project,缺的一直是"被谁拉起来"
    这一步——没人补上,服务一崩,后面每条命令就全废,批处理得靠人肉重启。

    只有"零个活服务"才该走到这里:服务活着但没开 Project、或者活着好几个,
    都是另一码事,再拉一个只会让局面更乱。

    这个二进制没有窗口(见 apps/desktop/src-tauri/src/main.rs 的头注释),
    窗口在 Electron 宿主里,所以自动拉起不会弹出界面。
    """
    binary = service_binary()
    if binary is None:
        return False
    root = app_data_root()
    try:
        (root / "runtime").mkdir(parents=True, exist_ok=True)
    except OSError:
        return False
    refuse_autostart_in_a_crash_loop(root)
    history = read_autostart_history(root)
    if history and 0 <= time.time() - float(history[-1].get("at", 0)) < AUTOSTART_MIN_INTERVAL_SECONDS:
        # 刚有人拉起过:服务多半在冷启动或忙碌。等它就绪,不再叠加进程——
        # 实测的拉起循环就是几条命令在一分钟里各拉了一个。
        return wait_for_responsive_service(registry, None)
    lock = autostart_lock_path(root)
    handle = acquire_autostart_lock(lock)
    if handle is None:
        # 另一条 oc 正在拉同一个服务。服务端本来就拒绝第二个实例,所以这里
        # 跟着再拉一个只会白起一个立刻自杀的进程——等着就行。
        return wait_for_responsive_service(registry, None)
    log = root / "runtime" / "autostart.log"
    try:
        offset = log.stat().st_size
    except OSError:
        offset = 0
    try:
        try:
            os.write(handle, f"{os.getpid()}\n".encode("utf-8"))
        except OSError:
            pass
        try:
            process = spawn_service(binary, root, log)
        except OSError as error:
            raise CliFailure(
                "SERVICE_AUTOSTART_FAILED",
                "preconditions",
                f"the local OrangeCut service could not be started: {error}",
                remediation="start OrangeCut and retry",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
                details={"binary": str(binary)},
            ) from error
        if wait_for_responsive_service(registry, process):
            note_service_death_in_log(log)
            record_autostart(root, unclean=bool(_REAPED_STALE_DESCRIPTORS))
            return True
        raise autostart_failed(binary, process, log, offset)
    finally:
        # 锁按住整个等待过程,不是只按住 spawn:提前放开,下一条 oc 就会
        # 在服务还没就绪时再拉一个。
        os.close(handle)
        try:
            lock.unlink()
        except OSError:
            pass


SESSION_RECOVERY_WAIT_SECONDS = 180.0


def session_recovery_pending(status: dict[str, Any]) -> int:
    data = status.get("data") if isinstance(status, dict) else None
    value = data.get("recoveringProjects") if isinstance(data, dict) else None
    return value if isinstance(value, int) and value > 0 else 0


def await_session_recovery(
    registry: Path,
    responsive: list[tuple["Client", dict[str, Any]]],
    require_project: bool,
) -> list[tuple["Client", dict[str, Any]]]:
    """服务先应答、再在后台重开上次的工程(见 lib.rs 的会话恢复)。

    需要"有工程打开"的命令必须等这段跑完,否则刚拉起来的服务会被当成
    "没有打开的工程"而报错——那正是从前恢复挡在启动前面的原因。等待有
    上限,恢复卡住时照常按没打开处理,由后面的错误如实报出来。
    """
    if not require_project:
        return responsive
    if any(item[1].get("data", {}).get("projectOpen") is True for item in responsive):
        return responsive
    if not any(session_recovery_pending(item[1]) for item in responsive):
        return responsive
    deadline = time.monotonic() + SESSION_RECOVERY_WAIT_SECONDS
    while time.monotonic() < deadline:
        time.sleep(0.5)
        responsive = responsive_services(registry)
        if any(item[1].get("data", {}).get("projectOpen") is True for item in responsive):
            return responsive
        if not any(session_recovery_pending(item[1]) for item in responsive):
            return responsive
    return responsive


def discover_client(
    require_project: bool,
    *,
    allow_multiple_idle: bool = False,
    autostart: bool = True,
) -> tuple[Client, dict[str, Any]]:
    root = app_data_root()
    registry = root / "runtime" / "http-v1"
    responsive = responsive_services(registry)
    if not responsive and any(True for _ in descriptor_candidates(registry)):
        # 注册文件还在、快探却一个都没答上:多半是服务忙,不是死。拉起
        # 之前多给一次耐心探测——白拉的进程只会跟正主抢同一个数据根。
        responsive = responsive_services(
            registry, timeout_seconds=PATIENT_DISCOVERY_TIMEOUT_SECONDS
        )
    responsive = await_session_recovery(registry, responsive, require_project)
    active = [item for item in responsive if item[1].get("data", {}).get("projectOpen") is True]
    candidates = active if require_project or active else responsive
    if not candidates:
        if responsive and require_project:
            raise CliFailure(
                "PROJECT_NOT_OPEN",
                "preconditions",
                "no responsive OrangeCut service has an open Project",
                remediation="open or create a Project in OrangeCut and retry",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
            )
        # 走到这里必然是零个活服务(有活的但没开 Project 已经在上面分流走了),
        # 也就是唯一该自动拉起的那一种。autostart=False 是递归的止点。
        if (
            autostart
            and not responsive
            and autostart_allowed()
            and autostart_service(registry)
        ):
            return discover_client(
                require_project,
                allow_multiple_idle=allow_multiple_idle,
                autostart=False,
            )
        raise CliFailure(
            "ORANGECUT_SERVICE_UNAVAILABLE",
            "preconditions",
            "no responsive local OrangeCut service was found",
            retryable=True,
            # 走到这里说明连服务二进制都没找到——OrangeCut 多半就没装。对用户
            # 该说的是"打开 OrangeCut",不是让他去配环境变量;那个旋钮留给
            # 开着源码仓库的人,写在 details 里给会看的人看就够了。
            remediation="start OrangeCut and retry",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
            details={
                "searchedForService": [str(path) for path in install_search_roots()],
                # 逃生口写在 details 里,不写进 remediation。在还没有本平台
                # 发行包的机器上(渲染机就是这样)这是唯一的出路,而实测有人
                # 因为报错只列了六个不存在的安装路径,去读源码才发现它——
                # 只列搜过哪里,读的人会以为唯一出路是装一个并不存在的安装包。
                "serviceBinaryOverride": SERVICE_BINARY_ENV,
            },
        )
    if len(candidates) != 1 and allow_multiple_idle and not active:
        candidates = [min(candidates, key=lambda item: item[0].descriptor.instance_id)]
    if len(candidates) != 1:
        raise CliFailure(
            "LIVE_SESSION_AMBIGUOUS",
            "preconditions",
            f"{len(candidates)} OrangeCut services match the request",
            retryable=True,
            remediation="keep only the target OrangeCut Project open, then retry",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )
    client, response = candidates[0]
    client.timeout = DEFAULT_TIMEOUT_SECONDS
    note_autostart_history(root)
    return client, response


def descriptor_candidates(registry: Path) -> list[Path]:
    try:
        metadata = registry.lstat()
    except FileNotFoundError:
        return []
    except OSError as error:
        raise descriptor_registry_invalid() from error
    if not stat.S_ISDIR(metadata.st_mode):
        raise descriptor_registry_invalid()
    candidates: list[Path] = []
    try:
        with os.scandir(registry) as entries:
            for entry in entries:
                if not entry.name.startswith("instance-") or not entry.name.endswith(".json"):
                    continue
                candidates.append(Path(entry.path))
                if len(candidates) > MAX_DISCOVERY_DESCRIPTORS:
                    raise CliFailure(
                        "HTTP_DESCRIPTOR_REGISTRY_LIMIT_REACHED",
                        "preconditions",
                        "the local OrangeCut service registry contains too many descriptor candidates",
                        retryable=True,
                        remediation="restart OrangeCut or repair its stale local service registry",
                        exit_code=EXIT_SERVICE_UNAVAILABLE,
                        details={"maximumCandidates": MAX_DISCOVERY_DESCRIPTORS},
                    )
    except CliFailure:
        raise
    except OSError as error:
        raise descriptor_registry_invalid() from error
    return sorted(candidates)


def descriptor_registry_invalid() -> CliFailure:
    return CliFailure(
        "HTTP_DESCRIPTOR_REGISTRY_INVALID",
        "preconditions",
        "the local OrangeCut service registry is not a readable private directory",
        retryable=True,
        remediation="restart the official OrangeCut application and retry",
        exit_code=EXIT_SERVICE_UNAVAILABLE,
    )


def descriptor_port_dead(descriptor: Descriptor) -> bool:
    """注册文件通告的端口是否确定已经没人监听。

    判据与服务端的 sweep 保持一致——看端口是否接受连接,而不是看 PID
    (操作系统会回收 PID)。服务写下注册文件时监听已经建立,所以正在启动的
    实例不会被误判。任何查不动的情况都当作"还活着":误删活服务的注册文件
    会让它彻底失联,代价远大于多留一个死文件。
    """
    parsed = urllib.parse.urlsplit(descriptor.base_url)
    try:
        port = parsed.port
    except ValueError:
        return False
    if port is None:
        return False
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.4):
            return False
    except (ConnectionRefusedError, socket.timeout, TimeoutError):
        return True
    except OSError:
        return False


# 本次进程里回收掉的陈旧注册文件。干净退出的服务会自己删掉注册文件
# (http_service.rs 的 sweep_dead_descriptors 注释写着这条),所以"文件还在、
# 端口已死"就是上一个服务没能好好退出的凭证——比单纯数拉起次数准。
_REAPED_STALE_DESCRIPTORS: list[str] = []

# 本次进程里收掉的僵住实例的 PID。
_TERMINATED_STUCK_SERVICES: list[int] = []


def port_refused(descriptor: Descriptor) -> bool:
    """连接被**明确拒绝**——也就是说,那个端口上确实没有人在监听。

    与 `descriptor_port_dead` 的区别就是超时算不算数,而这个区别很贵:
    `descriptor_port_dead` 的后果只是删一个注册文件,超时当死是划算的;这条
    判据后面跟着的是**杀进程**,超时当死就可能打死一个正忙的健康服务——一次
    662 帧的导出会同时压着十个截帧进程,0.4 秒握不上手再正常不过。

    拒绝是操作系统给的确定答复(没有监听套接字),超时不是答复。所以这里只认
    拒绝,而且要连着几次都拒绝:端口刚好在重启的缝隙里也会拒一次。
    """
    parsed = urllib.parse.urlsplit(descriptor.base_url)
    try:
        port = parsed.port
    except ValueError:
        return False
    if port is None:
        return False
    for attempt in range(STUCK_SERVICE_CONFIRMATIONS):
        if attempt:
            time.sleep(STUCK_SERVICE_RECHECK_SECONDS)
        try:
            with socket.create_connection(
                ("127.0.0.1", port), timeout=STUCK_SERVICE_CONNECT_TIMEOUT_SECONDS
            ):
                return False
        except ConnectionRefusedError:
            continue
        except OSError:
            # 超时、被防火墙吞掉、查不动——都不是"没人监听"的证据。
            return False
    return True


def process_is_this_service(process_id: int) -> bool:
    """这个 PID 现在还是个 OrangeCut 服务吗?

    PID 会被系统回收,而注册文件里的那个可能是几小时前写下的——照着它开枪,
    打中的完全可能是别人的进程。所以先按映像名自证身份,认不出来就不动手。
    """
    if process_id <= 0 or process_id == os.getpid():
        return False
    try:
        if sys.platform == "win32":
            output = subprocess.run(
                ["tasklist", "/FI", f"PID eq {process_id}", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                timeout=STUCK_SERVICE_PROBE_TIMEOUT_SECONDS,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            ).stdout
        else:
            output = subprocess.run(
                ["ps", "-p", str(process_id), "-o", "comm="],
                capture_output=True,
                text=True,
                timeout=STUCK_SERVICE_PROBE_TIMEOUT_SECONDS,
            ).stdout
    except (OSError, subprocess.SubprocessError):
        return False
    return "orangecut" in output.lower()


def terminate_stuck_service(descriptor: Descriptor) -> bool:
    """端口已死、进程还在——把这个僵住的实例收掉。

    真实故障里见过六个这样的进程堆在同一个数据根上:CPU 全是 0,起来之后
    卡住而不是退出,并且和后来每一个新服务抢同一份数据。新起的那个也活不了,
    于是每条命令都在"自动拉起 → 抢不过 → 再拉一个"里空转。清掉是让下一次
    拉起有意义的前提。

    两道门都要过:端口连着几次被**明确拒绝**(`port_refused`——超时不算,忙到
    接不下连接的健康服务也会超时),以及那个 PID 现在确实还是个 OrangeCut 服务
    (`process_is_this_service`——PID 会被系统回收)。失败一律无视。
    """
    if not port_refused(descriptor) or not process_is_this_service(descriptor.process_id):
        return False
    try:
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/PID", str(descriptor.process_id), "/F", "/T"],
                capture_output=True,
                timeout=STUCK_SERVICE_PROBE_TIMEOUT_SECONDS,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        else:
            os.kill(descriptor.process_id, signal.SIGKILL)
    except (OSError, subprocess.SubprocessError):
        return False
    _TERMINATED_STUCK_SERVICES.append(descriptor.process_id)
    return True


def reap_stale_descriptor(descriptor: Descriptor) -> None:
    """回收死服务留下的注册文件,连同僵在那里的进程。

    服务端只在自己启动时扫一遍,所以服务不在跑的这段时间里没有任何人清理;
    而每个残留文件都要在后续每一次发现里被并发探活一次。失败一律无视
    ——这是顺手清理,不是主线任务。
    """
    path = descriptor.source_path
    if path is None or not descriptor_port_dead(descriptor):
        return
    terminate_stuck_service(descriptor)
    try:
        path.unlink()
    except OSError:
        return
    _REAPED_STALE_DESCRIPTORS.append(descriptor.instance_id)


def probe_descriptor(
    descriptor: Descriptor,
    timeout_seconds: float = DISCOVERY_TIMEOUT_SECONDS,
) -> tuple[Client, dict[str, Any]] | None:
    client = Client(descriptor, timeout_seconds)
    try:
        response = client.request(
            "GET",
            "/v1/status",
            response_limit=MAX_DISCOVERY_RESPONSE_BYTES,
        )
    except CliFailure:
        reap_stale_descriptor(descriptor)
        return None
    data = response.get("data")
    if isinstance(data, dict) and data.get("serviceReady") is True:
        return client, response
    return None


def add_text_style_arguments(command: argparse.ArgumentParser, *, patch: bool) -> None:
    default = argparse.SUPPRESS if patch else None
    command.add_argument("--font-asset-id", required=not patch, default=default)
    # 尺寸类不给 CLI 默认值:省略即由服务端按画布短边比例计算,
    # 这样同一条命令在 720p / 1080 / 4K 竖屏上都给出等比例的字幕。
    command.add_argument("--font-size", type=positive_integer, default=default)
    command.add_argument("--color", type=text_color, default=default if patch else "#FFFFFFFF")
    command.add_argument(
        "--font-weight",
        choices=("normal", "bold"),
        default=default if patch else "bold",
    )
    command.add_argument(
        "--font-style",
        choices=("normal", "italic"),
        default=default if patch else "normal",
    )
    command.add_argument(
        "--underline",
        action=argparse.BooleanOptionalAction,
        default=default if patch else False,
    )
    command.add_argument(
        "--align",
        choices=("left", "center", "right"),
        default=default if patch else "center",
    )
    command.add_argument(
        "--position",
        choices=("top", "center", "bottom"),
        default=default if patch else "bottom",
    )
    command.add_argument("--x", type=int, default=default if patch else 0)
    command.add_argument("--y", type=int, default=default if patch else 0)
    command.add_argument(
        "--scale-percent", type=positive_integer, default=default if patch else 100
    )
    command.add_argument("--rotation", type=int, default=default if patch else 0)
    command.add_argument(
        "--outline-color",
        type=text_color,
        default=default if patch else "#000000FF",
    )
    command.add_argument(
        "--outline-width",
        type=non_negative_integer,
        default=default,
    )
    command.add_argument(
        "--background-color",
        type=text_color,
        default=default if patch else "#00000000",
    )
    command.add_argument(
        "--background-padding",
        type=non_negative_integer,
        default=default if patch else 0,
    )
    command.add_argument(
        "--background-radius",
        type=non_negative_integer,
        default=default if patch else 0,
    )
    command.add_argument(
        "--shadow-color",
        type=text_color,
        default=default if patch else "#000000CC",
    )
    command.add_argument("--shadow-x", type=int, default=default if patch else 0)
    command.add_argument("--shadow-y", type=int, default=default)
    command.add_argument(
        "--shadow-blur",
        type=non_negative_integer,
        default=default,
    )
    # 逐字高亮默认关:它只有在字幕带着可信的字级时间时才好看,
    # 而且是题材选择(口播/干货合适,画面主导的片子是干扰),不该由系统替用户默认选。
    command.add_argument(
        "--highlight",
        choices=("none", "word"),
        default=default if patch else "none",
        help="逐字高亮模式;word 需要字幕带字级时间(见 import-srt --words)",
    )
    command.add_argument(
        "--highlight-color",
        type=text_color,
        default=default if patch else "#FFD400FF",
    )


def add_text_sticker_arguments(
    command: argparse.ArgumentParser, *, include_font: bool
) -> None:
    default = argparse.SUPPRESS
    # add 时也不必填。preset 是一套完整的"看相",而字体是其中最强的一笔——
    # 服务端按「调用方指名 > preset 自带 > 工程默认」解析。这里从前写死
    # required,于是从 CLI 走的每一个 preset 都被迫用同一款字,preset 自带的
    # 那款永远轮不到,二十八个 preset 在画面上就只是同一个东西的二十八种配色。
    command.add_argument(
        "--font-asset-id",
        default=default,
        help=(
            "字体 asset id;省略则由 --preset 自带的字体决定"
            if include_font
            else argparse.SUPPRESS
        ),
    )
    command.add_argument(
        "--preset",
        # Deliberately unconstrained here: the preset set lives in the service's
        # catalog, and a copy in this file is exactly how the CLI ended up
        # offering six of twenty-six. An unknown id is refused by the service
        # with the full list, and `oc sticker presets` prints it.
        metavar="PRESET",
        default=default,
    )
    command.add_argument("--font-size", type=positive_integer, default=default)
    command.add_argument("--letter-spacing", type=int, default=default, help="字距，画布像素 -64..256")
    command.add_argument("--line-height-percent", type=non_negative_integer, default=default, help="行高占字号百分比 80..250；0 恢复自动")
    command.add_argument("--color", type=text_color, default=default)
    command.add_argument(
        "--font-weight", choices=("normal", "bold"), default=default
    )
    command.add_argument(
        "--font-style", choices=("normal", "italic"), default=default
    )
    command.add_argument(
        "--align", choices=("left", "center", "right"), default=default
    )
    command.add_argument("--outline-color", type=text_color, default=default)
    command.add_argument(
        "--outline-width", type=non_negative_integer, default=default
    )
    command.add_argument("--background-color", type=text_color, default=default)
    command.add_argument(
        "--background-padding", type=non_negative_integer, default=default
    )
    command.add_argument(
        "--background-radius", type=non_negative_integer, default=default
    )
    command.add_argument("--shadow-color", type=text_color, default=default)
    command.add_argument("--shadow-x", type=int, default=default)
    command.add_argument("--shadow-y", type=int, default=default)
    command.add_argument(
        "--shadow-blur", type=non_negative_integer, default=default
    )
    command.add_argument(
        "--enter",
        choices=TEXT_STICKER_ANIMATIONS,
        default=default,
    )
    command.add_argument(
        "--enter-frames", type=non_negative_integer, default=default
    )
    command.add_argument(
        "--exit",
        choices=TEXT_STICKER_ANIMATIONS,
        default=default,
    )
    command.add_argument(
        "--exit-frames", type=non_negative_integer, default=default
    )
    command.add_argument("--x", type=int, default=default)
    command.add_argument("--y", type=int, default=default)
    command.add_argument(
        "--scale-percent", type=positive_integer, default=default
    )
    command.add_argument("--rotation", type=int, default=default)
    command.add_argument(
        "--opacity-percent", type=non_negative_integer, default=default
    )


def add_shape_arguments(command: argparse.ArgumentParser, *, include_kind: bool) -> None:
    default = argparse.SUPPRESS
    if not include_kind:
        command.add_argument(
            "--kind",
            choices=("rectangle", "square", "ellipse", "circle", "triangle"),
            default=default,
        )
    command.add_argument("--width", type=positive_integer, default=default)
    command.add_argument("--height", type=positive_integer, default=default)
    command.add_argument("--fill-color", type=text_color, default=default)
    command.add_argument("--stroke-color", type=text_color, default=default)
    command.add_argument(
        "--stroke-width", type=non_negative_integer, default=default
    )
    command.add_argument("--shadow-color", type=text_color, default=default)
    command.add_argument("--shadow-x", type=int, default=default)
    command.add_argument("--shadow-y", type=int, default=default)
    command.add_argument(
        "--shadow-blur", type=non_negative_integer, default=default
    )
    command.add_argument("--x", type=int, default=default)
    command.add_argument("--y", type=int, default=default)
    command.add_argument(
        "--scale-percent", type=positive_integer, default=default
    )
    command.add_argument("--rotation", type=int, default=default)
    command.add_argument(
        "--opacity-percent", type=non_negative_integer, default=default
    )


def add_keyframe_target_arguments(command: argparse.ArgumentParser) -> None:
    command.add_argument("target_id")
    command.add_argument(
        "--target-type", choices=("clip", "caption"), default="clip"
    )
    command.add_argument("--sequence-id")
    command.add_argument(
        "--track-id",
        help="required for a Caption target; omitted for a Clip target",
    )


def parser() -> argparse.ArgumentParser:
    root = StructuredArgumentParser(
        prog="oc", description="Control the local OrangeCut service"
    )
    root.add_argument("--version", action="version", version="oc 0.1.0")
    root.add_argument(
        "--no-autostart",
        action="store_true",
        help="fail instead of starting a local OrangeCut service when none is running",
    )
    # 只为出现在 --help 里:真正的解析在 normalize_arguments,它允许写在子命令后面。
    root.add_argument(
        "--project",
        metavar="PROJECT_ID",
        help=(
            "address this open Project when several are open "
            f"(also {PROJECT_ENV}); with exactly one open it is implied"
        ),
    )
    commands = root.add_subparsers(dest="command", required=True)
    commands.add_parser("status")
    license_group = commands.add_parser("license", help="Read the native desktop license tier")
    license_commands = license_group.add_subparsers(dest="license_command", required=True)
    license_commands.add_parser("status", help="Read tier and allowed capabilities; no activation or refresh")
    capability = commands.add_parser("capabilities")
    capability.add_argument("--command", dest="operation", help="read one semantic operation's exact schema")
    tts_group = commands.add_parser(
        "tts",
        help="[plugin: tts] Voice-cloning speech synthesis (IndexTTS-2.5)",
    )
    tts_commands = tts_group.add_subparsers(dest="tts_command", required=True)
    tts_say = tts_commands.add_parser(
        "say",
        help="Synthesize speech in the voice of a reference audio sample",
    )
    tts_say.add_argument("text")
    tts_say.add_argument("--ref", type=Path, required=True, help="reference voice sample (wav/mp3, ~5-15s)")
    tts_say.add_argument("--output", type=Path, required=True)
    tts_say.add_argument("--lang", default="zh")
    tts_say.add_argument(
        "--duration-factor", type=non_negative_float, default=None,
        help="0.5-2.0 speaking-speed control",
    )
    plugin = commands.add_parser(
        "plugin",
        help="Optional heavy AI capabilities (OCP): list, install, remove",
    )
    plugin_commands = plugin.add_subparsers(dest="plugin_command", required=True)
    plugin_ls = plugin_commands.add_parser(
        "ls",
        help="List every plugin the registry offers: install state, platform "
        "fit, disk cost; pass a name for just that plugin's row",
    )
    plugin_ls.add_argument("name", nargs="?", type=plugin_name, default=None)
    plugin_add = plugin_commands.add_parser(
        "add",
        help="Install a plugin onto this machine. Idempotent: reruns resume an "
        "interrupted download, repair a broken install, and apply upgrades. "
        "Model runtimes are multi-GB downloads",
    )
    plugin_add.add_argument("name", type=plugin_name)
    plugin_add.add_argument(
        "--force",
        action="store_true",
        help="install even when the platform preflight objects",
    )
    plugin_rm = plugin_commands.add_parser(
        "rm",
        help="Delete a plugin's on-disk runtime. A dev override environment "
        "(ORANGECUT_PLUGIN_<NAME>) is the caller's and is never touched",
    )
    plugin_rm.add_argument("name", type=plugin_name)
    plugin_run_cmd = plugin_commands.add_parser(
        "run",
        help="Escape hatch: invoke any plugin's entry with a raw JSON request "
        "(the semantic commands are sugar over this)",
    )
    plugin_run_cmd.add_argument("name", type=plugin_name)
    plugin_run_cmd.add_argument(
        "--request", type=Path, required=True,
        help="path to a UTF-8 JSON file with the entry request",
    )
    plugin_run_cmd.add_argument("--timeout", type=positive_integer, default=1800)
    plugin_cache = plugin_commands.add_parser(
        "cache",
        help="Show what deterministic plugin calls this machine has already "
        "answered, and how much disk that costs; --clear throws it away",
    )
    plugin_cache.add_argument(
        "name",
        nargs="?",
        type=plugin_name,
        default=None,
        help="limit --clear to one plugin",
    )
    plugin_cache.add_argument(
        "--clear",
        action="store_true",
        help="discard stored answers, so the next call runs for real",
    )
    plugin_config = plugin_commands.add_parser(
        "config",
        help="Configure a cloud plugin's secrets on this machine: stored per "
        "machine, kept across upgrades and rm, values never echo back",
    )
    plugin_config.add_argument("name", type=plugin_name)
    plugin_config.add_argument(
        "--set", dest="set_pairs", action="append", default=[], metavar="KEY=VALUE",
        help="set one secret (repeatable)",
    )
    plugin_config.add_argument(
        "--unset", dest="unset_keys", action="append", default=[], metavar="KEY",
        help="remove one secret (repeatable)",
    )
    glossary = commands.add_parser(
        "glossary",
        help="Machine-level transcription glossary: proper nouns (+ known "
        "mis-hearings) applied to every `media transcribe` and to the GUI's "
        "one-click captions; shared with the desktop settings panel",
    )
    glossary_commands = glossary.add_subparsers(dest="glossary_command", required=True)
    glossary_commands.add_parser("list", help="Show the current terms")
    glossary_add = glossary_commands.add_parser(
        "add",
        help="Add (or extend) one term: the canonical spelling first, then any "
        "aliases the ASR tends to produce; single characters are rejected",
    )
    glossary_add.add_argument("canonical")
    glossary_add.add_argument("aliases", nargs="*")
    glossary_rm = glossary_commands.add_parser("rm", help="Remove one term by its canonical spelling")
    glossary_rm.add_argument("canonical")
    glossary_set = glossary_commands.add_parser(
        "set",
        help="Replace the whole glossary from a JSON file "
        "({\"terms\": [{\"canonical\", \"aliases\"}]} or a bare array); "
        "--clear empties it",
    )
    glossary_set.add_argument("--file", type=Path, default=None)
    glossary_set.add_argument("--clear", action="store_true")
    docs = commands.add_parser("docs")
    docs.add_argument(
        "--url",
        action="store_true",
        help="print the read-only Swagger URL instead of opening an authenticated session",
    )

    project = commands.add_parser("project")
    project_commands = project.add_subparsers(dest="project_command", required=True)
    project_commands.add_parser("current")
    project_commands.add_parser("list")
    create = project_commands.add_parser("create")
    create.add_argument(
        "--from-source",
        type=Path,
        help="build the whole project from a project-source file instead of an "
        "empty timeline; the .opaque.json sidecar next to it is read too",
    )
    create.add_argument(
        "--media-root",
        type=Path,
        help="with --from-source: directory holding the asset files, when they "
        "no longer sit where the source file recorded them",
    )
    create.add_argument("--title", default="Untitled project")
    create.add_argument(
        "--width",
        type=canvas_dimension,
        help="explicit canvas width; omitting every canvas option creates the "
        "project in auto mode, where the canvas follows the first visual clip "
        "placed on the timeline",
    )
    create.add_argument("--height", type=canvas_dimension)
    create.add_argument(
        "--aspect-ratio",
        choices=("9:16", "16:9", "1:1"),
        help="legacy shortcut; use --width and --height for a concrete or custom canvas",
    )
    create.add_argument(
        "--fps",
        type=positive_integer,
        help="explicit frame rate; omitted defaults to 30 and, in auto mode, "
        "follows the first clip's constant frame rate",
    )
    create.add_argument(
        "--match",
        type=Path,
        metavar="VIDEO",
        help="Take canvas and frame rate from a source video so an overlay burns "
        "in without resampling it; overrides --width/--height/--aspect-ratio/--fps",
    )
    create.add_argument("--idempotency-key")
    open_project = project_commands.add_parser("open")
    open_project.add_argument("project_id")
    trash = project_commands.add_parser(
        "trash",
        help="Move a closed project to the operating system Trash (recoverable)",
    )
    trash.add_argument("project_id")
    rename = project_commands.add_parser("rename", help="Retitle a project")
    rename.add_argument("project_id")
    rename.add_argument("--title", required=True)
    duplicate = project_commands.add_parser(
        "duplicate", help="Copy a closed project under a new title"
    )
    duplicate.add_argument("project_id")
    duplicate.add_argument("--title", required=True)
    fork = project_commands.add_parser("fork", help="Copy a fixed revision without closing the source Project")
    fork.add_argument("project_id")
    fork.add_argument("--title", required=True)
    fork.add_argument("--revision", type=non_negative_integer, required=True)
    fork.add_argument("--idempotency-key", required=True)
    diff = project_commands.add_parser("diff", help="Compare domain changes between project revisions")
    diff.add_argument("project_id")
    diff.add_argument("--against", help="other project id (default: same project)")
    diff.add_argument("--from-revision", type=non_negative_integer)
    diff.add_argument("--to-revision", type=non_negative_integer)
    check = project_commands.add_parser("check", help="Collect explicit domain, layout, frame and audio checks in one revision-bound report")
    check.add_argument("--layout", action="store_true")
    check.add_argument("--sync", action="store_true", help="Check source-frame mappings between related video tracks")
    check.add_argument("--read-frames", type=frame_index_list)
    check.add_argument("--audio-clip", action="append", default=[])
    check.add_argument("--from-frame", type=non_negative_integer)
    check.add_argument("--to-frame", type=non_negative_integer)
    check.add_argument("--sequence-id")
    check.add_argument("--output", type=Path)

    source_command = project_commands.add_parser(
        "source",
        help="Write the open project as a readable project-source file",
    )
    source_command.add_argument(
        "--output",
        type=Path,
        help="write here (a .opaque.json sidecar is written alongside); "
        "omitted prints the document",
    )
    source_command.add_argument(
        "--format", choices=("yaml", "json"), default="yaml"
    )
    source_command.add_argument("--sequence-id")
    project_commands.add_parser("close")

    canvas = commands.add_parser(
        "canvas", help="Show or pin the sequence canvas and frame rate"
    )
    canvas_commands = canvas.add_subparsers(dest="canvas_command", required=True)
    canvas_commands.add_parser("show")
    canvas_set = canvas_commands.add_parser(
        "set",
        help="Pin an explicit canvas; the sequence stops following source media",
    )
    canvas_set.add_argument("--width", type=canvas_dimension, required=True)
    canvas_set.add_argument("--height", type=canvas_dimension, required=True)
    canvas_set.add_argument("--fps", type=positive_integer)
    canvas_set.add_argument("--sequence-id")
    canvas_set.add_argument("--intent", default="修改画布尺寸")
    canvas_set.add_argument("--base-revision", type=non_negative_integer)
    canvas_set.add_argument("--idempotency-key")
    canvas_set.add_argument("--dry-run", action="store_true")
    canvas_commands.add_parser(
        "looks",
        help="List the built-in looks (engine presets and bundled 3D LUTs) "
        "that `canvas grade --look` accepts; needs a service, not a Project",
    )
    canvas_grade = canvas_commands.add_parser(
        "grade",
        help="Set or clear the sequence-wide color grade the engine renders "
        "identically in preview and export",
    )
    canvas_grade.add_argument(
        "--preset",
        help="engine grade preset id (e.g. warm-daylight, skin-soft, mono-clean); Core "
        "rejects unknown ids and lists the valid set in the error",
    )
    canvas_grade.add_argument(
        "--intensity",
        type=percent_0_100,
        help="preset strength as an integer percent 0..100",
    )
    canvas_grade.add_argument(
        "--adjust",
        action="append",
        default=[],
        metavar="KEY=PERCENT",
        help="manual adjustment as an integer percent -100..100, e.g. "
        "temperature=20; repeatable; keys: exposure contrast highlights "
        "shadows whites blacks temperature tint vibrance saturation",
    )
    canvas_grade.add_argument(
        "--look",
        metavar="LOOK_ID",
        help="a built-in look by id from `canvas looks` (e.g. teal-orange, "
        "warm-daylight): resolves to the engine preset or bundled LUT behind it; "
        "--intensity overrides the look's suggested strength",
    )
    canvas_grade.add_argument(
        "--lut",
        metavar="CUBE_FILE_OR_ASSET_ID",
        help="a 3D .cube LUT: an absolute file path (imported as a Data asset "
        "first, or reused when already imported) or the asset id of one; "
        "applied after preset and adjustments in preview and export alike",
    )
    canvas_grade.add_argument(
        "--lut-intensity",
        type=percent_0_100,
        help="LUT strength as an integer percent 0..100 (default full)",
    )
    canvas_grade.add_argument(
        "--clear", action="store_true", help="remove the grade entirely"
    )
    canvas_grade.add_argument("--sequence-id")
    canvas_grade.add_argument("--intent", default="设置全局调色")
    canvas_grade.add_argument("--base-revision", type=non_negative_integer)
    canvas_grade.add_argument("--idempotency-key")
    canvas_grade.add_argument("--dry-run", action="store_true")

    effect = commands.add_parser(
        "effect", help="Put a keyframable visual effect on one Clip"
    )
    effect_commands = effect.add_subparsers(dest="effect_command", required=True)
    exposure = effect_commands.add_parser(
        "exposure",
        help="Ramp one Clip's brightness and saturation over time — the flash "
        "`canvas grade` cannot express, because a grade is one static state "
        "for the whole sequence",
    )
    exposure.add_argument("clip_id")
    exposure.add_argument(
        "--brightness-percent",
        type=exposure_percent,
        default=100,
        help="static brightness where 100 leaves the frame untouched; it is "
        "what plays wherever brightness carries no keyframe",
    )
    exposure.add_argument(
        "--saturation-percent",
        type=exposure_percent,
        default=100,
        help="static saturation where 100 leaves the frame untouched",
    )
    exposure.add_argument(
        "--keyframe",
        action="append",
        default=[],
        metavar="PARAM@FRAME=PERCENT[:EASE]",
        help="repeatable, e.g. brightness@94=190:hold. PARAM is brightness or "
        "saturation; FRAME counts from the Clip's own start; EASE is hold or "
        "linear (default linear) and drives the segment that starts there, so "
        "the last keyframe's easing is never used",
    )
    exposure.add_argument(
        "--clear",
        action="store_true",
        help="remove the Clip's exposure effect entirely",
    )
    exposure.add_argument("--sequence-id")
    exposure.add_argument("--intent", default="设置曝光斜坡")
    exposure.add_argument("--base-revision", type=non_negative_integer)
    exposure.add_argument("--idempotency-key")
    exposure.add_argument("--dry-run", action="store_true")
    style = effect_commands.add_parser(
        "style",
        help="Give one visual Clip (footage, cut-out, sticker, shape, HTML card) a "
        "layer look: blur it and/or make it glow along its own outline. Flags "
        "patch the existing look; lengths are canvas pixels",
    )
    style.add_argument("clip_id")
    style.add_argument(
        "--blur", type=float, default=None,
        help=f"Gaussian blur of the layer itself, canvas pixels 0..{LAYER_STYLE_MAX_BLUR} (0 = sharp)",
    )
    style.add_argument(
        "--glow", type=float, default=None,
        help=f"glow radius around what the layer paints (its alpha outline, not a box), canvas pixels 0..{LAYER_STYLE_MAX_GLOW} (0 = none)",
    )
    style.add_argument(
        "--glow-color", default=None,
        help="#RRGGBB or #RRGGBBAA (default white)",
    )
    style.add_argument(
        "--glow-strength", type=int, choices=(1, 2, 3, 4), default=None,
        help="how many glow passes stack: 1 soft halo .. 4 neon (default 2)",
    )
    style.add_argument(
        "--keyframe", action="append", default=None, metavar="PARAM@FRAME=PX[:EASE]",
        help="repeatable, e.g. glow@0=0 glow@12=40 blur@30=0:hold. PARAM is blur or glow; "
        "FRAME counts from the Clip's own start; EASE is linear (default) or hold. "
        "Passing any --keyframe replaces the Clip's keyframes; omit to keep them",
    )
    style.add_argument("--clear-keyframes", action="store_true", help="drop all keyframes, keep the static look")
    style.add_argument("--clear", action="store_true", help="remove the Clip's layer look entirely")
    style.add_argument("--sequence-id")
    style.add_argument("--intent", default="设置图层模糊/发光")
    style.add_argument("--base-revision", type=non_negative_integer)
    style.add_argument("--idempotency-key")
    style.add_argument("--dry-run", action="store_true")

    overlay = commands.add_parser(
        "overlay", help="Moving stickers you bring yourself (GIF, APNG, animated WebP, alpha video)"
    )
    overlay_commands = overlay.add_subparsers(dest="overlay_command", required=True)
    overlay_add = overlay_commands.add_parser(
        "add",
        help="Put a moving sticker above the footage: a file is converted to a frame-seekable alpha "
        "WebM (looped or trimmed to the duration), imported, and placed on its own overlay track "
        "under captions and text stickers; an existing video asset id is placed as is",
    )
    overlay_add.add_argument("source", help="absolute path to a .gif/.png(APNG)/.webp/.webm/.mov, or a video asset id")
    overlay_add.add_argument("--at-frame", type=non_negative_integer, required=True)
    overlay_add.add_argument(
        "--duration-frames", type=positive_integer, default=None,
        help="how long it stays; a shorter animation loops to fill it (default: one play of the animation, 3 s for a still)",
    )
    overlay_add.add_argument("--no-loop", action="store_true", help="play the animation once even if --duration-frames is longer (it then ends early)")
    overlay_add.add_argument("--x", type=float, default=0.0, help="centre offset from the canvas centre, canvas pixels, right positive")
    overlay_add.add_argument("--y", type=float, default=0.0, help="centre offset from the canvas centre, canvas pixels, down positive")
    overlay_add.add_argument(
        "--width", type=float, default=None,
        help="rendered width in canvas pixels (default 30%% of the canvas short side)",
    )
    overlay_add.add_argument("--track-id", default=None, help="an existing video track to put it on instead of a new overlay track")
    overlay_add.add_argument("--sequence-id")
    overlay_add.add_argument("--intent", default="放一个动态贴纸")
    overlay_add.add_argument("--base-revision", type=non_negative_integer)
    overlay_add.add_argument("--idempotency-key")

    asset = commands.add_parser("asset")
    asset_commands = asset.add_subparsers(dest="asset_command", required=True)
    list_assets = asset_commands.add_parser(
        "list",
        help="List the Project's assets; --kind narrows it, e.g. which fonts are available to caption/sticker",
    )
    list_assets.add_argument(
        "--kind", choices=("audio", "data", "font", "image", "video"), default=None,
        help="only assets of this kind",
    )
    remove_asset = asset_commands.add_parser(
        "remove", help="Remove one project asset that no clip or component uses"
    )
    remove_asset.add_argument("asset_id")
    remove_asset.add_argument("--intent", default="移除不再使用的素材")
    remove_asset.add_argument("--base-revision", type=non_negative_integer)
    remove_asset.add_argument("--idempotency-key")
    import_assets = asset_commands.add_parser("import")
    import_assets.add_argument("paths", nargs="+", type=Path)
    import_assets.add_argument(
        "--kind", choices=("audio", "font", "image", "video")
    )
    import_assets.add_argument("--intent", default="导入指定素材")
    import_assets.add_argument("--base-revision", type=non_negative_integer)
    import_assets.add_argument("--idempotency-key")

    sequence = commands.add_parser("sequence", help="Manage sequences in the current Project")
    sequence_commands = sequence.add_subparsers(dest="sequence_command", required=True)
    sequence_commands.add_parser("list", help="List sequence IDs, names, canvases, rates and durations in frames")
    sequence_create = sequence_commands.add_parser("create", help="Create an independent sequence without changing the default sequence")
    sequence_create.add_argument("--name", required=True)
    sequence_create.add_argument("--width", type=positive_integer, default=1920, help="Canvas width (default: 1920)")
    sequence_create.add_argument("--height", type=positive_integer, default=1080, help="Canvas height (default: 1080)")
    sequence_create.add_argument("--fps", type=positive_frame_rate, default=Fraction(30), help="Exact FPS, e.g. 30 or 30000/1001 (default: 30)")
    sequence_create.add_argument("--base-revision", type=non_negative_integer, help="Use with --idempotency-key to replay the same edit")
    sequence_create.add_argument("--idempotency-key")
    timeline = commands.add_parser("timeline")
    timeline_commands = timeline.add_subparsers(dest="timeline_command", required=True)
    nest = timeline_commands.add_parser("add-sequence", help="Place an editable same-Project sequence on a video track")
    nest.add_argument("source_sequence_id", help="Source sequence ID (in the current Project)")
    nest.add_argument("--sequence-id", help="Target sequence ID (default: project's default sequence)")
    nest.add_argument("--track-id", help="Target video track; omitted picks a free track or creates one")
    nest.add_argument("--at-frame", type=non_negative_integer, default=0, help="Start frame on the target sequence grid (default: 0)")
    nest.add_argument("--in-frame", type=non_negative_integer, default=0, help="First frame on the source grid (default: 0)")
    nest.add_argument("--out-frame", type=non_negative_integer, help="Exclusive end on the source grid (default: exact source end)")
    nest.add_argument("--muted", action="store_true", help="Mute this instance, not the child sequence or target track")
    nest.add_argument("--base-revision", type=non_negative_integer, help="Use with --idempotency-key to replay the same edit")
    nest.add_argument("--idempotency-key")
    nest.add_argument("--intent")
    timeline_place = timeline_commands.add_parser(
        "place",
        help="Place trimmed clips from a cutlist, atomically and in order",
    )
    timeline_place.add_argument("--cutlist", required=True,
                                help='JSON file: [{"assetId": ..., "atFrame": 0, '
                                     '"durationFrames": 48, "sourceStartUs": 23000000}]')
    timeline_place.add_argument("--track-id", help="place onto this track (default: a new video track)")
    timeline_place.add_argument("--muted", action="store_true",
                                help="zero每个放置片段的音频增益(解说压住的画面)。"
                                     "不用轨道 muted:引擎把 muted 轨整个跳过渲染,画面也没了")
    timeline_place.add_argument("--sequence-id")
    timeline_place.add_argument("--intent", default="按剪单放置片段")
    timeline_place.add_argument("--base-revision", type=non_negative_integer)
    timeline_place.add_argument("--idempotency-key")
    timeline_snapshot = timeline_commands.add_parser("snapshot")
    inspect = timeline_commands.add_parser("inspect", help="Read only matching objects, with revision and linked IDs")
    inspect.add_argument("--sequence-id")
    inspect.add_argument("--id", action="append", default=[], dest="ids")
    inspect.add_argument("--track-id", action="append", default=[], dest="track_ids")
    inspect.add_argument("--kind", choices=("clip", "caption"))
    inspect.add_argument("--text")
    inspect.add_argument("--external-ref")
    inspect.add_argument("--from-frame", type=non_negative_integer)
    inspect.add_argument("--to-frame", type=non_negative_integer)
    inspect.add_argument("--full", action="store_true")
    inspect.add_argument("--limit", type=positive_integer)
    edit_plan = timeline_commands.add_parser("edit", help="Apply an explicit compound edit as one undoable transaction")
    edit_plan.add_argument("--file", type=Path, required=True)
    edit_plan.add_argument("--dry-run", action="store_true")
    for name in ("ripple-delete", "ripple-trim"):
        ripple = timeline_commands.add_parser(name, help="Atomically splice all included tracks")
        ripple.add_argument("--sequence-id")
        ripple.add_argument("--intent", default=name)
        ripple.add_argument("--base-revision", type=non_negative_integer)
        ripple.add_argument("--idempotency-key")
        ripple.add_argument("--exclude-tracks", help="Comma-separated track IDs, names, or kinds")
        ripple.add_argument("--dry-run", action="store_true")
        if name == "ripple-delete":
            ripple.add_argument("--from-frame", required=True, type=non_negative_integer)
            ripple.add_argument("--to-frame", required=True, type=positive_integer)
        else:
            ripple.add_argument("clip_id")
            ripple.add_argument("--delta-frames", required=True, type=int)
            ripple.add_argument("--edge", choices=("end", "start"), default="end")
    timeline_snapshot.add_argument("--sequence-id")
    timeline_snapshot.add_argument(
        "--tracks",
        help="comma-separated track ids; other tracks are dropped from the output",
    )
    timeline_snapshot.add_argument(
        "--kind",
        help="comma-separated track kinds to keep: video,audio,caption,component",
    )
    timeline_snapshot.add_argument(
        "--no-assets", action="store_true",
        help="drop the assets array (it dominates the payload in big projects)",
    )
    clear = timeline_commands.add_parser("clear")
    clear.add_argument("--sequence-id")
    clear.add_argument("--intent", default="清空当前时间线")
    clear.add_argument("--base-revision", type=non_negative_integer)
    clear.add_argument("--idempotency-key")
    for gap_command, gap_help, gap_intent in (
        (
            "gap-insert",
            "Open a gap across every Track, moving later content back",
            "在时间线上插入空隙",
        ),
        (
            "gap-remove",
            "Close an empty gap across every Track, pulling later content forward",
            "关闭时间线上的空隙",
        ),
    ):
        gap = timeline_commands.add_parser(gap_command, help=gap_help)
        gap.add_argument("--at-frame", type=non_negative_integer, required=True)
        gap.add_argument("--duration-frames", type=positive_integer, required=True)
        gap.add_argument("--sequence-id")
        gap.add_argument("--intent", default=gap_intent)
        gap.add_argument("--base-revision", type=non_negative_integer)
        gap.add_argument("--idempotency-key")
        if gap_command == "gap-insert":
            gap.add_argument(
                "--split-crossing",
                action="store_true",
                help="first split every clip that straddles the gap position "
                     "(BGM, SFX, stickers included), then open the gap — splits "
                     "are visually lossless, so no manual shrink-and-restore",
            )
        gap.add_argument("--dry-run", action="store_true")
    timeline_privacy = timeline_commands.add_parser(
        "privacy",
        help="Cover faces on one video Clip, or --clear the cover. Default (no flags) = the cloud sticker following each face (no re-encode); --style/--box/--no-faces switch to the pixel path: the service tracks faces on the clip's asset, derives a blurred/pixelated/blocked copy and swaps it in at render time; the model keeps the original source",
    )
    timeline_privacy.add_argument("clip_id")
    add_privacy_cover_arguments(timeline_privacy)
    timeline_privacy.add_argument(
        "--sticker", choices=tuple(COVER_STICKERS), default=None, nargs="?", const=DEFAULT_COVER_STICKER,
        help="cover each face with a bundled cartoon sticker that follows it (position/scale keyframes on an image clip above the footage) instead of re-encoding: cloud (the default, also when the flag is bare or omitted), smile, bear, star, flower, heart",
    )
    timeline_privacy.add_argument(
        "--size-factor", type=float, default=None,
        help="sticker edge = face width × this (default 1.5, hairline to chin)",
    )
    timeline_privacy.add_argument("--clear", action="store_true", help="remove the cover (pixel derivation and/or stickers); the clip renders its original source again")
    timeline_privacy.add_argument("--sequence-id")
    timeline_privacy.add_argument("--intent", default=None)
    timeline_follow = timeline_commands.add_parser(
        "follow",
        help="Make an overlay clip (sticker, shape, HTML component, image, video) follow an object inside a video clip: the service tracks the object, the CLI writes position (and optionally scale) keyframes onto the overlay in one batch. --clear drops the follow keyframes",
    )
    timeline_follow.add_argument("clip_id", help="the overlay clip that should move")
    timeline_follow.add_argument("--target", default=None, help="the video clip whose picture holds the object")
    add_object_track_arguments(timeline_follow, source_pixels=False)
    timeline_follow.add_argument(
        "--at-frame", type=non_negative_integer, default=None,
        help="timeline frame the --box is drawn on (default: the overlay's first frame inside the target); read it with `oc read --frames <frame>`",
    )
    timeline_follow.add_argument(
        "--offset", type=pair_argument, default=None,
        help="overlay centre relative to the object centre, canvas pixels, e.g. --offset=0,-180 (default: keep the overlay where it sits now relative to the object at the reference frame)",
    )
    timeline_follow.add_argument("--center", action="store_true", help="put the overlay centre on the object centre (same as --offset=0,0)")
    timeline_follow.add_argument(
        "--scale", choices=("none", "uniform", "box"), default="none",
        help="none (default): keep the overlay's size; uniform: grow/shrink with the object's area; box: stretch x and y with the object's width and height (a frame or highlight box drawn around it)",
    )
    timeline_follow.add_argument(
        "--step", type=positive_integer, default=None,
        help="one keyframe every N frames (default 2; capped to 600 keyframes per property)",
    )
    timeline_follow.add_argument("--clear", action="store_true", help="remove the follow keyframes (position, and scale if follow wrote it) from the overlay")
    timeline_follow.add_argument("--sequence-id")
    timeline_follow.add_argument("--intent", default=None)
    timeline_follow.add_argument("--base-revision", type=non_negative_integer)
    timeline_follow.add_argument("--idempotency-key")
    timeline_mask = timeline_commands.add_parser(
        "mask",
        help="Put a mask on one video Clip (or --clear it): the service derives "
        "an alpha cutout from the clip's asset plus an external mask and swaps "
        "it in at render time; the model keeps the original source",
    )
    timeline_mask.add_argument("clip_id")
    timeline_mask.add_argument(
        "--mask", type=Path, default=None,
        help="external mask, absolute path: a segment mask video (white=keep) "
        "or a still PNG applied to the whole clip",
    )
    timeline_mask.add_argument(
        "--shape", choices=("rect", "ellipse", "linear"), default=None,
        help="server-generated geometric mask instead of a file; shape "
        "parameters as in `media make-mask`",
    )
    timeline_mask.add_argument("--box", type=box_argument, default=None)
    timeline_mask.add_argument("--center", type=pair_argument, default=None)
    timeline_mask.add_argument("--radius", type=radius_argument, default=None)
    timeline_mask.add_argument("--angle", type=float, default=None)
    timeline_mask.add_argument("--position", type=float, default=None)
    timeline_mask.add_argument("--softness", type=non_negative_float, default=None)
    timeline_mask.add_argument(
        "--point", action="append", type=point_argument, default=None,
        dest="points",
        help="smart mask: prompt the segment plugin with points on the source "
        "(x,y or neg:x,y, source pixels; repeatable)",
    )
    timeline_mask.add_argument(
        "--prompt-box", type=box_argument, default=None,
        help="smart mask: prompt the segment plugin with a box on the source",
    )
    timeline_mask.add_argument(
        "--frame", type=non_negative_integer, default=None,
        help="smart mask: source-asset frame index the prompt refers to",
    )
    timeline_mask.add_argument(
        "--feather", type=non_negative_float, default=None,
        help="edge softening in output pixels (default 2)",
    )
    timeline_mask.add_argument(
        "--invert", action="store_true",
        help="keep what the mask blacks out instead",
    )
    timeline_mask.add_argument(
        "--clear", action="store_true",
        help="remove the clip's mask and render its original source again",
    )
    timeline_mask.add_argument("--sequence-id")
    timeline_mask.add_argument("--intent", default=None)
    transition = timeline_commands.add_parser(
        "transition",
        help="Put a transition on one video Clip: crossfade from the previous "
        "Clip, or fade the Clip itself in or out",
    )
    transition.add_argument("clip_id")
    transition.add_argument(
        "--type",
        dest="transition_type",
        choices=("crossfade", "fade-in", "fade-out"),
        default="crossfade",
        help="crossfade blends from the previous Clip on the same Track; "
        "fade-in/fade-out ramp the Clip's own opacity (over the composition "
        "background, so black unless something plays beneath)",
    )
    transition.add_argument(
        "--duration-frames", type=positive_integer, required=True
    )
    transition.add_argument(
        "--easing",
        choices=(
            "linear",
            "ease-in",
            "ease-out",
            "ease-in-out",
            "ease-in-out-strong",
            "smooth",
        ),
        default="linear",
        help="how the blend travels from 0 to 1 (crossfade only). linear is the "
        "old behaviour and reads hard at both ends; ease-in-out-strong is the "
        "S curve measured off real reference footage",
    )
    transition.add_argument("--sequence-id")
    transition.add_argument("--intent", default="添加片段转场")
    transition.add_argument("--base-revision", type=non_negative_integer)
    transition.add_argument("--idempotency-key")
    transition.add_argument("--dry-run", action="store_true")
    add = timeline_commands.add_parser("add")
    add.add_argument("asset_id")
    add.add_argument("--at-frame", type=non_negative_integer, required=True)
    add.add_argument("--sequence-id")
    track_target = add.add_mutually_exclusive_group()
    track_target.add_argument("--track-id")
    track_target.add_argument("--new-track", action="store_true")
    add.add_argument("--intent", default="把素材添加到时间线")
    add.add_argument("--base-revision", type=non_negative_integer)
    add.add_argument("--idempotency-key")
    clip = commands.add_parser(
        "clip",
        help="Direct clip-level edits (transform without hand-writing rationals)",
    )
    clip_commands = clip.add_subparsers(dest="clip_command", required=True)
    clip_transform = clip_commands.add_parser(
        "transform",
        help="Position/scale/rotate/fade one clip on the canvas",
    )
    clip_transform_commands = clip_transform.add_subparsers(
        dest="transform_command", required=True
    )
    transform_set = clip_transform_commands.add_parser(
        "set",
        help="Partial update: only the fields you pass change; the rest keep "
             "their current values (raw clip.transform.set wants all six as "
             "reduced rationals — this command does that for you)",
    )
    transform_set.add_argument("clip_id")
    transform_set.add_argument(
        "--x", type=float, help="box center offset from canvas center, px (right is +)"
    )
    transform_set.add_argument(
        "--y", type=float, help="box center offset from canvas center, px (down is +)"
    )
    transform_set.add_argument(
        "--scale-percent", type=float, help="uniform scale (100 = original size)"
    )
    transform_set.add_argument("--scale-x-percent", type=float)
    transform_set.add_argument("--scale-y-percent", type=float)
    transform_set.add_argument("--rotation", type=float, help="degrees, clockwise")
    transform_set.add_argument(
        "--opacity-percent", type=float, help="100 = opaque, 0 = invisible"
    )
    transform_set.add_argument("--sequence-id")
    transform_set.add_argument("--intent", default="调整片段的画面变换")
    transform_set.add_argument("--base-revision", type=non_negative_integer)
    transform_set.add_argument("--idempotency-key")
    transform_clear = clip_transform_commands.add_parser(
        "clear", help="Reset the clip to identity (fill the canvas as placed)"
    )
    transform_clear.add_argument("clip_id")
    transform_clear.add_argument("--sequence-id")
    transform_clear.add_argument("--intent", default="重置片段的画面变换")
    transform_clear.add_argument("--base-revision", type=non_negative_integer)
    transform_clear.add_argument("--idempotency-key")

    freeze_frame = timeline_commands.add_parser(
        "freeze-frame",
        help="Hold one frame of a clip for N frames, pushing later content "
             "back (split + freeze + gap in one command)",
    )
    freeze_frame.add_argument("clip_id")
    freeze_frame.add_argument(
        "--at-frame", type=non_negative_integer, required=True,
        help="the timeline frame whose picture is held",
    )
    freeze_frame.add_argument(
        "--duration-frames", type=positive_integer, required=True,
        help="how many frames the held picture lasts",
    )
    freeze_frame.add_argument("--sequence-id")
    freeze_frame.add_argument("--intent", default="在此帧插入定格")

    timeline_grid = timeline_commands.add_parser(
        "grid",
        help="Arrange 2-9 visual clips as a grid in one atomic batch: 4 = 2x2, "
             "2/3 stack or sit side by side (3 = one big + two small), 5-6 two "
             "or three columns, 7-9 = 3x3; portrait and landscape canvases lay "
             "out differently; each clip is scaled uniformly to fit its cell",
    )
    timeline_grid.add_argument(
        "--clips",
        required=True,
        help="2-9 clip ids, comma-separated, in reading order (top-left first, "
             "row by row); for 4 clips that is top-left,top-right,bottom-left,bottom-right",
    )
    timeline_grid.add_argument(
        "--gap", type=non_negative_integer, default=0,
        help="gutter between cells and around the edge, in canvas pixels (default 0; "
             "the GUI defaults to 2%% of the short side)",
    )
    timeline_grid.add_argument("--sequence-id")
    timeline_grid.add_argument("--intent", default="片段排成宫格")
    timeline_grid.add_argument("--base-revision", type=non_negative_integer)
    timeline_grid.add_argument("--idempotency-key")

    split = timeline_commands.add_parser("split")
    split.add_argument("clip_id")
    split.add_argument("--at-frame", type=non_negative_integer, required=True)
    split.add_argument("--sequence-id")
    split.add_argument("--intent", default="在指定帧切分片段")
    split.add_argument("--base-revision", type=non_negative_integer)
    split.add_argument("--idempotency-key")
    move = timeline_commands.add_parser("move")
    move.add_argument("clip_id")
    move.add_argument("--to-frame", type=non_negative_integer)
    move.add_argument(
        "--to-track",
        metavar="TRACK_ID",
        help="Move the Clip onto another Track (kind-compatible; linked A/V pairs must detach first)",
    )
    move.add_argument("--sequence-id")
    move.add_argument("--intent", default="把片段移动到指定帧")
    move.add_argument("--base-revision", type=non_negative_integer)
    move.add_argument("--idempotency-key")
    trim = timeline_commands.add_parser("trim")
    trim.add_argument("clip_id")
    trim_edge = trim.add_mutually_exclusive_group(required=True)
    trim_edge.add_argument("--start-frame", type=non_negative_integer)
    trim_edge.add_argument("--end-frame", type=non_negative_integer)
    trim.add_argument("--sequence-id")
    trim.add_argument("--intent", default="在指定帧裁剪片段边缘")
    trim.add_argument("--base-revision", type=non_negative_integer)
    trim.add_argument("--idempotency-key")
    speed = timeline_commands.add_parser(
        "speed", help="Retime one placed Clip without losing its motion or effects"
    )
    speed.add_argument("clip_id")
    speed.add_argument(
        "--rate-percent",
        type=speed_rate_percent,
        help="200 plays twice as fast, 50 half as fast; an integer percent keeps the mapping exact",
    )
    speed_direction = speed.add_mutually_exclusive_group()
    speed_direction.add_argument("--reverse", action="store_true", default=None)
    speed_direction.add_argument("--no-reverse", action="store_false", dest="reverse")
    speed_hold = speed.add_mutually_exclusive_group()
    speed_hold.add_argument("--freeze", action="store_true", default=None)
    speed_hold.add_argument("--no-freeze", action="store_false", dest="freeze")
    speed.add_argument(
        "--curve",
        type=Path,
        default=None,
        help='JSON file of a speed curve: [{"atFrame": 0, "ratePercent": 200}, '
        '{"atFrame": 48, "ratePercent": 25}]. Frames are relative to the clip\'s own '
        "start and the last keyframe sets its new length; rates ramp linearly between "
        "keyframes. Not combinable with --rate-percent, --reverse or --freeze",
    )
    speed.add_argument("--sequence-id")
    speed.add_argument("--intent", default="调整片段速度")
    speed.add_argument("--base-revision", type=non_negative_integer)
    speed.add_argument("--idempotency-key")
    remove = timeline_commands.add_parser("remove")
    remove.add_argument("clip_id")
    remove.add_argument("--sequence-id")
    remove.add_argument("--intent", default="从时间线移除片段")
    remove.add_argument("--base-revision", type=non_negative_integer)
    remove.add_argument("--idempotency-key")

    html = commands.add_parser("html")
    html_commands = html.add_subparsers(dest="html_command", required=True)
    html_add = html_commands.add_parser(
        "add", help="Place an HTML overlay component Clip parsed from a fragment file"
    )
    html_add.add_argument("html_file", type=Path, nargs="?")
    html_add.add_argument(
        "--preset",
        help="Place a catalog preset instead of a fragment file; see `oc html presets --json`",
    )
    html_add.add_argument(
        "--set",
        action="append",
        default=[],
        dest="preset_assignments",
        metavar="NAME=VALUE",
        help="Fill a preset slot or CSS variable, repeatable",
    )
    html_add.add_argument(
        "--placement",
        choices=("overlay", "insert"),
        help="Override the preset's placement: overlay leaves what is underneath"
        " playing, insert opens a gap across every Track first",
    )
    html_add.add_argument("--css", type=Path, help="Extra stylesheet merged after inline <style>")
    html_add.add_argument(
        "--sfx",
        help="sound id or kind (see `oc sfx list`) overrides the first cue; "
        "`none` mutes all cues. Fragment files default to none",
    )
    html_add.add_argument("--at-frame", type=non_negative_integer, required=True)
    html_add.add_argument(
        "--duration-frames",
        type=positive_integer,
        help="Defaults to the preset's authoring duration when --preset is used",
    )
    html_add.add_argument("--sequence-id")
    html_add.add_argument("--track-id")
    html_add.add_argument("--intent", default="添加 HTML 浮层组件")
    html_add.add_argument("--base-revision", type=non_negative_integer)
    html_add.add_argument("--idempotency-key")
    html_compile = html_commands.add_parser(
        "compile",
        help="Compile a fragment file into the typed node tree a component carries",
    )
    html_compile.add_argument("html_file", type=Path)

    html_presets = html_commands.add_parser(
        "presets", help="List the shared HTML component presets a human can also click"
    )
    html_presets.add_argument(
        "preset_id",
        nargs="?",
        help="Describe one preset's properties instead of listing the catalog",
    )
    html_presets.add_argument("--pack", choices=("cinema", "editorial", "kinetic", "meme", "utility", "atmosphere"))
    html_presets.add_argument("--category", choices=(
        "opening", "evidence", "data", "narrative", "callout", "transition", "meme", "lighting", "texture",
    ))
    html_presenter = html_commands.add_parser("presenter", help="Animate a presenter video between semantic poses; default movement sfx is wind-swoosh")
    html_presenter.add_argument("config", help='JSON or file: {assetId,durationFrames,startFrame,sourceStartFrame,cues:[{atFrame:0,pose:"center"},{atFrame:90,pose:"br"}],transitionSec,borderColor,dimOnCenter,faceX,faceY,includeAudio,sfx,sfxVolume}; cue frames are clip-local')
    html_presenter.add_argument("--fit", choices=("cover", "contain"), help="override video fit (default cover); circular poses always cover")
    html_presenter.add_argument("--sfx", help="bundled sfx ID; none disables movement sounds")
    html_presenter.add_argument("--sfx-volume", type=float, help="linear gain 0..2 (default 0.5, approximately -6dB)")
    html_presenter.add_argument("--sequence-id")
    html_presenter.add_argument("--intent", default="添加口播画中画走位")
    html_presenter.add_argument("--base-revision", type=non_negative_integer)
    html_presenter.add_argument("--idempotency-key")
    html_presenter.add_argument("--dry-run", action="store_true")
    html_dual = html_commands.add_parser("dual", help="Place two independently timed media windows from a JSON config; sources are imported asset IDs")
    html_dual.add_argument("config", type=Path, help="JSON {layout, gapPx, splitPercent, panes:[{assetId, startFrame, sourceStartFrame, durationFrames, fit, cropX, cropY, audio, rect}, ...]}; audio adds an independent track")
    html_dual.add_argument("--sequence-id")
    html_dual.add_argument("--intent", default="添加双画面编排")
    html_dual.add_argument("--base-revision", type=non_negative_integer)
    html_dual.add_argument("--idempotency-key")
    html_dual.add_argument("--dry-run", action="store_true")
    html_focus = html_commands.add_parser("focus", help="Emphasize a source-aligned region or alpha-cutout object using a shared native composition")
    html_focus.add_argument("config", type=Path, help="JSON {assetId,mode:region|object,box:[x,y,w,h],durationFrames,startFrame,sourceStartFrame,alphaAssetId,alphaStartFrame,dimPercent,feather,halo,enterFrames,exitFrames,shape}")
    html_focus.add_argument("--sequence-id")
    html_focus.add_argument("--intent", default="添加目标聚焦")
    html_focus.add_argument("--base-revision", type=non_negative_integer)
    html_focus.add_argument("--idempotency-key")
    html_focus.add_argument("--dry-run", action="store_true")
    html_visual = html_commands.add_parser("visual", help="Magnifier, aligned wipe, desktop window, foreground typography, and drawn annotations")
    html_visual.add_argument("kind", choices=("magnify", "wipe", "window", "layers", "markup"))
    html_visual.add_argument("config", type=Path, help="Visual-tool JSON config; source coordinates use original media pixels")
    html_visual.add_argument("--sequence-id")
    html_visual.add_argument("--intent", default="添加通用视觉组件")
    html_visual.add_argument("--base-revision", type=non_negative_integer)
    html_visual.add_argument("--idempotency-key")
    html_visual.add_argument("--dry-run", action="store_true")
    html_device = html_commands.add_parser("device", help="Embed an imported recording in a transparent Devices.css phone frame over other footage")
    html_device.add_argument("config", type=Path, help="JSON {assetId,durationFrames,startFrame,sourceStartFrame,color:silver|black,pose:front|left|right,cutout:none|island,xPercent,yPercent,heightPercent,shadow}")
    html_device.add_argument("--sequence-id")
    html_device.add_argument("--intent", default="添加设备展示")
    html_device.add_argument("--base-revision", type=non_negative_integer)
    html_device.add_argument("--idempotency-key")
    html_device.add_argument("--dry-run", action="store_true")
    html_screen = html_commands.add_parser(
        "screen",
        help="Wrap a screen recording: background, device frame, a camera that"
        " pushes in on every click, a cursor and click ripples",
    )
    html_screen.add_argument("recording", type=Path, help="absolute path of the screen recording")
    html_screen.add_argument(
        "--clicks",
        help="t:x,y;t:x,y — seconds from the selected clip's start and the clicked"
        " point in the recording's own pixels; the camera pushes in on each",
    )
    html_screen.add_argument("--focus", help="manual focus points t:x,y;t:x,y; omitted follows clicks; empty string disables zoom")
    html_screen.add_argument("--crop", help="source pixel crop x,y,width,height; default full source")
    html_screen.add_argument("--source-start-frame", type=non_negative_integer, default=0, help="source in point at sequence frame rate")
    html_screen.add_argument("--source-end-frame", type=positive_integer, help="exclusive source out point at sequence frame rate")
    html_screen.add_argument("--keep-audio", action="store_true", help="add an independent original-audio track in the same batch; later moves/trims are separate")
    html_screen.add_argument(
        "--device", choices=("auto", "window", "laptop", "phone", "none"), default="auto",
        help="frame around the recording; auto picks phone for portrait, window otherwise",
    )
    html_screen.add_argument("--zoom", type=float, default=1.8, help="push-in scale on a click (default 1.8)")
    html_screen.add_argument("--hold", type=float, default=1.4, help="seconds to stay pushed in after a click")
    html_screen.add_argument("--no-cursor", action="store_true", help="draw no synthetic cursor")
    html_screen.add_argument("--background", help="CSS background behind the device (default: deep blue gradient)")
    html_screen.add_argument("--accent", default="#F28C28", help="ripple colour")
    html_screen.add_argument(
        "--sfx", default="dianji",
        help="sound on every click (id or kind from `oc sfx list`), or `none`",
    )
    html_screen.add_argument("--at-frame", type=non_negative_integer, required=True)
    html_screen.add_argument("--sequence-id")
    html_screen.add_argument("--track-id")
    html_screen.add_argument("--intent", default="添加录屏包装")

    sfx = commands.add_parser(
        "sfx", help="Place, swap, or list registered sound effects"
    )
    sfx_commands = sfx.add_subparsers(dest="sfx_command", required=True)
    sfx_commands.add_parser(
        "list", help="List the sfx library (ORANGECUT_SFX_DIR/sfx.json)"
    )
    marker_global=sfx_commands.add_parser("markers",help="Enable/disable component marker cues for this sequence")
    marker_global.add_argument("--enabled",action=argparse.BooleanOptionalAction,required=True)
    marker_global.add_argument("--sequence-id")
    marker_global.add_argument("--base-revision",type=non_negative_integer)
    marker_global.add_argument("--idempotency-key")
    marker_global.add_argument("--intent",default="切换标记提示音")
    marker_set=sfx_commands.add_parser("marker",help="Change a marker component's owned cue, volume or silence")
    marker_set.add_argument("clip_id")
    marker_set.add_argument("--preset",choices=("auto","tick","sweep","glow","custom","none"))
    marker_set.add_argument("--asset-id")
    marker_set.add_argument("--volume-percent",type=non_negative_integer)
    marker_set.add_argument("--sequence-id")
    marker_set.add_argument("--base-revision",type=non_negative_integer)
    marker_set.add_argument("--idempotency-key")
    marker_set.add_argument("--intent",default="更换标记提示音")
    sfx_add = sfx_commands.add_parser(
        "add", help="Place one sound effect on the dedicated sfx track"
    )
    sfx_add.add_argument("sfx_id", help="an id or kind from `oc sfx list`")
    sfx_add.add_argument("--at-frame", type=non_negative_integer, required=True)
    sfx_add.add_argument("--sequence-id")
    sfx_add.add_argument("--intent", default="添加音效")
    sfx_add.add_argument("--base-revision", type=non_negative_integer)
    sfx_add.add_argument("--idempotency-key")
    sfx_set = sfx_commands.add_parser(
        "set",
        help="Swap, attach, or remove the sound effect linked to one clip",
    )
    sfx_set.add_argument("clip_id", help="the visual clip the sfx belongs to")
    sfx_set.add_argument(
        "--sfx", required=True, help="an id or kind from `oc sfx list`, or `none`"
    )
    sfx_set.add_argument("--sequence-id")
    sfx_set.add_argument("--intent", default="更换音效")
    sfx_set.add_argument("--base-revision", type=non_negative_integer)
    sfx_set.add_argument("--idempotency-key")
    cutaway = commands.add_parser(
        "cutaway",
        help="Insert a short reaction/meme clip (切出镜头/插梗) at a moment: bundled or your own",
    )
    cutaway_commands = cutaway.add_subparsers(dest="cutaway_command", required=True)
    cutaway_commands.add_parser(
        "list", help="List the bundled cutaway clips (needs no service)"
    )
    cutaway_add = cutaway_commands.add_parser(
        "add", help="Place one cutaway clip at a frame on its own video track"
    )
    cutaway_add.add_argument(
        "cutaway_id", help="a bundled id from `oc cutaway list`, or a video asset id of the project"
    )
    cutaway_add.add_argument("--at-frame", type=non_negative_integer, required=True)
    cutaway_add.add_argument(
        "--mode", choices=CUTAWAY_MODES, default="insert",
        help="insert (default): cut the main picture track at the frame, open a gap "
             "across every track and put the clip in that gap — the main content "
             "pauses and resumes after it, letterboxed when the aspect differs; "
             "overlay: the clip covers the picture on its own layer while the voice "
             "and everything underneath keep playing; pip: overlay scaled into a corner",
    )
    cutaway_add.add_argument(
        "--duration-frames", type=positive_integer,
        help="cap the clip at this many frames (default: the whole clip)",
    )
    cutaway_add.add_argument(
        "--fit", choices=("contain", "cover"), default="contain",
        help="contain (default) keeps the clip whole, aspect kept, black bars when "
             "inserted (the picture beneath shows through when overlaid); cover "
             "fills the canvas and crops",
    )
    cutaway_add.add_argument(
        "--volume-percent", type=int, default=100,
        help="the clip's own sound, 100 = as recorded, 0 = picture only",
    )
    cutaway_add.add_argument(
        "--pip-scale-percent", type=float, default=45.0,
        help="pip only: clip width as a percentage of the canvas width (default 45)",
    )
    cutaway_add.add_argument(
        "--pip-corner", choices=CUTAWAY_PIP_CORNERS, default="top-right",
        help="pip only: which corner (default top-right)",
    )
    cutaway_add.add_argument("--sequence-id")
    cutaway_add.add_argument("--intent", default="插梗")
    cutaway_add.add_argument("--base-revision", type=non_negative_integer)
    cutaway_add.add_argument("--idempotency-key")
    media = commands.add_parser("media")
    media_commands = media.add_subparsers(dest="media_command", required=True)
    media_probe = media_commands.add_parser(
        "probe", help="Read a media file's canvas, frame rate and rotation"
    )
    media_probe.add_argument("media_file", type=Path)
    media_transcribe = media_commands.add_parser(
        "transcribe",
        help="Transcribe a media file's speech with the bundled offline ASR",
    )
    media_transcribe.add_argument("media_file", type=Path)
    media_transcribe.add_argument(
        "--srt",
        type=Path,
        default=None,
        help="Also write the transcript as an SRT file at this path",
    )
    media_transcribe.add_argument(
        "--glossary",
        type=Path,
        default=None,
        help="JSON glossary ({\"terms\": [{\"canonical\", \"aliases\"}]}) for "
        "deterministic proper-noun correction after ASR; added on top of the "
        "machine-level glossary (`oc glossary`), which always applies",
    )
    media_transcribe.add_argument(
        "--script",
        type=Path,
        default=None,
        help="UTF-8 text file with what the speaker was meant to say: the captions "
        "use the script's wording (homophones, numbers, names) with the ASR's "
        "per-character timing; data.scriptAlignment reports coverage and the "
        "spans that were skipped, ad-libbed or said differently",
    )
    media_transcribe.add_argument(
        "--max-line-width",
        type=float,
        default=None,
        help="widest caption in CJK characters (ASCII counts 0.55; default 14, "
        "the vertical short-video size). Landscape mid-length videos use small "
        "captions and read well at about 18-22",
    )

    media_subtitles = media_commands.add_parser(
        "subtitles",
        help="Discover a media file's subtitle tracks (sidecar + embedded) with "
        "admission verdicts; --read returns one track's cues",
    )
    media_subtitles.add_argument("media_file", type=Path)
    media_subtitles.add_argument(
        "--read", action="store_true",
        help="return the cues of the single admissible track (or --track)",
    )
    media_subtitles.add_argument(
        "--track", default=None,
        help="track id from the listing (file:<name> or stream:<index>)",
    )
    media_subtitles.add_argument(
        "--language", choices=("zh", "en"), default=None,
        help="admission script check + which line of a bilingual cue to keep",
    )
    media_matte = media_commands.add_parser(
        "matte",
        help="Cut a media file down to its subject with an alpha channel, so it can "
        "sit above text and occlude it (not a keyer: see --help notes)",
    )
    media_matte.add_argument("media_file", type=Path)
    media_matte.add_argument("--in-frame", type=non_negative_integer)
    media_matte.add_argument("--out-frame", type=positive_integer)
    media_matte.add_argument("--first-mask", type=Path)
    media_matte.add_argument("--no-cache", action="store_true")
    media_matte.add_argument(
        "--output",
        type=Path,
        required=True,
        help="where to write the matted clip; must end in .webm (VP9 is the only "
        "alpha-carrying encoding the renderer decodes)",
    )
    media_matte.add_argument(
        "--feather",
        type=non_negative_float,
        default=None,
        help="edge softening in output pixels (default 2). The mask is a 192x192 "
        "segmentation upscaled, so a little feather hides the stair-stepping",
    )
    media_matte.add_argument(
        "--invert",
        action="store_true",
        help="keep the background and cut the subject out instead",
    )
    media_matte.add_argument(
        "--outline-width", type=matte_outline_width, default=0,
        help="outer alpha outline in output pixels (0–32; default: 0, disabled)",
    )
    media_matte.add_argument(
        "--outline-color", type=matte_outline_color, default="#FFFFFF",
        help="outline color, #RRGGBB or #RRGGBBAA (default: #FFFFFF); quote the hex value",
    )
    media_matte.add_argument(
        "--quality",
        choices=("fast", "high"),
        default=None,
        help="fast (default): the built-in 192x192 segmentation, good for "
        "occlusion. high: hair-level alpha via the matting plugin "
        "(`oc plugin add matting`; GPU machine only, ~0.4s/frame)",
    )
    media_make_mask = media_commands.add_parser(
        "make-mask",
        help="Generate a geometric mask (rect / ellipse / linear gradient): a "
        "still PNG, or with --end-* and --frames an interpolated wipe video; "
        "feed it to apply-mask or timeline mask",
    )
    media_make_mask.add_argument(
        "--output", type=Path, required=True,
        help="where to write the mask: .png (static) or .mp4 (animated)",
    )
    media_make_mask.add_argument(
        "--like", type=Path, default=None,
        help="take canvas width/height from this media file",
    )
    media_make_mask.add_argument(
        "--size", type=size_argument, default=None,
        help="explicit canvas geometry as WxH, e.g. 1920x1080",
    )
    media_make_mask.add_argument(
        "--shape", choices=("rect", "ellipse", "linear"), required=True,
    )
    media_make_mask.add_argument(
        "--box", type=box_argument, default=None,
        help="rect: x,y,w,h in pixels",
    )
    media_make_mask.add_argument(
        "--center", type=pair_argument, default=None,
        help="ellipse: center as x,y",
    )
    media_make_mask.add_argument(
        "--radius", type=radius_argument, default=None,
        help="ellipse: radius as r (circle) or rx,ry",
    )
    media_make_mask.add_argument(
        "--angle", type=float, default=None,
        help="linear: gradient direction in degrees (0 = white on the left)",
    )
    media_make_mask.add_argument(
        "--position", type=float, default=None,
        help="linear: where the boundary sits along the gradient (0..1)",
    )
    media_make_mask.add_argument(
        "--softness", type=non_negative_float, default=None,
        help="edge softening band in pixels (default 0 = hard edge)",
    )
    media_make_mask.add_argument("--invert", action="store_true")
    media_make_mask.add_argument(
        "--end-box", type=box_argument, default=None,
        help="animate the rect toward this end state",
    )
    media_make_mask.add_argument("--end-center", type=pair_argument, default=None)
    media_make_mask.add_argument("--end-radius", type=radius_argument, default=None)
    media_make_mask.add_argument("--end-position", type=float, default=None)
    media_make_mask.add_argument(
        "--frames", type=positive_integer, default=None,
        help="animated mask length in frames (needs an --end-* parameter)",
    )
    media_make_mask.add_argument("--fps", type=non_negative_float, default=None)
    media_apply_mask = media_commands.add_parser(
        "apply-mask",
        help="Apply an external mask (a segment mask video or a still PNG) to a "
        "media file, producing a VP9 alpha WebM cutout - the blessed home of "
        "the alphamerge recipe",
    )
    media_apply_mask.add_argument("media_file", type=Path)
    media_apply_mask.add_argument(
        "--mask", type=Path, required=True,
        help="mask file: white=keep, black=transparent; a video is applied "
        "frame by frame, a still image covers the whole clip",
    )
    media_apply_mask.add_argument(
        "--output", type=Path, required=True,
        help="where to write the cutout; must end in .webm (VP9 is the only "
        "alpha-carrying encoding the renderer decodes)",
    )
    media_apply_mask.add_argument(
        "--feather", type=non_negative_float, default=None,
        help="edge softening in output pixels (default 2)",
    )
    media_apply_mask.add_argument(
        "--invert", action="store_true",
        help="keep what the mask blacks out instead: the masked region "
        "becomes transparent",
    )
    media_shots = media_commands.add_parser(
        "shots",
        help="[plugin: shots] Split footage into shots via TransNetV2 cut "
        "probabilities; the first step of teardown and commentary workflows",
    )
    media_shots.add_argument("media_file", type=Path)
    media_shots.add_argument("--threshold", type=non_negative_float, default=None)
    media_shots.add_argument(
        "--min-scene-frames", type=positive_integer, default=None,
        help="merge cuts closer than this many frames (default 8)",
    )
    media_segment = media_commands.add_parser(
        "segment",
        help="[plugin: segment] Track one prompted object through a clip via "
        "SAM 2.1: box or points on a prompt frame in, white-on-black mask "
        "video out (the maskVideo shape `media inpaint` consumes)",
    )
    media_segment.add_argument("media_file", type=Path)
    media_segment.add_argument(
        "--output", type=Path, required=True,
        help="where to write the mask video (.mp4, white object on black)",
    )
    media_segment.add_argument(
        "--box", type=box_argument, default=None,
        help="prompt box as x,y,w,h in source pixels on the prompt frame",
    )
    media_segment.add_argument(
        "--point", action="append", type=point_argument, default=None,
        dest="points",
        help="prompt point as x,y (repeatable); prefix neg: to mark background",
    )
    media_segment.add_argument(
        "--frame", type=non_negative_integer, default=None,
        help="prompt frame index (default 0); masks propagate both directions",
    )
    media_segment.add_argument(
        "--alpha", type=Path, default=None,
        help="also compose a VP9 alpha cutout (.webm) of the tracked object",
    )
    media_segment.add_argument(
        "--mask-png", type=Path, default=None,
        help="also save the prompt frame's mask as a PNG (the first-frame "
        "mask shape the matting pipeline consumes)",
    )
    media_segment.add_argument(
        "--max-frames", type=positive_integer, default=None,
        help="refuse clips longer than this many frames (default 3000)",
    )
    media_people = media_commands.add_parser(
        "people",
        help="[plugin: faces] Detect faces, embed identities, and cluster "
        "appearances into person-N timelines",
    )
    media_people.add_argument("media_file", type=Path)
    media_people.add_argument("--every-n-frames", type=positive_integer, default=None)
    media_people.add_argument(
        "--similarity", type=non_negative_float, default=None,
        help="cosine threshold for same-person clustering (default 0.45)",
    )
    media_people.add_argument("--max-frames", type=positive_integer, default=None)
    media_search_index = media_commands.add_parser(
        "search-index",
        help="[plugin: clip] Embed sampled frames once into an .npz index for "
        "Chinese-text shot retrieval",
    )
    media_search_index.add_argument("media_file", type=Path)
    media_search_index.add_argument("--index", type=Path, required=True)
    media_search_index.add_argument("--every-n-frames", type=positive_integer, default=None)
    media_search = media_commands.add_parser(
        "search",
        help="[plugin: clip] Find shots by Chinese text against a built index",
    )
    media_search.add_argument("text")
    media_search.add_argument("--index", type=Path, required=True)
    media_search.add_argument("--top-k", type=positive_integer, default=None)
    media_describe = media_commands.add_parser(
        "describe",
        help="[plugin: vl] Ask Qwen2.5-VL about one frame: content, quality, "
        "faces, composition",
    )
    media_describe.add_argument("--prompt", required=True)
    media_describe.add_argument("--video", type=Path, default=None)
    media_describe.add_argument("--frame", type=non_negative_integer, default=None)
    media_describe.add_argument("--image", type=Path, default=None)
    media_describe.add_argument("--max-new-tokens", type=positive_integer, default=None)
    media_upscale = media_commands.add_parser(
        "upscale",
        help="[plugin: upscale] Real-ESRGAN super-resolution: rescue low-res "
        "footage or stills on the GPU",
    )
    media_upscale.add_argument("media_file", type=Path)
    media_upscale.add_argument("--output", type=Path, required=True)
    media_upscale.add_argument("--scale", type=int, choices=(2, 3, 4), default=None)
    media_upscale.add_argument("--model", choices=("photo", "anime"), default=None)
    media_upscale.add_argument(
        "--still", action="store_true",
        help="treat the input as a single image instead of a video",
    )
    media_ocr = media_commands.add_parser(
        "ocr",
        help="[plugin: ocr] Read text out of a frame or image (PP-OCR): "
        "captions, title cards, watermarks",
    )
    media_ocr.add_argument("--image", type=Path, default=None)
    media_ocr.add_argument("--video", type=Path, default=None)
    media_ocr.add_argument("--frame", type=non_negative_integer, default=None)
    media_interp = media_commands.add_parser(
        "interp",
        help="[plugin: interp] RIFE optical-flow interpolation: 2x/4x smooth "
        "slow motion, the renderer-safe detour around speed curves",
    )
    media_interp.add_argument("media_file", type=Path)
    media_interp.add_argument("--output", type=Path, required=True)
    media_interp.add_argument("--factor", type=int, choices=(2, 4), default=2)
    media_genimage = media_commands.add_parser(
        "genimage",
        help="[plugin: gen-image] OpenAI Images compatible generation (metered "
        "billing): covers, cards, reference-guided edits",
    )
    media_genimage.add_argument("prompt")
    media_genimage.add_argument("--output", type=Path, required=True)
    media_genimage.add_argument(
        "--model", default=None, help="provider model identifier (default IMAGE_API_MODEL or gpt-image-1)",
    )
    media_genimage.add_argument("--size", default=None, help="WxH, default 1024x1024")
    media_genimage.add_argument(
        "--image", dest="images", action="append", default=[], metavar="REF",
        help="reference image, path or URL, max 3 (provider must support images/edits)",
    )
    media_fetch = media_commands.add_parser(
        "fetch",
        help="[plugin: fetch] Download source/reference media by URL via "
        "yt-dlp (1000+ sites incl. Douyin; watermark-free h264 by default)",
    )
    media_fetch.add_argument("url")
    media_fetch.add_argument(
        "--output", type=Path, default=None,
        help="destination file; extension steers container/transcode",
    )
    media_fetch.add_argument(
        "--cookies", type=Path, default=None,
        help="Netscape cookie jar (login-gated sites, e.g. Douyin)",
    )
    media_fetch.add_argument(
        "--cookies-from-browser", default=None,
        help="read cookies from a local browser profile on other sites; for Douyin use --cookies with a Netscape export",
    )
    media_fetch.add_argument(
        "--audio-only", action="store_true",
        help="best audio only; .wav/.mp3/.m4a/.flac/.opus output transcodes",
    )
    media_fetch.add_argument(
        "--format", default=None,
        help="raw yt-dlp format expression; overrides the h264 default",
    )
    media_fetch.add_argument(
        "--url-only", action="store_true",
        help="print the direct media URL(s) without downloading",
    )
    media_douyin_creator = media_commands.add_parser(
        "douyin-creator",
        help="[plugin: douyin] Resolve the author of a work/share URL or a public creator; no download or works listing",
    )
    media_douyin_creator.add_argument(
        "target", help="Douyin work/profile/share URL (or full share text), Douyin id, or sec_uid",
    )
    media_douyin_works = media_commands.add_parser(
        "douyin-works",
        help="[plugin: douyin] Resolve a public Douyin creator and list works; "
        "pass each returned shareUrl to media fetch when a file is needed",
    )
    media_douyin_works.add_argument(
        "target",
        help="Douyin work/profile/share URL (or full share text), Douyin id, or sec_uid",
    )
    media_douyin_works.add_argument(
        "--limit", type=positive_integer, default=None,
        help="maximum works to return, 1-200 (default 20)",
    )
    media_douyin_works.add_argument(
        "--cursor", default=None,
        help="numeric nextCursor from the previous page",
    )
    media_douyin_works.add_argument(
        "--cookies", type=Path, default=None,
        help="Netscape or Playwright JSON seed; uses an isolated managed session; platform renewals are encrypted and reused",
    )
    media_product = media_commands.add_parser(
        "product",
        help="[plugin: product] Snapshot a public product page (Douyin haohuo "
        "first) into a product pack: spec table, main/detail images, title, "
        "shop - facts only, judgment stays with the caller",
    )
    media_product.add_argument("url")
    media_product.add_argument(
        "--output-dir", type=Path, required=True,
        help="pack directory: images/ + product.json + raw-api.json",
    )
    media_product.add_argument(
        "--cookies", type=Path, default=None,
        help="Netscape cookie jar for login-walled pages (haohuo needs none)",
    )
    media_product.add_argument(
        "--max-images", type=int, default=None,
        help="cap downloads per image group (default: all)",
    )
    media_beats = media_commands.add_parser(
        "beats",
        help="Analyse an audio or video file's tempo: BPM, beat grid, downbeats, and the strongest onset moments",
    )
    media_beats.add_argument("media_file", type=Path)
    media_beats.add_argument(
        "--from-sec", type=float, default=None,
        help="analyse from this second (default: the whole file)",
    )
    media_beats.add_argument(
        "--to-sec", type=float, default=None,
        help="analyse up to this second",
    )
    media_beats.add_argument(
        "--top-hits", type=positive_integer, default=None,
        help="how many onset moments to return, strongest first (default 10)",
    )

    media_loudness = media_commands.add_parser(
        "loudness",
        help="Measure a file's integrated loudness (LUFS), true peak (dBTP) and loudness range over an optional time range — the number `audio volume` needs before it can be anything but a guess",
    )
    media_loudness.add_argument("media_file", type=Path)
    media_loudness.add_argument(
        "--from-sec", type=non_negative_float, default=None,
        help="start measuring at this second of the file (default: the start)",
    )
    media_loudness.add_argument(
        "--to-sec", type=non_negative_float, default=None,
        help="stop measuring at this second of the file (default: the end)",
    )
    media_silence = media_commands.add_parser(
        "silence",
        help="Measure where an audio or video file goes quiet: silence spans, what is left between them, and the track's own noise floor and speech level",
    )
    media_silence.add_argument("media_file", type=Path)
    media_silence.add_argument(
        "--threshold-db", type=float, default=None,
        help="below this dBFS counts as silent (default -35). Absolute, so check speechLevelDb before trusting the spans",
    )
    media_silence.add_argument(
        "--min-duration-sec", type=float, default=None,
        help="ignore quiet runs shorter than this (default 0.35: natural speech pauses are about this long)",
    )
    media_silence.add_argument(
        "--pad-ms", type=float, default=None,
        help="leave this much at each end of every span so a cut does not clip a consonant (default 0)",
    )

    media_analyze = media_commands.add_parser(
        "analyze",
        help="Measure a media file's motion without a Project",
    )
    media_analyze.add_argument("media_file", type=Path)
    media_analyze.add_argument(
        "--motion", action="store_true", required=True,
        help="mean absolute frame difference (signalstats-YDIF scale) overall "
             "and per second, plus a static/subtle/moving verdict — "
             "meanYdif < 2 is a dead shot, < 6 barely moves",
    )
    media_analyze.add_argument("--from-sec", type=float, default=None)
    media_analyze.add_argument("--to-sec", type=float, default=None)
    media_colorstats = media_commands.add_parser(
        "colorstats",
        help="Measure a media file's picture (brightness, saturation, warmth, skin share, contrast) "
        "with coarse verdict words; the look recommendation's evidence, no Project needed",
    )
    media_colorstats.add_argument("media_file", type=Path)
    media_colorstats.add_argument(
        "--every", type=positive_integer, default=None,
        help="sample one frame every N frames (default: about one frame per second)",
    )
    media_colorstats.add_argument("--from-sec", type=float, default=None, help="measure from this second")
    media_colorstats.add_argument("--to-sec", type=float, default=None, help="measure up to this second")

    media_letterbox = media_commands.add_parser(
        "letterbox",
        help="Scan a finished cut for top/bottom letterbox bars frame by frame",
    )
    media_letterbox.add_argument("media_file", type=Path)
    media_letterbox.add_argument(
        "--every", type=positive_integer, default=None,
        help="sample one frame every N frames (default 1: bars often show on a few endpoint frames only)",
    )
    media_letterbox.add_argument(
        "--source-dir", type=Path, default=None,
        help="directory of the source clips; enables the third test that tells a real bar from dark content sitting at the frame edge",
    )

    media_face_tracks = media_commands.add_parser(
        "face-tracks",
        help="Track faces through a media file with the bundled detector: per-face tracks with dense, padded, smoothed per-frame boxes — the geometry any cover (pixel or sticker) follows",
    )
    media_face_tracks.add_argument("media_file", type=Path)
    add_privacy_tracking_arguments(media_face_tracks)
    media_track = media_commands.add_parser(
        "track",
        help="Follow any object through a media file: draw a box on one reference frame (built-in template tracker, CPU, no plugin) or hand over a `media segment` mask video; returns the per-frame box in source pixels with lost frames marked",
    )
    media_track.add_argument("media_file", type=Path)
    add_object_track_arguments(media_track, source_pixels=True)
    media_track.add_argument(
        "--frame", type=non_negative_integer, default=None,
        help="source frame the --box is drawn on (default: --from-frame, or 0)",
    )
    media_track.add_argument("--from-frame", type=non_negative_integer, default=None, help="first source frame to track (default 0)")
    media_track.add_argument("--to-frame", type=positive_integer, default=None, help="exclusive end source frame (default: end of the file)")
    media_anonymize = media_commands.add_parser(
        "anonymize",
        help="Cover tracked faces (and manual regions) with blur, mosaic or a solid block; writes a frame-aligned silent derivation and rechecks it for faces that survived",
    )
    media_anonymize.add_argument("media_file", type=Path)
    media_anonymize.add_argument("--output", type=Path, required=True, help="derived video path (.mp4)")
    add_privacy_cover_arguments(media_anonymize)
    media_faces = media_commands.add_parser(
        "faces",
        help="Detect faces in a media file with the bundled detector: boxes, five landmarks, and a frame-labeled crops sheet",
    )
    media_faces.add_argument("media_file", type=Path)
    media_faces.add_argument(
        "--every", type=positive_integer, default=None,
        help="sample one frame every N frames (default 6)",
    )
    media_faces.add_argument(
        "--frames", type=frame_index_list, default=None,
        help="exactly these frame indices, comma separated",
    )
    media_faces.add_argument(
        "--face", type=non_negative_integer, default=None,
        help="write only this face (by index) as a native-resolution crop; pair with a single --frames entry",
    )
    media_faces.add_argument(
        "--output", type=Path, default=None,
        help="crops sheet (or single-face crop) path; defaults to a temporary file",
    )
    media_faces.add_argument(
        "--no-sheet", action="store_true",
        help="metadata only, skip rendering the crops sheet",
    )
    media_faces.add_argument(
        "--all", action="store_true",
        help="render every detected face; the default sheet shows only quality-flagged suspects",
    )

    media_subject = media_commands.add_parser(
        "subject",
        help="Measure where the subject sits in a frame: a segmentation box and centroid as percentages of the frame, plus pose keypoints when they are visible",
    )
    media_subject.add_argument("media_file", type=Path)
    media_subject.add_argument(
        "--every", type=positive_integer, default=None,
        help="sample one frame every N frames (default 1, i.e. a still image)",
    )
    media_subject.add_argument(
        "--frames", type=frame_index_list, default=None,
        help="exactly these frame indices, comma separated",
    )
    media_subject.add_argument(
        "--no-pose", action="store_true",
        help="segmentation only; skips the pose pass when you just need the box",
    )
    media_subject.add_argument(
        "--output-mask", type=Path, default=None,
        help="also write the segmentation mask; one sampled frame writes this file, several treat it as a directory named by frame index",
    )
    media_subject.add_argument(
        "--mask-full-resolution", action="store_true",
        help="upscale the mask to the source resolution; by default it comes out at the engine's own 192x192, which is also where the box's precision comes from",
    )

    media_align = media_commands.add_parser(
        "align",
        help="Rank candidate frames by how far their subject sits from a reference frame's, worst axis first",
    )
    media_align.add_argument("reference", type=Path)
    media_align.add_argument("candidates", type=Path, nargs="+")
    media_align.add_argument(
        "--no-pose", action="store_true",
        help="skip the pose pass; drops the arm-angle column",
    )

    track = commands.add_parser("track")
    track_commands = track.add_subparsers(dest="track_command", required=True)
    track_remove = track_commands.add_parser(
        "remove", help="Remove one unlocked timeline Track (empty, or whole with --with-content)"
    )
    track_remove.add_argument("track_id")
    track_remove.add_argument(
        "--with-content",
        action="store_true",
        help="Also remove every Clip and Caption on the Track in the same transaction",
    )
    track_remove.add_argument("--sequence-id")
    track_remove.add_argument("--intent", default=None)
    track_remove.add_argument("--base-revision", type=non_negative_integer)
    track_remove.add_argument("--idempotency-key")
    track_move = track_commands.add_parser(
        "move",
        help="Reorder one Track in the layer stack — track order IS the paint order (top = frontmost)",
    )
    track_move.add_argument("track_id")
    track_move_target = track_move.add_mutually_exclusive_group(required=True)
    track_move_target.add_argument("--to-top", action="store_true")
    track_move_target.add_argument("--to-bottom", action="store_true")
    track_move_target.add_argument("--above", metavar="TRACK_ID")
    track_move_target.add_argument("--below", metavar="TRACK_ID")
    track_move.add_argument("--sequence-id")
    track_move.add_argument("--intent", default=None)
    track_move.add_argument("--base-revision", type=non_negative_integer)
    track_move.add_argument("--idempotency-key")

    keyframe = commands.add_parser("keyframe")
    keyframe_commands = keyframe.add_subparsers(
        dest="keyframe_command", required=True
    )
    keyframe_commands.add_parser("list")
    upsert_keyframe = keyframe_commands.add_parser("upsert")
    add_keyframe_target_arguments(upsert_keyframe)
    upsert_keyframe.add_argument(
        "--property",
        choices=("position", "scale", "rotation_degrees", "opacity"),
        required=True,
    )
    upsert_keyframe.add_argument(
        "--at-frame", type=non_negative_integer, required=True
    )
    upsert_keyframe.add_argument("--x", type=exact_decimal_rational)
    upsert_keyframe.add_argument("--y", type=exact_decimal_rational)
    upsert_keyframe.add_argument("--value", type=exact_decimal_rational)
    upsert_keyframe.add_argument(
        "--easing",
        choices=("hold", "linear", "ease_in", "ease_out", "ease_in_out"),
        default="linear",
    )
    upsert_keyframe.add_argument("--keyframe-id")
    upsert_keyframe.add_argument("--intent", default="添加或更新视觉关键帧")
    upsert_keyframe.add_argument("--base-revision", type=non_negative_integer)
    upsert_keyframe.add_argument("--idempotency-key")
    remove_keyframe = keyframe_commands.add_parser("remove")
    add_keyframe_target_arguments(remove_keyframe)
    remove_keyframe.add_argument(
        "--property",
        choices=("position", "scale", "rotation_degrees", "opacity"),
        required=True,
    )
    remove_keyframe.add_argument("--keyframe-id", required=True)
    remove_keyframe.add_argument("--intent", default="删除视觉关键帧")
    remove_keyframe.add_argument("--base-revision", type=non_negative_integer)
    remove_keyframe.add_argument("--idempotency-key")
    clear_keyframes = keyframe_commands.add_parser("clear")
    add_keyframe_target_arguments(clear_keyframes)
    clear_keyframes.add_argument(
        "--property",
        choices=("position", "scale", "rotation_degrees", "opacity"),
    )
    clear_keyframes.add_argument("--intent", default="清除视觉关键帧")
    clear_keyframes.add_argument("--base-revision", type=non_negative_integer)
    clear_keyframes.add_argument("--idempotency-key")

    audio = commands.add_parser("audio")
    audio_commands = audio.add_subparsers(dest="audio_command", required=True)
    audio_speakers = audio_commands.add_parser(
        "speakers",
        help="[plugin: diarize] Who speaks when: segment dialogue into "
        "speaker_N timelines (CPU)",
    )
    audio_speakers.add_argument("media_file", type=Path)
    audio_speakers.add_argument("--num-speakers", type=positive_integer, default=None)
    audio_speakers.add_argument("--threshold", type=non_negative_float, default=None)
    audio_commands.add_parser("enhance-presets", help="Read bundled versioned voice-enhancement presets (no Project required)")
    audio_enhance = audio_commands.add_parser("enhance", help="Enhance a standalone voice file with bundled FFmpeg; waits for verified 48 kHz / 24-bit WAV")
    audio_enhance.add_argument("media_file", type=Path)
    audio_enhance.add_argument("--output", type=Path, required=True)
    audio_enhance.add_argument("--preset", default="natural")
    audio_enhance.add_argument("--noise-reduction", choices=("off", "standard", "strong"))
    audio_enhance.add_argument("--noise-engine", choices=("fft", "deepfilter"))
    audio_enhance.add_argument("--target-lufs", type=float)
    audio_enhance.add_argument("--denoise-db", type=float)
    audio_enhance.add_argument("--compression-ratio", type=float)
    audio_enhance.add_argument("--channels", default="preserve")
    audio_enhance.add_argument("--timeout-seconds", type=int, default=1800)
    audio_enhance.add_argument("--allow-reprocess", action="store_true")
    audio_enhance.add_argument("--no-wait", action="store_true", help="Return service-scoped task ID immediately")
    media_task = media_commands.add_parser("task", help="Observe or cancel independent media work")
    focus_cutout = media_commands.add_parser("focus-cutout", help="Prepare a prompted target alpha as a cancellable media task; leaves the Project unchanged")
    focus_cutout.add_argument("media_file", type=Path)
    focus_cutout.add_argument("--output", type=Path, required=True, help="New .png for images or .webm for videos; existing files are refused")
    focus_cutout.add_argument("--box", required=True, help="x,y,width,height in source pixels")
    focus_start = focus_cutout.add_mutually_exclusive_group()
    focus_start.add_argument("--from-sec", type=non_negative_float, default=0)
    focus_start.add_argument("--from-time", help="Exact source seconds as numerator/denominator, e.g. 4/15")
    focus_cutout.add_argument("--duration-sec", type=positive_float)
    focus_cutout.add_argument("--feather", type=non_negative_float, default=2)
    focus_cutout.add_argument("--no-wait", action="store_true")
    media_task_commands = media_task.add_subparsers(dest="media_task_command", required=True)
    media_task_commands.add_parser("list")
    for action in ("watch", "cancel"):
        task_parser = media_task_commands.add_parser(action)
        task_parser.add_argument("task_id")
        if action == "watch":
            task_parser.add_argument("--timeout-seconds", type=int, default=1800)
            task_parser.add_argument("--no-wait", action="store_true")
    audio_denoise = audio_commands.add_parser(
        "denoise",
        help="Clean narration via shared service media tasks with DeepFilterNet "
        "(CPU, real-time fast)",
    )
    audio_denoise.add_argument("media_file", type=Path)
    audio_denoise.add_argument("--output", type=Path, required=True)
    audio_index = audio_commands.add_parser(
        "index",
        help="[plugin: clap] Embed every audio file under a folder into a "
        "searchable .npz index (SFX/BGM library)",
    )
    audio_index.add_argument("directory", type=Path)
    audio_index.add_argument("--index", type=Path, required=True)
    audio_find = audio_commands.add_parser(
        "find",
        help="[plugin: clap] Find sounds/music by an ENGLISH text description "
        "against a built index (translate Chinese queries first)",
    )
    audio_find.add_argument("text")
    audio_find.add_argument("--index", type=Path, required=True)
    audio_find.add_argument("--top-k", type=positive_integer, default=None)
    audio_separate = audio_commands.add_parser(
        "separate",
        help="[plugin: vocal-sep] Split a mixed track into vocals / "
        "accompaniment (or four stems) with Demucs",
    )
    audio_separate.add_argument("media_file", type=Path)
    audio_separate.add_argument("--output-dir", type=Path, required=True)
    audio_separate.add_argument("--mode", choices=("two", "four"), default="two")
    audio_commands.add_parser(
        "list", help="List every sound Clip with its effective gain, pan and fades"
    )
    audio_duck = audio_commands.add_parser(
        "duck",
        help="Dip one Clip's level over given spans and lift it back — the "
        "background-music side of narration",
    )
    audio_duck.add_argument("clip_id")
    audio_duck.add_argument(
        "--over",
        type=Path,
        required=True,
        help='JSON file of spans to dip over: [{"atFrame": 0, "durationFrames": 48}]. '
        "Same shape as a `timeline place` cutlist",
    )
    audio_duck.add_argument(
        "--gain-percent",
        type=audio_gain_percent,
        default=None,
        help="level to dip to while a span runs (default 25). Absolute, same "
        "meaning as `oc audio volume --gain-percent`",
    )
    audio_duck.add_argument(
        "--fade-frames",
        type=non_negative_integer,
        default=None,
        help="frames to ramp down at each span's head and back up at its tail "
        "(default 6). A hard step reads as a mistake, not as ducking",
    )
    audio_duck.add_argument("--sequence-id")
    audio_duck.add_argument("--intent", default="解说压住背景音乐")
    audio_duck.add_argument("--base-revision", type=non_negative_integer)
    audio_duck.add_argument("--idempotency-key")
    audio_duck.add_argument("--dry-run", action="store_true")

    audio_loudness = audio_commands.add_parser(
        "loudness",
        help="Set or clear the integrated loudness the export normalizes to (LUFS)",
    )
    audio_loudness.add_argument(
        "--target-lufs",
        type=float,
        default=None,
        help="normalize the finished mix to this integrated loudness, e.g. -14 "
        "(streaming) or -16 (spoken word). Must be negative",
    )
    audio_loudness.add_argument(
        "--clear",
        action="store_true",
        help="stop normalizing and publish the mix as-is",
    )
    audio_loudness.add_argument("--sequence-id")
    audio_loudness.add_argument("--intent", default="设定出片响度目标")
    audio_loudness.add_argument("--base-revision", type=non_negative_integer)
    audio_loudness.add_argument("--idempotency-key")
    audio_loudness.add_argument("--dry-run", action="store_true")

    audio_measure = audio_commands.add_parser(
        "measure",
        help="Measure one sound Clip's loudness over exactly the source range it uses: integrated LUFS, true peak, and what it lands at after the Clip's own gain",
    )
    audio_measure.add_argument("clip_id")
    audio_measure.add_argument("--sequence-id")
    audio_level = audio_commands.add_parser(
        "level",
        help="Measure a sound Clip and set its gain so it lands on a target loudness — a LUFS figure, or the effective loudness of another Clip",
    )
    audio_level.add_argument("clip_id")
    level_target = audio_level.add_mutually_exclusive_group(required=True)
    level_target.add_argument(
        "--target-lufs", type=float, default=None,
        help="land the Clip on this integrated loudness (-16 suits narration, -14 a full mix, music under speech about -28)",
    )
    level_target.add_argument(
        "--like", metavar="CLIP_ID", default=None,
        help="land the Clip on the effective loudness (measured + its own gain) of this other Clip",
    )
    audio_level.add_argument(
        "--max-boost-db", type=non_negative_float, default=None,
        help="never raise the gain more than this many dB above the recorded level (default 12): a very quiet source is noise, not signal",
    )
    audio_level.add_argument("--sequence-id")
    audio_level.add_argument("--intent", default="把音量对齐到目标响度")
    audio_level.add_argument("--base-revision", type=non_negative_integer)
    audio_level.add_argument("--idempotency-key")
    audio_level.add_argument("--dry-run", action="store_true")
    audio_volume = audio_commands.add_parser("volume")
    audio_volume.add_argument("clip_id")
    audio_volume.add_argument(
        "--gain-percent",
        type=audio_gain_percent,
        help="100 keeps the recorded level, 50 halves it, 0 silences the Clip",
    )
    audio_volume.add_argument(
        "--pan-percent",
        type=audio_pan_percent,
        help="-100 is hard left, 0 centred, 100 hard right",
    )
    audio_volume.add_argument("--fade-in-frames", type=non_negative_integer)
    audio_volume.add_argument("--fade-out-frames", type=non_negative_integer)
    audio_volume.add_argument("--sequence-id")
    audio_volume.add_argument("--intent", default="调整音频音量")
    audio_volume.add_argument("--base-revision", type=non_negative_integer)
    audio_volume.add_argument("--idempotency-key")

    caption = commands.add_parser("caption")
    caption_commands = caption.add_subparsers(dest="caption_command", required=True)
    caption_commands.add_parser("list")
    add_caption = caption_commands.add_parser("add")
    add_caption.add_argument("text")
    add_caption.add_argument("--at-frame", type=non_negative_integer, required=True)
    add_caption.add_argument(
        "--duration-frames", type=positive_integer, required=True
    )
    add_caption.add_argument(
        "--emphasis",
        action="append",
        default=[],
        metavar="TEXT=#RRGGBB",
        help="colour every occurrence of TEXT in this caption for its whole "
        "life; repeatable; TEXT must appear in the caption text",
    )
    add_caption.add_argument("--sequence-id")
    add_caption.add_argument("--track-id")
    add_caption.add_argument("--intent", default="添加字幕")
    add_caption.add_argument("--base-revision", type=non_negative_integer)
    add_caption.add_argument("--idempotency-key")
    add_text_style_arguments(add_caption, patch=False)
    add_caption_batch = caption_commands.add_parser(
        "add-batch",
        help="Add every Caption in one JSON file under one shared style and one undo step",
    )
    add_caption_batch.add_argument(
        "--file",
        type=Path,
        required=True,
        help='JSON array of {"text", "startFrame", "durationFrames"}, or an object with a "captions" array',
    )
    add_caption_batch.add_argument("--sequence-id")
    add_caption_batch.add_argument("--track-id")
    add_caption_batch.add_argument("--intent", default="批量添加字幕")
    add_caption_batch.add_argument("--base-revision", type=non_negative_integer)
    add_caption_batch.add_argument("--idempotency-key")
    add_text_style_arguments(add_caption_batch, patch=False)
    import_srt = caption_commands.add_parser(
        "import-srt",
        help="Turn an .srt transcript into one atomic Caption batch under one shared style",
    )
    import_srt.add_argument("--file", type=Path, required=True)
    import_srt.add_argument(
        "--offset-frames",
        type=int,
        default=0,
        help="Shift every cue by this many frames; negative pulls the transcript earlier",
    )
    import_srt.add_argument(
        "--words",
        type=Path,
        help=(
            "`oc media transcribe --json` 的输出;把字级时间随字幕一起存进工程,"
            "配合 --highlight word 即为逐字高亮"
        ),
    )
    import_srt.add_argument("--sequence-id")
    import_srt.add_argument("--track-id")
    import_srt.add_argument("--intent", default="导入 SRT 字幕")
    import_srt.add_argument("--base-revision", type=non_negative_integer)
    import_srt.add_argument("--idempotency-key")
    add_text_style_arguments(import_srt, patch=False)
    update_caption = caption_commands.add_parser("update")
    update_caption.add_argument("caption_id")
    update_caption.add_argument("--text")
    update_caption.add_argument("--start-frame", type=non_negative_integer)
    update_caption.add_argument("--end-frame", type=positive_integer)
    update_caption.add_argument(
        "--emphasis",
        action="append",
        default=[],
        metavar="TEXT=#RRGGBB",
        help="replace the caption's emphasis set with these entries",
    )
    update_caption.add_argument(
        "--clear-emphases",
        action="store_true",
        help="remove every emphasis from the caption",
    )
    update_caption.add_argument(
        "--clear-tokens",
        action="store_true",
        help="drop the caption's per-word highlight timings explicitly",
    )
    update_caption.add_argument("--sequence-id")
    update_caption.add_argument("--intent", default="修改字幕")
    update_caption.add_argument("--base-revision", type=non_negative_integer)
    update_caption.add_argument("--idempotency-key")
    add_text_style_arguments(update_caption, patch=True)
    move_caption = caption_commands.add_parser(
        "move", help="Move one Caption to another Caption Track and/or exact start frame"
    )
    move_caption.add_argument("caption_id")
    move_caption.add_argument("--to-track", metavar="TRACK_ID", required=True)
    move_caption.add_argument("--to-frame", type=non_negative_integer)
    move_caption.add_argument("--sequence-id")
    move_caption.add_argument("--intent", default=None)
    move_caption.add_argument("--base-revision", type=non_negative_integer)
    move_caption.add_argument("--idempotency-key")
    remove_caption = caption_commands.add_parser("remove")
    remove_caption.add_argument("caption_id")
    remove_caption.add_argument("--sequence-id")
    remove_caption.add_argument("--intent", default="删除字幕")
    remove_caption.add_argument("--base-revision", type=non_negative_integer)
    remove_caption.add_argument("--idempotency-key")

    sticker = commands.add_parser("sticker")
    sticker_commands = sticker.add_subparsers(dest="sticker_command", required=True)
    sticker_commands.add_parser("list")
    sticker_commands.add_parser(
        "presets", help="List every text sticker preset this OrangeCut build offers"
    )
    add_sticker = sticker_commands.add_parser("add")
    add_sticker.add_argument("text")
    add_sticker.add_argument("--at-frame", type=non_negative_integer, required=True)
    add_sticker.add_argument(
        "--duration-frames", type=positive_integer, required=True
    )
    add_sticker.add_argument("--sequence-id")
    add_sticker.add_argument("--track-id")
    add_sticker.add_argument(
        "--sfx",
        help="sound effect for the sticker's entrance: an id or kind from "
        "`oc sfx list`, or `none`. Defaults follow the entrance animation "
        "(pop→pop, zoom→impact, bounce→boing, slide→whoosh; fade/none stay "
        "silent)",
    )
    add_sticker.add_argument("--intent", default="添加文字贴纸")
    add_sticker.add_argument("--base-revision", type=non_negative_integer)
    add_sticker.add_argument("--idempotency-key")
    add_text_sticker_arguments(add_sticker, include_font=True)
    update_sticker = sticker_commands.add_parser("update")
    update_sticker.add_argument("clip_id")
    update_sticker.add_argument("--text")
    update_sticker.add_argument("--start-frame", type=non_negative_integer)
    update_sticker.add_argument("--end-frame", type=positive_integer)
    update_sticker.add_argument("--sequence-id")
    update_sticker.add_argument("--intent", default="修改文字贴纸")
    update_sticker.add_argument("--base-revision", type=non_negative_integer)
    update_sticker.add_argument("--idempotency-key")
    update_sticker.add_argument(
        "--reset-placement",
        action="store_true",
        help="with --preset: also reset position/scale/rotation/opacity and "
             "entrance/exit animation to the preset's seed (by default both stay unchanged)",
    )
    add_text_sticker_arguments(update_sticker, include_font=False)
    remove_sticker = sticker_commands.add_parser("remove")
    remove_sticker.add_argument("clip_id")
    remove_sticker.add_argument("--sequence-id")
    remove_sticker.add_argument("--intent", default="删除文字贴纸")
    remove_sticker.add_argument("--base-revision", type=non_negative_integer)
    remove_sticker.add_argument("--idempotency-key")

    shape = commands.add_parser("shape")
    shape_commands = shape.add_subparsers(dest="shape_command", required=True)
    shape_commands.add_parser("list")
    add_shape = shape_commands.add_parser("add")
    add_shape.add_argument(
        "kind", choices=("rectangle", "square", "ellipse", "circle", "triangle")
    )
    add_shape.add_argument("--at-frame", type=non_negative_integer, required=True)
    add_shape.add_argument(
        "--duration-frames", type=positive_integer, required=True
    )
    add_shape.add_argument("--sequence-id")
    add_shape.add_argument("--track-id")
    add_shape.add_argument("--intent", default="添加形状图层")
    add_shape.add_argument("--base-revision", type=non_negative_integer)
    add_shape.add_argument("--idempotency-key")
    add_shape_arguments(add_shape, include_kind=True)
    update_shape = shape_commands.add_parser("update")
    update_shape.add_argument("clip_id")
    update_shape.add_argument("--start-frame", type=non_negative_integer)
    update_shape.add_argument("--end-frame", type=positive_integer)
    update_shape.add_argument("--sequence-id")
    update_shape.add_argument("--intent", default="修改形状图层")
    update_shape.add_argument("--base-revision", type=non_negative_integer)
    update_shape.add_argument("--idempotency-key")
    add_shape_arguments(update_shape, include_kind=False)
    remove_shape = shape_commands.add_parser("remove")
    remove_shape.add_argument("clip_id")
    remove_shape.add_argument("--sequence-id")
    remove_shape.add_argument("--intent", default="删除形状图层")
    remove_shape.add_argument("--base-revision", type=non_negative_integer)
    remove_shape.add_argument("--idempotency-key")

    undo = commands.add_parser("undo")
    undo.add_argument("--intent", default="撤销上一次编辑")
    undo.add_argument("--base-revision", type=non_negative_integer)
    undo.add_argument("--idempotency-key")
    redo = commands.add_parser("redo")
    redo.add_argument("--intent", default="重做上一次编辑")
    redo.add_argument("--base-revision", type=non_negative_integer)
    redo.add_argument("--idempotency-key")

    command = commands.add_parser("command")
    command_commands = command.add_subparsers(dest="command_command", required=True)
    apply_command = command_commands.add_parser("apply")
    request_source = apply_command.add_mutually_exclusive_group(required=True)
    request_source.add_argument("--file", type=Path)
    request_source.add_argument("--stdin", action="store_true")
    apply_command.add_argument("--dry-run", action="store_true")
    apply_command.add_argument(
        "--intent",
        help="fills the batch's intent when the JSON leaves it out",
    )

    proposal = commands.add_parser("proposal")
    proposal_commands = proposal.add_subparsers(dest="proposal_command", required=True)
    proposal_create = proposal_commands.add_parser("create")
    proposal_source = proposal_create.add_mutually_exclusive_group(required=True)
    proposal_source.add_argument("--file", type=Path)
    proposal_source.add_argument("--stdin", action="store_true")
    proposal_commands.add_parser("list")
    proposal_status = proposal_commands.add_parser("status")
    proposal_status.add_argument("proposal_id")
    proposal_cancel = proposal_commands.add_parser("cancel")
    proposal_cancel.add_argument("proposal_id")

    event = commands.add_parser("event")
    event_commands = event.add_subparsers(dest="event_command", required=True)
    event_watch = event_commands.add_parser("watch")
    event_watch.add_argument("--count", type=positive_integer, default=1)
    event_watch.add_argument("--timeout-seconds", type=positive_float, default=30.0)
    event_watch.add_argument("--cursor")

    export = commands.add_parser("export")
    export_commands = export.add_subparsers(dest="export_command", required=True)
    export_start = export_commands.add_parser("start")
    export_start.add_argument("--output", type=Path, required=True)
    export_start.add_argument("--sequence-id")
    export_start.add_argument(
        "--preset",
        choices=("compact", "publish", "preview"),
        default="publish",
        help="publish = full quality; compact = fast draft; preview = compact "
             "plus a high crf so a vertical minute lands well under ~20MB for "
             "sending to a phone — no external re-compress step",
    )
    export_start.add_argument(
        "--fps",
        type=export_frame_rate,
        help="An integer (30) or an exact ratio (30000/1001); never a decimal",
    )
    export_start.add_argument(
        "--crf",
        type=export_crf,
        help="Constant rate factor 0-63; lower looks better and weighs more",
    )
    export_start.add_argument("--bitrate-kbps", type=positive_integer)
    export_start.add_argument("--gpu", action=argparse.BooleanOptionalAction, default=None,
                              help="Request capability-probed GPU video encoding for this export; --no-gpu explicitly requests CPU")
    export_start.add_argument("--from-frame", type=non_negative_integer,
                              help="区间导出起点帧(含);缺省=0。两端都缺省即全量导出")
    export_start.add_argument("--to-frame", type=positive_integer,
                              help="区间导出终点帧(不含);缺省=片尾")
    export_start.add_argument("--intent", default="导出当前时间线")
    export_start.add_argument("--idempotency-key")

    # Every way of looking at the timeline is one command with parameters. An
    # Agent that has to pick between `oc frame`, `oc frames`, `oc range` and
    # `oc contact-sheet` spends its attention on the CLI instead of the edit.
    marker = commands.add_parser(
        "marker",
        help="Put named points on the sequence: chapters, review notes, beats",
    )
    marker_commands = marker.add_subparsers(dest="marker_command", required=True)
    marker_commands.add_parser("list", help="List every marker with its time").add_argument(
        "--sequence-id"
    )
    marker_add = marker_commands.add_parser("add", help="Add one marker at an exact frame")
    marker_add.add_argument("label")
    marker_add.add_argument("--at-frame", type=non_negative_integer, required=True)
    marker_add.add_argument("--marker-id", help="explicit id; omitted generates one")
    marker_add.add_argument("--sequence-id")
    marker_add.add_argument("--intent", default="添加序列标记")
    marker_add.add_argument("--base-revision", type=non_negative_integer)
    marker_add.add_argument("--idempotency-key")
    marker_update = marker_commands.add_parser(
        "update", help="Move a marker and/or relabel it"
    )
    marker_update.add_argument("marker_id")
    marker_update.add_argument("--label")
    marker_update.add_argument("--at-frame", type=non_negative_integer)
    marker_update.add_argument("--sequence-id")
    marker_update.add_argument("--intent", default="调整序列标记")
    marker_update.add_argument("--base-revision", type=non_negative_integer)
    marker_update.add_argument("--idempotency-key")
    marker_remove = marker_commands.add_parser("remove", help="Remove one marker")
    marker_remove.add_argument("marker_id")
    marker_remove.add_argument("--sequence-id")
    marker_remove.add_argument("--intent", default="移除序列标记")
    marker_remove.add_argument("--base-revision", type=non_negative_integer)
    marker_remove.add_argument("--idempotency-key")

    layout = commands.add_parser(
        "layout",
        help="Check what the visible layers do to each other on screen",
    )
    layout_commands = layout.add_subparsers(dest="layout_command", required=True)
    layout_check = layout_commands.add_parser(
        "check",
        help="Find captions, stickers and components that overlap on screen at the same time",
    )
    layout_check.add_argument(
        "--min-overlap",
        type=float,
        default=0.12,
        help="report a pair when this fraction of the smaller box is covered (default 0.12)",
    )
    layout_check.add_argument(
        "--at-frame",
        type=non_negative_integer,
        help="only consider elements on screen at this frame",
    )
    layout_check.add_argument(
        "--from-frame",
        type=non_negative_integer,
        help="with --to-frame: consider every element on screen anywhere in "
             "[from, to) — one call instead of an --at-frame loop",
    )
    layout_check.add_argument(
        "--to-frame",
        type=non_negative_integer,
        help="end (exclusive) of the --from-frame range",
    )
    layout_check.add_argument(
        "--near",
        type=float,
        help="also report pairs closer than this many canvas px as a notice "
             "(default 1.5%% of the short edge; 0 disables)",
    )
    layout_check.add_argument("--sequence-id")
    layout_check.add_argument("--human", action="store_true", help="Print a readable layout report instead of JSON")
    layout_commands.add_parser(
        "list", help="List every visible element with its box on the canvas"
    ).add_argument("--sequence-id")

    read = commands.add_parser(
        "read",
        help="Read composited frames of the edited sequence as one image",
    )
    # Not an argparse mutually-exclusive group: `--range` is a region on its own
    # but also narrows `--at-edits`, which a group cannot express. read_selection
    # enforces the real rule and can say which flags collided.
    read.add_argument(
        "--at",
        type=exact_decimal_rational,
        help="the single frame on screen at this instant, in seconds",
    )
    read.add_argument(
        "--frames",
        type=frame_index_list,
        help="exactly these frame indices, comma separated, in this order",
    )
    read.add_argument(
        "--at-edits",
        action="store_true",
        help="the instants the edit structure makes meaningful",
    )
    read.add_argument(
        "--range",
        dest="range_",
        type=exact_decimal_range,
        help="a half-open START:END second range; sample it with --count or --every, or narrow --at-edits with it",
    )
    read_density = read.add_mutually_exclusive_group()
    read_density.add_argument(
        "--count",
        type=positive_integer,
        help="with --range: this many frames spread evenly across it",
    )
    read_density.add_argument(
        "--every",
        type=positive_integer,
        help="with --range: one frame every this many frames",
    )
    read.add_argument(
        "--detail",
        choices=("thumbnail", "full"),
        default="thumbnail",
        help="thumbnail fits a width budget; full keeps the composition's own pixels",
    )
    read.add_argument("--sequence-id")
    read.add_argument(
        "--output",
        type=Path,
        help="where to write the sheet; defaults to a temporary file",
    )
    read.add_argument("--timeout-seconds", type=read_timeout_seconds, default=180.0)

    feedback = commands.add_parser(
        "feedback",
        help="Append a product feedback note to the local log the OC side "
             "harvests (a bug you had to work around, a missing capability, "
             "a misleading error)",
    )
    feedback.add_argument(
        "text", help="what happened, and what you did instead — one honest sentence beats a form"
    )
    feedback.add_argument(
        "--repro", default=None, help="minimal reproduction: commands, ids, media traits"
    )

    job = commands.add_parser("job")
    job_commands = job.add_subparsers(dest="job_command", required=True)
    job_commands.add_parser("list")
    job_watch = job_commands.add_parser("watch")
    job_watch.add_argument("job_id")
    # 名字叫 watch 就该等:此前不带 --until-terminal 只拍一张快照就返回,
    # 调用方以为等完了,实际导出还在 96/660 帧——真踩过。等待改为默认,
    # --until-terminal 保留为兼容空操作,要旧行为用 --no-wait。
    job_watch.add_argument(
        "--until-terminal", action="store_true", help=argparse.SUPPRESS
    )
    job_watch.add_argument(
        "--no-wait",
        action="store_true",
        help="return one snapshot immediately instead of waiting for a terminal state",
    )
    job_watch.add_argument(
        "--timeout-seconds",
        type=positive_float,
        default=300.0,
        help="how long to wait, at most 300 (a longer wait is refused, not clamped); "
        "for an export that outlives it, call watch again — JOB_WATCH_TIMEOUT "
        "means 'still running', not failure",
    )
    job_cancel = job_commands.add_parser("cancel")
    job_cancel.add_argument("job_id")
    job_collect = job_commands.add_parser("collect")
    job_collect.add_argument("job_id")
    job_retry = job_commands.add_parser("retry")
    job_retry.add_argument("job_id")
    job_retry.add_argument("--idempotency-key")
    return root


def execute(arguments: argparse.Namespace) -> dict[str, Any]:
    if arguments.command == "cutaway" and arguments.cutaway_command == "list":
        # The bundled registry is static; listing it needs no running service.
        return {
            "schemaVersion": SCHEMA_VERSION,
            "ok": True,
            "data": {
                "source": "bundled",
                "modes": list(CUTAWAY_MODES),
                "cutaways": [dict(entry) for entry in BUNDLED_CUTAWAY_MANIFEST],
            },
        }
    if arguments.command == "sfx" and arguments.sfx_command == "list":
        # The registry is a local file; listing it needs no running service.
        entries = load_sfx_library()
        return {
            "schemaVersion": SCHEMA_VERSION,
            "ok": True,
            "data": {
                "source": "custom" if sfx_library_dir() else "bundled",
                "directory": str(sfx_library_dir()) if sfx_library_dir() else None,
                "sfx": [
                    {"id": entry["id"], "kind": entry["kind"],
                     **({"file": entry["file"]} if entry.get("file") else {}),
                     **({"assetId": entry["assetId"]} if entry.get("assetId") else {}),
                     **({"label": entry["label"]} if entry.get("label") else {}),
                     **({"use": entry["use"]} if entry.get("use") else {})}
                    for entry in entries
                ],
            },
        }
    if arguments.command == "feedback":
        # 纯本地追加,不碰服务:反馈的价值在于"绕过的那一刻"顺手记一笔,
        # 要是还得等服务在线,坑就白踩了。产品方定期收割这个文件——
        # 垂直场景踩的坑就是这样变成泛化修复的(2026-09 那轮 22 条全部
        # 落地,源头正是一份这样的清单)。
        root = app_data_root()
        path = root / "feedback.md"
        stamp = time.strftime("%Y-%m-%d %H:%M")
        project = os.environ.get("ORANGECUT_PROJECT") or ""
        entry = "- **{}**{} {}\n".format(
            stamp, f" [{project}]" if project else "", arguments.text.strip()
        )
        if arguments.repro:
            entry += f"  - 复现: {arguments.repro.strip()}\n"
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "a", encoding="utf-8") as handle:
                handle.write(entry)
        except OSError as error:
            raise CliFailure(
                "FEEDBACK_WRITE_FAILED",
                "runtime",
                f"cannot append to {path}: {error}",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
            ) from error
        return {"recorded": True, "path": str(path)}
    if arguments.command == "html" and arguments.html_command == "compile":
        # 纯转换,不碰工程也不碰服务:作者手上是 markup,组件里存的是类型化节点
        # 树,中间这一步不该逼每个调用方自己实现一遍(SVG 大小写、id→class、
        # style→styles、裸文本包 span 的规则都在这里)。
        root, stylesheet = parse_html_fragment(arguments.html_file.read_text(encoding="utf-8"))
        return {
            "componentType": "dev.orangecut.html",
            "capabilityRequirements": ["dev.orangecut.component.html"],
            "properties": {"root": root, "stylesheet": stylesheet},
        }
    if arguments.command == "status":
        _, response = discover_client(require_project=False)
        return response
    if arguments.command == "license":
        client, _ = discover_client(require_project=False)
        response = client.request("GET", "/v1/license")
        if not response.get("ok"):
            return response
        status = require_object(response, "data")
        if status.get("tier") not in ("community", "pro"):
            raise CliFailure(
                "LICENSE_STATUS_INVALID", "serialization",
                "授权分级缺失或不受支持；请更新 OrangeCut，勿猜测 Pro 权限",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
            )
        pro = status["tier"] == "pro"
        return {**response, "data": {**status, "capabilities": {
            "projectEditing": True, "realtimePreview": True,
            "builtinAsr": True, "fonts": True, "cpuExportUpTo1080p": True,
            "advancedOcpPlugins": pro, "gpuEncoding": pro,
            "exportAbove1080p": pro,
        }}}
    if arguments.command == "plugin" and arguments.plugin_command == "ls":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        response = client.request("GET", "/v1/plugins")
        if arguments.name is not None and response.get("ok"):
            rows = response.get("data") or []
            match = [row for row in rows if row.get("name") == arguments.name]
            if not match:
                known = ", ".join(sorted(row.get("name", "?") for row in rows))
                raise CliFailure(
                    "PLUGIN_UNKNOWN",
                    "preconditions",
                    f"no plugin named {arguments.name!r} exists",
                    remediation=f"known plugins: {known}",
                )
            response["data"] = match[0]
        return response
    if arguments.command == "plugin" and arguments.plugin_command == "add":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload = {"force": True} if arguments.force else {}
        started = client.request(
            "POST", f"/v1/plugins/{arguments.name}/install", payload, timeout_seconds=120
        )
        if (started.get("data") or {}).get("status") == "ready":
            return started
        # 安装在服务端后台线程里跑,这里轮询 ls 把进度画到 stderr。
        # Ctrl-C/断网都不算事故:重跑 add 从上个完成的步骤续。
        deadline = time.time() + 4 * 3600
        last_line = None
        while time.time() < deadline:
            rows = client.request("GET", "/v1/plugins").get("data") or []
            row = next((r for r in rows if r.get("name") == arguments.name), None)
            if row is None:
                break
            status = row.get("status")
            if status in ("ready", "dev_override"):
                return envelope({"data": row})
            if status == "broken":
                raise CliFailure(
                    "PLUGIN_INSTALL_FAILED",
                    "media",
                    row.get("reason") or "the install failed",
                    remediation="rerun `oc plugin add` to resume from the last completed step",
                )
            line = (
                f"{row.get('progressStep') or status} "
                f"{row.get('progressPercent') or 0}% "
                f"{row.get('progressDetail') or ''}"
            ).strip()
            if line != last_line:
                print(line, file=sys.stderr)
                last_line = line
            time.sleep(3)
        raise CliFailure(
            "PLUGIN_INSTALL_FAILED",
            "media",
            f"{arguments.name} did not reach ready before the client stopped waiting",
            remediation="rerun `oc plugin add` to resume from the last completed step",
        )
    if arguments.command == "media" and arguments.media_command == "shots":
        payload = {"input": str(absolute_media_path(arguments.media_file))}
        if arguments.threshold is not None:
            payload["threshold"] = arguments.threshold
        if arguments.min_scene_frames is not None:
            payload["minSceneFrames"] = arguments.min_scene_frames
        # 900s 曾在 99 分钟长片上被墙钟杀掉(TransNetV2 全帧解码),放宽到一部长片的安全余量。
        return plugin_invoke("shots", payload, 5400)
    if arguments.command == "media" and arguments.media_command == "segment":
        if (arguments.box is None) == (not arguments.points):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "pass exactly one prompt: --box x,y,w,h or one or more --point",
                remediation="describe the object on the prompt frame with either "
                "a box or points, not both and not neither",
            )
        payload = {
            "video": str(absolute_media_path(arguments.media_file)),
            "outputPath": str(arguments.output.expanduser().resolve()),
        }
        if arguments.box is not None:
            payload["box"] = arguments.box
        if arguments.points:
            payload["points"] = [[x, y] for x, y, _ in arguments.points]
            payload["labels"] = [label for _, _, label in arguments.points]
        if arguments.frame is not None:
            payload["frame"] = arguments.frame
        if arguments.alpha is not None:
            payload["alphaPath"] = str(arguments.alpha.expanduser().resolve())
        if arguments.mask_png is not None:
            payload["maskPngPath"] = str(arguments.mask_png.expanduser().resolve())
        if arguments.max_frames is not None:
            payload["maxFrames"] = arguments.max_frames
        # 帧抽取 + 逐帧传播:量级与 matting 同档(约 0.2-0.5s/帧),给到
        # 3000 帧上限片长的余量。
        return plugin_invoke("segment", payload, 3600)
    if arguments.command == "media" and arguments.media_command == "people":
        payload = {"input": str(absolute_media_path(arguments.media_file))}
        if arguments.every_n_frames is not None:
            payload["everyNFrames"] = arguments.every_n_frames
        if arguments.similarity is not None:
            payload["similarity"] = arguments.similarity
        if arguments.max_frames is not None:
            payload["maxFrames"] = arguments.max_frames
        return plugin_invoke("faces", payload, 1800)
    if arguments.command == "media" and arguments.media_command == "search-index":
        payload = {
            "mode": "index",
            "input": str(absolute_media_path(arguments.media_file)),
            "indexPath": str(arguments.index.expanduser().resolve()),
        }
        if arguments.every_n_frames is not None:
            payload["everyNFrames"] = arguments.every_n_frames
        return plugin_invoke("clip", payload, 3600)
    if arguments.command == "media" and arguments.media_command == "search":
        payload = {
            "mode": "query",
            "text": arguments.text,
            "indexPath": str(arguments.index.expanduser().resolve()),
        }
        if arguments.top_k is not None:
            payload["topK"] = arguments.top_k
        return plugin_invoke("clip", payload, 600)
    if arguments.command == "media" and arguments.media_command == "genimage":
        payload = {
            "prompt": arguments.prompt,
            "outputPath": str(arguments.output.expanduser().resolve()),
        }
        if arguments.model is not None:
            payload["model"] = arguments.model
        if arguments.size is not None:
            payload["size"] = arguments.size
        if arguments.images:
            payload["images"] = [
                ref if ref.startswith(("http://", "https://", "data:"))
                else str(absolute_media_path(Path(ref)))
                for ref in arguments.images
            ]
        return plugin_invoke("gen-image", payload, 900)
    if arguments.command == "media" and arguments.media_command == "fetch":
        payload = {"url": arguments.url}
        if arguments.url_only:
            payload["urlOnly"] = True
        elif arguments.output is None:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "--output is required unless --url-only",
            )
        if arguments.output is not None:
            payload["outputPath"] = str(arguments.output.expanduser().resolve())
        if arguments.cookies is not None:
            payload["cookiesFile"] = str(absolute_media_path(arguments.cookies))
        if arguments.cookies_from_browser is not None:
            payload["cookiesFromBrowser"] = arguments.cookies_from_browser
        if arguments.audio_only:
            payload["audioOnly"] = True
        if arguments.format is not None:
            payload["format"] = arguments.format
        return plugin_invoke("fetch", payload, 1800)
    if arguments.command == "media" and arguments.media_command == "douyin-creator":
        return plugin_invoke("douyin", {"target": arguments.target, "mode": "creator"}, 600)
    if arguments.command == "media" and arguments.media_command == "douyin-works":
        payload = {"target": arguments.target}
        if arguments.cookies is not None:
            # A previously enrolled seed may have been removed. The plugin
            # validates a new seed, or restores its protected identity slot.
            payload["cookiesFile"] = str(arguments.cookies.expanduser().resolve())
        if arguments.limit is not None:
            if arguments.limit > 200:
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID", "validation", "--limit must be from 1 to 200",
                )
            payload["limit"] = arguments.limit
        if arguments.cursor is not None:
            if not arguments.cursor.isdigit():
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID", "validation", "--cursor must be numeric",
                )
            payload["cursor"] = arguments.cursor
        return plugin_invoke("douyin", payload, 600)
    if arguments.command == "media" and arguments.media_command == "product":
        payload = {
            "url": arguments.url,
            "outputDir": str(arguments.output_dir.expanduser().resolve()),
        }
        if arguments.cookies is not None:
            payload["cookiesFile"] = str(absolute_media_path(arguments.cookies))
        if arguments.max_images is not None:
            payload["maxImages"] = arguments.max_images
        return plugin_invoke("product", payload, 600)
    if arguments.command == "media" and arguments.media_command == "describe":
        if (arguments.image is None) == (arguments.video is None):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "pass exactly one of --image or --video (with --frame)",
            )
        payload = {"prompt": arguments.prompt}
        if arguments.image is not None:
            payload["image"] = str(absolute_media_path(arguments.image))
        else:
            if arguments.frame is None:
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID", "validation",
                    "--video needs --frame to pick the frame to look at",
                )
            payload["video"] = str(absolute_media_path(arguments.video))
            payload["frame"] = arguments.frame
        if arguments.max_new_tokens is not None:
            payload["maxNewTokens"] = arguments.max_new_tokens
        return plugin_invoke("vl", payload, 1800)
    if arguments.command == "media" and arguments.media_command == "upscale":
        payload = {"outputPath": str(arguments.output.expanduser().resolve())}
        key = "image" if arguments.still else "video"
        payload[key] = str(absolute_media_path(arguments.media_file))
        if arguments.scale is not None:
            payload["scale"] = arguments.scale
        if arguments.model is not None:
            payload["model"] = arguments.model
        return plugin_invoke("upscale", payload, 3600)
    if arguments.command == "media" and arguments.media_command == "ocr":
        if (arguments.image is None) == (arguments.video is None):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "pass exactly one of --image or --video (with --frame)",
            )
        payload = {}
        if arguments.image is not None:
            payload["image"] = str(absolute_media_path(arguments.image))
        else:
            if arguments.frame is None:
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID", "validation",
                    "--video needs --frame",
                )
            payload["video"] = str(absolute_media_path(arguments.video))
            payload["frame"] = arguments.frame
        return plugin_invoke("ocr", payload, 600)
    if arguments.command == "media" and arguments.media_command == "interp":
        payload = {
            "input": str(absolute_media_path(arguments.media_file)),
            "outputPath": str(arguments.output.expanduser().resolve()),
            "factor": arguments.factor,
        }
        return plugin_invoke("interp", payload, 3600)
    if arguments.command == "audio" and arguments.audio_command == "speakers":
        payload = {"input": str(absolute_media_path(arguments.media_file))}
        if arguments.num_speakers is not None:
            payload["numSpeakers"] = arguments.num_speakers
        if arguments.threshold is not None:
            payload["threshold"] = arguments.threshold
        return plugin_invoke("diarize", payload, 5400)
    if arguments.command == "audio" and arguments.audio_command in ("enhance", "enhance-presets"):
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        if arguments.audio_command == "enhance-presets":
            return client.request("GET", "/v1/media/audio-enhance/presets")
        payload = {"path": str(absolute_media_path(arguments.media_file)),
                   "outputPath": str(arguments.output.expanduser().absolute()),
                   "preset": arguments.preset, "channels": arguments.channels,
                   "timeoutSeconds": arguments.timeout_seconds,
                   "allowReprocess": arguments.allow_reprocess}
        for flag, field in (("noise_reduction", "noiseReduction"), ("noise_engine", "noiseEngine"), ("target_lufs", "targetLufs"), ("denoise_db", "denoiseDb"), ("compression_ratio", "compressionRatio")):
            if getattr(arguments, flag) is not None:
                payload[field] = getattr(arguments, flag)
        started = client.request("POST", "/v1/media/audio-enhance", payload)
        if arguments.no_wait:
            return started
        task_id = require_object(started, "data")["jobId"]
        return wait_media_task(client, task_id, arguments.timeout_seconds + 30)
    if arguments.command == "media" and arguments.media_command == "focus-cutout":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        try:
            box = [float(v) for v in arguments.box.split(",")]
            if len(box) != 4 or not all(math.isfinite(v) for v in box): raise ValueError("box needs four finite numbers")
        except ValueError as error:
            raise CliFailure("FOCUS_CUTOUT_INVALID", "validation", str(error), exit_code=EXIT_INVALID_INPUT) from error
        payload = {"path": str(absolute_media_path(arguments.media_file)), "outputPath": str(arguments.output.expanduser().absolute()), "box":box, "fromSec":arguments.from_sec, "feather":arguments.feather}
        if arguments.from_time is not None:
            try:
                exact = Fraction(arguments.from_time)
                if exact < 0: raise ValueError("from-time must be non-negative")
                payload["fromTime"] = {"num":str(exact.numerator),"den":str(exact.denominator)}
            except (ValueError, ZeroDivisionError) as error:
                raise CliFailure("FOCUS_CUTOUT_INVALID", "validation", str(error), exit_code=EXIT_INVALID_INPUT) from error
        if arguments.duration_sec is not None: payload["durationSec"] = arguments.duration_sec
        started = client.request("POST", "/v1/media/focus-cutout", payload)
        return started if arguments.no_wait else wait_media_task(client, require_object(started,"data")["jobId"], 3630)
    if arguments.command == "media" and arguments.media_command == "task":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        if arguments.media_task_command == "list":
            return client.request("GET", "/v1/media/tasks")
        endpoint = f"/v1/media/tasks/{quote(arguments.task_id)}"
        if arguments.media_task_command == "cancel":
            return client.request("POST", endpoint + "/cancel", {})
        if arguments.no_wait:
            return client.request("GET", endpoint)
        return wait_media_task(client, arguments.task_id, arguments.timeout_seconds)
    if arguments.command == "audio" and arguments.audio_command == "denoise":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload = {"path": str(absolute_media_path(arguments.media_file)),
                   "outputPath": str(arguments.output.expanduser().absolute()),
                   "preset": "none", "noiseReduction": "standard", "noiseEngine": "deepfilter"}
        started = client.request("POST", "/v1/media/audio-enhance", payload)
        return wait_media_task(client, require_object(started, "data")["jobId"], 1830)
    if arguments.command == "audio" and arguments.audio_command == "index":
        payload = {
            "mode": "index",
            "dir": str(arguments.directory.expanduser().resolve()),
            "indexPath": str(arguments.index.expanduser().resolve()),
        }
        return plugin_invoke("clap", payload, 7200)
    if arguments.command == "audio" and arguments.audio_command == "find":
        payload = {
            "mode": "query",
            "text": arguments.text,
            "indexPath": str(arguments.index.expanduser().resolve()),
        }
        if arguments.top_k is not None:
            payload["topK"] = arguments.top_k
        return plugin_invoke("clap", payload, 600)
    if arguments.command == "audio" and arguments.audio_command == "separate":
        payload = {
            "input": str(absolute_media_path(arguments.media_file)),
            "outputDir": str(arguments.output_dir.expanduser().resolve()),
            "mode": arguments.mode,
        }
        return plugin_invoke("vocal-sep", payload, 3600)
    if arguments.command == "tts" and arguments.tts_command == "say":
        payload = {
            "text": arguments.text,
            "refAudio": str(absolute_media_path(arguments.ref)),
            "outputPath": str(arguments.output.expanduser().resolve()),
            "lang": arguments.lang,
        }
        if arguments.duration_factor is not None:
            payload["durationFactor"] = arguments.duration_factor
        return plugin_invoke("tts", payload, 3600)
    if arguments.command == "plugin" and arguments.plugin_command == "config":
        if not arguments.set_pairs and not arguments.unset_keys:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "pass --set KEY=VALUE and/or --unset KEY",
            )
        set_map = {}
        for pair in arguments.set_pairs:
            key, sep, value = pair.partition("=")
            if not sep or not key:
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID", "validation",
                    f"--set takes KEY=VALUE, got: {pair}",
                )
            set_map[key] = value
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload = {}
        if set_map:
            payload["set"] = set_map
        if arguments.unset_keys:
            payload["unset"] = arguments.unset_keys
        return client.request(
            "POST", f"/v1/plugins/{arguments.name}/config", payload
        )
    if arguments.command == "plugin" and arguments.plugin_command == "cache":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        if arguments.clear:
            payload = {"plugin": arguments.name} if arguments.name else {}
            return client.request("POST", "/v1/plugins/cache/clear", payload)
        return client.request("GET", "/v1/plugins/cache")
    if arguments.command == "plugin" and arguments.plugin_command == "run":
        request = read_request_file(arguments.request)
        return plugin_invoke(arguments.name, request, arguments.timeout)
    if arguments.command == "plugin" and arguments.plugin_command == "rm":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        return client.request("POST", f"/v1/plugins/{arguments.name}/remove", {})
    if arguments.command == "glossary":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        if arguments.glossary_command == "list":
            return client.request("GET", "/v1/glossary")
        if arguments.glossary_command == "set":
            if arguments.clear == (arguments.file is not None):
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID", "validation",
                    "pass exactly one of --file <glossary.json> or --clear",
                )
            terms = [] if arguments.clear else _load_glossary_terms(arguments.file)
            return client.request("POST", "/v1/glossary", {"terms": terms})
        current = client.request("GET", "/v1/glossary")
        if not current.get("ok"):
            return current
        terms = list((current.get("data") or {}).get("terms") or [])
        canonical = arguments.canonical.strip()
        if arguments.glossary_command == "add":
            aliases = [alias.strip() for alias in arguments.aliases if alias.strip()]
            for term in terms:
                if term.get("canonical") == canonical:
                    merged = list(term.get("aliases") or [])
                    merged.extend(alias for alias in aliases if alias not in merged)
                    term["aliases"] = merged
                    break
            else:
                terms.append({"canonical": canonical, "aliases": aliases})
        else:
            remaining = [term for term in terms if term.get("canonical") != canonical]
            if len(remaining) == len(terms):
                raise CliFailure(
                    "GLOSSARY_TERM_NOT_FOUND", "validation",
                    f"no glossary term is spelled {canonical!r}",
                    remediation="`oc glossary list` shows the canonical spellings",
                )
            terms = remaining
        return client.request("POST", "/v1/glossary", {"terms": terms})
    if arguments.command == "docs":
        client, _ = discover_client(require_project=False)
        if arguments.url:
            return {
                "schemaVersion": SCHEMA_VERSION,
                "ok": True,
                "data": {
                    "url": f"{client.descriptor.base_url}/docs/",
                    "interactive": False,
                    "headless": client.descriptor.headless,
                },
            }
        session = client.request("POST", "/v1/docs/sessions")
        data = require_object(session, "data")
        launch_path = require_documentation_launch_path(data)
        launch_url = f"{client.descriptor.base_url}{launch_path}"
        try:
            opened = webbrowser.open(launch_url, new=2)
        except (OSError, webbrowser.Error) as error:
            raise documentation_browser_unavailable() from error
        if not opened:
            raise documentation_browser_unavailable()
        return {
            "schemaVersion": SCHEMA_VERSION,
            "ok": True,
            "data": {
                "opened": True,
                "interactive": True,
                "headless": client.descriptor.headless,
                "expiresInSeconds": require_integer(data, "expiresInSeconds"),
            },
        }
    if arguments.command == "html" and arguments.html_command == "presets":
        # A catalog read, not a Session read: the table is the same file the
        # editor's preset library is generated from, so this answers without a
        # running service and cannot report presets a person cannot click.
        #
        # Two forms on purpose. Bare, it lists what exists; named, it describes
        # one preset in full. Every property of every preset at once is a few
        # thousand tokens of colours and lengths that are irrelevant until a
        # preset has been chosen, so the index only says how many there are and
        # where to read them.
        if arguments.preset_id:
            preset = html_preset_by_id(arguments.preset_id)
            return {
                "schemaVersion": SCHEMA_VERSION,
                "ok": True,
                "data": {
                    "preset": {
                        "id": preset.get("id"),
                        "label": preset.get("label"),
                        "detail": preset.get("detail"),
                        "pack": preset.get("pack"),
                        "category": preset.get("category"),
                        "description": preset.get("description"),
                        "defaultDurationSeconds": preset.get("defaultDurationSeconds"),
                        "placement": preset.get("placement"),
                        # 放置时默认跟着落的那一声(id 或 kind);没有就是无声。
                        "sfx": preset.get("sfx") or "none",
                        "sfxDelaySeconds": float(preset_sfx_delay(preset)),
                        # 主音效之外跟着落的几声(如打完字点搜索的鼠标声)。
                        "sfxExtra": preset.get("sfxExtra", []),
                        "sfxCues": preset.get("sfxCues", []),
                        "themeVariables": preset.get("themeVariables", []),
                        "slots": preset.get("slots", []),
                        "lists": preset.get("lists", []),
                        "variables": preset.get("variables", []),
                    },
                    "usage": (
                        "pass any of these to `oc html add --preset "
                        f"{preset.get('id')}` as `--set NAME=VALUE`; "
                        "`--sfx none` drops the default sound, `--sfx <id|kind>` swaps it"
                    ),
                },
            }
        return {
            "schemaVersion": SCHEMA_VERSION,
            "ok": True,
            "data": {
                "presets": [
                    {key: preset.get(key) for key in (
                        "id", "pack", "category", "description", "defaultDurationSeconds",
                    )}
                    for preset in load_html_presets()
                    if (arguments.pack is None or preset.get("pack") == arguments.pack)
                    and (arguments.category is None or preset.get("category") == arguments.category)
                    and (not preset.get("discoverByFilter") or arguments.pack is not None or arguments.category is not None)
                ],
            },
        }
    if arguments.command == "media" and arguments.media_command == "probe":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        return client.request(
            "POST", "/v1/media/probe", {"path": str(absolute_media_path(arguments.media_file))}
        )
    if arguments.command == "media" and arguments.media_command == "beats":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload: dict[str, Any] = {"path": str(absolute_media_path(arguments.media_file))}
        if arguments.from_sec is not None:
            payload["fromSec"] = arguments.from_sec
        if arguments.to_sec is not None:
            payload["toSec"] = arguments.to_sec
        if arguments.top_hits is not None:
            payload["topHits"] = arguments.top_hits
        # 谱分析按音频长度走;整首歌几秒内完成,长素材留足余量。
        return client.request("POST", "/v1/media/beats", payload, timeout_seconds=600)
    if arguments.command == "media" and arguments.media_command == "loudness":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload: dict[str, Any] = {"path": str(absolute_media_path(arguments.media_file))}
        if arguments.from_sec is not None:
            payload["fromSec"] = arguments.from_sec
        if arguments.to_sec is not None:
            payload["toSec"] = arguments.to_sec
        # 整段解码并过 BS.1770 滤波;长素材留足余量,同 silence。
        return client.request("POST", "/v1/media/loudness", payload, timeout_seconds=600)
    if arguments.command == "media" and arguments.media_command == "silence":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload: dict[str, Any] = {"path": str(absolute_media_path(arguments.media_file))}
        if arguments.threshold_db is not None:
            payload["thresholdDb"] = arguments.threshold_db
        if arguments.min_duration_sec is not None:
            payload["minDurationSec"] = arguments.min_duration_sec
        if arguments.pad_ms is not None:
            payload["padMs"] = arguments.pad_ms
        # 整条音轨解码;长口播留足余量,同 beats。
        return client.request("POST", "/v1/media/silence", payload, timeout_seconds=600)
    if arguments.command == "media" and arguments.media_command == "colorstats":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload: dict[str, Any] = {"path": str(absolute_media_path(arguments.media_file))}
        if arguments.every is not None:
            payload["every"] = arguments.every
        if arguments.from_sec is not None:
            payload["fromSec"] = arguments.from_sec
        if arguments.to_sec is not None:
            payload["toSec"] = arguments.to_sec
        return client.request("POST", "/v1/media/colorstats", payload, timeout_seconds=900)
    if arguments.command == "media" and arguments.media_command == "analyze":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload = {"path": str(absolute_media_path(arguments.media_file))}
        if arguments.from_sec is not None:
            payload["fromSec"] = arguments.from_sec
        if arguments.to_sec is not None:
            payload["toSec"] = arguments.to_sec
        # 逐帧小尺度解码按片长走。
        return client.request("POST", "/v1/media/motion", payload, timeout_seconds=900)
    if arguments.command == "media" and arguments.media_command == "letterbox":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload: dict[str, Any] = {"path": str(absolute_media_path(arguments.media_file))}
        if arguments.every is not None:
            payload["every"] = arguments.every
        if arguments.source_dir is not None:
            payload["sourceDir"] = str(arguments.source_dir.expanduser().resolve())
        # 逐帧扫描按片长走;比对源素材时每个可疑帧还要再解一次源画面。
        return client.request("POST", "/v1/media/letterbox", payload, timeout_seconds=900)
    if arguments.command == "media" and arguments.media_command == "face-tracks":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload: dict[str, Any] = {"path": str(absolute_media_path(arguments.media_file))}
        payload.update(privacy_tracking_payload(arguments))
        # 检测按采样帧数走(默认每 3 帧一次);长素材分钟级。
        return client.request("POST", "/v1/media/face-tracks", payload, timeout_seconds=1800)
    if arguments.command == "media" and arguments.media_command == "track":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload = {"path": str(absolute_media_path(arguments.media_file))}
        payload.update(object_track_payload(arguments))
        if arguments.box is not None:
            payload["box"] = arguments.box
        if arguments.frame is not None:
            payload["frame"] = arguments.frame
        if arguments.from_frame is not None:
            payload["fromFrame"] = arguments.from_frame
        if arguments.to_frame is not None:
            payload["toFrame"] = arguments.to_frame
        # 逐帧解码 + 模板匹配:几千帧是十几秒到一分钟的量级。
        return client.request("POST", "/v1/media/object-track", payload, timeout_seconds=1800)
    if arguments.command == "media" and arguments.media_command == "anonymize":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload = {
            "path": str(absolute_media_path(arguments.media_file)),
            "output": str(arguments.output.expanduser().resolve()),
        }
        payload.update(privacy_cover_payload(arguments))
        # 检测 + 逐帧掩膜 + 一次 x264 编码:整条素材一遍,长素材分钟级。
        return client.request("POST", "/v1/media/anonymize", payload, timeout_seconds=3600)
    if arguments.command == "media" and arguments.media_command == "faces":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload: dict[str, Any] = {"path": str(absolute_media_path(arguments.media_file))}
        if arguments.every is not None:
            payload["every"] = arguments.every
        if arguments.frames is not None:
            payload["frames"] = arguments.frames
        if arguments.face is not None:
            payload["face"] = arguments.face
        if arguments.output is not None:
            payload["output"] = str(arguments.output.expanduser().resolve())
        if arguments.no_sheet:
            payload["noSheet"] = True
        if arguments.all:
            payload["all"] = True
        # 检测耗时与采样帧数成正比;整条 8s 素材默认采样约 30 帧,秒级完成,
        # 长素材密采样时留足余量。
        return client.request("POST", "/v1/media/faces", payload, timeout_seconds=600)
    if arguments.command == "media" and arguments.media_command == "subject":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload: dict[str, Any] = {"path": str(absolute_media_path(arguments.media_file))}
        if arguments.every is not None:
            payload["every"] = arguments.every
        if arguments.frames is not None:
            payload["frames"] = arguments.frames
        if arguments.no_pose:
            payload["noPose"] = True
        if arguments.output_mask is not None:
            payload["outputMask"] = str(arguments.output_mask.expanduser().resolve())
        if arguments.mask_full_resolution:
            payload["maskFullResolution"] = True
        return client.request("POST", "/v1/media/subject", payload, timeout_seconds=600)
    if arguments.command == "media" and arguments.media_command == "matte":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload = {
            "path": str(absolute_media_path(arguments.media_file)),
            "output": str(arguments.output.expanduser().resolve()),
        }
        if arguments.feather is not None:
            payload["feather"] = arguments.feather
        if arguments.invert:
            payload["invert"] = True
        if arguments.quality:
            payload["quality"] = arguments.quality
        if arguments.outline_width:
            payload["outlineWidth"] = arguments.outline_width
        if arguments.outline_width or arguments.outline_color != "#FFFFFF":
            payload["outlineColor"] = arguments.outline_color
        start = arguments.in_frame or 0
        end = arguments.out_frame
        if end is not None and end <= start:
            raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--out-frame must exceed --in-frame", exit_code=EXIT_INVALID_INPUT)
        if arguments.in_frame is not None:
            payload["inFrame"] = start
        if end is not None:
            payload["outFrame"] = end
        if arguments.first_mask is not None:
            if arguments.quality != "high" or arguments.first_mask.suffix.lower() != ".png":
                raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--first-mask requires --quality high and a PNG", exit_code=EXIT_INVALID_INPUT)
            payload["firstMask"] = str(absolute_media_path(arguments.first_mask))
        if arguments.no_cache:
            payload["noCache"] = True
        timeout = 7200 if arguments.quality == "high" else 1800
        if end is not None and arguments.quality == "high":
            timeout = max(1800, 1200 + 24 * (end - start))
        return client.request("POST", "/v1/media/matte", payload, timeout_seconds=timeout)
    if arguments.command == "media" and arguments.media_command == "make-mask":
        if (arguments.like is None) == (arguments.size is None):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "pass exactly one canvas geometry: --like <media> or --size WxH",
            )
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload: dict[str, Any] = {
            "output": str(arguments.output.expanduser().resolve()),
            "shape": arguments.shape,
        }
        if arguments.like is not None:
            payload["like"] = str(absolute_media_path(arguments.like))
        if arguments.size is not None:
            payload["width"], payload["height"] = arguments.size
        for name, value in (
            ("box", arguments.box),
            ("center", arguments.center),
            ("radius", arguments.radius),
            ("angle", arguments.angle),
            ("position", arguments.position),
            ("softness", arguments.softness),
            ("endBox", arguments.end_box),
            ("endCenter", arguments.end_center),
            ("endRadius", arguments.end_radius),
            ("endPosition", arguments.end_position),
            ("frames", arguments.frames),
            ("fps", arguments.fps),
        ):
            if value is not None:
                payload[name] = value
        if arguments.invert:
            payload["invert"] = True
        # 逐像素渲染秒级;动画掩膜多一次 H.264 编码,仍是秒级到十秒级。
        return client.request("POST", "/v1/media/make-mask", payload, timeout_seconds=300)
    if arguments.command == "media" and arguments.media_command == "apply-mask":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload = {
            "path": str(absolute_media_path(arguments.media_file)),
            "mask": str(absolute_media_path(arguments.mask)),
            "output": str(arguments.output.expanduser().resolve()),
        }
        if arguments.feather is not None:
            payload["feather"] = arguments.feather
        if arguments.invert:
            payload["invert"] = True
        # 掩膜现成,只剩一次 VP9 编码:比 matte 快路径还少一步分割,同档留余量。
        return client.request("POST", "/v1/media/apply-mask", payload, timeout_seconds=1800)
    if arguments.command == "media" and arguments.media_command == "align":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload = {
            "reference": str(absolute_media_path(arguments.reference)),
            "candidates": [str(absolute_media_path(c)) for c in arguments.candidates],
        }
        if arguments.no_pose:
            payload["noPose"] = True
        # 每个候选跑一遍分割 + 姿态;一次筛十来张仍在秒级,但留足余量。
        return client.request("POST", "/v1/media/align", payload, timeout_seconds=600)
    if arguments.command == "media" and arguments.media_command == "subtitles":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        payload = {
            "path": str(absolute_media_path(arguments.media_file)),
            "read": arguments.read,
        }
        if arguments.track is not None:
            payload["track"] = arguments.track
        if arguments.language is not None:
            payload["language"] = arguments.language
        return client.request("POST", "/v1/media/subtitles", payload, timeout_seconds=120)
    if arguments.command == "media" and arguments.media_command == "transcribe":
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        response = client.request(
            "POST",
            "/v1/media/transcribe",
            {
                "path": str(absolute_media_path(arguments.media_file)),
                "includeSrt": arguments.srt is not None,
                **(
                    {"glossary": _load_glossary_terms(arguments.glossary)}
                    if arguments.glossary is not None
                    else {}
                ),
                **(
                    {"script": read_script_file(arguments.script)}
                    if arguments.script is not None
                    else {}
                ),
                **(
                    {"maxLineWidth": arguments.max_line_width}
                    if arguments.max_line_width is not None
                    else {}
                ),
            },
            # 转写时长与素材成正比(RTF≈0.05):1 小时音频约 3 分钟,
            # 默认 30s 客户端超时必然不够。
            timeout_seconds=1800,
        )
        if arguments.srt is not None and response.get("ok"):
            srt_text = (response.get("data") or {}).pop("srt", None)
            if srt_text is not None:
                arguments.srt.expanduser().resolve().write_text(srt_text, encoding="utf-8")
                response["data"]["srtFile"] = str(arguments.srt.expanduser().resolve())
        return response
    if arguments.command == "project" and arguments.project_command == "list":
        client, _ = discover_client(require_project=False)
        return client.request("GET", "/v1/projects")
    if arguments.command == "project" and arguments.project_command == "create":
        client, _ = discover_client(require_project=False)
        frame_rate: dict[str, str] | None = None
        if arguments.match is not None:
            canvas, frame_rate = matched_source_canvas(client, arguments.match)
        else:
            canvas = requested_project_canvas(arguments)
            if arguments.fps is not None:
                frame_rate = {"num": str(arguments.fps), "den": "1"}
        source_document: dict[str, Any] | None = None
        if arguments.from_source is not None:
            source_document = read_project_source(Path(arguments.from_source))
        title = arguments.title
        # 源码带着标题;没显式指定就跟着它走,否则导入出来的工程叫
        # "Untitled project",往返比对第一行就对不上。
        if source_document is not None and title == "Untitled project":
            title = str((source_document.get("project") or {}).get("title") or title)
        # 画布模式是建工程时的参数,不是后续命令;auto 意味着画布跟随首个
        # 素材(ADR0042),这与 fixed 是两种工程行为。
        if source_document is not None:
            canvas, frame_rate = _source_creation_canvas(source_document, canvas, frame_rate)
        payload: dict[str, Any] = {
            "title": title,
            "idempotencyKey": arguments.idempotency_key
            or f"project-create:{uuid.uuid4()}",
        }
        # An omitted canvas creates the project in auto mode: the canvas then
        # follows the first visual clip placed on the timeline.
        if canvas is not None:
            payload["canvas"] = canvas
        if frame_rate is not None:
            payload["frameRate"] = frame_rate
        # Initial Project publication installs and fsyncs portable defaults before the
        # Session becomes visible. A cold debug build or slow disk can legitimately
        # exceed the short timeout used by ordinary control reads.
        client.timeout = PROJECT_LIFECYCLE_TIMEOUT_SECONDS
        created = client.request("POST", "/v1/projects", payload)
        if arguments.from_source is None:
            return created
        # 全量导入只对刚创建的空工程成立:没有旧状态,就绕开了 identity、
        # diff 与并发三个难点,整份文件收敛成一个 CommandBatch。
        source_path = Path(arguments.from_source)
        document = source_document if source_document is not None else read_project_source(source_path)
        sidecar = read_project_sidecar(source_path)
        created_data = created.get("data") or {}
        new_project_id = str(
            (created_data.get("capabilities") or {}).get("projectId")
            or created_data.get("projectId")
            or ""
        )
        if not new_project_id:
            raise CliFailure(
                "PROJECT_CREATE_UNCLEAR",
                "serialization",
                "the service did not report the new project id",
                exit_code=EXIT_OPERATION_FAILED,
            )
        # 素材先真正拷进新工程(服务的导入通道负责落盘、探测、分配 id),
        # 再按指纹把文件里的旧 id 映射到新 id;内置资产 id 稳定,不参与。
        media_root = Path(arguments.media_root) if arguments.media_root else None
        wanted = [
            asset
            for asset in document.get("assets", [])
            if not str(asset.get("id", "")).startswith("asset-bundled-")
        ]
        asset_ids: dict[str, str] = {}
        if wanted:
            if media_root is None:
                raise CliFailure(
                    "SOURCE_MEDIA_ROOT_REQUIRED",
                    "validation",
                    f"the source file references {len(wanted)} asset file(s); "
                    "pass --media-root <dir> so they can be copied into the new project",
                    remediation="point --media-root at the directory holding those files",
                    exit_code=EXIT_INVALID_INPUT,
                )
            paths: list[str] = []
            staging = Path(tempfile.mkdtemp(prefix="oc-source-import-"))
            for asset in wanted:
                stored = str(asset.get("path") or "").split("/")[-1]
                display = str(asset.get("name") or stored)
                candidate = (media_root / stored).resolve()
                if not candidate.is_file():
                    candidate = (media_root / display).resolve()
                if not candidate.is_file():
                    raise CliFailure(
                        "SOURCE_ASSET_FILE_MISSING",
                        "validation",
                        f"asset {asset.get('id')} needs {stored} or {display} under "
                        f"{media_root}, and neither is there",
                        remediation="check --media-root, or restore the file",
                        exit_code=EXIT_INVALID_INPUT,
                    )
                # 服务按文件名取显示名,而工程媒体目录里的文件是按资产 id 命名的
                # ——不还原成原名,导入后的素材就都叫 asset-import-xxx.mp4。
                if candidate.name != display:
                    staged = staging / display
                    shutil.copy2(candidate, staged)
                    candidate = staged
                paths.append(str(candidate))
            client.timeout = IMPORT_TIMEOUT_SECONDS
            imported_assets = client.request(
                "POST",
                f"/v1/projects/{quote(new_project_id)}/assets/import",
                {
                    "baseRevision": current_revision(client),
                    "paths": paths,
                    "intent": f"从项目源码导入素材 {source_path.name}",
                    "idempotencyKey": f"source-assets:{uuid.uuid4()}",
                },
            )
            shutil.rmtree(staging, ignore_errors=True)
            by_fingerprint = {}
            for item in (imported_assets.get("data") or {}).get("assets", []):
                digest = item.get("fingerprint")
                if isinstance(digest, dict):
                    digest = digest.get("value")
                by_fingerprint[str(digest)] = str(item.get("assetId"))
            for asset in wanted:
                digest = str(asset.get("fingerprint", "")).partition("-")[2]
                new_id = by_fingerprint.get(digest)
                if new_id is None:
                    raise CliFailure(
                        "SOURCE_ASSET_UNMATCHED",
                        "serialization",
                        f"imported files do not include a match for asset {asset.get('id')}",
                        exit_code=EXIT_OPERATION_FAILED,
                    )
                asset_ids[str(asset.get("id"))] = new_id
        snapshot = client.request(
            "GET", f"/v1/projects/{quote(new_project_id)}/snapshot"
        )
        fresh = require_object(require_object(snapshot, "data"), "project")
        sequence_id = default_sequence_id(fresh)
        rate = sequence_frame_rate_from(fresh, sequence_id)
        commands = source_commands(document, sidecar, sequence_id, rate, asset_ids)
        # 源码文件可能来自更新的 OrangeCut(带调色、标记这类后加的命令)。
        # 先对一遍能力表,否则旧服务只会回一句"请求不合法",看不出真因。
        assert_commands_supported(
            commands,
            created_data.get("capabilities"),
            context=f"rebuilding {source_path.name}",
            orphan_project_id=new_project_id,
        )
        action = f"project-import-source:{uuid.uuid4()}"
        batch = {
            "commandId": action,
            "idempotencyKey": action,
            "projectId": new_project_id,
            "baseRevision": int(fresh.get("revision", 0)),
            "actor": {"type": "agent", "id": "orangecut-skill"},
            "intent": f"从项目源码导入 {source_path.name}",
            "mode": "commit",
            "commands": commands,
        }
        applied = client.request(
            "POST", f"/v1/projects/{quote(new_project_id)}/commands", batch
        )
        return {
            "projectId": new_project_id,
            "importedAssets": len(asset_ids),
            "importedCommands": len(commands),
            "revision": (applied.get("data") or {}).get("revision"),
            "source": str(source_path),
        }
    if arguments.command == "project" and arguments.project_command == "open":
        client, _ = discover_client(require_project=False)
        client.timeout = PROJECT_LIFECYCLE_TIMEOUT_SECONDS
        return client.request("POST", "/v1/projects/open", {"projectId": arguments.project_id})
    if arguments.command == "project" and arguments.project_command in (
        "trash",
        "rename",
        "duplicate",
    ):
        # 三条都作用在"某个工程"而不是"当前打开的工程";trash 与 duplicate
        # 还要求目标处于关闭状态(服务端 ensure_no_active_project 把关),所以
        # 这里不能要求先打开一个工程。
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        client.timeout = PROJECT_LIFECYCLE_TIMEOUT_SECONDS
        target = quote(arguments.project_id)
        if arguments.project_command == "trash":
            return client.request("POST", f"/v1/projects/{target}/trash", {})
        return client.request(
            "POST",
            f"/v1/projects/{target}/{arguments.project_command}",
            {"title": arguments.title},
        )
    if arguments.command == "project" and arguments.project_command in ("fork", "diff"):
        client, _ = discover_client(require_project=False, allow_multiple_idle=True)
        client.timeout = PROJECT_LIFECYCLE_TIMEOUT_SECONDS
        target = quote(arguments.project_id)
        if arguments.project_command == "fork":
            return client.request("POST", f"/v1/projects/{target}/fork", {
                "sourceRevision":arguments.revision,"title":arguments.title,"idempotencyKey":arguments.idempotency_key})
        payload = {"otherProjectId":arguments.against or arguments.project_id}
        if arguments.from_revision is not None:
            payload["beforeRevision"] = arguments.from_revision
        if arguments.to_revision is not None:
            payload["afterRevision"] = arguments.to_revision
        return client.request("POST", f"/v1/projects/{target}/diff", payload)
    if arguments.command == "project" and arguments.project_command == "close":
        client, status = discover_client(require_project=False, allow_multiple_idle=True)
        client.timeout = PROJECT_LIFECYCLE_TIMEOUT_SECONDS
        # 关哪一个要说清(ADR 0043):点名的、或恰好开着的那一个。多开不点名在这里
        # 就拒绝,不把一个含糊的 close 发给服务。零个打开是幂等的空操作,照发。
        body: dict[str, Any] = {}
        open_ids = open_project_ids(status)
        if requested_project() is not None or (open_ids is not None and len(open_ids) > 1):
            body = {"projectId": resolve_project_id(status)}
        elif open_ids:
            body = {"projectId": open_ids[0]}
            global _RESOLVED_PROJECT
            _RESOLVED_PROJECT = open_ids[0]
        return client.request("POST", "/v1/projects/close", body)

    if arguments.command == "capabilities":
        client, status = discover_client(require_project=False, allow_multiple_idle=True)
        if arguments.operation:
            return client.request("GET", "/v1/capabilities?" + urllib.parse.urlencode({"command": arguments.operation}))
        named_project = resolve_project_id(status) if requested_project() or status.get("projectOpen") or open_project_ids(status) else None
        return client.request("GET", f"/v1/capabilities{project_query(named_project if service_is_multi_project(status) else None)}")
    client, status = discover_client(require_project=True)
    project_id = resolve_project_id(status)
    named = project_id if service_is_multi_project(status) else None
    global _NAMED_PROJECT
    _NAMED_PROJECT = named
    if arguments.command == "capabilities":
        return client.request("GET", f"/v1/capabilities{project_query(named)}")
    if arguments.command == "project" and arguments.project_command == "source":
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        document, sidecar = project_source_bundle(project, arguments.sequence_id)
        if arguments.output is None:
            return {"document": document, "sidecar": sidecar}
        output = Path(arguments.output)
        text = (
            json.dumps(document, ensure_ascii=False, indent=2) + "\n"
            if arguments.format == "json"
            else dump_source_yaml(document)
        )
        output.write_text(text, encoding="utf-8")
        sidecar_path = source_sidecar_path(output)
        sidecar_path.write_text(
            json.dumps(sidecar, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        return {
            "path": str(output),
            "sidecarPath": str(sidecar_path),
            "assets": len(document.get("assets", [])),
            "tracks": len(document.get("tracks", [])),
            "components": len(document.get("components", [])),
        }
    if arguments.command == "project" and arguments.project_command == "check":
        return project_check_report(client, project_id, arguments)
    if arguments.command == "sequence":
        path = f"/v1/projects/{quote(project_id)}"
        if arguments.sequence_command == "list":
            return client.request("GET", f"{path}/sequences")
        require_complete_retry_identity(arguments)
        if not arguments.name.strip() or max(arguments.width, arguments.height) > 2**32 - 1:
            raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "sequence name and canvas dimensions are invalid", exit_code=EXIT_INVALID_INPUT)
        identity = arguments.idempotency_key or f"sequence-create:{uuid.uuid4()}"
        sequence_id = f"sequence-{uuid.uuid5(uuid.NAMESPACE_URL, f'{project_id}:{identity}').hex}"
        revision = arguments.base_revision if arguments.base_revision is not None else current_revision(client)
        batch = sfx_command_batch(project_id, revision, "Create independent sequence", identity, "sequence-create", [{
            "type": "sequence.create", "payload": {"sequenceId": sequence_id, "name": arguments.name,
                "width": arguments.width, "height": arguments.height, "frameRate": rational_wire(arguments.fps)},
        }])
        response = client.request("POST", f"{path}/commands", batch)
        return {"sequenceId": sequence_id, "transaction": require_object(response, "data")}
    if arguments.command == "timeline" and arguments.timeline_command == "add-sequence":
        require_complete_retry_identity(arguments)
        if arguments.out_frame is not None and arguments.out_frame <= arguments.in_frame:
            raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--out-frame must follow --in-frame", exit_code=EXIT_INVALID_INPUT)
        revision = arguments.base_revision if arguments.base_revision is not None else current_revision(client)
        payload = {"sourceSequenceId": arguments.source_sequence_id, "sequenceId": arguments.sequence_id,
            "trackId": arguments.track_id, "atFrame": arguments.at_frame, "inFrame": arguments.in_frame,
            "outFrame": arguments.out_frame, "muted": arguments.muted, "baseRevision": revision,
            "idempotencyKey": arguments.idempotency_key, "intent": arguments.intent}
        return client.request("POST", f"/v1/projects/{quote(project_id)}/timeline/add-sequence",
            {key: value for key, value in payload.items() if value is not None})
    if arguments.command == "canvas" and arguments.canvas_command == "show":
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        return {
            "data": {
                "sequenceId": sequence_id,
                "canvas": require_object(sequence, "canvas"),
                "canvasMode": sequence.get("canvasMode", "fixed"),
                "frameRate": require_object(sequence, "frameRate"),
                # 整条 Sequence 的调色状态(preset/LUT/intensity/adjust);没调色就是 null。
                # GUI 的滑杆与 `canvas grade` 写的是同一份,读回来才能"改一项、其余照旧"。
                "colorGrading": sequence.get("colorGrading"),
            }
        }
    if arguments.command == "canvas" and arguments.canvas_command == "set":
        require_complete_retry_identity(arguments)
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        canvas_payload: dict[str, Any] = {
            "sequenceId": sequence_id,
            "canvas": {
                "width": arguments.width,
                "height": arguments.height,
                # Keep the sequence's own pixel aspect ratio: this command pins
                # the frame shape, it does not re-declare pixel geometry.
                "pixelAspectRatio": require_object(sequence, "canvas").get(
                    "pixelAspectRatio", {"num": "1", "den": "1"}
                ),
            },
            # An explicit set always pins the canvas; the sequence stops
            # following source media afterwards.
            "canvasMode": "fixed",
        }
        if arguments.fps is not None:
            canvas_payload["frameRate"] = {"num": str(arguments.fps), "den": "1"}
        command_id = arguments.idempotency_key or f"canvas-set:{uuid.uuid4()}"
        batch = {
            "commandId": command_id,
            "idempotencyKey": command_id,
            "projectId": project_id,
            "baseRevision": base_revision,
            "actor": {"type": "agent", "id": "orangecut-skill"},
            "intent": arguments.intent,
            "preconditions": [],
            "mode": "dry-run" if arguments.dry_run else "commit",
            "commands": [{"type": "sequence.canvas.set", "payload": canvas_payload}],
        }
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "cutaway" and arguments.cutaway_command == "add":
        require_complete_retry_identity(arguments)
        if not 0 <= arguments.volume_percent <= 200:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "--volume-percent must be within 0..200",
                exit_code=EXIT_INVALID_INPUT,
            )
        if not 5 <= arguments.pip_scale_percent <= 100:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "--pip-scale-percent must be within 5..100",
                exit_code=EXIT_INVALID_INPUT,
            )
        if arguments.mode == "insert" and arguments.base_revision is not None:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "--mode insert splits straddling clips first, so an explicit "
                "--base-revision cannot stay valid",
                remediation="drop --base-revision/--idempotency-key, or split manually and use overlay",
                exit_code=EXIT_INVALID_INPUT,
            )

        def load_sequence() -> tuple[dict[str, Any], str, dict[str, Any], Fraction]:
            snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
            project = require_object(require_object(snapshot, "data"), "project")
            sequence_id = arguments.sequence_id or default_sequence_id(project)
            sequence = require_sequence(project, sequence_id)
            rate = sequence_frame_rate_from(project, sequence_id)
            return project, sequence_id, sequence, rate

        project, sequence_id, sequence, rate = load_sequence()
        entry = resolve_cutaway(arguments.cutaway_id, project)
        asset = next(
            (asset for asset in project.get("assets", []) if asset.get("id") == entry["assetId"]),
            None,
        )
        if asset is None:
            raise CliFailure(
                "CUTAWAY_ASSET_MISSING", "preconditions",
                f"the bundled cutaway asset {entry['assetId']!r} is not in this project",
                remediation="reopen the project on an OrangeCut build that installs "
                "bundled cutaways (they are added automatically on open)",
                exit_code=EXIT_OPERATION_FAILED,
            )
        probe = asset.get("probe") or {}
        wire = probe.get("duration")
        if not (isinstance(wire, dict) and "num" in wire and "den" in wire):
            raise CliFailure(
                "CUTAWAY_DURATION_UNKNOWN", "preconditions",
                f"asset {entry['assetId']!r} has no probed duration yet",
                remediation="wait for the import to finish probing, then retry",
                exit_code=EXIT_OPERATION_FAILED,
            )
        total_frames = int(Fraction(int(wire["num"]), int(wire["den"])) * rate)
        length_frames = total_frames
        if arguments.duration_frames is not None:
            length_frames = min(length_frames, arguments.duration_frames)
        if length_frames < 1:
            raise CliFailure(
                "CUTAWAY_TOO_SHORT", "validation",
                f"asset {entry['assetId']!r} is shorter than one frame at this sequence rate",
                exit_code=EXIT_INVALID_INPUT,
            )
        start = Fraction(arguments.at_frame) / rate
        length = Fraction(length_frames) / rate
        commands: list[dict[str, Any]] = []
        track_id: str | None = None
        if arguments.mode == "insert":
            # 串联:与 gap-insert --split-crossing 同一套——先把横跨缝位的片段切开
            # (逐条独立写入,视觉无损),再在同一批次里撑开缝,把片段填进主画面轨
            # 的缝里。缝是全轨道一起撑的,人声、字幕、BGM 都后移,同步不乱。
            main_track = main_video_track_id(sequence, start)
            split_clips_crossing_gap(client, project_id, sequence_id, arguments.at_frame, start)
            project, sequence_id, sequence, rate = load_sequence()
            commands.append({
                "type": "sequence.gap.insert",
                "payload": {"sequenceId": sequence_id, "at": rational_wire(start),
                            "duration": rational_wire(length)},
            })
            track_id = main_track
        if track_id is None:
            # 叠层(overlay/pip),或时间线上还没有画面可切:自己开一条 cutaway 轨,
            # 垫在字幕之下。
            track_id = f"track-cutaway-{uuid.uuid4()}"
            commands.extend(visual_track_add_commands(sequence, sequence_id, track_id, "cutaway", "cutaway"))
        clip_id = f"clip-cutaway-{uuid.uuid4()}"
        commands.append(cutaway_clip_command(
            sequence_id, track_id, clip_id, entry["assetId"], start, length,
            arguments.fit, arguments.volume_percent, entry, arguments.mode))
        pip_applied = False
        if arguments.mode == "pip":
            transform = cutaway_pip_transform(
                sequence, sequence_id, clip_id, asset,
                arguments.pip_scale_percent, arguments.pip_corner)
            if transform is not None:
                commands.append(transform)
                pip_applied = True
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        batch = sfx_command_batch(project_id, base_revision, arguments.intent,
                                  arguments.idempotency_key, "cutaway-add", commands)
        response = client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
        if isinstance(response, dict) and isinstance(response.get("data"), dict):
            response["data"]["cutaway"] = {
                "id": entry["id"], "kind": entry["kind"], "assetId": entry["assetId"],
                "mode": arguments.mode, "clipId": clip_id, "trackId": track_id,
                "atFrame": arguments.at_frame, "durationFrames": length_frames,
                "sequenceId": sequence_id,
                **({"pip": {"applied": pip_applied}} if arguments.mode == "pip" else {}),
            }
            if arguments.mode == "pip" and not pip_applied:
                response.setdefault("warnings", []).append({
                    "code": "CUTAWAY_PIP_NO_SOURCE_SIZE",
                    "message": "the asset probe has no video size, so the clip was placed full-frame",
                })
        return response
    if arguments.command == "sfx" and arguments.sfx_command == "add":
        require_complete_retry_identity(arguments)
        entry = resolve_sfx(arguments.sfx_id)
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        rate = sequence_frame_rate_from(project, sequence_id)
        asset_id, duration_seconds = ensure_sfx_asset(client, project_id, project, entry)
        commands = sfx_placement_commands(
            sequence, sequence_id, asset_id, duration_seconds, rate,
            arguments.at_frame, entry, None)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        batch = sfx_command_batch(project_id, base_revision, arguments.intent,
                                  arguments.idempotency_key, "sfx-add", commands)
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "sfx" and arguments.sfx_command in ("marker","markers"):
        require_complete_retry_identity(arguments)
        snapshot=client.request("GET",f"/v1/projects/{quote(project_id)}/snapshot")
        project=require_object(require_object(snapshot,"data"),"project")
        sequence_id=arguments.sequence_id or default_sequence_id(project)
        sequence=require_sequence(project,sequence_id)
        if arguments.sfx_command=="markers":
            operations=[{"type":"sequence.audio.marker-sounds.set","payload":{"sequenceId":sequence_id,"enabled":arguments.enabled}}]
        else:
            from .marker_sound import update_component_sound
            try:operations=update_component_sound(project,sequence,arguments.clip_id,arguments.preset,arguments.asset_id,arguments.volume_percent)
            except ValueError as error:raise CliFailure("MARKER_SOUND_INVALID","validation",str(error),exit_code=EXIT_INVALID_INPUT) from error
        base_revision=arguments.base_revision if arguments.base_revision is not None else project["revision"]
        batch=sfx_command_batch(project_id,base_revision,arguments.intent,arguments.idempotency_key,"marker-sound",operations)
        return client.request("POST",f"/v1/projects/{quote(project_id)}/commands",batch)
    if arguments.command == "sfx" and arguments.sfx_command == "set":
        require_complete_retry_identity(arguments)
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        rate = sequence_frame_rate_from(project, sequence_id)
        target = None
        for track in sequence.get("tracks", []):
            for clip in track.get("clips", []):
                if clip.get("id") == arguments.clip_id:
                    target = clip
        if target is None:
            raise CliFailure(
                "SFX_TARGET_NOT_FOUND",
                "preconditions",
                f"clip {arguments.clip_id!r} does not exist in sequence {sequence_id!r}",
                remediation="run `oc timeline snapshot` and pass the visual clip id",
                exit_code=EXIT_INVALID_INPUT,
            )
        linked = []
        for track in sequence.get("tracks", []):
            for clip in track.get("clips", []):
                extension = clip.get("extensions", {}).get(SFX_LINK_EXTENSION)
                data = extension.get("data", {}) if isinstance(extension, dict) else {}
                if data.get("targetClipId") != arguments.clip_id:
                    continue
                # Swapping the main sound keeps a preset's extra cues; `none`
                # silences the component outright.
                if data.get("cue") == "extra" and arguments.sfx != "none":
                    continue
                linked.append((track["id"], clip["id"]))
        commands: list[dict[str, Any]] = [
            {
                "type": "clip.remove",
                "payload": {
                    "sequenceId": sequence_id,
                    "trackId": track_id,
                    "clipId": clip_id,
                },
            }
            for track_id, clip_id in linked
        ]
        if arguments.sfx != "none":
            entry = resolve_sfx(arguments.sfx)
            asset_id, duration_seconds = ensure_sfx_asset(
                client, project_id, project, entry)
            start = target["timelineRange"]["start"]
            target_frame = int(
                Fraction(int(start["num"]), int(start["den"])) * rate)
            preset_id = component_preset_id(project, target)
            if preset_id is not None:
                try:
                    preset = html_preset_by_id(preset_id)
                except CliFailure:
                    preset = None
                target_frame += round(preset_sfx_delay(preset) * rate)
            commands += sfx_placement_commands(
                sequence, sequence_id, asset_id, duration_seconds, rate,
                target_frame, entry, arguments.clip_id)
        if not commands:
            raise CliFailure(
                "SFX_SET_NOOP",
                "validation",
                "the clip has no linked sfx to remove",
                remediation="pass an sfx id/kind to attach one",
                exit_code=EXIT_INVALID_INPUT,
            )
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        batch = sfx_command_batch(project_id, base_revision, arguments.intent,
                                  arguments.idempotency_key, "sfx-set", commands)
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "audio" and arguments.audio_command == "duck":
        require_complete_retry_identity(arguments)
        gain_percent = 25 if arguments.gain_percent is None else arguments.gain_percent
        fade_frames = 6 if arguments.fade_frames is None else arguments.fade_frames
        try:
            raw_spans = json.loads(Path(arguments.over).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"could not read the duck spans: {error}",
                remediation="pass a readable JSON file",
                exit_code=EXIT_INVALID_INPUT,
            ) from error
        if not isinstance(raw_spans, list) or not raw_spans:
            raise CliFailure(
                "DUCK_SPANS_INVALID",
                "validation",
                "--over must be a non-empty JSON array of spans",
                remediation='each entry looks like {"atFrame": 0, "durationFrames": 48}',
                exit_code=EXIT_INVALID_INPUT,
            )
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        fps = sequence_frame_rate_from(project, sequence_id)

        found = None
        for track in sequence.get("tracks", []):
            for candidate in track.get("clips", []):
                if candidate.get("id") == arguments.clip_id:
                    found = candidate
        if found is None:
            raise CliFailure(
                "DUCK_CLIP_NOT_FOUND",
                "preconditions",
                f"clip {arguments.clip_id!r} does not exist in sequence {sequence_id!r}",
                remediation="run `oc timeline snapshot` and pass the music clip id",
                exit_code=EXIT_INVALID_INPUT,
            )

        def as_fraction(value: dict[str, Any]) -> Fraction:
            return Fraction(int(value["num"]), int(value["den"]))

        def as_rational(value: Fraction) -> dict[str, str]:
            return {"num": str(value.numerator), "den": str(value.denominator)}

        timeline_range = require_object(found, "timelineRange")
        clip_start = as_fraction(require_object(timeline_range, "start"))
        clip_end = as_fraction(require_object(timeline_range, "end"))
        # 全程在帧上算,只在拼命令时换回秒——帧是整数网格,混着算是这个仓库
        # 反复翻车的地方。关键帧的时间锚在 Clip 自己的起点上,所以先减掉起点。
        clip_frames = int((clip_end - clip_start) * fps)
        start_frame = int(clip_start * fps)

        wanted: list[tuple[int, int]] = []
        for index, span in enumerate(raw_spans):
            if not isinstance(span, dict):
                raise CliFailure(
                    "DUCK_SPANS_INVALID",
                    "validation",
                    f"span {index} is not an object",
                    remediation='each entry looks like {"atFrame": 0, "durationFrames": 48}',
                    exit_code=EXIT_INVALID_INPUT,
                )
            try:
                at = int(span["atFrame"])
                length = int(span["durationFrames"])
            except (KeyError, TypeError, ValueError):
                raise CliFailure(
                    "DUCK_SPANS_INVALID",
                    "validation",
                    f"span {index} needs integer atFrame and durationFrames",
                    remediation='each entry looks like {"atFrame": 0, "durationFrames": 48}',
                    exit_code=EXIT_INVALID_INPUT,
                ) from None
            # 落在 Clip 之外的部分裁掉:静音测量是对整条音轨做的,音乐床常常
            # 只铺在其中一段上,交集为空的 span 本就该被忽略。
            begin = max(at - start_frame, 0)
            finish = min(at + length - start_frame, clip_frames)
            if finish > begin:
                wanted.append((begin, finish))
        if not wanted:
            raise CliFailure(
                "DUCK_SPANS_OUTSIDE_CLIP",
                "preconditions",
                "no span overlaps the clip",
                remediation="check that the spans and the clip share a timeline range",
                exit_code=EXIT_INVALID_INPUT,
            )
        wanted.sort()
        spans: list[tuple[int, int]] = [wanted[0]]
        for begin, finish in wanted[1:]:
            if begin <= spans[-1][1]:
                spans[-1] = (spans[-1][0], max(spans[-1][1], finish))
            else:
                spans.append((begin, finish))

        existing = next(
            (
                effect
                for effect in found.get("effects", [])
                if effect.get("effectType") == "dev.orangecut.audio.mix"
            ),
            None,
        )
        base_gain = Fraction(1)
        base_pan = Fraction(0)
        base_fade_in = Fraction(0)
        base_fade_out = Fraction(0)
        if existing is not None:
            parameters = existing.get("parameters", {})
            base_gain = as_fraction(parameters["gain"])
            base_pan = as_fraction(parameters["pan"])
            base_fade_in = as_fraction(parameters["fadeIn"])
            base_fade_out = as_fraction(parameters["fadeOut"])
        ducked_gain = Fraction(gain_percent, 100)

        # 一段闪避是四个点:降到位、压住、开始抬、抬回原位。
        # 前一个点的插值决定它到下一个点之间怎么走,所以"压住"那段挂 hold。
        points: dict[int, tuple[Fraction, str]] = {}
        def put(frame: int, value: Fraction, interpolation: str) -> None:
            # Core 只收 [0, clipDuration) 的半开区间:一段解说说到片尾,它的
            # "抬回"点会落在 clipDuration 上,整条命令因此被拒。贴着片尾的区间
            # 根本不需要抬回——音乐随 Clip 一起结束——所以把点夹到最后一帧,
            # 下面"撞在同一帧取更低"的规则会让它保持压住直到结束。
            frame = max(0, min(frame, clip_frames - 1))
            previous = points.get(frame)
            # 两段挨得太近时斜坡会撞在同一帧上。撞了取更低的那个值——
            # 让音乐短暂弹回原音量,比继续压着更刺耳。
            if previous is None or value < previous[0]:
                points[frame] = (value, interpolation)

        for begin, finish in spans:
            ramp = min(fade_frames, max(0, (finish - begin) // 2))
            put(begin - ramp, base_gain, "linear")
            put(begin, ducked_gain, "hold")
            put(finish, ducked_gain, "linear")
            put(finish + ramp, base_gain, "linear")

        keyframes = [
            {
                "parameter": "gain",
                "time": as_rational(Fraction(frame) / fps),
                "value": as_rational(value),
                "interpolation": interpolation,
            }
            for frame, (value, interpolation) in sorted(points.items())
        ]

        effect_id = (
            existing["id"] if existing is not None else f"effect-duck-{uuid.uuid4()}"
        )
        effect = {
            "id": effect_id,
            "effectType": "dev.orangecut.audio.mix",
            "target": "audio",
            "parameters": {
                "gain": as_rational(base_gain),
                "pan": as_rational(base_pan),
                "fadeIn": as_rational(base_fade_in),
                "fadeOut": as_rational(base_fade_out),
            },
            "keyframes": keyframes,
            "capabilityRequirements": [],
            "extensions": {},
        }
        # 重跑就整体替换掉上一次的包络。Adobe 的自动闪避有个众所周知的限制:
        # 关键帧是生成那一刻写下的,之后挪动对白或音乐它不会跟着更新。我们同样
        # 躲不掉,所以把"重跑一次就好"做成第一等的用法。
        commands = [
            {
                "type": "effect.update" if existing is not None else "effect.add",
                "payload": {
                    "sequenceId": sequence_id,
                    "clipId": arguments.clip_id,
                    "effect": effect,
                },
            }
        ]
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        key = arguments.idempotency_key or f"audio-duck:{uuid.uuid4()}"
        batch = {
            "commandId": key,
            "idempotencyKey": key,
            "projectId": project_id,
            "baseRevision": base_revision,
            "actor": {"type": "agent", "id": "orangecut-skill"},
            "intent": arguments.intent,
            "preconditions": [],
            "mode": "dry-run" if arguments.dry_run else "commit",
            "commands": commands,
        }
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "audio" and arguments.audio_command == "loudness":
        require_complete_retry_identity(arguments)
        if arguments.clear and arguments.target_lufs is not None:
            raise CliFailure(
                "LOUDNESS_CLEAR_CONFLICT",
                "validation",
                "--clear cannot be combined with --target-lufs",
                remediation="pass either --clear or --target-lufs, not both",
                exit_code=EXIT_INVALID_INPUT,
            )
        if not arguments.clear and arguments.target_lufs is None:
            raise CliFailure(
                "LOUDNESS_EMPTY",
                "validation",
                "pass --target-lufs <negative LUFS> or --clear",
                remediation="use -14 for streaming, -16 for spoken word, or --clear",
                exit_code=EXIT_INVALID_INPUT,
            )
        if arguments.target_lufs is not None and arguments.target_lufs >= 0:
            # 响度是相对满刻度的,永远是负数。正值会算出一个把整条推爆的增益。
            raise CliFailure(
                "LOUDNESS_NOT_NEGATIVE",
                "validation",
                "targetLufs must be negative",
                remediation="use a value like -14 (streaming) or -16 (spoken word)",
                exit_code=EXIT_INVALID_INPUT,
            )
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        require_sequence(project, sequence_id)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        loudness_payload: dict[str, Any] = {"sequenceId": sequence_id}
        if not arguments.clear:
            # 线上只收规约过的分数,所以 -14.5 要走 Fraction 化简成 -29/2。
            fraction = Fraction(arguments.target_lufs).limit_denominator(100)
            loudness_payload["targetLoudnessLufs"] = {
                "num": str(fraction.numerator),
                "den": str(fraction.denominator),
            }
        command_id = arguments.idempotency_key or f"audio-loudness:{uuid.uuid4()}"
        batch = {
            "commandId": command_id,
            "idempotencyKey": command_id,
            "projectId": project_id,
            "baseRevision": base_revision,
            "actor": {"type": "agent", "id": "orangecut-skill"},
            "intent": arguments.intent,
            "preconditions": [],
            "mode": "dry-run" if arguments.dry_run else "commit",
            "commands": [
                {"type": "sequence.audio.loudness.set", "payload": loudness_payload}
            ],
        }
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "canvas" and arguments.canvas_command == "looks":
        return client.request("GET", "/v1/looks")
    if arguments.command == "canvas" and arguments.canvas_command == "grade":
        require_complete_retry_identity(arguments)
        if arguments.look and (arguments.preset or arguments.lut):
            raise CliFailure(
                "GRADE_LOOK_CONFLICT",
                "validation",
                "--look already decides the preset or LUT; do not add --preset/--lut",
                remediation="pass --look <id> alone (with --intensity/--adjust if wanted), or --preset/--lut without --look",
                exit_code=EXIT_INVALID_INPUT,
            )
        if arguments.clear and (
            arguments.preset
            or arguments.intensity is not None
            or arguments.adjust
            or arguments.lut
            or arguments.lut_intensity is not None
            or arguments.look
        ):
            raise CliFailure(
                "GRADE_CLEAR_CONFLICT",
                "validation",
                "--clear cannot be combined with --preset/--intensity/--adjust/--lut",
                remediation="pass either --clear or a grade to set, not both",
                exit_code=EXIT_INVALID_INPUT,
            )
        if (
            not arguments.clear
            and not arguments.preset
            and not arguments.adjust
            and not arguments.lut
            and not arguments.look
        ):
            raise CliFailure(
                "GRADE_EMPTY",
                "validation",
                "a grade needs --look, --preset, --lut and/or --adjust (or --clear to remove)",
                remediation="pass --look <id>, --preset <id>, --lut <file.cube>, --adjust key=percent, or --clear",
                exit_code=EXIT_INVALID_INPUT,
            )
        if arguments.lut_intensity is not None and not arguments.lut:
            raise CliFailure(
                "GRADE_LUT_INTENSITY_WITHOUT_LUT",
                "validation",
                "--lut-intensity needs --lut",
                remediation="pass --lut <file.cube or asset id> alongside --lut-intensity",
                exit_code=EXIT_INVALID_INPUT,
            )
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        require_sequence(project, sequence_id)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        grade_payload: dict[str, Any] = {"sequenceId": sequence_id}
        if not arguments.clear:
            grading: dict[str, Any] = {}
            if arguments.look:
                look = resolve_look(client, arguments.look)
                strength = (
                    arguments.intensity
                    if arguments.intensity is not None
                    else int(look.get("defaultIntensityPercent") or 100)
                )
                if look.get("kind") == "preset":
                    grading["preset"] = look["presetId"]
                    grading["intensity"] = percent_rational(strength)
                else:
                    grading["lut"] = {
                        "assetId": look["assetId"],
                        "intensity": percent_rational(strength),
                    }
            if arguments.preset:
                grading["preset"] = arguments.preset
            if arguments.intensity is not None and not arguments.look:
                grading["intensity"] = percent_rational(arguments.intensity)
            if arguments.adjust:
                grading["adjust"] = {
                    key: percent_rational(value)
                    for key, value in parse_adjust_arguments(arguments.adjust)
                }
            if arguments.lut:
                lut_asset_id, base_revision = resolve_lut_asset(
                    client, project_id, project, arguments.lut, base_revision
                )
                lut: dict[str, Any] = {"assetId": lut_asset_id}
                if arguments.lut_intensity is not None:
                    lut["intensity"] = percent_rational(arguments.lut_intensity)
                grading["lut"] = lut
            grade_payload["grading"] = grading
        command_id = arguments.idempotency_key or f"canvas-grade:{uuid.uuid4()}"
        batch = {
            "commandId": command_id,
            "idempotencyKey": command_id,
            "projectId": project_id,
            "baseRevision": base_revision,
            "actor": {"type": "agent", "id": "orangecut-skill"},
            "intent": arguments.intent,
            "preconditions": [],
            "mode": "dry-run" if arguments.dry_run else "commit",
            "commands": [
                {"type": "sequence.color-grading.set", "payload": grade_payload}
            ],
        }
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "event" and arguments.event_command == "watch":
        return client.watch_events(
            arguments.count, arguments.timeout_seconds, arguments.cursor, project=named
        )
    if arguments.command == "export" and arguments.export_command == "start":
        output = arguments.output
        if not output.is_absolute():
            raise CliFailure(
                "EXPORT_PATH_NOT_ABSOLUTE",
                "validation",
                "export --output must be an absolute local path",
                remediation="pass an absolute .mp4 destination chosen by the user",
                exit_code=EXIT_INVALID_INPUT,
            )
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        # Export start resolves and fingerprints every required runtime asset before
        # publishing the Job, so it has the same cold-storage budget as import.
        client.timeout = EXPORT_START_TIMEOUT_SECONDS
        overrides: dict[str, Any] = {}
        if arguments.fps is not None:
            overrides["frameRate"] = arguments.fps
        if arguments.crf is not None:
            overrides["crf"] = arguments.crf
        if arguments.bitrate_kbps is not None:
            overrides["bitrateKbps"] = arguments.bitrate_kbps
        if arguments.gpu is not None:
            overrides["gpuEncoding"] = arguments.gpu
        # preview 在线上就是 compact + 高 crf:渲染器要求渲染尺寸等于工程
        # 尺寸,做不了真 720p 缩放,但压码率就足够把竖屏一分钟压进手机能
        # 随手传的体积——省掉外部 ffmpeg 二压那一步。
        preset = arguments.preset
        if preset == "preview":
            preset = "compact"
            overrides.setdefault("crf", 30)
        # 最后一道闸:视频轨没铺满时间线,导出来的就是黑帧(开屏黑闪/结尾
        # 黑屏放 BGM)。实拍了两条成片才发现的坑——导出照常开跑,但把黑场
        # 警告钉在响应上,不依赖调用方记得先跑 layout check。
        export_warnings: list[dict[str, Any]] = []
        try:
            gap_sequence = require_sequence(project, sequence_id)
            for gap in layout_coverage(gap_sequence):
                if arguments.from_frame is not None and gap["frames"]["end"] <= arguments.from_frame:
                    continue
                if arguments.to_frame is not None and gap["frames"]["start"] >= arguments.to_frame:
                    continue
                where_cn = {"opening": "开头", "middle": "中段", "tail": "结尾"}[gap["where"]]
                export_warnings.append({
                    "code": "EXPORT_VIDEO_LANE_GAP",
                    "message": (
                        f"{where_cn}第 {gap['frames']['start']}-{gap['frames']['end']} 帧"
                        f"没有画面(黑场 {gap['seconds']}s"
                        + (",期间音频还在放" if gap.get("audioDuringGap") else "")
                        + ")"
                    ),
                    "remediation": "oc layout check --json 看 coverage;补齐首/尾 clip 或裁掉多余时长",
                })
        except Exception:  # noqa: BLE001 - 警告是附赠的,不拦导出
            pass
        return attach_warnings(
            client.request(
                "POST",
                f"/v1/projects/{quote(project_id)}/exports",
                {
                    "sequenceId": sequence_id,
                    "preset": preset,
                    **({"fromFrame": arguments.from_frame} if arguments.from_frame is not None else {}),
                    **({"toFrame": arguments.to_frame} if arguments.to_frame is not None else {}),
                    **({"overrides": overrides} if overrides else {}),
                    "suggestedFileName": output.name,
                    "intentId": arguments.intent,
                    "outputPath": str(output),
                    "idempotencyKey": arguments.idempotency_key or f"export:{uuid.uuid4()}",
                },
            ),
            export_warnings,
        )
    if arguments.command == "timeline" and arguments.timeline_command == "place":
        try:
            cutlist = json.loads(Path(arguments.cutlist).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                f"could not read the cutlist: {error}",
                remediation="pass a readable JSON file",
                exit_code=EXIT_INVALID_INPUT,
            )
        if not isinstance(cutlist, list) or not cutlist:
            raise CliFailure(
                "PLACE_CUTLIST_INVALID", "validation",
                "the cutlist must be a non-empty JSON array",
                remediation='each entry looks like {"assetId": ..., "atFrame": 0, "durationFrames": 48}',
                exit_code=EXIT_INVALID_INPUT,
            )
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        rate = sequence_frame_rate_from(project, sequence_id)
        asset_durations: dict[str, Fraction | None] = {}
        for asset in project.get("assets", []):
            probe = asset.get("probe") or {}
            duration = None
            wire = probe.get("duration")
            if isinstance(wire, dict) and "num" in wire and "den" in wire:
                duration = Fraction(int(wire["num"]), int(wire["den"]))
            asset_durations[str(asset.get("id"))] = duration
        assets_by_id = {str(asset.get("id")): asset for asset in project.get("assets", [])}
        first_entry = cutlist[0] if isinstance(cutlist[0], dict) else {}
        rate = effective_place_frame_rate(
            sequence, rate, assets_by_id.get(str(first_entry.get("assetId")))
        )
        place_warnings: list[dict[str, Any]] = []
        placements = timeline_place_plan(cutlist, rate, asset_durations, place_warnings)
        asset_frame_rates: dict[str, Fraction | None] = {
            asset_id: asset_source_frame_rate(asset)
            for asset_id, asset in assets_by_id.items()
        }
        place_warnings.extend(
            frame_rate_mismatch_warnings(placements, rate, asset_frame_rates)
        )
        commands = []
        track_id = arguments.track_id
        if track_id is None:
            # 自动建轨的 kind 跟着素材走:纯音频剪单建音频轨(BGM/配音直接
            # place,不必绕 timeline add);混着音频和画面则明确报错,好过
            # 服务端一句 incompatible。
            entry_kinds = {
                str((assets_by_id.get(str(entry.get("assetId"))) or {}).get("kind"))
                for entry in cutlist if isinstance(entry, dict)
            }
            audio_only = entry_kinds == {"audio"}
            if "audio" in entry_kinds and not audio_only:
                raise CliFailure(
                    "PLACE_MIXED_ASSET_KINDS", "validation",
                    "the cutlist mixes audio and visual assets on one track",
                    remediation="place audio and visual assets in separate `oc timeline place` calls",
                    exit_code=EXIT_INVALID_INPUT,
                )
            orders = [int(track.get("order", 0)) for track in sequence.get("tracks", [])]
            track_id = f"track-place-{uuid.uuid4()}"
            new_order = (max(orders) + 1) if orders else 0
            if not audio_only:
                # 新视频轨插到最低的文字类轨道(caption/component)之下,
                # 不盖字幕/贴纸:把文字边界及其上全部轨道整体抬高 10
                # (order 从高到低发 track.update,+10 永不撞号),腾出的
                # 边界位给新轨。与服务端 timeline add 同一条规则。
                text_orders = [
                    int(track.get("order", 0))
                    for track in sequence.get("tracks", [])
                    if track.get("kind") in ("caption", "component")
                ]
                if text_orders:
                    floor = min(text_orders)
                    lifted = sorted(
                        (
                            track for track in sequence.get("tracks", [])
                            if int(track.get("order", 0)) >= floor
                        ),
                        key=lambda track: -int(track.get("order", 0)),
                    )
                    for track in lifted:
                        settings = {
                            "kind": track.get("kind"),
                            "order": int(track.get("order", 0)) + 10,
                            "muted": bool(track.get("muted", False)),
                            "locked": bool(track.get("locked", False)),
                            "extensions": track.get("extensions") or {},
                        }
                        if track.get("role") is not None:
                            settings["role"] = track.get("role")
                        commands.append({
                            "type": "track.update",
                            "payload": {
                                "sequenceId": sequence_id,
                                "trackId": track.get("id"),
                                "settings": settings,
                            },
                        })
                    new_order = floor
            commands.append({
                "type": "track.add",
                "payload": {
                    "sequenceId": sequence_id,
                    "track": {
                        "id": track_id,
                        "kind": "audio" if audio_only else "video",
                        "order": new_order,
                        # 引擎契约:muted 轨的节点在编译期整个跳过——画面
                        # 也没了。静音只能走 clip 级增益。
                        "role": "audio" if audio_only else "footage",
                        "muted": False, "locked": False,
                        "clips": [], "captions": [],
                        # 与服务端建轨同款的来源标记:删空后可被自动回收,
                        # 显式 track add 建的轨道则永不误删。
                        "extensions": {
                            "dev.orangecut.track-origin": {
                                "schemaVersion": "1",
                                "data": {"origin": "auto-placement"},
                            },
                        },
                    },
                },
            })
        # 静音随 Clip 一起建,而不是放置成功之后再逐条改音量。此前那样做时,
        # 服务端缺 `audio/volume` 端点就会在放置**已经提交**之后才报
        # SERVICE_ENDPOINT_UNKNOWN——按"报错=没写入"重跑一次就多出一整条
        # 重复视频轨。一条命令批次要么全成要么全不成,这件事才有保证。
        commands.extend(
            timeline_place_commands(
                sequence_id, track_id, placements, muted=arguments.muted
            )
        )
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        batch = sfx_command_batch(project_id, base_revision, arguments.intent,
                                  arguments.idempotency_key, "timeline-place", commands)
        response = client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
        data = response.get("data") if isinstance(response, dict) else None
        result: dict[str, Any] = {
            "trackId": track_id,
            "placed": [
                {
                    "clipId": item["clipId"],
                    "assetId": item["assetId"],
                    "atFrame": item["atFrame"],
                    "durationFrames": item["durationFrames"],
                }
                for item in placements
            ],
            "revision": (data or {}).get("revision"),
        }
        if place_warnings:
            result["warnings"] = place_warnings
        return result
    if arguments.command == "marker":
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        rate = sequence_frame_rate_from(project, sequence_id)
        markers = sequence.get("markers", [])
        if arguments.marker_command == "list":
            return {
                "sequenceId": sequence_id,
                "markers": [
                    {
                        "id": item.get("id"),
                        "label": item.get("label"),
                        "atFrame": round(float(_rational_of(item.get("time"))) * float(rate)),
                        "seconds": _seconds_text(item.get("time")),
                    }
                    for item in markers
                ],
            }
        require_complete_retry_identity(arguments)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)

        def marker_time(frame: int) -> dict[str, str]:
            amount = Fraction(frame) / rate
            return {"num": str(amount.numerator), "den": str(amount.denominator)}

        if arguments.marker_command == "add":
            marker_id = arguments.marker_id or f"marker-{uuid.uuid4()}"
            payload = {
                "sequenceId": sequence_id,
                "marker": {
                    "id": marker_id,
                    "time": marker_time(arguments.at_frame),
                    "label": arguments.label,
                },
            }
            command_type = "sequence.marker.add"
        elif arguments.marker_command == "update":
            existing = next(
                (item for item in markers if item.get("id") == arguments.marker_id), None
            )
            if existing is None:
                raise CliFailure(
                    "MARKER_NOT_FOUND",
                    "preconditions",
                    f"the sequence has no marker {arguments.marker_id!r}",
                    remediation="run `oc marker list --json` and pass an existing id",
                    exit_code=EXIT_INVALID_INPUT,
                )
            if arguments.label is None and arguments.at_frame is None:
                raise CliFailure(
                    "MARKER_UPDATE_EMPTY",
                    "validation",
                    "a marker update must change the label or the time",
                    remediation="pass --label and/or --at-frame",
                    exit_code=EXIT_INVALID_INPUT,
                )
            payload = {
                "sequenceId": sequence_id,
                "marker": {
                    "id": arguments.marker_id,
                    "time": (
                        marker_time(arguments.at_frame)
                        if arguments.at_frame is not None
                        else existing.get("time")
                    ),
                    "label": (
                        arguments.label if arguments.label is not None else existing.get("label")
                    ),
                },
            }
            command_type = "sequence.marker.update"
        else:
            payload = {"sequenceId": sequence_id, "markerId": arguments.marker_id}
            command_type = "sequence.marker.remove"
        action = (
            arguments.idempotency_key or f"marker-{arguments.marker_command}:{uuid.uuid4()}"
        )
        return client.request(
            "POST",
            f"/v1/projects/{quote(project_id)}/commands",
            {
                "commandId": action,
                "idempotencyKey": action,
                "projectId": project_id,
                "baseRevision": base_revision,
                "actor": {"type": "agent", "id": "orangecut-skill"},
                "intent": arguments.intent,
                "preconditions": [],
                "mode": "commit",
                "commands": [{"type": command_type, "payload": payload}],
            },
        )
    if arguments.command == "layout":
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        if arguments.layout_command == "list":
            elements = collect_layout_elements(project, sequence)
            return {
                "sequenceId": sequence_id,
                "canvas": sequence.get("canvas"),
                "elements": [
                    {
                        **{k: item[k] for k in ("kind", "id", "label", "startFrame", "endFrame")},
                        "box": _round_box(item["box"]),
                        "animated": bool(item.get("motion")),
                    }
                    for item in elements
                ],
            }
        if (arguments.from_frame is None) != (arguments.to_frame is None):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "--from-frame and --to-frame must be provided together",
                exit_code=EXIT_INVALID_INPUT,
            )
        if arguments.from_frame is not None and arguments.at_frame is not None:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "--at-frame and --from-frame/--to-frame are mutually exclusive",
                exit_code=EXIT_INVALID_INPUT,
            )
        if arguments.from_frame is not None and arguments.to_frame <= arguments.from_frame:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "--to-frame must be greater than --from-frame",
                exit_code=EXIT_INVALID_INPUT,
            )
        return layout_report(
            project,
            sequence,
            image_bounds=lambda asset_id: require_object(client.request(
                "GET", f"/v1/projects/{quote(project_id)}/assets/{quote(asset_id)}/alpha-bounds", timeout_cap=2.0
            ), "data"),
            minimum_ratio=arguments.min_overlap,
            near_px=arguments.near,
            at_frame=arguments.at_frame,
            frame_range=(
                (arguments.from_frame, arguments.to_frame)
                if arguments.from_frame is not None else None
            ),
        )
    if arguments.command == "read":
        selection = read_selection(arguments)
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        client.timeout = arguments.timeout_seconds
        started = require_object(
            client.request(
                "POST",
                f"/v1/projects/{quote(project_id)}/frames",
                {
                    "sequenceId": sequence_id,
                    "selection": selection,
                    "detail": arguments.detail,
                },
            ),
            "data",
        )
        job_id = require_object(started, "snapshot").get("jobId")
        if not isinstance(job_id, str) or not job_id:
            raise CliFailure(
                "HTTP_RESPONSE_INVALID",
                "serialization",
                "the read Job did not return an opaque Job ID",
            )
        jobs = f"/v1/projects/{quote(project_id)}/jobs/{quote(job_id)}"
        deadline = time.monotonic() + arguments.timeout_seconds
        while True:
            snapshot = require_object(client.request("GET", jobs), "data")
            state = require_job_state(snapshot)
            if state in ("cancelled", "failed", "interrupted", "succeeded"):
                break
            if time.monotonic() >= deadline:
                progress = snapshot.get("progress") or {}
                stage = progress.get("phase") or ("captureQueue" if state == "queued" else "frameCapture")
                queue_depth = None
                try:
                    client.request("POST", f"{jobs}/cancel", {}, timeout_cap=2.0)
                except CliFailure:
                    pass
                try:
                    job_list = client.request("GET", f"/v1/projects/{quote(project_id)}/jobs", timeout_cap=2.0).get("data")
                    if isinstance(job_list, list):
                        queue_depth = sum(job.get("kind") == "frames" and job.get("state") == "queued" for job in job_list)
                except CliFailure:
                    pass
                raise CliFailure(
                    "READ_TIMEOUT",
                    "job",
                    "the read did not finish before the requested timeout",
                    retryable=True,
                    remediation="raise --timeout-seconds or read fewer frames",
                    details={"jobId": job_id, "blockingStage": stage, "queueDepth": queue_depth},
                    exit_code=EXIT_SERVICE_UNAVAILABLE,
                )
            time.sleep(0.2)
        collected = require_object(client.request("POST", f"{jobs}/collect", {}), "data")
        result = require_object(collected, "snapshot")
        if result.get("state") != "succeeded":
            # The failure the renderer reported is more useful than any summary
            # this layer could invent, so hand it back verbatim.
            raise decode_server_failure(
                result.get("error"),
                invalid_code="READ_FAILED",
                invalid_message="the read did not produce a frame sheet",
            )
        artifact_id = result.get("artifactId")
        if not isinstance(artifact_id, str) or not artifact_id:
            raise CliFailure(
                "HTTP_RESPONSE_INVALID",
                "serialization",
                "the finished read did not return an artifact handle",
            )
        output = arguments.output or Path(tempfile.gettempdir()) / f"orangecut-read-{job_id}.png"
        written = client.download(
            f"/v1/projects/{quote(project_id)}/frames/{quote(artifact_id)}",
            output,
        )
        return {
            "schemaVersion": SCHEMA_VERSION,
            "ok": True,
            "data": {
                "sheet": str(output),
                "bytes": written,
                "sequenceId": started.get("sequenceId"),
                "detail": started.get("detail"),
                "frames": started.get("frames"),
                "layout": started.get("layout"),
            },
        }
    if arguments.command == "job":
        base = f"/v1/projects/{quote(project_id)}/jobs"
        if arguments.job_command == "list":
            return client.request("GET", base)
        job_id = quote(arguments.job_id)
        if arguments.job_command == "watch":
            if arguments.no_wait:
                return client.request("GET", f"{base}/{job_id}")
            deadline = time.monotonic() + arguments.timeout_seconds
            while True:
                response = client.request("GET", f"{base}/{job_id}")
                snapshot = require_object(response, "data")
                state = require_job_state(snapshot)
                if state in ("cancelled", "failed", "interrupted", "succeeded"):
                    return response
                if time.monotonic() >= deadline:
                    raise CliFailure(
                        "JOB_WATCH_TIMEOUT",
                        "job",
                        "the Job did not become terminal before the requested timeout",
                        retryable=True,
                        remediation="continue watching the same opaque Job ID or cancel it",
                        exit_code=EXIT_SERVICE_UNAVAILABLE,
                    )
                time.sleep(0.2)
        if arguments.job_command == "cancel":
            return client.request("POST", f"{base}/{job_id}/cancel", {})
        if arguments.job_command == "collect":
            client.timeout = JOB_TIMEOUT_SECONDS
            return client.request("POST", f"{base}/{job_id}/collect", {})
        if arguments.job_command == "retry":
            return client.request(
                "POST",
                f"{base}/{job_id}/retry",
                {
                    "idempotencyKey": arguments.idempotency_key
                    or f"job-retry:{uuid.uuid4()}"
                },
            )
    if arguments.command == "project" and arguments.project_command == "current":
        # 多开时 `/v1/projects/current` 没有确定含义,带上点名的工程(ADR 0043)。
        return client.request("GET", f"/v1/projects/current{project_query(named)}")
    if arguments.command == "asset" and arguments.asset_command == "list":
        listed = client.request("GET", f"/v1/projects/{quote(project_id)}/assets")
        # 在客户端筛,不给服务端加一个只为省一次 jq 的查询参数。这条命令存在的
        # 理由是:内置字体有哪些、它们的 id 是什么,此前只能靠翻仓库源码知道。
        if arguments.kind is not None:
            data = listed.get("data")
            assets = data.get("assets") if isinstance(data, dict) else None
            if isinstance(assets, list):
                listed = dict(listed)
                listed["data"] = dict(data)
                listed["data"]["assets"] = [
                    asset
                    for asset in assets
                    if isinstance(asset, dict) and asset.get("kind") == arguments.kind
                ]
        return listed
    if arguments.command == "asset" and arguments.asset_command == "remove":
        require_complete_retry_identity(arguments)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        return client.request(
            "POST",
            f"/v1/projects/{quote(project_id)}/assets/remove",
            {
                "assetId": arguments.asset_id,
                "baseRevision": base_revision,
                "idempotencyKey": arguments.idempotency_key
                or f"asset-remove:{uuid.uuid4()}",
                "intent": arguments.intent,
            },
        )
    if arguments.command == "asset" and arguments.asset_command == "import":
        require_complete_retry_identity(arguments)
        paths = [path for path in arguments.paths]
        if any(not path.is_absolute() for path in paths):
            raise CliFailure(
                "ASSET_PATH_NOT_ABSOLUTE",
                "validation",
                "every imported file path must be absolute",
                remediation="pass an absolute local file path",
                exit_code=EXIT_INVALID_INPUT,
            )
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        payload: dict[str, Any] = {
            "baseRevision": base_revision,
            "paths": [str(path) for path in paths],
            "intent": arguments.intent,
            "idempotencyKey": arguments.idempotency_key
            or f"asset-import:{uuid.uuid4()}",
        }
        if arguments.kind:
            payload["expectedKind"] = arguments.kind
        client.timeout = IMPORT_TIMEOUT_SECONDS
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/assets/import", payload
        )
    if arguments.command == "timeline" and arguments.timeline_command == "snapshot":
        response = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        return filter_snapshot_response(
            response,
            sequence_id=arguments.sequence_id,
            track_ids=arguments.tracks,
            kinds=arguments.kind,
            drop_assets=arguments.no_assets,
        )
    if arguments.command == "timeline" and arguments.timeline_command == "inspect":
        payload = {"ids": arguments.ids, "trackIds": arguments.track_ids, "full": arguments.full}
        for attribute, key in [("sequence_id", "sequenceId"), ("kind", "kind"), ("text", "text"),
                               ("external_ref", "externalRef"), ("from_frame", "fromFrame"),
                               ("to_frame", "toFrame"), ("limit", "limit")]:
            value = getattr(arguments, attribute)
            if value is not None:
                payload[key] = value
        return client.request("POST", f"/v1/projects/{quote(project_id)}/inspect", payload)
    if arguments.command == "timeline" and arguments.timeline_command in ("ripple-delete", "ripple-trim"):
        require_complete_retry_identity(arguments)
        name = arguments.timeline_command
        selectors = arguments.exclude_tracks.split(",") if arguments.exclude_tracks is not None else []
        operation = {"op": name, "excludeTracks": [selector.strip() for selector in selectors]}
        if any(not selector.strip() for selector in selectors):
            raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--exclude-tracks contains an empty selector", exit_code=EXIT_INVALID_INPUT)
        if name == "ripple-delete":
            if arguments.to_frame <= arguments.from_frame:
                raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--to-frame must exceed --from-frame", exit_code=EXIT_INVALID_INPUT)
            operation.update(fromFrame=arguments.from_frame, toFrame=arguments.to_frame)
        else:
            if arguments.delta_frames == 0:
                raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--delta-frames must be nonzero", exit_code=EXIT_INVALID_INPUT)
            operation.update(clipId=arguments.clip_id, deltaFrames=arguments.delta_frames, edge=arguments.edge)
        payload = {
            "baseRevision": current_revision(client) if arguments.base_revision is None else arguments.base_revision,
            "idempotencyKey": arguments.idempotency_key or f"{name}:{uuid.uuid4()}",
            "intent": arguments.intent,
            "mode": "dry-run" if arguments.dry_run else "commit",
            "operations": [operation],
        }
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        return client.request("POST", f"/v1/projects/{quote(project_id)}/edit-plan", payload)
    if arguments.command == "timeline" and arguments.timeline_command == "edit":
        payload = read_request_file(arguments.file)
        if arguments.dry_run:
            payload["mode"] = "dry-run"
        return client.request("POST", f"/v1/projects/{quote(project_id)}/edit-plan", payload)
    if arguments.command == "timeline" and arguments.timeline_command == "clear":
        require_complete_retry_identity(arguments)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        payload: dict[str, Any] = {
            "baseRevision": base_revision,
            "intent": arguments.intent,
            "idempotencyKey": arguments.idempotency_key
            or f"timeline-clear:{uuid.uuid4()}",
        }
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/timeline/clear", payload
        )
    if arguments.command == "effect" and arguments.effect_command == "style":
        require_complete_retry_identity(arguments)
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        rate = sequence_frame_rate_from(project, sequence_id)
        found = find_sequence_clip(sequence, arguments.clip_id)
        if found is None:
            raise CliFailure(
                "STYLE_CLIP_NOT_FOUND", "preconditions",
                f"clip {arguments.clip_id!r} does not exist in sequence {sequence_id!r}",
                remediation="run `oc timeline snapshot` (or `oc sticker list` / `oc shape list`) and pass a clip id",
                exit_code=EXIT_INVALID_INPUT,
            )
        style_track, clip = found
        # 画面片段在 video 轨,贴纸/形状/HTML 卡片在 component 轨;音频与字幕轨没有可发光的图层。
        if style_track.get("kind") not in ("video", "component"):
            raise CliFailure("STYLE_TARGET_INVALID", "validation", "layer looks go on visual clips (footage, stickers, shapes, HTML cards), not audio or caption tracks", exit_code=EXIT_INVALID_INPUT)
        commands = layer_style_commands(sequence_id, clip, rate, arguments)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        command_id = arguments.idempotency_key or f"layer-style:{uuid.uuid4()}"
        batch = {
            "commandId": command_id,
            "idempotencyKey": command_id,
            "projectId": project_id,
            "baseRevision": base_revision,
            "actor": {"type": "agent", "id": "orangecut-skill"},
            "intent": arguments.intent,
            "preconditions": [],
            "mode": "dry-run" if arguments.dry_run else "commit",
            "commands": commands,
        }
        return client.request("POST", f"/v1/projects/{quote(project_id)}/commands", batch)
    if arguments.command == "effect" and arguments.effect_command == "exposure":
        require_complete_retry_identity(arguments)
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        rate = sequence_frame_rate_from(project, sequence_id)
        clip = None
        for track in sequence.get("tracks", []):
            for candidate in track.get("clips", []):
                if candidate.get("id") == arguments.clip_id:
                    clip = candidate
        if clip is None:
            raise CliFailure(
                "EXPOSURE_CLIP_NOT_FOUND",
                "preconditions",
                f"clip {arguments.clip_id!r} does not exist in sequence {sequence_id!r}",
                remediation="run `oc timeline snapshot` and pass a clip id",
                exit_code=EXIT_INVALID_INPUT,
            )
        existing = next(
            (
                candidate
                for candidate in clip.get("effects", [])
                if candidate.get("effectType") == EXPOSURE_EFFECT_TYPE
            ),
            None,
        )
        if arguments.clear:
            if existing is None:
                raise CliFailure(
                    "EXPOSURE_NOT_PRESENT",
                    "preconditions",
                    f"clip {arguments.clip_id!r} carries no exposure effect to clear",
                    remediation="drop --clear, or pass a clip that has one",
                    exit_code=EXIT_INVALID_INPUT,
                )
            commands = [
                {
                    "type": "effect.remove",
                    "payload": {
                        "sequenceId": sequence_id,
                        "clipId": clip["id"],
                        "effectId": existing["id"],
                    },
                }
            ]
        else:
            keyframes = []
            for spec in arguments.keyframe:
                parameter, frame, percent, easing = parse_exposure_keyframe(spec)
                # Never name this `time`: any name assigned inside `execute`
                # is local for the whole function, and the module-level `time`
                # is what the job/read paths call `monotonic` on.
                at = Fraction(frame) / rate
                keyframes.append(
                    {
                        "parameter": parameter,
                        "time": {
                            "num": str(at.numerator),
                            "den": str(at.denominator),
                        },
                        "value": percent_rational(percent),
                        "interpolation": easing,
                    }
                )
            # Core wants one strictly increasing run per parameter, and the CLI
            # is the last place that still knows the author's typing order.
            keyframes.sort(key=lambda entry: (entry["parameter"], Fraction(int(entry["time"]["num"]), int(entry["time"]["den"]))))
            effect = {
                "id": existing["id"] if existing else f"exposure-{uuid.uuid4()}",
                "effectType": EXPOSURE_EFFECT_TYPE,
                "target": "visual",
                "parameters": {
                    "brightness": percent_rational(arguments.brightness_percent),
                    "saturation": percent_rational(arguments.saturation_percent),
                },
                "keyframes": keyframes,
                "capabilityRequirements": [],
                "extensions": {},
            }
            commands = [
                {
                    "type": "effect.update" if existing else "effect.add",
                    "payload": {
                        "sequenceId": sequence_id,
                        "clipId": clip["id"],
                        "effect": effect,
                    },
                }
            ]
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        command_id = arguments.idempotency_key or f"exposure:{uuid.uuid4()}"
        batch = {
            "commandId": command_id,
            "idempotencyKey": command_id,
            "projectId": project_id,
            "baseRevision": base_revision,
            "actor": {"type": "agent", "id": "orangecut-skill"},
            "intent": arguments.intent,
            "preconditions": [],
            "mode": "dry-run" if arguments.dry_run else "commit",
            "commands": commands,
        }
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "overlay" and arguments.overlay_command == "add":
        require_complete_retry_identity(arguments)
        return apply_overlay_add(client, project_id, arguments)
    if arguments.command == "timeline" and arguments.timeline_command == "follow":
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        return apply_follow(client, project_id, project, sequence, arguments)
    if arguments.command == "timeline" and arguments.timeline_command == "privacy" and privacy_wants_sticker(arguments):
        # 裸 `oc timeline privacy <clip>` 就是云朵贴——像素模糊看着像打码的小电影,
        # 只在点名 --style / --box / --no-faces 时才走派生重编码那条路。
        if arguments.sticker is None and not arguments.clear:
            arguments.sticker = DEFAULT_COVER_STICKER
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        stickers = face_stickers_of(sequence, arguments.clip_id)
        if arguments.clear:
            removed = None
            if stickers:
                removed = apply_face_sticker_clear(client, project_id, sequence, arguments.clip_id, stickers, arguments)
            found = find_sequence_clip(sequence, arguments.clip_id)
            has_pixel = found is not None and any(
                effect.get("effectType") == PRIVACY_EFFECT_TYPE for effect in found[1].get("effects", [])
            )
            if has_pixel:
                payload = {"clipId": arguments.clip_id, "clear": True}
                if arguments.sequence_id:
                    payload["sequenceId"] = arguments.sequence_id
                if arguments.intent:
                    payload["intent"] = arguments.intent
                response = client.request(
                    "POST", f"/v1/projects/{quote(project_id)}/clips/privacy", payload, timeout_seconds=600,
                )
                if removed is not None:
                    require_object(response, "data")["stickers"] = removed
                return response
            if removed is None:
                # Nothing local to clear: let the service answer (it reports CLIP_PRIVACY_NOT_PRESENT itself).
                payload = {"clipId": arguments.clip_id, "clear": True}
                if arguments.sequence_id:
                    payload["sequenceId"] = arguments.sequence_id
                if arguments.intent:
                    payload["intent"] = arguments.intent
                return client.request(
                    "POST", f"/v1/projects/{quote(project_id)}/clips/privacy", payload, timeout_seconds=600,
                )
            return {"schemaVersion": SCHEMA_VERSION, "ok": True, "data": {"clipId": arguments.clip_id, "cleared": True, "stickers": removed}}
        return apply_face_stickers(client, project_id, project, sequence, arguments, stickers)
    if arguments.command == "timeline" and arguments.timeline_command == "privacy":
        payload = {"clipId": arguments.clip_id}
        if arguments.clear:
            if arguments.boxes or arguments.no_faces:
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID", "validation",
                    "--clear takes no cover parameters",
                    exit_code=EXIT_INVALID_INPUT,
                )
            payload["clear"] = True
        else:
            payload.update(privacy_cover_payload(arguments))
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        if arguments.intent:
            payload["intent"] = arguments.intent
        # 派生 = 整条源素材跟踪 + 一次编码(同 key 命中缓存秒回);长素材分钟级。
        return client.request(
            "POST",
            f"/v1/projects/{quote(project_id)}/clips/privacy",
            payload,
            timeout_seconds=3600,
        )
    if arguments.command == "timeline" and arguments.timeline_command == "mask":
        sources = sum((
            arguments.mask is not None,
            arguments.shape is not None,
            bool(arguments.points) or arguments.prompt_box is not None,
        ))
        if (sources + int(arguments.clear)) != 1:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                "pass exactly one of --mask <file>, --shape <geometry>, "
                "--point/--prompt-box (smart), or --clear",
            )
        payload: dict[str, Any] = {"clipId": arguments.clip_id}
        if arguments.mask is not None:
            payload["mask"] = str(absolute_media_path(arguments.mask))
        if arguments.shape is not None:
            payload["shape"] = arguments.shape
            for name, value in (
                ("box", arguments.box),
                ("center", arguments.center),
                ("radius", arguments.radius),
                ("angle", arguments.angle),
                ("position", arguments.position),
                ("softness", arguments.softness),
            ):
                if value is not None:
                    payload[name] = value
        if arguments.points:
            payload["points"] = [[x, y] for x, y, _ in arguments.points]
            payload["labels"] = [label for _, _, label in arguments.points]
        if arguments.prompt_box is not None:
            payload["promptBox"] = arguments.prompt_box
        if arguments.frame is not None:
            payload["frame"] = arguments.frame
        if arguments.feather is not None:
            payload["feather"] = arguments.feather
        if arguments.invert:
            payload["invert"] = True
        if arguments.clear:
            payload["clear"] = True
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        if arguments.intent:
            payload["intent"] = arguments.intent
        # 派生 = 整条源素材一次 VP9 编码(有缓存命中则秒回);长素材分钟级。
        return client.request(
            "POST",
            f"/v1/projects/{quote(project_id)}/clips/mask",
            payload,
            timeout_seconds=1800,
        )
    if arguments.command == "timeline" and arguments.timeline_command == "transition":
        require_complete_retry_identity(arguments)
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        rate = sequence_frame_rate_from(project, sequence_id)
        duration = Fraction(arguments.duration_frames) / rate

        def as_fraction(value: dict[str, Any]) -> Fraction:
            return Fraction(int(value["num"]), int(value["den"]))

        def as_rational(value: Fraction) -> dict[str, str]:
            return {"num": str(value.numerator), "den": str(value.denominator)}

        found: tuple[dict[str, Any], dict[str, Any]] | None = None
        for track in sequence.get("tracks", []):
            for clip in track.get("clips", []):
                if clip.get("id") == arguments.clip_id:
                    found = (track, clip)
        if found is None:
            raise CliFailure(
                "TRANSITION_CLIP_NOT_FOUND",
                "preconditions",
                f"clip {arguments.clip_id!r} does not exist in sequence {sequence_id!r}",
                remediation="run `oc timeline snapshot` and pass a video clip id",
                exit_code=EXIT_INVALID_INPUT,
            )
        track, clip = found
        clip_start = as_fraction(clip["timelineRange"]["start"])
        clip_end = as_fraction(clip["timelineRange"]["end"])
        if clip_end - clip_start < duration:
            raise CliFailure(
                "TRANSITION_LONGER_THAN_CLIP",
                "validation",
                "the transition cannot be longer than the clip it is on",
                remediation="pass a smaller --duration-frames",
                exit_code=EXIT_INVALID_INPUT,
            )
        commands: list[dict[str, Any]] = []
        if arguments.transition_type == "crossfade":
            if track.get("kind") != "video":
                raise CliFailure(
                    "TRANSITION_TRACK_NOT_VIDEO",
                    "validation",
                    "crossfade is limited to clips on a video track",
                    exit_code=EXIT_INVALID_INPUT,
                )
            previous_clips = [
                candidate
                for candidate in track.get("clips", [])
                if candidate.get("id") != clip.get("id")
                and as_fraction(candidate["timelineRange"]["start"]) < clip_start
            ]
            if not previous_clips:
                raise CliFailure(
                    "TRANSITION_NO_PREVIOUS_CLIP",
                    "preconditions",
                    "crossfade needs a preceding clip on the same track to blend from",
                    remediation="use --type fade-in for the first clip",
                    exit_code=EXIT_INVALID_INPUT,
                )
            previous = max(
                previous_clips,
                key=lambda candidate: as_fraction(candidate["timelineRange"]["start"]),
            )
            previous_end = as_fraction(previous["timelineRange"]["end"])
            transition_end = clip_start + duration
            if previous_end < transition_end:
                # The engine blends only where both clips exist, so an abutting
                # cut is stretched: the outgoing clip keeps playing (more source
                # material) under the incoming one for the transition window.
                if previous_end != clip_start:
                    raise CliFailure(
                        "TRANSITION_GAP_BETWEEN_CLIPS",
                        "preconditions",
                        "crossfade needs the previous clip to abut or overlap this one",
                        remediation="close the gap first (timeline move / gap-remove)",
                        exit_code=EXIT_INVALID_INPUT,
                    )
                source_range = previous.get("sourceRange")
                if not isinstance(source_range, dict):
                    raise CliFailure(
                        "TRANSITION_PREVIOUS_NOT_EXTENDABLE",
                        "preconditions",
                        "the previous clip carries no source range to extend into the overlap",
                        remediation="overlap the clips yourself, then rerun",
                        exit_code=EXIT_INVALID_INPUT,
                    )
                # The stretch borrows unused source material from the previous
                # clip. Check the asset actually has that much left, so the
                # caller gets frame math instead of a downstream INVALID_RANGE.
                previous_asset_id = (previous.get("source") or {}).get("assetId")
                previous_asset = next(
                    (
                        asset
                        for asset in project.get("assets", [])
                        if asset.get("id") == previous_asset_id
                    ),
                    None,
                )
                probe_duration = None
                if isinstance(previous_asset, dict):
                    probe = previous_asset.get("probe") or {}
                    if isinstance(probe.get("duration"), dict):
                        probe_duration = as_fraction(probe["duration"])
                if probe_duration is not None:
                    playback_rate = Fraction(1)
                    playback = previous.get("playback")
                    if isinstance(playback, dict) and isinstance(playback.get("rate"), dict):
                        playback_rate = as_fraction(playback["rate"])
                    headroom = (
                        probe_duration - as_fraction(source_range["end"])
                    ) / playback_rate
                    if headroom < duration:
                        available_frames = max(int(headroom * rate), 0)
                        raise CliFailure(
                            "TRANSITION_SOURCE_EXHAUSTED",
                            "preconditions",
                            "the previous clip's asset has "
                            f"{available_frames} unused frame(s) left, but this "
                            f"crossfade must extend it by {arguments.duration_frames}",
                            remediation=(
                                f"pass --duration-frames {available_frames} or less"
                                if available_frames >= 2
                                else "the previous clip already uses its whole asset: trim its end first to free material, or keep the hard cut"
                            ),
                            exit_code=EXIT_INVALID_INPUT,
                        )
                def extend_command(target: dict[str, Any]) -> dict[str, Any] | None:
                    target_source = target.get("sourceRange")
                    if not isinstance(target_source, dict):
                        return None
                    target_rate = Fraction(1)
                    playback = target.get("playback")
                    if isinstance(playback, dict) and isinstance(playback.get("rate"), dict):
                        target_rate = as_fraction(playback["rate"])
                    return {
                        "type": "clip.trim",
                        "payload": {
                            "sequenceId": sequence_id,
                            "clipId": target["id"],
                            "timelineRange": {
                                "start": target["timelineRange"]["start"],
                                "end": as_rational(transition_end),
                            },
                            "sourceRange": {
                                "start": target_source["start"],
                                "end": as_rational(
                                    as_fraction(target_source["end"]) + duration * target_rate
                                ),
                            },
                        },
                    }

                commands.append(extend_command(previous))
                if commands[-1] is None:
                    raise CliFailure(
                        "TRANSITION_PREVIOUS_NOT_EXTENDABLE",
                        "preconditions",
                        "the previous clip carries no source range to extend into the overlap",
                        remediation="overlap the clips yourself, then rerun",
                        exit_code=EXIT_INVALID_INPUT,
                    )
                # A linked audio peer must stretch with its video: linked AV
                # segments are validated as identical timeline+source ranges,
                # so extending one side alone is rejected by Core.
                link = previous.get("extensions", {}).get("dev.orangecut.linked-av")
                group_id = (
                    link.get("data", {}).get("groupId") if isinstance(link, dict) else None
                )
                if group_id:
                    for peer_track in sequence.get("tracks", []):
                        for peer in peer_track.get("clips", []):
                            peer_link = peer.get("extensions", {}).get(
                                "dev.orangecut.linked-av"
                            )
                            if (
                                peer.get("id") != previous.get("id")
                                and isinstance(peer_link, dict)
                                and peer_link.get("data", {}).get("groupId") == group_id
                            ):
                                peer_command = extend_command(peer)
                                if peer_command is not None:
                                    commands.append(peer_command)
            commands.append(
                {
                    "type": "effect.add",
                    "payload": {
                        "sequenceId": sequence_id,
                        "clipId": clip["id"],
                        "effect": {
                            "id": f"transition-crossfade-{uuid.uuid4()}",
                            "effectType": "dev.orangecut.transition.crossfade",
                            "target": "visual",
                            "parameters": {
                                "fromClipId": previous["id"],
                                "duration": as_rational(duration),
                                # 线性时整个字段不发:老 Project 的规范字节
                                # 与哈希一个比特都不变。
                                **(
                                    {"easing": arguments.easing}
                                    if arguments.easing != "linear"
                                    else {}
                                ),
                            },
                            "keyframes": [],
                            "capabilityRequirements": [],
                            "extensions": {},
                        },
                    },
                }
            )
        else:
            # Opacity keyframe times live on the clip's own clock and must stay
            # strictly inside it, so the fade lands on the last drawable frame.
            frame = Fraction(1) / rate
            clip_duration = clip_end - clip_start
            if arguments.transition_type == "fade-in":
                points = [(Fraction(0), Fraction(0)), (duration, Fraction(1))]
            else:
                points = [
                    (clip_duration - duration, Fraction(1)),
                    (clip_duration - frame, Fraction(0)),
                ]
            for index, (offset, value) in enumerate(points):
                commands.append(
                    {
                        "type": "visual.keyframe.upsert",
                        "payload": {
                            "target": {
                                "type": "clip",
                                "sequenceId": sequence_id,
                                "clipId": clip["id"],
                            },
                            "property": "opacity",
                            "keyframe": {
                                "id": f"transition-{arguments.transition_type}-{index}",
                                "time": as_rational(offset),
                                "value": {"type": "scalar", "value": as_rational(value)},
                                "easing": "linear",
                            },
                        },
                    }
                )
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        command_id = arguments.idempotency_key or f"transition:{uuid.uuid4()}"
        batch = {
            "commandId": command_id,
            "idempotencyKey": command_id,
            "projectId": project_id,
            "baseRevision": base_revision,
            "actor": {"type": "agent", "id": "orangecut-skill"},
            "intent": arguments.intent,
            "preconditions": [],
            "mode": "dry-run" if arguments.dry_run else "commit",
            "commands": commands,
        }
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "timeline" and arguments.timeline_command in (
        "gap-insert",
        "gap-remove",
    ):
        # Built here rather than behind its own endpoint: the gap commands are
        # ordinary registered semantic Commands, and the only thing the CLI adds
        # is turning frames into the Sequence's own exact Rational.
        require_complete_retry_identity(arguments)
        sequence_id, rate = resolve_sequence_time_base(
            client, project_id, arguments.sequence_id
        )
        at = Fraction(arguments.at_frame) / rate
        duration = Fraction(arguments.duration_frames) / rate
        if getattr(arguments, "split_crossing", False):
            if arguments.base_revision is not None:
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID", "validation",
                    "--split-crossing performs its own writes, so an explicit "
                    "--base-revision cannot stay valid",
                    remediation="drop --base-revision/--idempotency-key or split manually first",
                    exit_code=EXIT_INVALID_INPUT,
                )
            split_clips_crossing_gap(
                client, project_id, sequence_id, arguments.at_frame, at
            )
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        operation = (
            "sequence.gap.insert"
            if arguments.timeline_command == "gap-insert"
            else "sequence.gap.remove"
        )
        command_id = arguments.idempotency_key or f"gap:{uuid.uuid4()}"
        batch: dict[str, Any] = {
            "commandId": command_id,
            "idempotencyKey": command_id,
            "projectId": project_id,
            "baseRevision": base_revision,
            "actor": {"type": "agent", "id": "orangecut-skill"},
            "intent": arguments.intent,
            "preconditions": [],
            "mode": "commit",
            "commands": [
                {
                    "type": operation,
                    "payload": {
                        "sequenceId": sequence_id,
                        "at": {"num": str(at.numerator), "den": str(at.denominator)},
                        "duration": {
                            "num": str(duration.numerator),
                            "den": str(duration.denominator),
                        },
                    },
                }
            ],
        }
        if arguments.dry_run:
            batch["mode"] = "dry-run"
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "html" and arguments.html_command in ("dual", "focus", "device", "visual", "presenter"):
        from .dual_view import build_dual_view
        from .target_focus import build_target_focus
        from .device_presentation import build_device_presentation
        from .visual_tools import build_visual_tool
        from .presenter_pip import build_presenter_pip

        require_complete_retry_identity(arguments)
        try:
            if arguments.html_command == "presenter" and arguments.config.lstrip().startswith("{"):
                text = arguments.config
            else:
                config_path = Path(arguments.config)
                if config_path.stat().st_size > 1024 * 1024:
                    raise ValueError("composition config exceeds 1 MiB")
                text = config_path.read_text(encoding="utf-8-sig")
            if len(text.encode("utf-8")) > 1024 * 1024:
                raise ValueError("composition config exceeds 1 MiB")
            config = json.loads(text)
            if arguments.html_command == "presenter":
                if not isinstance(config, dict):
                    raise ValueError("presenter config must be an object")
                config = dict(config)
                if arguments.fit is not None:
                    config["fit"] = arguments.fit
                if arguments.sfx is not None:
                    config["sfx"] = arguments.sfx
                if arguments.sfx_volume is not None:
                    config["sfxVolume"] = arguments.sfx_volume
            if arguments.html_command == "visual":
                if not isinstance(config, dict) or config.get("kind", arguments.kind) != arguments.kind:
                    raise ValueError("config kind must match the selected visual tool")
                config = dict(config, kind=arguments.kind)
            snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
            project = require_object(require_object(snapshot, "data"), "project")
            sequence = require_sequence(project, arguments.sequence_id or default_sequence_id(project))
            # A named retry reuses IDs. The builder uses surviving own tracks
            # to recover its original order even after unrelated tracks arrive.
            identity = arguments.idempotency_key or f"{arguments.html_command}:{uuid.uuid4()}"
            serial = (uuid.uuid5(uuid.NAMESPACE_URL, f"{identity}:{index}").hex for index in itertools.count())
            builder = {"focus":build_target_focus,"dual":build_dual_view,"device":build_device_presentation,"visual":build_visual_tool,"presenter":build_presenter_pip}[arguments.html_command]
            built = builder(project, sequence, config, lambda: next(serial))
        except (OSError, ValueError, TypeError, KeyError) as error:
            raise CliFailure({"focus":"FOCUS_INVALID","dual":"DUAL_VIEW_INVALID","device":"DEVICE_PRESENTATION_INVALID","visual":"VISUAL_TOOL_INVALID","presenter":"PRESENTER_PIP_INVALID"}[arguments.html_command], "validation", str(error), exit_code=EXIT_INVALID_INPUT) from error
        batch = {
            "commandId": identity, "idempotencyKey": identity, "projectId": project_id,
            "baseRevision": arguments.base_revision if arguments.base_revision is not None else project["revision"],
            "actor": {"type": "agent", "id": "orangecut-skill"}, "intent": arguments.intent,
            "preconditions": [], "mode": "dry-run" if arguments.dry_run else "commit", "commands": built["operations"],
        }
        response = client.request("POST", f"/v1/projects/{quote(project_id)}/commands", batch)
        require_object(response, "data")["windows"] = built["clips"]
        return response
    if arguments.command == "html" and arguments.html_command == "screen":
        return place_screen_recording(arguments, client, project_id)
    if arguments.command == "html" and arguments.html_command == "add":
        require_complete_retry_identity(arguments)
        if (arguments.html_file is None) == (arguments.preset is None):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                "pass either a fragment file or --preset, not both and not neither",
                remediation="run `oc html presets --json` to see the preset ids",
                exit_code=EXIT_INVALID_INPUT,
            )
        preset_stylesheet = ""
        preset_expansions: list[tuple[str, str]] = []
        preset = None
        rate = None
        cue_project = None
        identity = arguments.idempotency_key or f"html-add:{uuid.uuid4()}"
        duration_frames = arguments.duration_frames
        placement = arguments.placement or "overlay"
        if arguments.preset is not None:
            preset = html_preset_by_id(arguments.preset)
            if arguments.placement is None:
                placement = str(preset.get("placement", "overlay"))
            if "sfxCues" in preset:
                snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
                cue_project = require_object(require_object(snapshot, "data"), "project")
                rate = sequence_frame_rate_from(cue_project, arguments.sequence_id)
            elif (
                preset.get("frameVariable") is not None
                or preset.get("lifeVariable") is not None
                or duration_frames is None
            ):
                rate = sequence_frame_rate(client, project_id, arguments.sequence_id)
            if duration_frames is None:
                seconds = preset.get("defaultDurationSeconds")
                if not isinstance(seconds, (int, float)) or seconds <= 0:
                    raise CliFailure(
                        "HTML_PRESET_CATALOG_INVALID",
                        "serialization",
                        f"preset {arguments.preset} has no usable authoring duration",
                        remediation="pass --duration-frames",
                        exit_code=EXIT_INVALID_INPUT,
                    )
                duration_frames = max(1, round(Fraction(str(seconds)) * rate))
            html_source, preset_stylesheet, preset_expansions = fill_html_preset(
                preset,
                arguments.preset_assignments,
                frame_seconds=None if rate is None else 1 / rate,
                life_seconds=None if rate is None else Fraction(duration_frames) / rate,
                instance_key=identity,
            )
        else:
            if duration_frames is None:
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID",
                    "validation",
                    "--duration-frames is required for a fragment file",
                    remediation="pass --duration-frames, or use --preset",
                    exit_code=EXIT_INVALID_INPUT,
                )
            try:
                html_source = arguments.html_file.read_text(encoding="utf-8")
            except OSError as error:
                raise CliFailure(
                    "HTML_FRAGMENT_UNREADABLE",
                    "validation",
                    f"cannot read the HTML fragment file: {error}",
                    remediation="pass a readable UTF-8 HTML fragment file",
                    exit_code=EXIT_INVALID_INPUT,
                )
        root, inline_css = parse_html_fragment(html_source)
        for container, items in preset_expansions:
            expanded, _ = parse_html_fragment(f"<div>{items}</div>")
            if not replace_container_children(root, container, expanded.get("children", [])):
                raise CliFailure(
                    "HTML_PRESET_CATALOG_INVALID",
                    "serialization",
                    f"the preset has no element carrying the container class {container}",
                    exit_code=EXIT_INVALID_INPUT,
                )
        stylesheet_parts = [inline_css] if inline_css else []
        if preset_stylesheet:
            stylesheet_parts.append(preset_stylesheet)
        if arguments.css is not None:
            try:
                stylesheet_parts.append(arguments.css.read_text(encoding="utf-8"))
            except OSError as error:
                raise CliFailure(
                    "HTML_FRAGMENT_UNREADABLE",
                    "validation",
                    f"cannot read the stylesheet file: {error}",
                    remediation="pass a readable UTF-8 CSS file",
                    exit_code=EXIT_INVALID_INPUT,
                )
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = cue_project["revision"] if cue_project is not None else current_revision(client)
        payload: dict[str, Any] = {
            "baseRevision": base_revision,
            "root": root,
            "startFrame": arguments.at_frame,
            "durationFrames": duration_frames,
            "placement": placement,
            "intent": arguments.intent,
            "idempotencyKey": identity,
        }
        stylesheet = "\n".join(part for part in stylesheet_parts if part.strip())
        if stylesheet:
            payload["stylesheet"] = stylesheet
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        if arguments.track_id:
            payload["preferredTrackId"] = arguments.track_id
        explicit_sfx = arguments.sfx
        if cue_project is not None:
            cues = html_preset_cue_payload(preset, explicit_sfx, rate, duration_frames, cue_project)
            if cues:
                payload["sfxCues"] = cues
            return client.request("POST", f"/v1/projects/{quote(project_id)}/timeline/html", payload)
        sfx_token = explicit_sfx
        if sfx_token is None and arguments.preset is not None:
            preset_sfx = html_preset_by_id(arguments.preset).get("sfx")
            if isinstance(preset_sfx, str) and preset_sfx:
                sfx_token = preset_sfx
        # Extra cues ride along with the preset's own sound; `--sfx none`
        # silences the whole component, `--sfx <x>` swaps only the main one.
        extra_cues: list[tuple[str, Fraction]] = []
        if arguments.preset is not None and explicit_sfx != "none":
            extra_cues = preset_extra_sfx(
                html_preset_by_id(arguments.preset), preset_stylesheet)
        response = client.request(
            "POST", f"/v1/projects/{quote(project_id)}/timeline/html", payload
        )
        clip_id = require_object(response, "data").get("clipId")
        if extra_cues:
            placed_extra: list[dict[str, Any]] = []
            for cue_token, cue_delay in extra_cues:
                try:
                    placed_extra.append(attach_placement_sfx(
                        client, project_id, arguments.sequence_id, arguments.at_frame,
                        cue_token, clip_id, f"{arguments.intent} + 音效", cue_delay,
                        cue="extra"))
                except CliFailure as error:
                    # A default cue must never fail the component itself.
                    require_object(response, "data").setdefault("sfxExtraErrors", []).append({
                        "sfx": cue_token, "code": error.code, "message": error.message,
                    })
            require_object(response, "data")["sfxExtra"] = placed_extra
        if sfx_token in (None, "none"):
            return response
        # The component is committed; the sound rides in a second batch. If
        # that batch fails the component stays, and the error names the clip
        # so one `oc sfx set` finishes the job instead of redoing both.
        delay = Fraction(0)
        if arguments.preset is not None:
            delay = preset_sfx_delay(html_preset_by_id(arguments.preset))
        try:
            placed = attach_placement_sfx(
                client, project_id, arguments.sequence_id, arguments.at_frame,
                sfx_token, clip_id, f"{arguments.intent} + 音效", delay)
        except CliFailure as error:
            if explicit_sfx is None:
                require_object(response, "data")["sfxError"] = {
                    "code": error.code,
                    "message": error.message,
                    "remediation": f"oc sfx set {clip_id} --sfx {sfx_token}",
                }
                return response
            raise CliFailure(
                error.code,
                error.stage,
                f"the component was added (clipId={clip_id}) but its sfx was not: "
                f"{error.message}",
                remediation=f"retry with `oc sfx set {clip_id} --sfx {sfx_token}`",
                exit_code=error.exit_code,
            )
        require_object(response, "data")["sfx"] = placed
        return response
    if arguments.command == "track" and arguments.track_command == "remove":
        require_complete_retry_identity(arguments)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        payload = {
            "baseRevision": base_revision,
            "trackId": arguments.track_id,
            "withContent": arguments.with_content,
            "intent": arguments.intent
            or ("删除整条轨道及其全部内容" if arguments.with_content else "移除空轨道"),
            "idempotencyKey": arguments.idempotency_key
            or f"track-remove:{uuid.uuid4()}",
        }
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/timeline/tracks/remove", payload
        )
    if arguments.command == "track" and arguments.track_command == "move":
        require_complete_retry_identity(arguments)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        payload = {
            "baseRevision": base_revision,
            "trackId": arguments.track_id,
            "intent": arguments.intent or "调整轨道图层顺序",
            "idempotencyKey": arguments.idempotency_key or f"track-move:{uuid.uuid4()}",
        }
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        if arguments.to_top:
            payload["position"] = "top"
        elif arguments.to_bottom:
            payload["position"] = "bottom"
        elif arguments.above:
            payload["aboveTrackId"] = arguments.above
        else:
            payload["belowTrackId"] = arguments.below
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/timeline/tracks/move", payload
        )
    if (
        arguments.command == "timeline"
        and arguments.timeline_command == "speed"
        and arguments.curve is not None
    ):
        require_complete_retry_identity(arguments)
        if (
            arguments.rate_percent is not None
            or arguments.reverse is not None
            or arguments.freeze is not None
        ):
            raise CliFailure(
                "SPEED_CURVE_CONFLICT",
                "validation",
                "--curve cannot be combined with --rate-percent, --reverse or --freeze",
                remediation="pass a curve on its own, or drop the curve",
                exit_code=EXIT_INVALID_INPUT,
            )
        try:
            raw_curve = json.loads(Path(arguments.curve).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"could not read the speed curve: {error}",
                remediation="pass a readable JSON file",
                exit_code=EXIT_INVALID_INPUT,
            ) from error
        if not isinstance(raw_curve, list) or len(raw_curve) < 2:
            raise CliFailure(
                "SPEED_CURVE_INVALID",
                "validation",
                "a speed curve needs at least two keyframes",
                remediation='each entry looks like {"atFrame": 0, "ratePercent": 200}; '
                "for one constant speed use --rate-percent",
                exit_code=EXIT_INVALID_INPUT,
            )
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        fps = sequence_frame_rate_from(project, sequence_id)
        found = None
        for track in sequence.get("tracks", []):
            for candidate in track.get("clips", []):
                if candidate.get("id") == arguments.clip_id:
                    found = candidate
        if found is None:
            raise CliFailure(
                "SPEED_CLIP_NOT_FOUND",
                "preconditions",
                f"clip {arguments.clip_id!r} does not exist in sequence {sequence_id!r}",
                remediation="run `oc timeline snapshot` and pass a clip id",
                exit_code=EXIT_INVALID_INPUT,
            )

        def as_fraction(value: dict[str, Any]) -> Fraction:
            return Fraction(int(value["num"]), int(value["den"]))

        def as_rational(value: Fraction) -> dict[str, str]:
            return {"num": str(value.numerator), "den": str(value.denominator)}

        curve: list[tuple[Fraction, Fraction]] = []
        for index, point in enumerate(raw_curve):
            try:
                at = int(point["atFrame"])
                percent = int(point["ratePercent"])
            except (KeyError, TypeError, ValueError):
                raise CliFailure(
                    "SPEED_CURVE_INVALID",
                    "validation",
                    f"keyframe {index} needs integer atFrame and ratePercent",
                    remediation='each entry looks like {"atFrame": 0, "ratePercent": 200}',
                    exit_code=EXIT_INVALID_INPUT,
                ) from None
            if percent <= 0:
                raise CliFailure(
                    "SPEED_CURVE_INVALID",
                    "validation",
                    f"keyframe {index} has a rate of {percent}%",
                    remediation="every keyframe needs a rate above zero",
                    exit_code=EXIT_INVALID_INPUT,
                )
            curve.append((Fraction(at) / fps, Fraction(percent, 100)))
        if curve[0][0] != 0:
            raise CliFailure(
                "SPEED_CURVE_INVALID",
                "validation",
                "the first keyframe must sit at frame 0",
                remediation="the curve has to cover the clip from its own start",
                exit_code=EXIT_INVALID_INPUT,
            )
        if any(later[0] <= earlier[0] for earlier, later in zip(curve, curve[1:])):
            raise CliFailure(
                "SPEED_CURVE_INVALID",
                "validation",
                "keyframes must be sorted and sit at distinct frames",
                remediation="sort by atFrame and move duplicates by at least one frame",
                exit_code=EXIT_INVALID_INPUT,
            )
        # 最后一个关键帧定这段的新长度:曲线必须铺满这个 Clip,不能只覆盖前半段。
        duration = curve[-1][0]
        # 源区间跟着曲线走。守恒由引擎再核一遍,但这里先算对,免得往返一次
        # 才知道差了多少。
        consumed = speed_curve_consumed(curve, Fraction(0), duration)
        timeline_start = as_fraction(require_object(require_object(found, "timelineRange"), "start"))
        source_start = as_fraction(require_object(require_object(found, "sourceRange"), "start"))
        # 曲线要吃掉的源可能比这条素材从入点算起剩下的还多。让它往返一次再由
        # 引擎报"区间越界",读到的是一个不提曲线的错误;这里直接说清差多少。
        curve_asset_id = (found.get("source") or {}).get("assetId")
        curve_asset = next(
            (
                asset
                for asset in project.get("assets", [])
                if asset.get("id") == curve_asset_id
            ),
            None,
        )
        probe = (curve_asset or {}).get("probe") or {}
        if isinstance(probe.get("duration"), dict):
            available = as_fraction(probe["duration"]) - source_start
            if consumed > available:
                raise CliFailure(
                    "SPEED_CURVE_SOURCE_EXHAUSTED",
                    "preconditions",
                    f"the curve consumes {float(consumed):.3f}s of source but only "
                    f"{float(available):.3f}s remain after the clip's in-point",
                    remediation="shorten the curve, slow it down, or start the clip earlier",
                    exit_code=EXIT_INVALID_INPUT,
                )
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        key = arguments.idempotency_key or f"speed-curve:{uuid.uuid4()}"
        # 曲线走 speed 端点而不是裸 CommandBatch:引擎没有速率原语,服务要在
        # 同一个原子批里把派生媒体一并挂上——只改模型的话画面按 1 倍走,迁移
        # 层会直接拒渲。上面的本地校验保留,为的是把可预判的错误留在本地。
        payload = {
            "baseRevision": base_revision,
            "clipId": arguments.clip_id,
            "curve": [
                {"atFrame": int(point["atFrame"]), "ratePercent": int(point["ratePercent"])}
                for point in raw_curve
            ],
            "idempotencyKey": key,
        }
        if arguments.intent:
            payload["intent"] = arguments.intent
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        # 曲线的最慢那一点决定会不会重复帧:中间那段保持 25% 的话,
        # 下限就按 25% 判,而不是按平均速率。
        slowest = min(Fraction(int(point["ratePercent"]), 100) for point in raw_curve)
        curve_warnings = slow_motion_warnings(
            arguments.clip_id,
            slowest,
            fps,
            asset_source_frame_rate(curve_asset or {}),
        )
        return attach_warnings(
            client.request(
                "POST", f"/v1/projects/{quote(project_id)}/timeline/speed", payload
            ),
            curve_warnings,
        )
    if arguments.command == "timeline" and arguments.timeline_command in (
        "add",
        "split",
        "move",
        "trim",
        "speed",
        "remove",
    ):
        require_complete_retry_identity(arguments)
        action = arguments.timeline_command
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        speed_warnings: list[dict[str, Any]] = []
        payload = {
            "baseRevision": base_revision,
            "intent": arguments.intent,
            "idempotencyKey": arguments.idempotency_key
            or f"timeline-{action}:{uuid.uuid4()}",
        }
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        if action == "add":
            payload["timelineFrame"] = arguments.at_frame
            payload["assetId"] = arguments.asset_id
            if arguments.track_id:
                payload["preferredTrackId"] = arguments.track_id
            if arguments.new_track:
                payload["forceNewTrack"] = True
        elif action == "split":
            payload["clipId"] = arguments.clip_id
            payload["timelineFrame"] = arguments.at_frame
        elif action == "move":
            if arguments.to_frame is None and arguments.to_track is None:
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID",
                    "validation",
                    "pass --to-frame, --to-track, or both",
                    exit_code=EXIT_INVALID_INPUT,
                )
            payload["clipId"] = arguments.clip_id
            if arguments.to_frame is not None:
                payload["timelineFrame"] = arguments.to_frame
            if arguments.to_track is not None:
                payload["targetTrackId"] = arguments.to_track
        elif action == "trim":
            payload["clipId"] = arguments.clip_id
            if arguments.start_frame is not None:
                payload["edge"] = "start"
                payload["timelineFrame"] = arguments.start_frame
            else:
                payload["edge"] = "end"
                payload["timelineFrame"] = arguments.end_frame
        elif action == "speed":
            payload["clipId"] = arguments.clip_id
            # 变速/定格/倒放要把整条源素材重新转码(见 SKILL.md),两分钟的
            # 素材远超默认 30s;按导出同级的预算等,而不是让每次重试都
            # 杀掉一次快跑完的 ffmpeg。
            client.timeout = EXPORT_START_TIMEOUT_SECONDS
            if arguments.rate_percent is not None:
                payload["ratePercent"] = arguments.rate_percent
                # 只有真的在减速时才多取一次快照:守门要两个帧率,而画布帧率
                # 和素材 probe 都只有快照里有。加速与定格不看这条线。
                if arguments.rate_percent < 100:
                    speed_warnings = clip_slow_motion_warnings(
                        client,
                        project_id,
                        arguments.sequence_id,
                        arguments.clip_id,
                        Fraction(arguments.rate_percent, 100),
                    )
            if arguments.reverse is not None:
                payload["reverse"] = arguments.reverse
            if arguments.freeze is not None:
                payload["freeze"] = arguments.freeze
            if (
                arguments.rate_percent is None
                and arguments.reverse is None
                and arguments.freeze is None
            ):
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID",
                    "validation",
                    "timeline speed requires a rate, a direction, or a freeze",
                    remediation="pass --rate-percent, --reverse/--no-reverse, or --freeze/--no-freeze",
                    exit_code=EXIT_INVALID_INPUT,
                )
        else:
            payload["clipId"] = arguments.clip_id
        return attach_warnings(
            client.request(
                "POST", f"/v1/projects/{quote(project_id)}/timeline/{action}", payload
            ),
            speed_warnings,
        )
    if arguments.command == "timeline" and arguments.timeline_command == "freeze-frame":
        # 编排而非新语义命令:split(≤2 刀)→ 开缝 → 把切出的一帧拉到 hold 帧
        # → 最后对这一整段定格派生。每一步都是既有端点,中途失败留下的只是
        # 切点或一段没定格的画面,不破坏画面;不做原子性承诺,换来的是零协议改动。
        sequence_id, rate = resolve_sequence_time_base(
            client, project_id, arguments.sequence_id
        )
        at = arguments.at_frame
        hold = arguments.duration_frames

        def locate_clip(wanted_id: str | None, track_id: str | None, start_frame: int | None):
            snap = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
            proj = require_object(require_object(snap, "data"), "project")
            seq = require_sequence(proj, sequence_id)
            for track in seq.get("tracks", []):
                if track_id is not None and track.get("id") != track_id:
                    continue
                for item in track.get("clips", []):
                    if wanted_id is not None and item.get("id") != wanted_id:
                        continue
                    wire = item.get("timelineRange") or {}
                    clip_start = round(float(_rational_of(wire.get("start"))) * float(rate))
                    clip_end = round(float(_rational_of(wire.get("end"))) * float(rate))
                    if start_frame is not None and clip_start != start_frame:
                        continue
                    return proj, track, item, clip_start, clip_end
            return None

        located = locate_clip(arguments.clip_id, None, None)
        if located is None:
            raise CliFailure(
                "CLIP_NOT_FOUND", "preconditions",
                f"clip {arguments.clip_id} does not exist in sequence {sequence_id}",
                remediation="run `oc timeline snapshot` and pass a clip id from it",
                exit_code=EXIT_INVALID_INPUT,
            )
        _, track, _, clip_start, clip_end = located
        track_id = str(track.get("id"))
        if not (clip_start <= at < clip_end):
            raise CliFailure(
                "FREEZE_FRAME_OUT_OF_RANGE", "validation",
                f"--at-frame {at} is outside the clip's [{clip_start}, {clip_end}) range",
                exit_code=EXIT_INVALID_INPUT,
            )

        def timeline_call(action: str, payload: dict[str, Any]) -> dict[str, Any]:
            payload = {
                "baseRevision": current_revision(client),
                "intent": arguments.intent,
                "idempotencyKey": f"freeze-frame-{action}:{uuid.uuid4()}",
                "sequenceId": sequence_id,
                **payload,
            }
            return client.request(
                "POST", f"/v1/projects/{quote(project_id)}/timeline/{action}", payload
            )

        if at > clip_start:
            timeline_call("split", {"clipId": arguments.clip_id, "timelineFrame": at})
        located = locate_clip(None, track_id, at)
        if located is None:
            raise CliFailure(
                "FREEZE_FRAME_SPLIT_LOST", "runtime",
                "the split did not leave a clip starting at the freeze frame",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
            )
        _, _, middle, middle_start, middle_end = located
        middle_id = str(middle.get("id"))
        if middle_end > at + 1:
            timeline_call("split", {"clipId": middle_id, "timelineFrame": at + 1})
        if hold > 1:
            # 先腾位、再把切出的一帧按普通 trim 拉到 hold 帧(源区间随之延长,
            # 联动的声音一半由 trim 端点一起拉),**最后**才定格:speed 端点对
            # 最终长度的一整对画音派生一次,渲染侧「联动两半共用同一资产/媒体
            # 起点」的检查才成立。此前的顺序是先定格一帧再裸 clip.trim 拉长,
            # 带声素材上留下一帧长的派生和只换了画面的对,read/export 被拒。
            gap_at = Fraction(at + 1) / rate
            gap_duration = Fraction(hold - 1) / rate
            split_clips_crossing_gap(client, project_id, sequence_id, at + 1, gap_at)
            gap_id = f"freeze-frame-gap:{uuid.uuid4()}"
            client.request(
                "POST", f"/v1/projects/{quote(project_id)}/commands",
                sfx_command_batch(
                    project_id, current_revision(client), arguments.intent,
                    gap_id, "freeze-frame-gap",
                    [{
                        "type": "sequence.gap.insert",
                        "payload": {
                            "sequenceId": sequence_id,
                            "at": {"num": str(gap_at.numerator), "den": str(gap_at.denominator)},
                            "duration": {
                                "num": str(gap_duration.numerator),
                                "den": str(gap_duration.denominator),
                            },
                        },
                    }],
                ),
            )
            timeline_call("trim", {"clipId": middle_id, "edge": "end", "timelineFrame": at + hold})
        response = timeline_call("speed", {"clipId": middle_id, "freeze": True})
        data = response.get("data") if isinstance(response, dict) else None
        return {
            "sequenceId": sequence_id,
            "frozenClipId": middle_id,
            "atFrame": at,
            "durationFrames": hold,
            "revision": (data or {}).get("revision")
            or ((data or {}).get("transaction") or {}).get("revision")
            or ((data or {}).get("project") or {}).get("revision"),
        }
    if arguments.command == "timeline" and arguments.timeline_command == "grid":
        require_complete_retry_identity(arguments)
        clip_ids = [item.strip() for item in arguments.clips.split(",") if item.strip()]
        if not GRID_MIN <= len(clip_ids) <= GRID_MAX or len(set(clip_ids)) != len(clip_ids):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation",
                f"--clips needs {GRID_MIN} to {GRID_MAX} distinct clip ids in reading order",
                remediation="--clips tl,tr,bl,br (2x2) or any 2-9 ids, top-left first, row by row",
                exit_code=EXIT_INVALID_INPUT,
            )
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        canvas = sequence.get("canvas") or {}
        width = int(canvas.get("width") or 1080)
        height = int(canvas.get("height") or 1920)
        clips_by_id = {
            str(item.get("id")): item
            for track in sequence.get("tracks", [])
            for item in track.get("clips", [])
        }
        missing = [clip_id for clip_id in clip_ids if clip_id not in clips_by_id]
        if missing:
            raise CliFailure(
                "CLIP_NOT_FOUND", "preconditions",
                f"clips not in sequence {sequence_id}: {', '.join(missing)}",
                remediation="run `oc timeline snapshot` and pass clip ids from it",
                exit_code=EXIT_INVALID_INPUT,
            )

        def grid_wire(value: Fraction) -> dict[str, str]:
            return {"num": str(value.numerator), "den": str(value.denominator)}

        try:
            cells = grid_cells(len(clip_ids), width, height, arguments.gap)
        except ValueError as error:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID", "validation", str(error),
                exit_code=EXIT_INVALID_INPUT,
            ) from error
        commands = []
        placements = []
        for clip_id, cell in zip(clip_ids, cells):
            current = clips_by_id[clip_id].get("transform") or {}
            opacity = current.get("opacity")
            if not (isinstance(opacity, dict) and "num" in opacity):
                opacity = {"num": "1", "den": "1"}
            x, y, cell_width, cell_height = cell
            scale = min(cell_width / width, cell_height / height)
            position_x = x + cell_width / 2 - Fraction(width, 2)
            position_y = y + cell_height / 2 - Fraction(height, 2)
            commands.append({
                "type": "clip.transform.set",
                "payload": {
                    "sequenceId": sequence_id,
                    "clipId": clip_id,
                    "transform": {
                        "positionX": grid_wire(position_x),
                        "positionY": grid_wire(position_y),
                        "scaleX": grid_wire(scale),
                        "scaleY": grid_wire(scale),
                        "rotationDegrees": grid_wire(Fraction(0)),
                        "opacity": opacity,
                    },
                },
            })
            placements.append({
                "clipId": clip_id,
                "cell": {
                    "x": grid_wire(x), "y": grid_wire(y),
                    "width": grid_wire(cell_width), "height": grid_wire(cell_height),
                },
            })
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = require_integer(project, "revision")
        batch = sfx_command_batch(
            project_id, base_revision, arguments.intent,
            arguments.idempotency_key, "timeline-grid", commands,
        )
        response = client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
        data = response.get("data") if isinstance(response, dict) else None
        return {
            "sequenceId": sequence_id,
            "count": len(clip_ids),
            "gap": arguments.gap,
            "grid": placements,
            "revision": (data or {}).get("revision"),
        }
    if arguments.command == "clip" and arguments.clip_command == "transform":
        require_complete_retry_identity(arguments)
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        found = None
        for track in sequence.get("tracks", []):
            for item in track.get("clips", []):
                if item.get("id") == arguments.clip_id:
                    found = item
        if found is None:
            raise CliFailure(
                "CLIP_NOT_FOUND", "preconditions",
                f"clip {arguments.clip_id} does not exist in sequence {sequence_id}",
                remediation="run `oc timeline snapshot` and pass a clip id from it",
                exit_code=EXIT_INVALID_INPUT,
            )
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = require_integer(project, "revision")
        if arguments.transform_command == "clear":
            command: dict[str, Any] = {
                "type": "clip.transform.clear",
                "payload": {"sequenceId": sequence_id, "clipId": arguments.clip_id},
            }
        else:
            if arguments.scale_percent is not None and (
                arguments.scale_x_percent is not None
                or arguments.scale_y_percent is not None
            ):
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID", "validation",
                    "--scale-percent replaces both axes; do not combine it with "
                    "--scale-x-percent/--scale-y-percent",
                    exit_code=EXIT_INVALID_INPUT,
                )
            if all(
                value is None
                for value in (
                    arguments.x, arguments.y, arguments.scale_percent,
                    arguments.scale_x_percent, arguments.scale_y_percent,
                    arguments.rotation, arguments.opacity_percent,
                )
            ):
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID", "validation",
                    "clip transform set changes nothing without at least one field",
                    remediation="pass --x/--y, a scale, --rotation, or --opacity-percent",
                    exit_code=EXIT_INVALID_INPUT,
                )
            current = found.get("transform") or {}

            def current_value(key: str, default: Fraction) -> Fraction:
                wire = current.get(key)
                if isinstance(wire, dict) and "num" in wire and "den" in wire:
                    try:
                        return Fraction(int(wire["num"]), int(wire["den"]))
                    except (TypeError, ValueError, ZeroDivisionError):
                        return default
                return default

            def given(value: float | None) -> Fraction | None:
                return None if value is None else Fraction(str(value))

            position_x = given(arguments.x)
            if position_x is None:
                position_x = current_value("positionX", Fraction(0))
            position_y = given(arguments.y)
            if position_y is None:
                position_y = current_value("positionY", Fraction(0))
            uniform = given(arguments.scale_percent)
            if uniform is not None:
                scale_x = scale_y = uniform / 100
            else:
                scale_x = given(arguments.scale_x_percent)
                scale_x = (
                    scale_x / 100 if scale_x is not None
                    else current_value("scaleX", Fraction(1))
                )
                scale_y = given(arguments.scale_y_percent)
                scale_y = (
                    scale_y / 100 if scale_y is not None
                    else current_value("scaleY", Fraction(1))
                )
            rotation = given(arguments.rotation)
            if rotation is None:
                rotation = current_value("rotationDegrees", Fraction(0))
            opacity = given(arguments.opacity_percent)
            opacity = (
                opacity / 100 if opacity is not None
                else current_value("opacity", Fraction(1))
            )

            def wire(value: Fraction) -> dict[str, str]:
                return {"num": str(value.numerator), "den": str(value.denominator)}

            command = {
                "type": "clip.transform.set",
                "payload": {
                    "sequenceId": sequence_id,
                    "clipId": arguments.clip_id,
                    "transform": {
                        "positionX": wire(position_x),
                        "positionY": wire(position_y),
                        "scaleX": wire(scale_x),
                        "scaleY": wire(scale_y),
                        "rotationDegrees": wire(rotation),
                        "opacity": wire(opacity),
                    },
                },
            }
        batch = sfx_command_batch(
            project_id, base_revision, arguments.intent,
            arguments.idempotency_key, "clip-transform", [command],
        )
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "keyframe" and arguments.keyframe_command == "list":
        return client.request(
            "GET", f"/v1/projects/{quote(project_id)}/visual-motion"
        )
    if arguments.command == "keyframe" and arguments.keyframe_command in (
        "upsert",
        "remove",
        "clear",
    ):
        require_complete_retry_identity(arguments)
        action = arguments.keyframe_command
        base_revision = arguments.base_revision
        snapshot = client.request(
            "GET", f"/v1/projects/{quote(project_id)}/snapshot"
        )
        project = require_object(require_object(snapshot, "data"), "project")
        if base_revision is None:
            base_revision = require_integer(project, "revision")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        target = keyframe_target_payload(arguments, sequence_id)
        payload = {
            "baseRevision": base_revision,
            "target": target,
            "intent": arguments.intent,
            "idempotencyKey": arguments.idempotency_key
            or f"visual-keyframe-{action}:{uuid.uuid4()}",
        }
        if action == "upsert":
            payload["property"] = arguments.property
            payload["localFrame"] = arguments.at_frame
            payload["value"] = keyframe_value_payload(arguments)
            payload["easing"] = arguments.easing
            if arguments.keyframe_id:
                payload["keyframeId"] = arguments.keyframe_id
        elif action == "remove":
            payload["property"] = arguments.property
            payload["keyframeId"] = arguments.keyframe_id
        elif arguments.property is not None:
            payload["property"] = arguments.property
        return client.request(
            "POST",
            f"/v1/projects/{quote(project_id)}/visual-motion/keyframes/{action}",
            payload,
        )
    if arguments.command == "audio" and arguments.audio_command == "measure":
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        return measure_clip_loudness(client, project_id, sequence, arguments.clip_id)
    if arguments.command == "audio" and arguments.audio_command == "level":
        require_complete_retry_identity(arguments)
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = arguments.sequence_id or default_sequence_id(project)
        sequence = require_sequence(project, sequence_id)
        measured = require_object(
            measure_clip_loudness(client, project_id, sequence, arguments.clip_id), "data"
        )
        if measured.get("integratedLufs") is None:
            raise CliFailure(
                "AUDIO_CLIP_SILENT",
                "preconditions",
                f"clip {arguments.clip_id!r} is digital silence over its source range; there is no loudness to align",
                remediation="check the source range, or pick a different take",
                exit_code=EXIT_INVALID_INPUT,
            )
        if arguments.like is not None:
            reference = require_object(
                measure_clip_loudness(client, project_id, sequence, arguments.like), "data"
            )
            if reference.get("effectiveLufs") is None:
                raise CliFailure(
                    "AUDIO_CLIP_SILENT",
                    "preconditions",
                    f"reference clip {arguments.like!r} is digital silence; nothing to match",
                    exit_code=EXIT_INVALID_INPUT,
                )
            target_lufs = float(reference["effectiveLufs"])
            target_source = {"clipId": arguments.like, "effectiveLufs": target_lufs}
        else:
            target_lufs = float(arguments.target_lufs)
            target_source = {"targetLufs": target_lufs}
        max_boost = (
            LOUDNESS_DEFAULT_MAX_BOOST_DB
            if arguments.max_boost_db is None
            else float(arguments.max_boost_db)
        )
        plan = loudness_gain_plan(float(measured["integratedLufs"]), target_lufs, max_boost)
        summary = {
            "clipId": arguments.clip_id,
            "measured": measured,
            "target": target_source,
            **plan,
        }
        if arguments.dry_run:
            return {
                "schemaVersion": SCHEMA_VERSION,
                "ok": True,
                "data": {"mode": "dry-run", **summary},
            }
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        payload = {
            "baseRevision": base_revision,
            "clipId": arguments.clip_id,
            "intent": arguments.intent,
            "idempotencyKey": arguments.idempotency_key or f"audio-level:{uuid.uuid4()}",
            "gainPercent": plan["gainPercent"],
        }
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        response = client.request(
            "POST", f"/v1/projects/{quote(project_id)}/audio/volume", payload
        )
        require_object(response, "data")["loudness"] = summary
        return response
    if arguments.command == "audio" and arguments.audio_command == "list":
        return client.request("GET", f"/v1/projects/{quote(project_id)}/audio")
    if arguments.command == "audio" and arguments.audio_command == "volume":
        require_complete_retry_identity(arguments)
        if (
            arguments.gain_percent is None
            and arguments.pan_percent is None
            and arguments.fade_in_frames is None
            and arguments.fade_out_frames is None
        ):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                "audio volume requires a gain, a pan, or a fade",
                remediation="pass --gain-percent, --pan-percent, --fade-in-frames, or --fade-out-frames",
                exit_code=EXIT_INVALID_INPUT,
            )
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        payload = {
            "baseRevision": base_revision,
            "clipId": arguments.clip_id,
            "intent": arguments.intent,
            "idempotencyKey": arguments.idempotency_key or f"audio-volume:{uuid.uuid4()}",
        }
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        if arguments.gain_percent is not None:
            payload["gainPercent"] = arguments.gain_percent
        if arguments.pan_percent is not None:
            payload["panPercent"] = arguments.pan_percent
        if arguments.fade_in_frames is not None:
            payload["fadeInFrames"] = arguments.fade_in_frames
        if arguments.fade_out_frames is not None:
            payload["fadeOutFrames"] = arguments.fade_out_frames
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/audio/volume", payload
        )
    if arguments.command == "caption" and arguments.caption_command == "list":
        return client.request("GET", f"/v1/projects/{quote(project_id)}/captions")
    if arguments.command == "caption" and arguments.caption_command in (
        "add",
        "add-batch",
        "import-srt",
        "update",
        "move",
        "remove",
    ):
        require_complete_retry_identity(arguments)
        action = arguments.caption_command
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        payload = {
            "baseRevision": base_revision,
            "intent": arguments.intent,
            "idempotencyKey": arguments.idempotency_key
            or f"caption-{action}:{uuid.uuid4()}",
        }
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        if action == "add":
            payload["text"] = arguments.text
            payload["startFrame"] = arguments.at_frame
            payload["durationFrames"] = arguments.duration_frames
            if arguments.emphasis:
                payload["emphases"] = parse_caption_emphases(arguments.emphasis)
            payload["style"] = text_style_payload(arguments)
            if arguments.track_id:
                payload["preferredTrackId"] = arguments.track_id
        elif action == "add-batch":
            payload["captions"] = caption_batch_items(arguments.file)
            payload["style"] = text_style_payload(arguments)
            if arguments.track_id:
                payload["preferredTrackId"] = arguments.track_id
        elif action == "import-srt":
            # SRT carries milliseconds; the timeline carries frames. Read the
            # Sequence's exact frame rate rather than assuming one, or every
            # cue in a 23.976 project lands a little late.
            frame_rate = sequence_frame_rate(client, project_id, arguments.sequence_id)
            payload["captions"] = srt_captions(
                read_srt_file(arguments.file),
                frame_rate,
                arguments.offset_frames,
            )
            if arguments.words is not None:
                attach_caption_tokens(
                    payload["captions"],
                    arguments.words,
                    frame_rate,
                    arguments.offset_frames,
                )
            elif getattr(arguments, "highlight", "none") == "word":
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID",
                    "validation",
                    "--highlight word needs word-level timings",
                    remediation="pass --words with the `oc media transcribe --json` output",
                    exit_code=EXIT_INVALID_INPUT,
                )
            payload["style"] = text_style_payload(arguments)
            if arguments.track_id:
                payload["preferredTrackId"] = arguments.track_id
        else:
            payload["captionId"] = arguments.caption_id
            if action == "move":
                payload["targetTrackId"] = arguments.to_track
                if arguments.to_frame is not None:
                    payload["timelineFrame"] = arguments.to_frame
            if action == "update":
                if arguments.text is not None:
                    payload["text"] = arguments.text
                if arguments.start_frame is not None:
                    payload["startFrame"] = arguments.start_frame
                if arguments.end_frame is not None:
                    payload["endFrame"] = arguments.end_frame
                if arguments.clear_emphases and arguments.emphasis:
                    raise CliFailure(
                        "CLI_ARGUMENT_INVALID",
                        "validation",
                        "--clear-emphases cannot be combined with --emphasis",
                        remediation="pass either replacement emphases or the clear flag",
                        exit_code=EXIT_INVALID_INPUT,
                    )
                if arguments.clear_emphases:
                    payload["emphases"] = []
                elif arguments.emphasis:
                    payload["emphases"] = parse_caption_emphases(arguments.emphasis)
                if arguments.clear_tokens:
                    payload["tokens"] = []
                style = text_style_payload(arguments, patch=True)
                if style:
                    payload["style"] = style
                if (
                    arguments.text is None
                    and arguments.start_frame is None
                    and arguments.end_frame is None
                    and "emphases" not in payload
                    and "tokens" not in payload
                    and not style
                ):
                    raise CliFailure(
                        "CLI_ARGUMENT_INVALID",
                        "validation",
                        "caption update requires content, range, emphasis, or style changes",
                        remediation="pass --text, --start-frame/--end-frame, --emphasis/--clear-emphases, or a style option",
                        exit_code=EXIT_INVALID_INPUT,
                    )
        route = "add-batch" if action == "import-srt" else action
        response = client.request(
            "POST", f"/v1/projects/{quote(project_id)}/captions/{route}", payload
        )
        if action != "remove":
            data = require_object(response, "data")
            attach_layout_check(
                client, project_id, response,
                [data.get("captionId"), *(data.get("captionIds") or [])],
            )
        return response
    if arguments.command == "sticker" and arguments.sticker_command == "presets":
        # Not Project-scoped: the catalog is a property of the build, so it can be
        # read before deciding which Project to open.
        return client.request("GET", "/v1/text-stickers/presets")
    if arguments.command == "sticker" and arguments.sticker_command == "list":
        return client.request("GET", f"/v1/projects/{quote(project_id)}/stickers")
    if arguments.command == "sticker" and arguments.sticker_command in (
        "add",
        "update",
        "remove",
    ):
        require_complete_retry_identity(arguments)
        action = arguments.sticker_command
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        payload = {
            "baseRevision": base_revision,
            "intent": arguments.intent,
            "idempotencyKey": arguments.idempotency_key
            or f"text-sticker-{action}:{uuid.uuid4()}",
        }
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        if action == "add":
            payload["text"] = arguments.text
            payload["startFrame"] = arguments.at_frame
            payload["durationFrames"] = arguments.duration_frames
            if hasattr(arguments, "font_asset_id"):
                payload["fontAssetId"] = arguments.font_asset_id
            if hasattr(arguments, "preset"):
                payload["preset"] = arguments.preset
            style, placement = text_sticker_payload(arguments)
            if style:
                payload["style"] = style
            if placement:
                payload["placement"] = placement
            if arguments.track_id:
                payload["preferredTrackId"] = arguments.track_id
        else:
            payload["clipId"] = arguments.clip_id
            if action == "update":
                if arguments.text is not None:
                    payload["text"] = arguments.text
                if arguments.start_frame is not None:
                    payload["startFrame"] = arguments.start_frame
                if arguments.end_frame is not None:
                    payload["endFrame"] = arguments.end_frame
                if hasattr(arguments, "preset"):
                    payload["preset"] = arguments.preset
                if getattr(arguments, "reset_placement", False):
                    payload["resetPlacement"] = True
                style, placement = text_sticker_payload(arguments)
                if style:
                    payload["style"] = style
                if placement:
                    payload["placement"] = placement
                if (
                    arguments.text is None
                    and arguments.start_frame is None
                    and arguments.end_frame is None
                    and not hasattr(arguments, "preset")
                    and not style
                    and not placement
                ):
                    raise CliFailure(
                        "CLI_ARGUMENT_INVALID",
                        "validation",
                        "sticker update requires content, lifecycle, preset, style, or placement changes",
                        remediation="pass --text, a frame boundary, --preset, or a style/placement option",
                        exit_code=EXIT_INVALID_INPUT,
                    )
        response = client.request(
            "POST", f"/v1/projects/{quote(project_id)}/stickers/{action}", payload
        )
        if action != "remove":
            attach_layout_check(
                client, project_id, response,
                [require_object(response, "data").get("clipId")],
            )
        if action != "add":
            return response
        explicit_sfx = getattr(arguments, "sfx", None)
        sfx_token = explicit_sfx
        if sfx_token is None:
            enter = getattr(arguments, "enter", None)
            if enter is None:
                enter = sticker_preset_enter_animation(
                    getattr(arguments, "preset", None))
            sfx_token = entrance_sfx_token(enter)
        if sfx_token in (None, "none"):
            return response
        clip_id = require_object(response, "data").get("clipId")
        try:
            placed = attach_placement_sfx(
                client, project_id, arguments.sequence_id, arguments.at_frame,
                sfx_token, clip_id, f"{arguments.intent} + 音效")
        except CliFailure as error:
            # An implied default sound must never fail the sticker the user
            # actually asked for; only an explicit --sfx is a hard promise.
            if explicit_sfx is None:
                require_object(response, "data")["sfxError"] = {
                    "code": error.code,
                    "message": error.message,
                    "remediation": f"oc sfx set {clip_id} --sfx {sfx_token}",
                }
                return response
            raise CliFailure(
                error.code,
                error.stage,
                f"the sticker was added (clipId={clip_id}) but its sfx was not: "
                f"{error.message}",
                remediation=f"retry with `oc sfx set {clip_id} --sfx {sfx_token}`",
                exit_code=error.exit_code,
            )
        require_object(response, "data")["sfx"] = placed
        return response
    if arguments.command == "shape" and arguments.shape_command == "list":
        return client.request("GET", f"/v1/projects/{quote(project_id)}/shapes")
    if arguments.command == "shape" and arguments.shape_command in (
        "add",
        "update",
        "remove",
    ):
        require_complete_retry_identity(arguments)
        action = arguments.shape_command
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        payload = {
            "baseRevision": base_revision,
            "intent": arguments.intent,
            "idempotencyKey": arguments.idempotency_key
            or f"shape-{action}:{uuid.uuid4()}",
        }
        if arguments.sequence_id:
            payload["sequenceId"] = arguments.sequence_id
        if action == "add":
            payload["kind"] = arguments.kind
            payload["startFrame"] = arguments.at_frame
            payload["durationFrames"] = arguments.duration_frames
            style, placement = shape_payload(arguments)
            if style:
                payload["style"] = style
            if placement:
                payload["placement"] = placement
            if arguments.track_id:
                payload["preferredTrackId"] = arguments.track_id
        else:
            payload["clipId"] = arguments.clip_id
            if action == "update":
                if arguments.start_frame is not None:
                    payload["startFrame"] = arguments.start_frame
                if arguments.end_frame is not None:
                    payload["endFrame"] = arguments.end_frame
                style, placement = shape_payload(arguments)
                if style:
                    payload["style"] = style
                if placement:
                    payload["placement"] = placement
                if (
                    arguments.start_frame is None
                    and arguments.end_frame is None
                    and not style
                    and not placement
                ):
                    raise CliFailure(
                        "CLI_ARGUMENT_INVALID",
                        "validation",
                        "shape update requires lifecycle, geometry, appearance, or placement changes",
                        remediation="pass a frame boundary or a shape style/placement option",
                        exit_code=EXIT_INVALID_INPUT,
                    )
        response = client.request(
            "POST", f"/v1/projects/{quote(project_id)}/shapes/{action}", payload
        )
        if action != "remove":
            attach_layout_check(
                client, project_id, response,
                [require_object(response, "data").get("clipId")],
            )
        return response
    if arguments.command in ("undo", "redo"):
        require_complete_retry_identity(arguments)
        base_revision = arguments.base_revision
        if base_revision is None:
            base_revision = current_revision(client)
        action_id = arguments.idempotency_key or f"history-{arguments.command}:{uuid.uuid4()}"
        payload = {
            "commandId": action_id,
            "idempotencyKey": action_id,
            "projectId": project_id,
            "baseRevision": base_revision,
            "actor": {"type": "agent", "id": "orangecut-skill"},
            "intent": arguments.intent,
            "mode": "commit",
        }
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/{arguments.command}", payload
        )
    if arguments.command == "command" and arguments.command_command == "apply":
        batch = read_request_stdin() if arguments.stdin else read_request_file(arguments.file)
        # 信封字段 CLI 都能自己生成,调用方只欠 commands 数组;显式写了的
        # 字段原样尊重。服务端的 CommandBatch 反序列化是全字段必填的,
        # 这里补齐而不是把重担压给每个调用方。
        if isinstance(batch, dict):
            command_id = batch.get("commandId") or batch.get("idempotencyKey") \
                or f"command-apply-{uuid.uuid4()}"
            batch.setdefault("commandId", command_id)
            batch.setdefault("idempotencyKey", command_id)
            batch.setdefault("projectId", project_id)
            batch.setdefault("actor", {"type": "agent", "id": "orangecut-skill"})
            batch.setdefault(
                "intent",
                arguments.intent or "Apply a raw CommandBatch through the CLI.",
            )
            batch.setdefault("preconditions", [])
            batch.setdefault("mode", "commit")
            if batch.get("baseRevision") is None:
                batch["baseRevision"] = current_revision(client)
        batch_project_id = require_text(batch, "projectId")
        if batch_project_id != project_id:
            raise CliFailure(
                "PROJECT_MISMATCH",
                "validation",
                "the CommandBatch Project is not the active OrangeCut Project",
                remediation="read `oc project current --json` and rebuild the CommandBatch",
                exit_code=EXIT_INVALID_INPUT,
            )
        if arguments.dry_run:
            batch["mode"] = "dry-run"
        return client.request(
            "POST", f"/v1/projects/{quote(project_id)}/commands", batch
        )
    if arguments.command == "proposal":
        base = f"/v1/projects/{quote(project_id)}/proposals"
        if arguments.proposal_command == "list":
            return client.request("GET", base)
        if arguments.proposal_command == "status":
            return client.request("GET", f"{base}/{quote(arguments.proposal_id)}")
        if arguments.proposal_command == "cancel":
            return client.request(
                "POST", f"{base}/{quote(arguments.proposal_id)}/cancel", {}
            )
        if arguments.proposal_command == "create":
            request = (
                read_request_stdin()
                if arguments.stdin
                else read_request_file(arguments.file)
            )
            request_project_id = require_text(request, "projectId")
            if request_project_id != project_id:
                raise CliFailure(
                    "PROJECT_MISMATCH",
                    "validation",
                    "the ProposedChangeSet Project is not the active OrangeCut Project",
                    remediation="read `oc project current --json` and rebuild the proposal",
                    exit_code=EXIT_INVALID_INPUT,
                )
            return client.request("POST", base, request)
    raise CliFailure(
        "CLI_COMMAND_UNSUPPORTED",
        "validation",
        "the requested oc command is not implemented",
        exit_code=EXIT_INVALID_INPUT,
    )


def project_check_report(client: "Client", project_id: str, arguments: argparse.Namespace) -> dict[str, Any]:
    if ((arguments.from_frame is None) != (arguments.to_frame is None)
            or arguments.from_frame is not None and arguments.to_frame <= arguments.from_frame):
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "check range needs both boundaries and a positive interval", exit_code=EXIT_INVALID_INPUT)
    if arguments.from_frame is not None and not arguments.layout:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "check frame range scopes --layout; add --layout or omit the range", exit_code=EXIT_INVALID_INPUT)
    query = {"sync": "true"} if arguments.sync else {}
    if arguments.sync and arguments.sequence_id:
        query["sequenceId"] = arguments.sequence_id
    suffix = "?" + urllib.parse.urlencode(query) if query else ""
    report = dict(require_object(client.request("GET", f"/v1/projects/{quote(project_id)}/check{suffix}"), "data"))
    report["optionalChecks"] = {"layout": None, "frames": None, "audioClips": None}
    report["notPerformed"] = ["full media decode", "full mix loudness", "human picture and sound review"]
    if arguments.read_frames is None:
        report["notPerformed"].append("rendered frame inspection")
    # Every nested read explicitly targets the same Project even if another
    # window opens while the report is being collected.
    def read_command(tokens: list[str]) -> Any:
        global _REQUESTED_PROJECT
        previous = _REQUESTED_PROJECT
        _REQUESTED_PROJECT = project_id
        try:
            parsed = parser().parse_args(tokens)
            return execute(parsed)
        finally:
            _REQUESTED_PROJECT = previous
    failures = []
    checks = []
    if arguments.layout:
        tokens = ["layout", "check"]
        if arguments.sequence_id:
            tokens += ["--sequence-id", arguments.sequence_id]
        if arguments.from_frame is not None:
            tokens += ["--from-frame", str(arguments.from_frame), "--to-frame", str(arguments.to_frame)]
        checks.append(("layout", tokens))
    if arguments.read_frames is not None:
        tokens = ["read", "--frames", ",".join(map(str, arguments.read_frames))]
        if arguments.sequence_id:
            tokens += ["--sequence-id", arguments.sequence_id]
        if arguments.output:
            tokens += ["--output", str(arguments.output.with_suffix(".frames.png"))]
        checks.append(("frames", tokens))
    for clip_id in arguments.audio_clip:
        tokens = ["audio", "measure", clip_id]
        if arguments.sequence_id:
            tokens += ["--sequence-id", arguments.sequence_id]
        checks.append((f"audio:{clip_id}", tokens))
    for name, tokens in checks:
        try:
            evidence = read_command(tokens)
            if name.startswith("audio:"):
                if report["optionalChecks"]["audioClips"] is None:
                    report["optionalChecks"]["audioClips"] = []
                report["optionalChecks"]["audioClips"].append({"clipId": name[6:], "status": "measured", "evidence": evidence})
            else:
                report["optionalChecks"][name] = {"status": "rendered" if name == "frames" else "checked", "evidence": evidence}
        except CliFailure as error:
            failures.append({"check": name, "error": error.wire()["error"]})
    status = require_object(client.request("GET", "/v1/status"), "data")
    current = next((p.get("revision") for p in status.get("openProjects", []) if p.get("projectId") == project_id), None)
    if current is None and status.get("activeProjectId") == project_id:
        current = status.get("revision")
    report["revisionStable"] = current == report.get("revision")
    report["finalRevision"] = current
    report["executionFailures"] = failures
    report["passed"] = bool(report.get("passed")) and not failures and report["revisionStable"]
    layout = report["optionalChecks"]["layout"]
    report["attentionRequired"] = bool(layout and layout["evidence"].get("warningCount", 0)) or bool(report.get("checks", {}).get("mediaLibrary", {}).get("missing"))
    if arguments.output:
        try:
            arguments.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        except OSError as error:
            raise CliFailure("CLI_OUTPUT_WRITE_FAILED", "store", "could not write the requested check report",
                             details={"ioErrorType": type(error).__name__}, exit_code=EXIT_OPERATION_FAILED) from error
    if not report["passed"]:
        sync_details = {"syncIssues": report.get("syncIssues", [])} if arguments.sync else {}
        raise CliFailure("PROJECT_CHECK_FAILED", "validation", "one or more requested checks failed, or the Project changed during verification",
                         details={"revisionStable":report["revisionStable"],"reportWritten":arguments.output is not None,
                                  "checks":report.get("checks",{}),"stepFailures":[{"check":f["check"],"code":f["error"]["code"],"message":f["error"]["message"]}for f in failures], **sync_details},
                         exit_code=EXIT_OPERATION_FAILED)
    return {"data": report}


def read_request_file(path: Path) -> dict[str, Any]:
    payload = read_request_file_value(path)
    if not isinstance(payload, dict):
        raise CliFailure(
            "CLI_REQUEST_FILE_INVALID",
            "validation",
            "the request file must contain one JSON object",
            exit_code=EXIT_INVALID_INPUT,
        )
    return payload


def read_request_file_value(path: Path) -> Any:
    raw = read_request_file_bytes(path)
    try:
        payload = strict_json_loads(raw.decode("utf-8"))
    except (UnicodeError, ValueError, RecursionError) as error:
        raise CliFailure(
            "CLI_REQUEST_FILE_INVALID",
            "validation",
            "the request file does not contain one valid UTF-8 JSON value",
            exit_code=EXIT_INVALID_INPUT,
        ) from error
    return payload


def read_request_file_bytes(path: Path) -> bytes:
    """Read a bounded regular file, refusing symlinks and anything oversized.

    Shared by every `--file` input so a subtitle file gets the same protection
    a raw CommandBatch does.
    """
    try:
        metadata = path.lstat()
        if path_is_link(path, metadata) or not stat.S_ISREG(metadata.st_mode):
            raise CliFailure(
                "CLI_REQUEST_FILE_INVALID",
                "validation",
                "the request file must be a bounded regular file",
                exit_code=EXIT_INVALID_INPUT,
            )
        if metadata.st_size > MAX_CONTROL_REQUEST_BYTES:
            raise request_too_large("file")
        flags = os.O_RDONLY
        for flag_name in ("O_BINARY", "O_CLOEXEC", "O_NOFOLLOW", "O_NONBLOCK"):
            flags |= getattr(os, flag_name, 0)
        descriptor = os.open(path, flags)
        with os.fdopen(descriptor, "rb") as request_file:
            opened = os.fstat(request_file.fileno())
            if not stat.S_ISREG(opened.st_mode):
                raise CliFailure(
                    "CLI_REQUEST_FILE_INVALID",
                    "validation",
                    "the request file must remain a regular file while it is read",
                    exit_code=EXIT_INVALID_INPUT,
                )
            if opened.st_size > MAX_CONTROL_REQUEST_BYTES:
                raise request_too_large("file")
            raw = request_file.read(MAX_CONTROL_REQUEST_BYTES + 1)
    except CliFailure:
        raise
    except OSError as error:
        raise CliFailure(
            "CLI_REQUEST_FILE_INVALID",
            "validation",
            "the request file could not be opened",
            exit_code=EXIT_INVALID_INPUT,
        ) from error
    if len(raw) > MAX_CONTROL_REQUEST_BYTES:
        raise request_too_large("file")
    return raw


SRT_TIMING = re.compile(
    r"^\s*(\d+):([0-5]?\d):([0-5]?\d)[,.](\d{1,3})"
    r"\s*-->\s*"
    r"(\d+):([0-5]?\d):([0-5]?\d)[,.](\d{1,3})\s*(?:\S.*)?$"
)


def srt_milliseconds(hours: str, minutes: str, seconds: str, fraction: str) -> int:
    return (
        int(hours) * 3_600_000
        + int(minutes) * 60_000
        + int(seconds) * 1_000
        # SRT writes milliseconds, but files in the wild truncate the field; pad
        # rather than read "1,5" as one and a half milliseconds.
        + int(fraction.ljust(3, "0"))
    )


def parse_srt(text: str) -> list[tuple[int, int, str]]:
    """Read an SRT file into (startMs, endMs, text) cues in file order.

    Deliberately permissive about what surrounds the timing line — index
    numbers, CRLF, a BOM, blank lines, and the WebVTT `.` decimal separator all
    appear in real transcripts — and deliberately strict about the timing line
    itself, because a misread timestamp puts a caption on the wrong shot
    without anything failing.
    """
    cues: list[tuple[int, int, str]] = []
    blocks = re.split(r"\r?\n\s*\r?\n", text.lstrip("﻿").strip())
    for position, block in enumerate(blocks):
        lines = [line for line in block.splitlines() if line.strip()]
        if not lines:
            continue
        if not SRT_TIMING.match(lines[0]) and len(lines) > 1:
            # The first line is the cue number, which carries no meaning here:
            # cues are used in file order so a duplicated index cannot reorder.
            lines = lines[1:]
        timing = SRT_TIMING.match(lines[0]) if lines else None
        if timing is None:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"SRT block {position + 1} has no readable timing line",
                remediation="expected `00:00:01,000 --> 00:00:03,000`",
                exit_code=EXIT_INVALID_INPUT,
            )
        start = srt_milliseconds(*timing.group(1, 2, 3, 4))
        end = srt_milliseconds(*timing.group(5, 6, 7, 8))
        if end <= start:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"SRT block {position + 1} ends at or before it starts",
                exit_code=EXIT_INVALID_INPUT,
            )
        # A cue's own line breaks are layout, not content; the caption style
        # decides wrapping, so they collapse to single spaces.
        body = " ".join(line.strip() for line in lines[1:] if line.strip())
        if not body:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"SRT block {position + 1} has timing but no text",
                exit_code=EXIT_INVALID_INPUT,
            )
        cues.append((start, end, body))
    if not cues:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            "the SRT file contains no cues",
            exit_code=EXIT_INVALID_INPUT,
        )
    return cues


def attach_caption_tokens(
    captions: list[dict[str, Any]],
    words_file: Path,
    frame_rate: Fraction,
    offset_frames: int,
) -> None:
    """Hand each caption the words that fall inside it.

    Words are consumed in order rather than filtered by time: a word whose
    timestamp sits in the gap between two cues belongs to the line that is
    still on screen, and time-filtering each cue independently would hand the
    same word to both neighbours — which then renders as a stutter in the
    highlight.
    """
    words = read_transcript_words(words_file)
    position = 0
    for caption in captions:
        start_frame = caption["startFrame"]
        end_frame = start_frame + caption["durationFrames"]
        tokens: list[dict[str, Any]] = []
        while position < len(words):
            word = words[position]
            word_start = round(Fraction(word["start"]).limit_denominator(1000) * frame_rate)
            word_start += offset_frames
            if word_start >= end_frame:
                break
            position += 1
            if word_start < start_frame:
                word_start = start_frame
            # Two words can round onto one frame, or be clamped onto the
            # caption's first frame together. Tokens have to stay strictly
            # ordered, so give the later one the next frame — and drop it if
            # that pushes it past the line.
            if tokens and word_start <= tokens[-1]["startFrame"]:
                word_start = tokens[-1]["startFrame"] + 1
            if word_start >= end_frame or not word["text"].strip():
                continue
            tokens.append({"text": word["text"], "startFrame": word_start})
        # token 文本对不上 caption 文本时按字符数就地取字:glossary 只改
        # SRT 文本不改 words、或标点只出现在文本里,都会让渲染端对不齐而
        # **静默**放弃逐字高亮(服务端现在也会在写入时直接拒绝)。时间戳
        # 一律不动——改字不改时长。
        caption_text = str(caption.get("text") or "")
        if tokens and not caption_tokens_cover_text(caption_text, tokens):
            tokens = realign_tokens_to_text(caption_text, tokens)
        for index, token in enumerate(tokens):
            following = (
                tokens[index + 1]["startFrame"] if index + 1 < len(tokens) else end_frame
            )
            token["durationFrames"] = max(1, following - token["startFrame"])
        if tokens:
            caption["tokens"] = tokens


def caption_tokens_cover_text(text: str, tokens: list[dict[str, Any]]) -> bool:
    """渲染端 split_caption_runs 的镜像:tokens 能按序拼回 caption 文本
    (token 之间只允许空白)才算对齐。改这边必须同步 core 的
    `caption_tokens_cover_text`,两边判定漂移就又回到静默失败。"""
    rest = text
    matched = False
    for token in tokens:
        piece = str(token.get("text") or "")
        if not piece:
            continue
        offset = rest.find(piece)
        if offset < 0 or rest[:offset].strip():
            return False
        rest = rest[offset + len(piece):]
        matched = True
    return matched and not rest.strip()


def realign_tokens_to_text(
    text: str, tokens: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """以 caption 文本为准,把每个 token 的文本换成对应位置的等长切片。

    结果必然对齐:多出的尾巴(标点等)并入最后一个 token;文本先用完则
    丢弃后面的 token(它们已经没有字可亮)。"""
    cursor = 0
    realigned: list[dict[str, Any]] = []
    for token in tokens:
        while cursor < len(text) and text[cursor].isspace():
            cursor += 1
        take = max(1, len(str(token.get("text") or "")))
        piece = text[cursor:cursor + take]
        if not piece:
            break
        realigned.append({**token, "text": piece})
        cursor += len(piece)
    if realigned and text[cursor:].strip():
        realigned[-1]["text"] += text[cursor:]
    return realigned


def read_transcript_words(path: Path) -> list[dict[str, Any]]:
    """Read the word list out of `oc media transcribe --json` output."""
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except OSError as error:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            f"cannot read {path}: {error}",
            exit_code=EXIT_INVALID_INPUT,
        ) from error
    except json.JSONDecodeError as error:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            f"{path} is not JSON: {error}",
            exit_code=EXIT_INVALID_INPUT,
        ) from error
    payload = document.get("data", document) if isinstance(document, dict) else {}
    words = payload.get("words") if isinstance(payload, dict) else None
    if not isinstance(words, list) or not words:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            f"{path} carries no word-level timings",
            remediation="produce it with `oc media transcribe --json`",
            exit_code=EXIT_INVALID_INPUT,
        )
    return [
        word
        for word in words
        if isinstance(word, dict)
        and isinstance(word.get("text"), str)
        and isinstance(word.get("start"), (int, float))
    ]


def srt_captions(
    text: str, frame_rate: Fraction, offset_frames: int
) -> list[dict[str, Any]]:
    """Convert SRT cues to the exact frame-based captions the service takes.

    Timestamps are milliseconds and the timeline is frames, so a cue almost
    never lands exactly on the grid. Each edge is rounded to its nearest frame
    — the same rule every NLE applies — and a cue whose rounded range collapses
    to nothing is widened to one frame rather than dropped, because a dropped
    line is a silent hole in a transcript.
    """
    captions: list[dict[str, Any]] = []
    previous_end = 0
    for index, (start_ms, end_ms, body) in enumerate(parse_srt(text)):
        start_frame = round(Fraction(start_ms, 1000) * frame_rate) + offset_frames
        end_frame = round(Fraction(end_ms, 1000) * frame_rate) + offset_frames
        if start_frame < 0:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"caption {index} starts before frame zero after the offset",
                remediation="raise --offset-frames",
                exit_code=EXIT_INVALID_INPUT,
            )
        if end_frame <= start_frame:
            end_frame = start_frame + 1
        # Overlapping cues cannot share one Caption Track, and SRT files
        # routinely overlap by a frame or two from rounding. Trimming the
        # earlier line is what a viewer would not notice; failing the whole
        # transcript is not.
        if start_frame < previous_end:
            start_frame = previous_end
            if end_frame <= start_frame:
                end_frame = start_frame + 1
        previous_end = end_frame
        captions.append(
            {
                "text": body,
                "startFrame": start_frame,
                "durationFrames": end_frame - start_frame,
            }
        )
    return captions


def resolve_sequence_time_base(
    client: Any, project_id: str, sequence_id: str | None
) -> tuple[str, Fraction]:
    """Name the Sequence a command lands on, and its exact frame rate.

    One snapshot answers both: a command that named no Sequence still has to put
    the Project's own default id on the wire, and the frames it was given only
    become exact times through that Sequence's own rate.
    """
    snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
    project = require_object(require_object(snapshot, "data"), "project")
    resolved = sequence_id or require_text(
        require_object(project, "settings"), "defaultSequenceId"
    )
    return resolved, sequence_frame_rate_from(project, resolved)


def sequence_frame_rate(
    client: Any, project_id: str, sequence_id: str | None
) -> Fraction:
    """Read one Sequence's exact frame rate as a Fraction.

    Exact because the rate is a ratio: 30000/1001 is not 29.97, and rounding it
    would drift a long transcript by whole frames before the end.
    """
    snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
    project = require_object(require_object(snapshot, "data"), "project")
    return sequence_frame_rate_from(project, sequence_id)


def sequence_frame_rate_from(project: dict[str, Any], sequence_id: str | None) -> Fraction:
    """The same read, against a snapshot the caller already holds."""
    wanted = sequence_id or require_object(project, "settings").get("defaultSequenceId")
    sequences = project.get("sequences")
    if not isinstance(sequences, list):
        raise CliFailure(
            "PROTOCOL_FIELD_INVALID",
            "serialization",
            "the protocol field sequences must be an array",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )
    for sequence in sequences:
        if not isinstance(sequence, dict):
            continue
        if wanted is not None and sequence.get("id") != wanted:
            continue
        rate = require_object(sequence, "frameRate")
        numerator = int(require_text(rate, "num"))
        denominator = int(require_text(rate, "den"))
        if numerator <= 0 or denominator <= 0:
            raise CliFailure(
                "PROTOCOL_FIELD_INVALID",
                "serialization",
                "the Sequence frame rate must be positive",
                exit_code=EXIT_SERVICE_UNAVAILABLE,
            )
        return Fraction(numerator, denominator)
    raise CliFailure(
        "CLI_ARGUMENT_INVALID",
        "validation",
        "the requested sequence does not exist",
        remediation="run `oc timeline snapshot --json` and use an exact sequence id",
        exit_code=EXIT_INVALID_INPUT,
    )


def read_srt_file(path: Path) -> str:
    raw = read_request_file_bytes(path)
    for encoding in ("utf-8-sig", "utf-8"):
        try:
            return raw.decode(encoding)
        except UnicodeError:
            continue
    raise CliFailure(
        "CLI_ARGUMENT_INVALID",
        "validation",
        "the SRT file is not valid UTF-8",
        remediation="re-save the subtitle file as UTF-8",
        exit_code=EXIT_INVALID_INPUT,
    )


def caption_batch_items(path: Path) -> list[dict[str, Any]]:
    """Read one transcript file into the exact `captions` array the service takes.

    A transcript is naturally a list, so a bare JSON array is accepted as well as
    an object carrying one under `captions`. Every entry is checked here rather
    than only at the service, so a malformed line is named with its index instead
    of failing the whole batch with one opaque message.
    """
    payload = read_request_file_value(path)
    if isinstance(payload, dict):
        payload = payload.get("captions")
    if not isinstance(payload, list) or not payload:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            "the caption file must contain a non-empty JSON array of captions",
            remediation='pass a JSON array of {"text", "startFrame", "durationFrames"}',
            exit_code=EXIT_INVALID_INPUT,
        )
    captions: list[dict[str, Any]] = []
    for index, entry in enumerate(payload):
        if not isinstance(entry, dict):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"caption {index} is not a JSON object",
                exit_code=EXIT_INVALID_INPUT,
            )
        text = entry.get("text")
        start_frame = entry.get("startFrame")
        duration_frames = entry.get("durationFrames")
        if not isinstance(text, str) or not text.strip():
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"caption {index} has no text",
                exit_code=EXIT_INVALID_INPUT,
            )
        if not isinstance(start_frame, int) or isinstance(start_frame, bool) or start_frame < 0:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"caption {index} has no non-negative integer startFrame",
                exit_code=EXIT_INVALID_INPUT,
            )
        if (
            not isinstance(duration_frames, int)
            or isinstance(duration_frames, bool)
            or duration_frames < 1
        ):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"caption {index} has no positive integer durationFrames",
                exit_code=EXIT_INVALID_INPUT,
            )
        unknown = sorted(set(entry) - {"text", "startFrame", "durationFrames", "emphases"})
        if unknown:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"caption {index} carries unknown fields: {', '.join(unknown)}",
                exit_code=EXIT_INVALID_INPUT,
            )
        item: dict[str, Any] = {
            "text": text,
            "startFrame": start_frame,
            "durationFrames": duration_frames,
        }
        emphases = entry.get("emphases")
        if emphases is not None:
            if not isinstance(emphases, list) or not all(
                isinstance(emphasis, dict)
                and isinstance(emphasis.get("text"), str)
                and isinstance(emphasis.get("color"), str)
                and set(emphasis) == {"text", "color"}
                for emphasis in emphases
            ):
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID",
                    "validation",
                    f'caption {index} emphases must be a list of {{"text", "color"}} objects',
                    exit_code=EXIT_INVALID_INPUT,
                )
            item["emphases"] = emphases
        captions.append(item)
    return captions


def path_is_link(path: Path, metadata: os.stat_result | None = None) -> bool:
    if metadata is None:
        try:
            metadata = path.lstat()
        except OSError:
            return False
    return stat.S_ISLNK(metadata.st_mode) or bool(
        getattr(metadata, "st_file_attributes", 0) & WINDOWS_REPARSE_POINT
    )


def read_request_stdin() -> dict[str, Any]:
    try:
        raw = sys.stdin.read(MAX_CONTROL_REQUEST_BYTES + 1)
        encoded = raw.encode("utf-8")
    except (OSError, UnicodeError) as error:
        raise CliFailure(
            "CLI_REQUEST_STDIN_INVALID",
            "validation",
            "stdin could not be read as UTF-8 text",
            exit_code=EXIT_INVALID_INPUT,
        ) from error
    if len(encoded) > MAX_CONTROL_REQUEST_BYTES:
        raise request_too_large("stdin")
    try:
        payload = strict_json_loads(raw)
    except (ValueError, RecursionError) as error:
        raise CliFailure(
            "CLI_REQUEST_STDIN_INVALID",
            "validation",
            "stdin does not contain one valid UTF-8 JSON value",
            exit_code=EXIT_INVALID_INPUT,
        ) from error
    if not isinstance(payload, dict):
        raise CliFailure(
            "CLI_REQUEST_STDIN_INVALID",
            "validation",
            "stdin must contain one JSON object",
            exit_code=EXIT_INVALID_INPUT,
        )
    return payload


def request_too_large(source: str) -> CliFailure:
    return CliFailure(
        f"CLI_REQUEST_{source.upper()}_TOO_LARGE",
        "validation",
        f"the raw {source} request exceeds the {MAX_CONTROL_REQUEST_BYTES}-byte control limit",
        remediation="reduce the atomic request below 4 MiB without truncating its JSON",
        exit_code=EXIT_INVALID_INPUT,
    )


def read_response_body(response: Any, maximum_bytes: int | None = None) -> bytes:
    if maximum_bytes is None:
        maximum_bytes = MAX_CONTROL_RESPONSE_BYTES
    body = response.read(maximum_bytes + 1)
    if len(body) > maximum_bytes:
        raise CliFailure(
            "HTTP_RESPONSE_TOO_LARGE",
            "serialization",
            "the OrangeCut control response exceeds the bounded client limit",
            remediation="reduce the Project or update OrangeCut; never infer a partial response",
        )
    return body


def decode_response(body: bytes) -> dict[str, Any]:
    try:
        payload = strict_json_loads(body.decode("utf-8"))
    except (UnicodeError, ValueError, RecursionError) as error:
        raise CliFailure(
            "HTTP_RESPONSE_INVALID",
            "serialization",
            "OrangeCut returned a response that is not UTF-8 JSON",
            retryable=True,
        ) from error
    if (
        not isinstance(payload, dict)
        or payload.get("schemaVersion") != SCHEMA_VERSION
        or not isinstance(payload.get("ok"), bool)
        or (payload["ok"] is True and "data" not in payload)
        or (payload["ok"] is False and not isinstance(payload.get("error"), dict))
    ):
        raise CliFailure(
            "HTTP_RESPONSE_INVALID",
            "serialization",
            "OrangeCut returned an invalid protocol envelope",
            retryable=True,
        )
    return payload


def decode_server_failure(
    value: Any,
    *,
    invalid_code: str,
    invalid_message: str,
    invalid_retryable: bool = False,
) -> CliFailure:
    def invalid() -> CliFailure:
        return CliFailure(
            invalid_code,
            "serialization",
            invalid_message,
            retryable=invalid_retryable,
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )

    if not isinstance(value, dict):
        return invalid()
    if not set(value).issubset(
        {
            "code",
            "stage",
            "message",
            "details",
            "retryable",
            "currentRevision",
            "remediation",
        }
    ):
        return invalid()
    code = value.get("code")
    stage = value.get("stage")
    message = value.get("message")
    details = value.get("details")
    retryable = value.get("retryable")
    if (
        not isinstance(code, str)
        or ERROR_CODE_PATTERN.fullmatch(code) is None
        or not isinstance(stage, str)
        or stage not in V0_ERROR_STAGES
        or not isinstance(message, str)
        or not message
        or len(message) > MAX_ERROR_MESSAGE_CHARS
        or not is_v0_json_object(details)
        or not isinstance(retryable, bool)
    ):
        return invalid()

    remediation_value = value.get("remediation", _MISSING)
    if remediation_value is _MISSING:
        remediation = None
    elif (
        not isinstance(remediation_value, str)
        or not remediation_value
        or len(remediation_value) > MAX_ERROR_MESSAGE_CHARS
    ):
        return invalid()
    else:
        remediation = remediation_value

    revision_value = value.get("currentRevision", _MISSING)
    if revision_value is _MISSING:
        current_revision = None
    elif (
        not isinstance(revision_value, int)
        or isinstance(revision_value, bool)
        or revision_value < 0
        or revision_value > MAX_SAFE_INTEGER
    ):
        return invalid()
    else:
        current_revision = revision_value

    return CliFailure(
        code,
        stage,
        message,
        retryable,
        remediation,
        current_revision,
        details=safe_error_details(details),
    )


def require_text(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value:
        raise CliFailure(
            "PROTOCOL_FIELD_INVALID",
            "serialization",
            f"the protocol field {key} must be a non-empty string",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )
    return value


def read_selection(arguments: argparse.Namespace) -> dict[str, Any]:
    """Turn the read flags into exactly one FrameSelection.

    Every rule here exists because breaking it would return a different region
    or density than the caller believes they asked for, and a picture of the
    wrong moment reads as evidence rather than as an error."""
    named = []
    if arguments.at is not None:
        named.append("--at")
    if arguments.frames is not None:
        named.append("--frames")
    if arguments.at_edits:
        named.append("--at-edits")
    if arguments.range_ is not None:
        named.append("--range")
    if not named:
        raise CliFailure(
            "READ_SELECTION_INVALID",
            "validation",
            "a read must name what to look at",
            remediation="pass --at, --frames, --at-edits, or --range with --count or --every",
            exit_code=EXIT_INVALID_INPUT,
        )
    # A range narrowing --at-edits is the one combination that means something.
    if len(named) > 1 and set(named) != {"--at-edits", "--range"}:
        raise CliFailure(
            "READ_SELECTION_INVALID",
            "validation",
            f"a read names one region, but {' and '.join(named)} were given",
            remediation="keep one of --at, --frames, --at-edits, or --range",
            exit_code=EXIT_INVALID_INPUT,
        )

    density = arguments.count is not None or arguments.every is not None
    if density and arguments.range_ is None:
        raise CliFailure(
            "READ_SELECTION_INVALID",
            "validation",
            "--count and --every describe how densely to sample --range",
            remediation="pass --range START:END alongside --count or --every",
            exit_code=EXIT_INVALID_INPUT,
        )
    if arguments.at is not None:
        return {"kind": "at", "time": arguments.at}
    if arguments.frames is not None:
        return {"kind": "frames", "frames": arguments.frames}
    if arguments.at_edits:
        if density:
            raise CliFailure(
                "READ_SELECTION_INVALID",
                "validation",
                "--at-edits picks its own instants, so it has no sampling density",
                remediation="drop --count and --every, or drop --at-edits",
                exit_code=EXIT_INVALID_INPUT,
            )
        selection: dict[str, Any] = {"kind": "edits"}
        if arguments.range_ is not None:
            selection["range"] = arguments.range_
        return selection
    if arguments.count is not None:
        return {"kind": "uniform", "range": arguments.range_, "count": arguments.count}
    if arguments.every is not None:
        return {"kind": "stride", "range": arguments.range_, "everyFrames": arguments.every}
    raise CliFailure(
        "READ_SELECTION_INVALID",
        "validation",
        "--range needs a density",
        remediation="add --count N to sample evenly, or --every N to stride",
        exit_code=EXIT_INVALID_INPUT,
    )


def require_object(payload: dict[str, Any], key: str) -> dict[str, Any]:
    value = payload.get(key)
    if not isinstance(value, dict):
        raise CliFailure(
            "PROTOCOL_FIELD_INVALID",
            "serialization",
            f"the protocol field {key} must be an object",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )
    return value


def require_integer(payload: dict[str, Any], key: str) -> int:
    value = payload.get(key)
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise CliFailure(
            "PROTOCOL_FIELD_INVALID",
            "serialization",
            f"the protocol field {key} must be a non-negative integer",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )
    return value


VOID_HTML_TAGS = frozenset(
    ("br", "hr", "img", "source", "col", "wbr", "stop", "path", "rect", "circle",
     "ellipse", "line", "polyline", "polygon", "use")
)


class _HtmlTreeBuilder(HTMLParser):
    """把 HTML 字符串解析成 dev.orangecut.html 的类型化节点树。

    服务端刻意不含 HTML 解析面(只收结构化节点),解析发生在这里:
    - style 属性 → styles 映射;class 属性 → classes 列表
    - <style> 标签内容抽出合并进组件 stylesheet
    - svg 子树自动标 namespace=svg
    - 文本与子元素混排时,裸文本包进 span 保持顺序
    白名单校验以服务端为准,这里只负责结构转换。
    """

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.roots: list[dict[str, Any]] = []
        self.stack: list[dict[str, Any]] = []
        self.styles: list[str] = []
        self._style_depth = 0

    # html.parser 把标签/属性统一转小写,SVG 的 camelCase 名要还原,
    # 否则服务端白名单(大小写敏感)拒收、浏览器属性失效。
    _SVG_TAG_CASING = {
        "lineargradient": "linearGradient",
        "radialgradient": "radialGradient",
        "clippath": "clipPath",
        "fegaussianblur": "feGaussianBlur",
        "feoffset": "feOffset",
        "feblend": "feBlend",
        "fecolormatrix": "feColorMatrix",
        "fecomposite": "feComposite",
        "femerge": "feMerge",
        "femergenode": "feMergeNode",
        "foreignobject": "foreignObject",
        "textpath": "textPath",
    }
    _SVG_ATTR_CASING = {
        "viewbox": "viewBox",
        "gradientunits": "gradientUnits",
        "gradienttransform": "gradientTransform",
        "patternunits": "patternUnits",
        "patterntransform": "patternTransform",
        "preserveaspectratio": "preserveAspectRatio",
        "stddeviation": "stdDeviation",
        "clippathunits": "clipPathUnits",
        "maskunits": "maskUnits",
        "markerunits": "markerUnits",
        "markerwidth": "markerWidth",
        "markerheight": "markerHeight",
        "refx": "refX",
        "refy": "refY",
        "spreadmethod": "spreadMethod",
        "startoffset": "startOffset",
        "stroke-dasharray": "stroke-dasharray",
    }

    def _node(self, tag: str, attrs: list[tuple[str, str | None]]) -> dict[str, Any]:
        tag = self._SVG_TAG_CASING.get(tag, tag)
        node: dict[str, Any] = {"tag": tag, "children": []}
        classes: list[str] = []
        styles: dict[str, str] = {}
        attributes: dict[str, str] = {}
        authored_id = None
        for name, raw in attrs:
            value = raw or ""
            if name == "id":
                # 节点 id 归编译器所有;来源片段的 id 转成 class 保留
                # CSS 定位能力(样式表引用 #x 时调用方需同步用 .id-x)。
                # svg 子树例外:url(#…) 交叉引用按 DOM id 解析,服务端对
                # svg 命名空间放行授权 id,这里原样透传(class 同步保留)。
                authored_id = value
                cls = f"id-{value}"
                if value and cls not in classes:
                    classes.append(cls)
                continue
            if name == "class":
                for cls in value.split():
                    if cls and cls not in classes:
                        classes.append(cls)
            elif name == "style":
                for declaration in value.split(";"):
                    if ":" not in declaration:
                        continue
                    prop, _, val = declaration.partition(":")
                    prop, val = prop.strip(), val.strip()
                    if prop and val:
                        styles[prop] = val
            elif name == "data-asset-id":
                node["assetId"] = value
            elif name == "data-audio-cue":
                try:
                    cue=json.loads(value)
                    if not isinstance(cue,dict) or set(cue)!={"offset","duration","volume"} or not all(isinstance(v,dict) and set(v)=={"num","den"} and isinstance(v['num'],str) and isinstance(v['den'],str) and re.fullmatch(r"\d+",v['num']) and re.fullmatch(r"[1-9]\d*",v['den']) for v in cue.values()):raise ValueError("invalid exact cue values")
                    node['audioCue']=cue
                except (ValueError,TypeError) as error:raise CliFailure("HTML_AUDIO_CUE_INVALID","validation",str(error),exit_code=EXIT_INVALID_INPUT) from error
            elif name == "data-media-start":
                if not re.fullmatch(r"\d+/[1-9]\d*", value):
                    raise CliFailure("HTML_MEDIA_START_INVALID", "validation",
                        "data-media-start must be a non-negative exact fraction such as 3/2",
                        exit_code=EXIT_INVALID_INPUT)
                numerator, denominator = value.split("/")
                node["mediaStart"] = {"num": numerator, "den": denominator}
            else:
                attributes[self._SVG_ATTR_CASING.get(name, name)] = value
        if classes:
            node["classes"] = classes
        if styles:
            node["styles"] = styles
        in_svg = tag == "svg" or any(
            entry.get("tag") == "svg" or entry.get("namespace") == "svg"
            for entry in self.stack
        )
        if in_svg:
            node["namespace"] = "svg"
            if authored_id:
                attributes["id"] = authored_id
        if attributes:
            node["attributes"] = attributes
        if "audioCue" in node and (tag!="audio" or not node.get("assetId")):
            raise CliFailure("HTML_AUDIO_CUE_INVALID","validation","audioCue requires an audio Asset",exit_code=EXIT_INVALID_INPUT)
        if "mediaStart" in node and (tag not in ("video", "audio") or not node.get("assetId")):
            raise CliFailure("HTML_MEDIA_START_INVALID", "validation",
                "data-media-start requires video/audio with data-asset-id", exit_code=EXIT_INVALID_INPUT)
        return node

    def _append(self, node: dict[str, Any]) -> None:
        if self.stack:
            self.stack[-1]["children"].append(node)
        else:
            self.roots.append(node)

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "style":
            self._style_depth += 1
            return
        node = self._node(tag, attrs)
        self._append(node)
        if tag not in VOID_HTML_TAGS:
            self.stack.append(node)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "style":
            return
        self._append(self._node(tag, attrs))

    def handle_endtag(self, tag: str) -> None:
        if tag == "style":
            self._style_depth = max(0, self._style_depth - 1)
            return
        tag = self._SVG_TAG_CASING.get(tag, tag)
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index]["tag"] == tag:
                del self.stack[index:]
                return

    def handle_data(self, data: str) -> None:
        if self._style_depth > 0:
            self.styles.append(data)
            return
        text = data.strip()
        if not text:
            # 浏览器语义:元素间的空白折叠为一个空格,inline 排版中有
            # 渲染意义(词间距)。已有子元素的父节点内补一个空格文本,
            # 丢弃则逐字 span 组件的词组间隔消失。svg 子树除外:HTML
            # 解析器在 foreign content 里遇到 <span> 会跳出 svg 上下文,
            # 之后的图形元素全被当 HTML 渲染。
            parent = self.stack[-1] if self.stack else None
            if (
                data
                and parent is not None
                and parent["children"]
                and parent.get("namespace") != "svg"
                and parent["tag"] != "svg"
            ):
                parent["children"].append({"tag": "span", "text": " ", "children": []})
            return
        parent = self.stack[-1] if self.stack else None
        if parent is not None and not parent["children"] and "text" not in parent:
            parent["text"] = text
        else:
            span: dict[str, Any] = {"tag": "span", "text": text, "children": []}
            if parent is not None and parent.get("namespace") == "svg":
                span["tag"] = "tspan"
                span["namespace"] = "svg"
            self._append(span)


def _strip_empty_children(node: dict[str, Any]) -> dict[str, Any]:
    children = [_strip_empty_children(child) for child in node.get("children", [])]
    if children:
        node["children"] = children
    else:
        node.pop("children", None)
    return node


HTML_PRESET_CATALOG_ENV = "ORANGECUT_HTML_PRESETS"


def html_preset_catalog_path() -> Path:
    """Locate `schemas/v0/html-presets.json`, the table the editor also reads.

    Resolved from the repository the CLI was installed from, because the
    development install is editable and lives inside it. The wheel carries a
    byte-identical generated catalog so a packaged installation remains usable
    without a repository or a machine-specific environment override.
    """
    override = os.environ.get(HTML_PRESET_CATALOG_ENV)
    if override:
        return Path(override)
    for parent in Path(__file__).resolve().parents:
        candidate = parent / "schemas" / "v0" / "html-presets.json"
        if candidate.is_file():
            return candidate
    bundled = Path(__file__).with_name("html-presets.json")
    if bundled.is_file():
        return bundled
    raise CliFailure(
        "HTML_PRESET_CATALOG_MISSING",
        "validation",
        "cannot find schemas/v0/html-presets.json next to this installation",
        remediation=f"set {HTML_PRESET_CATALOG_ENV} to the catalog path",
        exit_code=EXIT_INVALID_INPUT,
    )



# ---------------------------------------------------------------- layout check
#
# 画面占位冲突检查。字幕、文字贴纸、图案组件各自用不同的坐标体系表达位置
# (字幕说顶/中/底加偏移,贴纸说相对画面中心的像素偏移,预设组件说画布百分
# 比),所以放置时谁也看不出彼此会不会撞上——实测就撞过一次(惊讶符号压住
# 「好人呐~」)。这里把三套体系统一折算成画布像素框,再做时间×空间双重相交。
#
# 结果是建议而不是禁令:满屏黑场卡盖住字幕是设计意图,只标注不报错。


def _rational_number(value: Any, default: float = 0.0) -> float:
    if isinstance(value, dict) and "num" in value and "den" in value:
        try:
            return float(Fraction(int(value["num"]), int(value["den"])))
        except (TypeError, ValueError, ZeroDivisionError):
            return default
    if isinstance(value, (int, float)):
        return float(value)
    return default


def _css_length_to_px(raw: str, width: float, height: float) -> float | None:
    """把预设里的画布相对长度折算成像素。cqw/cqh/cqmin/cqmax 与 % 都认。"""
    text = str(raw).strip().lower()
    match = re.match(r"^(-?\d+(?:\.\d+)?)\s*(cqw|cqh|cqmin|cqmax|%|px)$", text)
    if match is None:
        return None
    amount = float(match.group(1))
    unit = match.group(2)
    if unit == "px":
        return amount
    basis = {
        "cqw": width,
        "cqh": height,
        "cqmin": min(width, height),
        "cqmax": max(width, height),
        "%": min(width, height),
    }[unit]
    return amount * basis / 100.0


def _component_variable(stylesheet: str, name: str) -> str | None:
    matches = re.findall(rf"{re.escape(name)}\s*:\s*([^;}}]+)", stylesheet or "")
    return matches[-1].strip() if matches else None


def _preset_layout_box(
    preset_id: str, stylesheet: str, width: float, height: float
) -> tuple[float, float, float, float] | None:
    """预设声明的占位 → 画布像素框 (x, y, w, h);声明缺失时返回 None(跳过)。"""
    preset = next(
        (item for item in load_html_presets() if item.get("id") == preset_id), None
    )
    spec = (preset or {}).get("layoutBox")
    if not isinstance(spec, dict):
        return None
    if spec.get("region") == "full":
        return (0.0, 0.0, width, height)
    if spec.get("region") == "band":
        thickness = _css_length_to_px(spec.get("thickness", "10%"), width, height)
        if thickness is None:
            thickness = height * 0.1
        # band 的厚度按画面高度算,而不是短边:横幅是横跨画面的一条。
        ratio = str(spec.get("thickness", "10%"))
        if ratio.endswith("%"):
            thickness = float(ratio[:-1]) * height / 100.0
        edge = spec.get("edge", "top")
        if edge == "top":
            return (0.0, 0.0, width, thickness)
        if edge == "bottom":
            return (0.0, height - thickness, width, thickness)
        return (0.0, (height - thickness) / 2.0, width, thickness)
    var_box = spec.get("varBox")
    if isinstance(var_box, dict):
        def resolve(key: str, fallback: float) -> float:
            raw = var_box.get(key)
            if raw is None:
                return fallback
            text = str(raw)
            if text.startswith("--"):
                declared = _component_variable(stylesheet, text)
                if declared is None:
                    return fallback
                text = declared
            value = _css_length_to_px(text, width, height)
            return fallback if value is None else value

        box_w = resolve("width", min(width, height) * 0.2)
        box_h = resolve("height", box_w)
        return (resolve("x", 0.0), resolve("y", 0.0), box_w, box_h)
    return None


# --------------------------------------------------------------- layout boxes
#
# 画面占位检查的盒子估算。这里是服务端排版规则的**镜像**,改一边必须改另一边:
#   - 文字层折行上限 86% 画布宽:hyperframes-native compiler.rs
#     `TEXT_LAYER_MAX_WIDTH_PERCENT`;贴纸适配用同一个数(http_service.rs
#     `TEXT_STICKER_LINE_BUDGET`)。
#   - 字宽估算 ASCII 0.6em / 其余 1.0em:http_service.rs `text_sticker_char_em`。
#   - 字幕竖直落点:core legacy_native_migration.rs `caption_vertical_offset`
#     (竖屏 bottom +26% 高、top −35%;横屏/方形 ±40%)。
#   - 摆位语义:元素以画布中心为原点,`translate(-50%,-50%) translate(x,y)
#     scale rotate`——即 positionX/Y 是盒子**中心**相对画布中心的像素偏移。
# 估算不追求排版级精度(展示体比等宽估算宽一到两成),所以除了真重叠还报
# 「贴近」,让 Agent 对贴近的对用 `oc read` 复核,而不是全片读图。

LAYOUT_TEXT_LINE_BUDGET = 0.86
# 浏览器 line-height: normal 在中文字体上约 1.3–1.45;取偏大值,宁可多报。
LAYOUT_TEXT_LINE_HEIGHT = 1.4
# 抖音/TikTok 竖屏信息流遮挡区(1080×1920 实测:顶 220px、底 380px、右 164px),
# 按比例套到任意竖屏画布;横屏/方形在信息流里居中显示,够不到遮挡区,不查。
LAYOUT_SAFE_ZONE_TOP = 220 / 1920
LAYOUT_SAFE_ZONE_BOTTOM = 380 / 1920
LAYOUT_SAFE_ZONE_RIGHT = 164 / 1080
# 运动曲线元素的采样步长(帧):半秒一采,加上区间两端。
LAYOUT_MOTION_SAMPLE_STEP = 15


def _text_em_width(line: str) -> float:
    return sum(0.6 if ord(char) < 0x80 else 1.0 for char in line)


def _color_visible(value: Any) -> bool:
    """`#RRGGBBAA` 的 AA 为 00、`transparent` 或缺省都算看不见。"""
    text = str(value or "").strip().lower()
    if not text or text == "transparent":
        return False
    if text.startswith("#") and len(text) == 9:
        return text[7:9] != "00"
    return True


def _text_layer_size(
    text: str,
    font_size: float,
    padding: float,
    outline: float,
    canvas_width: float,
    plate: bool = False,
) -> tuple[float, float]:
    """一个文字层(字幕/贴纸)停稳后**字迹**的外框宽高,画布像素。

    碰撞看的是字迹不是 DOM 盒子:没有底板时内边距是空气,不算;有底板时底板
    就是可见边界,内边距算进去。单行高按 1.0em(中文字迹实测 ≈0.95em),多行的
    行距按浏览器 line-height: normal 的偏大值 1.4;描边居中于字形边缘,总共多
    一个描边宽。显式换行按行算;超过 86% 画布宽的行按浏览器折行估算行数。
    """
    budget = max(1.0, canvas_width * LAYOUT_TEXT_LINE_BUDGET)
    lines = text.split("\n") or [""]
    widest = 0.0
    line_count = 0
    for line in lines:
        line_px = _text_em_width(line) * font_size
        if line_px > budget:
            line_count += max(1, math.ceil(line_px / budget))
            widest = budget
        else:
            line_count += 1
            widest = max(widest, line_px)
    line_count = max(1, line_count)
    inset = padding * 2 if plate else 0.0
    width = widest + inset + outline
    height = font_size * (1.0 + (line_count - 1) * LAYOUT_TEXT_LINE_HEIGHT) + inset + outline
    return (width, height)


def _caption_vertical_offset(position: str, width: float, height: float) -> float:
    portrait = height > width
    if position == "center":
        return 0.0
    if position == "top":
        return -(height * 7 / 20) if portrait else -(height * 2 / 5)
    return height * 13 / 50 if portrait else height * 2 / 5


def _placed_box(
    center_x: float,
    center_y: float,
    width: float,
    height: float,
    scale_x: float,
    scale_y: float,
    rotation_degrees: float,
) -> tuple[float, float, float, float]:
    """中心摆位 + 缩放 + 旋转 → 轴对齐外接框 (x, y, w, h)。"""
    w = abs(width * (scale_x or 1.0))
    h = abs(height * (scale_y or 1.0))
    if rotation_degrees:
        radians = math.radians(rotation_degrees)
        cos, sin = abs(math.cos(radians)), abs(math.sin(radians))
        w, h = w * cos + h * sin, w * sin + h * cos
    return (center_x - w / 2.0, center_y - h / 2.0, w, h)


def _caption_box(
    text: str, style: dict[str, Any], width: float, height: float
) -> tuple[float, float, float, float]:
    font_size = _rational_number(style.get("fontSizePx"), max(24.0, height * 0.03))
    padding = _rational_number(style.get("backgroundPaddingPx"), 0.0)
    outline = _rational_number(style.get("outlineWidthPx"), 0.0)
    scale = _rational_number(style.get("scale"), 1.0) or 1.0
    box_w, box_h = _text_layer_size(
        text, font_size, padding, outline, width,
        plate=_color_visible(style.get("backgroundColor")),
    )
    center_x = width / 2.0 + _rational_number(style.get("positionX"), 0.0)
    center_y = (
        height / 2.0
        + _caption_vertical_offset(str(style.get("position", "bottom")), width, height)
        + _rational_number(style.get("positionY"), 0.0)
    )
    return _placed_box(
        center_x, center_y, box_w, box_h, scale, scale,
        _rational_number(style.get("rotationDegrees"), 0.0),
    )


def _transform_parts(
    transform: dict[str, Any] | None,
) -> tuple[float, float, float, float, float]:
    """clip.transform → (positionX, positionY, scaleX, scaleY, rotation)。"""
    transform = transform or {}
    return (
        _rational_number(transform.get("positionX"), 0.0),
        _rational_number(transform.get("positionY"), 0.0),
        _rational_number(transform.get("scaleX"), 1.0) or 1.0,
        _rational_number(transform.get("scaleY"), 1.0) or 1.0,
        _rational_number(transform.get("rotationDegrees"), 0.0),
    )


def _sticker_size(properties: dict[str, Any], width: float, height: float) -> tuple[float, float]:
    text = str(properties.get("text", ""))
    font_size = _rational_number(properties.get("fontSizePx"), max(24.0, height * 0.04))
    padding = _rational_number(properties.get("backgroundPaddingPx"), 0.0)
    outline = _rational_number(properties.get("outlineWidthPx"), 0.0)
    return _text_layer_size(
        text, font_size, padding, outline, width,
        plate=_color_visible(properties.get("backgroundColor")),
    )


def _shape_size(properties: dict[str, Any]) -> tuple[float, float]:
    stroke = _rational_number(properties.get("strokeWidthPx"), 0.0)
    return (
        _rational_number(properties.get("widthPx"), 0.0) + stroke * 2,
        _rational_number(properties.get("heightPx"), 0.0) + stroke * 2,
    )


def _motion_easing(easing: str, progress: float) -> float:
    progress = min(1.0, max(0.0, progress))
    if easing == "hold":
        return 0.0
    if easing == "ease_in":
        return progress ** 3
    if easing == "ease_out":
        return 1.0 - (1.0 - progress) ** 3
    if easing == "ease_in_out":
        return progress * progress * (3.0 - 2.0 * progress)
    return progress


def _motion_vector_at(
    keyframes: list[dict[str, Any]], time_seconds: float
) -> tuple[float, float] | None:
    """镜像 core model.rs evaluate_motion_vector:首帧前取首值,末帧后取末值。"""
    if not keyframes:
        return None

    def value(frame: dict[str, Any]) -> tuple[float, float]:
        vector = frame.get("value") or {}
        return (_rational_number(vector.get("x")), _rational_number(vector.get("y")))

    first = keyframes[0]
    if time_seconds <= _rational_number(first.get("time")):
        return value(first)
    for left, right in zip(keyframes, keyframes[1:]):
        right_time = _rational_number(right.get("time"))
        if time_seconds <= right_time:
            if str(left.get("easing", "linear")) == "hold":
                return value(left)
            left_time = _rational_number(left.get("time"))
            duration = right_time - left_time
            if duration <= 0:
                return value(left)
            progress = _motion_easing(
                str(left.get("easing", "linear")), (time_seconds - left_time) / duration
            )
            lx, ly = value(left)
            rx, ry = value(right)
            return (lx + (rx - lx) * progress, ly + (ry - ly) * progress)
    return value(keyframes[-1])


def _element_box_at(element: dict[str, Any], frame: int) -> tuple[float, float, float, float]:
    """元素在某一帧的外接框;没有运动曲线的元素与 `box` 相同。

    运动曲线的位置/缩放关键帧是 GSAP 覆盖式的 x/y/scale——曲线值**替换**静态摆位,
    不是叠加(贴纸入场动画曾因此把落点甩飞,见 ADR/memory)。
    """
    if element.get("regions"):
        return polygon_box([point for region in _content_at(element, frame) for point in region])
    motion = element.get("motion")
    if not motion:
        return element["box"]
    px, py, sx, sy, rotation = _motion_pose_at(motion, frame)
    width, height = motion["size"]
    canvas_w, canvas_h = motion["canvas"]
    return _placed_box(canvas_w / 2.0 + px, canvas_h / 2.0 + py, width, height, sx, sy, rotation)


def _motion_pose_at(motion: dict[str, Any], frame: int) -> tuple[float, ...]:
    rate = float(motion["rate"]) or 30.0
    local = max(0.0, frame / rate - float(motion["start"])) + float(motion["timeOffset"])
    px, py, sx, sy, rotation = motion["static"]
    position = _motion_vector_at(motion["position"], local)
    if position is not None:
        px, py = position
    scale = _motion_vector_at(motion["scale"], local)
    if scale is not None:
        sx, sy = scale
    return px, py, sx, sy, rotation


def _content_at(element: dict[str, Any], frame: int) -> list:
    if element.get("regions"):
        motion = element.get("motion")
        pose = _motion_pose_at(motion, frame) if motion else element["pose"]
        return [transformed_region(region, element["canvas"], pose) for region in element["regions"]]
    left, top, width, height = _element_box_at(element, frame)
    return [[(left, top), (left + width, top), (left + width, top + height), (left, top + height)]]


def collect_layout_elements(
    project: dict[str, Any], sequence: dict[str, Any], *,
    image_bounds: Callable[[str], dict[str, Any]] | None = None,
    scan: tuple[int, int] | None = None,
    unverified: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """时间线上每个可见元素 → {kind, id, label, startFrame, endFrame, box, opaque, motion}。

    静音轨引擎整轨跳过、disabled 的片段不渲染,两者都不算可见元素。
    """
    canvas = sequence.get("canvas") or {}
    width = float(canvas.get("width") or 0) or 1080.0
    height = float(canvas.get("height") or 0) or 1920.0
    rate = sequence_frame_rate_from(project, sequence.get("id"))
    components = {
        str(item.get("id")): item for item in project.get("components", [])
    }
    image_assets = {item["id"]: item for item in project.get("assets", []) if item.get("kind") == "image"}
    image_cache: dict[str, dict[str, Any] | str] = {}
    image_deadline = time.monotonic() + 5.0

    def note(clip: dict[str, Any], code: str) -> None:
        if unverified is not None:
            unverified.append({"clipId": clip.get("id"), "reason": code})

    def frames(range_value: Any) -> tuple[int, int]:
        start = _rational_number((range_value or {}).get("start"))
        end = _rational_number((range_value or {}).get("end"))
        return (round(start * float(rate)), round(end * float(rate)))

    def motion_of(clip: dict[str, Any], size: tuple[float, float]) -> dict[str, Any] | None:
        motion = clip.get("motion") or {}
        position = motion.get("position") or []
        scale = motion.get("scale") or []
        if not position and not scale:
            return None
        return {
            "rate": float(rate),
            "start": _rational_number((clip.get("timelineRange") or {}).get("start")),
            "timeOffset": _rational_number(motion.get("timeOffset"), 0.0),
            "static": _transform_parts(clip.get("transform")),
            "position": position,
            "scale": scale,
            "size": size,
            "canvas": (width, height),
        }

    def placed(size: tuple[float, float], transform: dict[str, Any] | None):
        px, py, sx, sy, rotation = _transform_parts(transform)
        return _placed_box(width / 2.0 + px, height / 2.0 + py, size[0], size[1], sx, sy, rotation)

    def add_regions(clip: dict[str, Any], kind: str, label: str, regions: list[Box], start: int, end: int) -> None:
        if not regions:
            return
        element = {
            "kind": kind, "id": clip.get("id"), "label": label,
            "startFrame": start, "endFrame": end, "opaque": False,
            "regions": regions, "canvas": (width, height), "captionContent": True,
            "pose": _transform_parts(clip.get("transform")), "motion": motion_of(clip, (width, height)),
        }
        element["box"] = _element_box_at(element, start)
        elements.append(element)

    elements: list[dict[str, Any]] = []
    for track in sequence.get("tracks", []):
        if track.get("muted"):
            continue
        for caption in track.get("captions", []):
            style = components.get(str(caption.get("styleRef")), {}).get("properties", {})
            start, end = frames(caption.get("timelineRange"))
            text = str(caption.get("text", ""))
            elements.append({
                "kind": "caption",
                "id": caption.get("id"),
                "label": text[:18],
                "startFrame": start,
                "endFrame": end,
                "box": _caption_box(text, style, width, height),
                "opaque": False,
                "motion": None,
            })
        for clip in track.get("clips", []):
            if clip.get("enabled") is False:
                continue
            start, end = frames(clip.get("timelineRange"))
            if scan and (end <= scan[0] or start >= scan[1]):
                continue
            source = clip.get("source") or {}
            asset_id = source.get("assetId")
            if track.get("kind") == "video" and asset_id in image_assets and image_bounds is not None:
                if asset_id not in image_cache:
                    if len(image_cache) >= 64 or time.monotonic() >= image_deadline:
                        note(clip, "LAYOUT_IMAGE_SCAN_LIMIT")
                        continue
                    try:
                        image_cache[asset_id] = image_bounds(asset_id)
                    except CliFailure as error:
                        image_cache[asset_id] = error.code
                pixels = image_cache[asset_id]
                if isinstance(pixels, str):
                    note(clip, pixels)
                else:
                    try:
                        region = image_region(pixels, clip.get("visualFit") or "contain", width, height)
                    except (KeyError, TypeError, ValueError, ZeroDivisionError):
                        note(clip, "LAYOUT_IMAGE_BOUNDS_INVALID")
                    else:
                        if region:
                            add_regions(clip, "image", image_assets[asset_id].get("name", asset_id), [region], start, end)
                continue
            component_id = source.get("componentId")
            if component_id is None:
                continue
            component = components.get(str(component_id))
            if component is None:
                continue
            component_type = str(component.get("componentType", ""))
            properties = component.get("properties") or {}
            if component_type.endswith("text-sticker"):
                size = _sticker_size(properties, width, height)
                elements.append({
                    "kind": "sticker",
                    "id": clip.get("id"),
                    "label": str(properties.get("text", ""))[:18],
                    "startFrame": start,
                    "endFrame": end,
                    "box": placed(size, clip.get("transform")),
                    "opaque": False,
                    "captionContent": True,
                    "motion": motion_of(clip, size),
                })
                continue
            if component_type.endswith(".shape"):
                explicit_paint = any(key in properties for key in ("fillColor", "strokeColor", "shadowColor"))
                if explicit_paint and not any(overlay_color_visible(properties.get(key)) for key in ("fillColor", "strokeColor", "shadowColor")):
                    continue
                size = _shape_size(properties)
                elements.append({
                    "kind": "shape",
                    "id": clip.get("id"),
                    "label": str(properties.get("kind", "shape")),
                    "startFrame": start,
                    "endFrame": end,
                    "box": placed(size, clip.get("transform")),
                    # 形状多半是文字底下的色块,压着别的元素通常是设计意图。
                    "opaque": True,
                    "captionContent": size[0] < width * .95 or size[1] < height * .95,
                    "motion": motion_of(clip, size),
                })
                continue
            if component_type.endswith("html"):
                attributes = ((properties.get("root") or {}).get("attributes")) or {}
                preset_id = str(attributes.get("data-form-preset", ""))
                box = _preset_layout_box(
                    preset_id, str(properties.get("stylesheet") or ""), width, height
                ) if preset_id else None
                preset = next(
                    (item for item in load_html_presets() if item.get("id") == preset_id),
                    {},
                ) if preset_id else {}
                spec = preset.get("layoutBox") or {}
                if box is not None and spec.get("region") != "full":
                    add_regions(clip, "component", preset_id, [box], start, end)
                else:
                    regions, uncertain = html_regions(properties, width, height)
                    if uncertain:
                        note(clip, "LAYOUT_HTML_REVIEW_REQUIRED")
                    add_regions(clip, "component", preset_id or "HTML", regions, start, end)
    return elements


def _box_overlap(
    a: tuple[float, float, float, float], b: tuple[float, float, float, float]
) -> tuple[float, float]:
    """(重叠面积占较小盒子的比例, 两盒最近距离 px);相交时距离为 0。"""
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    gap_x = max(ax, bx) - min(ax + aw, bx + bw)
    gap_y = max(ay, by) - min(ay + ah, by + bh)
    if gap_x <= 0 and gap_y <= 0:
        smaller = min(aw * ah, bw * bh)
        if smaller <= 0:
            return (0.0, 0.0)
        return ((-gap_x) * (-gap_y) / smaller, 0.0)
    return (0.0, math.hypot(max(gap_x, 0.0), max(gap_y, 0.0)))


def _sample_frames(first: dict[str, Any], second: dict[str, Any], start: int, end: int) -> list[int]:
    if not first.get("motion") and not second.get("motion"):
        return [start]
    frames = list(range(start, end, LAYOUT_MOTION_SAMPLE_STEP))
    if end - 1 not in frames:
        frames.append(end - 1)
    return frames


def _best_content_overlap(overlay: dict[str, Any], target: Box, frame: int, minimum_ratio: float):
    best = None
    for polygon in _content_at(overlay, frame):
        overlap = polygon_overlap(polygon, target)
        if overlap is None:
            continue
        area, rectangle = overlap
        ratio = min(1.0, area / min(polygon_area(polygon), target[2] * target[3]))
        if ratio >= minimum_ratio and (best is None or area > best[0]):
            best = (area, ratio, rectangle)
    return best


def layout_conflicts(
    elements: list[dict[str, Any]],
    minimum_ratio: float,
    near_px: float = 0.0,
) -> list[dict[str, Any]]:
    """两两检查同时在画面上的元素:重叠报 `overlap`,没碰上但间距 ≤ near_px 报 `near`。"""
    conflicts: list[dict[str, Any]] = []
    for index, first in enumerate(elements):
        for second in elements[index + 1:]:
            start = max(first["startFrame"], second["startFrame"])
            end = min(first["endFrame"], second["endFrame"])
            if end <= start:
                continue
            caption, overlay = (first, second) if first["kind"] == "caption" else (second, first)
            caption_pair = caption["kind"] == "caption" and overlay.get("captionContent")
            if caption_pair:
                best = None
                best_frame = start
                for frame in _sample_frames(first, second, start, end):
                    overlap = _best_content_overlap(overlay, _element_box_at(caption, frame), frame, minimum_ratio)
                    if overlap is not None and (best is None or overlap[0] > best[0]):
                        best, best_frame = overlap, frame
                if best is not None:
                    area, ratio, rectangle = best
                    conflicts.append({
                        "type": "CAPTION_OVERLAP", "severity": "warning",
                        "clipId": overlay["id"], "captionId": caption["id"],
                        "overlapRatio": round(ratio, 3), "overlapAreaPx": round(area, 1),
                        "overlapRect": _round_box(rectangle),
                        "frames": {"start": start, "end": end}, "atFrame": best_frame,
                        "elements": [{**{k: element[k] for k in ("kind", "id", "label")},
                                      "box": _element_box_at(element, best_frame)} for element in (overlay, caption)],
                        "remediation": "Move, shrink or trim the overlay; alternatively reposition the caption and recheck.",
                    })
                    continue
                if overlay.get("regions"):
                    continue
            best_ratio, best_frame, best_gap = 0.0, start, math.inf
            boxes = (first["box"], second["box"])
            for frame in _sample_frames(first, second, start, end):
                a = _element_box_at(first, frame)
                b = _element_box_at(second, frame)
                ratio, gap = _box_overlap(a, b)
                if ratio > best_ratio or (ratio == best_ratio and gap < best_gap):
                    best_ratio, best_frame, best_gap, boxes = ratio, frame, gap, (a, b)
            # 满屏不透明卡/形状色块盖住别的元素通常是设计意图(黑场卡就是要
            # 遮住画面,色块就是给文字垫底),降级为提示而不是问题。
            intentional = first.get("opaque") or second.get("opaque")
            if best_ratio > 0:
                if caption_pair or best_ratio < minimum_ratio:
                    continue
                conflicts.append({
                    "type": "overlap",
                    "severity": "notice" if intentional else "warning",
                    "overlapRatio": round(best_ratio, 3),
                    "frames": {"start": start, "end": end},
                    "atFrame": best_frame,
                    "elements": [
                        {**{k: first[k] for k in ("kind", "id", "label")}, "box": boxes[0]},
                        {**{k: second[k] for k in ("kind", "id", "label")}, "box": boxes[1]},
                    ],
                })
            elif near_px > 0 and best_gap <= near_px and not intentional:
                conflicts.append({
                    "type": "near",
                    "severity": "notice",
                    "overlapRatio": 0.0,
                    "gapPx": round(best_gap, 1),
                    "frames": {"start": start, "end": end},
                    "atFrame": best_frame,
                    "elements": [
                        {**{k: first[k] for k in ("kind", "id", "label")}, "box": boxes[0]},
                        {**{k: second[k] for k in ("kind", "id", "label")}, "box": boxes[1]},
                    ],
                })
    conflicts.sort(key=lambda item: (-item["overlapRatio"], item["frames"]["start"]))
    return conflicts


def _uncovered_frames(start: int, end: int, covered: list[tuple[int, int]]) -> Iterable[tuple[int, int]]:
    for left, right in sorted(covered):
        if right <= start or left >= end:
            continue
        if left > start:
            yield start, left
        start = max(start, right)
    if start < end:
        yield start, end


def portrait_caption_zone(elements: list[dict[str, Any]], conflicts: list[dict[str, Any]],
                          width: float, height: float) -> list[dict[str, Any]]:
    if height <= width:
        return []
    band = (0.0, height * 0.70, width, height * 0.14)
    covered: dict[str, list[tuple[int, int]]] = {}
    for conflict in conflicts:
        if conflict["type"] == "CAPTION_OVERLAP":
            frames = conflict["frames"]
            covered.setdefault(conflict["clipId"], []).append((frames["start"], frames["end"]))
    issues = []
    for element in elements:
        if not element.get("captionContent"):
            continue
        for start, end in _uncovered_frames(element["startFrame"], element["endFrame"], covered.get(element["id"], [])):
            for frame in _sample_frames(element, {}, start, end):
                hit = _best_content_overlap(element, band, frame, 0.0)
                if hit is None:
                    continue
                issues.append({
                    "type": "PORTRAIT_CAPTION_SAFE_ZONE", "severity": "notice", "clipId": element["id"],
                    "frames": {"start": start, "end": end}, "atFrame": frame,
                    "element": {**{k: element[k] for k in ("kind", "id", "label")}, "box": _element_box_at(element, frame)},
                    "overlapRect": _round_box(hit[2]),
                    "remediation": "Keep substantive overlay content outside 70–84% of the portrait canvas height.",
                })
                break
    return issues


def layout_safe_zone(
    elements: list[dict[str, Any]], width: float, height: float
) -> list[dict[str, Any]]:
    """竖屏画布上闯进抖音/TikTok 信息流遮挡区的元素;横屏/方形返回空。"""
    if height <= width:
        return []
    top = height * LAYOUT_SAFE_ZONE_TOP
    bottom = height * (1.0 - LAYOUT_SAFE_ZONE_BOTTOM)
    right = width * (1.0 - LAYOUT_SAFE_ZONE_RIGHT)
    issues: list[dict[str, Any]] = []
    for element in elements:
        if element.get("opaque"):
            continue
        x, y, w, h = element["box"]
        intrusions: dict[str, float] = {}
        if y < top:
            intrusions["top"] = round(min(top - y, h), 1)
        if y + h > bottom:
            intrusions["bottom"] = round(min(y + h - bottom, h), 1)
        if x + w > right:
            intrusions["right"] = round(min(x + w - right, w), 1)
        if not intrusions:
            continue
        issues.append({
            "severity": "notice",
            "zones": intrusions,
            "frames": {"start": element["startFrame"], "end": element["endFrame"]},
            "element": {k: element[k] for k in ("kind", "id", "label", "box")},
        })
    return _merge_same_cause_safe_zone(issues)


def _merge_same_cause_safe_zone(issues: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """同一样式的整轨字幕落点相同,闯遮挡区是一个原因,合成一条报,别刷屏。

    合并键是 (kind, 盒子竖直位置与高度, 闯入的边与深度);合并后的条目带 `count`、
    覆盖的帧区间并集和前几个 id,盒子取第一条的。
    """
    groups: dict[tuple, dict[str, Any]] = {}
    for issue in issues:
        element = issue["element"]
        if element["kind"] != "caption":
            groups[("single", element["id"])] = issue
            continue
        x, y, w, h = element["box"]
        key = ("caption", round(y), round(h), tuple(sorted(issue["zones"].items())))
        group = groups.get(key)
        if group is None:
            issue["count"] = 1
            issue["elementIds"] = [element["id"]]
            issue["_ids"] = {str(element["id"])}
            groups[key] = issue
            continue
        group["count"] += 1
        group["_ids"].add(str(element["id"]))
        if len(group["elementIds"]) < 3:
            group["elementIds"].append(element["id"])
        group["frames"] = {
            "start": min(group["frames"]["start"], issue["frames"]["start"]),
            "end": max(group["frames"]["end"], issue["frames"]["end"]),
        }
    merged = list(groups.values())
    for issue in merged:
        if issue.get("count", 1) > 1:
            issue["element"]["label"] = f"{issue['count']} 条字幕(同一落点)"
    return merged


def _round_box(box: tuple[float, float, float, float]) -> dict[str, float]:
    x, y, w, h = box
    return {"x": round(x, 1), "y": round(y, 1), "width": round(w, 1), "height": round(h, 1)}


def layout_coverage(sequence: dict[str, Any]) -> list[dict[str, Any]]:
    """视频轨黑场检查:视频类轨道的 clip 区间并起来必须盖满 [0, duration)。

    盖不住的地方观众看到的就是黑屏,三种形态都报 warning:
    - opening: 第 0 帧没画面——开屏黑闪,封面抽出来就是黑的;
    - middle: 中段断档;
    - tail: 画面结束了序列还没完——结尾黑屏,BGM/旁白还在响。
    导出侧一直看得见这件事(渲染路由的 fallbackReason 就写着 video lane
    does not cover the whole timeline),但此前没有任何检查把它报给剪的人。
    """
    duration = sequence.get("duration")
    if not isinstance(duration, dict):
        return []
    try:
        total = Fraction(int(duration["num"]), int(duration["den"]))
    except (KeyError, ValueError, ZeroDivisionError, TypeError):
        return []
    if total <= 0:
        return []
    frame_rate = sequence.get("frameRate") or {}
    try:
        fps = Fraction(int(frame_rate["num"]), int(frame_rate["den"]))
    except (KeyError, ValueError, ZeroDivisionError, TypeError):
        fps = Fraction(30)

    def _ranges(kind: str) -> list[tuple[Fraction, Fraction]]:
        spans: list[tuple[Fraction, Fraction]] = []
        for track in sequence.get("tracks") or []:
            if track.get("kind") != kind or track.get("muted"):
                continue
            for clip in track.get("clips") or []:
                if not clip.get("enabled", True):
                    continue
                tl = clip.get("timelineRange") or {}
                try:
                    start = Fraction(int(tl["start"]["num"]), int(tl["start"]["den"]))
                    end = Fraction(int(tl["end"]["num"]), int(tl["end"]["den"]))
                except (KeyError, ValueError, ZeroDivisionError, TypeError):
                    continue
                if end > start:
                    spans.append((start, end))
        spans.sort()
        merged: list[tuple[Fraction, Fraction]] = []
        for start, end in spans:
            if merged and start <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], end))
            else:
                merged.append((start, end))
        return merged

    video = _ranges("video")
    audio = _ranges("audio")
    gaps: list[tuple[Fraction, Fraction]] = []
    cursor = Fraction(0)
    for start, end in video:
        if start > cursor:
            gaps.append((cursor, min(start, total)))
        cursor = max(cursor, end)
        if cursor >= total:
            break
    if cursor < total:
        gaps.append((cursor, total))

    issues: list[dict[str, Any]] = []
    for start, end in gaps:
        if end <= start:
            continue
        where = "opening" if start == 0 else ("tail" if end == total else "middle")
        end_frames = end * fps
        issues.append({
            "type": "blackGap",
            "severity": "warning",
            "where": where,
            "frames": {"start": int(start * fps), "end": -((-end_frames.numerator) // end_frames.denominator)},
            "seconds": round(float(end - start), 3),
            # 黑屏期间还有没有声音在放:有的话观众必然察觉(画面停了 BGM 还响)。
            "audioDuringGap": any(a_start < end and a_end > start for a_start, a_end in audio),
        })
    return issues


def _layout_near_px(sequence: dict[str, Any], explicit: float | None) -> float:
    if explicit is not None:
        return max(0.0, explicit)
    canvas = sequence.get("canvas") or {}
    short_edge = min(float(canvas.get("width") or 1080), float(canvas.get("height") or 1920))
    return round(short_edge * 0.015, 1)


def layout_report(
    project: dict[str, Any],
    sequence: dict[str, Any],
    *,
    minimum_ratio: float = 0.12,
    near_px: float | None = None,
    at_frame: int | None = None,
    frame_range: tuple[int, int] | None = None,
    involving: set[str] | None = None,
    image_bounds: Callable[[str], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """`oc layout check` 的报告;`involving` 只留牵涉到这些元素 id 的条目。

    Sampling and reported collision intervals are clipped to the requested scan.
    """
    canvas = sequence.get("canvas") or {}
    width = float(canvas.get("width") or 0) or 1080.0
    height = float(canvas.get("height") or 0) or 1920.0
    scan = (at_frame, at_frame + 1) if at_frame is not None else frame_range
    unverified: list[dict[str, Any]] = []
    elements = collect_layout_elements(project, sequence, image_bounds=image_bounds, scan=scan, unverified=unverified)
    if scan:
        elements = [{**item, "startFrame": max(item["startFrame"], scan[0]), "endFrame": min(item["endFrame"], scan[1])}
                    for item in elements if item["startFrame"] < scan[1] and item["endFrame"] > scan[0]]
        for item in elements:
            item["box"] = _element_box_at(item, item["startFrame"])
    conflicts = layout_conflicts(elements, minimum_ratio, _layout_near_px(sequence, near_px))
    safe_zone = layout_safe_zone(elements, width, height) + portrait_caption_zone(elements, conflicts, width, height)
    # 黑场检查只在整片检查里报:剪到一半的时间线天然尾部没铺满,
    # 写入附带的窄检查(involving)报它只会刷屏。
    coverage: list[dict[str, Any]] = []
    if involving is None:
        coverage = layout_coverage(sequence)
        if at_frame is not None:
            coverage = [
                item for item in coverage
                if item["frames"]["start"] <= at_frame < item["frames"]["end"]
            ]
        if frame_range is not None:
            range_start, range_end = frame_range
            coverage = [
                item for item in coverage
                if item["frames"]["start"] < range_end and item["frames"]["end"] > range_start
            ]
    if involving is not None:
        unverified = [issue for issue in unverified if issue.get("clipId") in involving]
        conflicts = [
            item for item in conflicts
            if any(str(element["id"]) in involving for element in item["elements"])
        ]
        safe_zone = [
            item for item in safe_zone
            if str(item["element"]["id"]) in involving
            or not involving.isdisjoint(item.get("_ids", set()))
        ]
    for conflict in conflicts:
        for element in conflict["elements"]:
            element["box"] = _round_box(element["box"])
    for issue in safe_zone:
        issue.pop("_ids", None)
        issue["element"]["box"] = _round_box(issue["element"]["box"])
    return {
        "sequenceId": sequence.get("id"),
        "canvas": canvas,
        "checkedElements": len(elements),
        "conflicts": conflicts,
        "coverage": coverage,
        "safeZone": safe_zone,
        "unverified": unverified,
        # 不叫 warnings:信封会把裸字典的 `warnings` 键当 CLI 警告列表挪到顶层。
        "warningCount": sum(1 for item in conflicts if item["severity"] == "warning") + len(coverage),
        "noticeCount": sum(1 for item in conflicts if item["severity"] == "notice") + len(safe_zone),
    }


def render_layout_human(report: dict[str, Any]) -> str:
    lines = [f"Layout {report['sequenceId']}: {report['checkedElements']} elements; "
             f"{report['warningCount']} warnings, {report['noticeCount']} notices"]
    for issue in report["conflicts"] + report["safeZone"] + report["coverage"]:
        frames = issue["frames"]
        ids = [entry["id"] for entry in issue.get("elements", [issue.get("element", {})]) if "id" in entry]
        kind = issue.get("type") or "PLATFORM_SAFE_ZONE"
        rect = issue.get("overlapRect")
        position = (f"; overlap x={rect['x']}, y={rect['y']}, w={rect['width']}, h={rect['height']} px" if rect else "")
        lines.append(f"{kind} [{frames['start']}, {frames['end']}) {' / '.join(map(str, ids))}{position}")
        if issue.get("remediation"):
            lines.append(f"  {issue['remediation']}")
    lines.extend(f"UNVERIFIED {item['clipId']}: {item['reason']}" for item in report["unverified"])
    return "\n".join(lines)


def attach_layout_check(
    client: "Client",
    project_id: str,
    response: dict[str, Any],
    element_ids: Iterable[str],
) -> dict[str, Any]:
    """写入成功后就地做一次占位检查,只报牵涉到刚写的元素的条目,挂到 data.layout。

    检查失败不能让已经成功的写入看起来失败:异常折成 data.layout.error。
    """
    data = response.get("data")
    if not isinstance(data, dict):
        return response
    ids = {str(item) for item in element_ids if item}
    if not ids:
        return response
    try:
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence_id = str(data.get("sequenceId") or default_sequence_id(project))
        sequence = require_sequence(project, sequence_id)
        report = layout_report(project, sequence, involving=ids)
        data["layout"] = {
            "conflicts": report["conflicts"],
            "safeZone": report["safeZone"],
            "warningCount": report["warningCount"],
            "noticeCount": report["noticeCount"],
        }
    except Exception as error:  # noqa: BLE001 - 检查是附赠的,写入已经成功
        data["layout"] = {"error": f"{type(error).__name__}: {error}"}
    return response


# ------------------------------------------------------------- project source
#
# 项目源码:工程的一份人类可读投影,给人和 Agent 当"整体可见 + 可 diff"的面。
# 它是 Project 的**刻意子集**——只放"人会想手写的东西"(镜头顺序、时长、
# 文本、预设槽位),不放引擎解算出来的东西(transform 矩阵、编译后的 DOM、
# keyframe 曲线)。文件表达不了的一律以 @opaque 引用出现,不展开也不丢弃。
#
# 真值仍然只有 Event Store:导出是单向投影,导入必须收敛为一个 CommandBatch。

SOURCE_SCHEMA = "orangecut/source@0.1"
OPAQUE_PREFIX = "@opaque:"



def _rational_of(value: Any) -> Fraction:
    if isinstance(value, dict) and "num" in value and "den" in value:
        return Fraction(int(value["num"]), int(value["den"]))
    if isinstance(value, (int, float)):
        return Fraction(value).limit_denominator(1000000)
    return Fraction(0)


def _seconds_text(value: Any) -> str:
    """Rational → 十进制秒字符串。人读的是秒,不是 {num, den}。"""
    amount = Fraction(0)
    if isinstance(value, dict) and "num" in value and "den" in value:
        amount = Fraction(int(value["num"]), int(value["den"]))
    elif isinstance(value, (int, float)):
        amount = Fraction(value).limit_denominator(1000000)
    text = f"{float(amount):.6f}".rstrip("0").rstrip(".")
    return text or "0"


def _seconds_value(text: Any) -> Fraction:
    try:
        return Fraction(str(text).strip())
    except (TypeError, ValueError, ZeroDivisionError) as error:
        raise CliFailure(
            "SOURCE_TIME_INVALID",
            "validation",
            f"time value {text!r} is not a decimal number of seconds",
            remediation='write seconds like "4.25"',
            exit_code=EXIT_INVALID_INPUT,
        ) from error


def _opaque_digest(payload: Any) -> str:
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return OPAQUE_PREFIX + hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


def project_source_document(
    project: dict[str, Any], sequence_id: str | None = None
) -> dict[str, Any]:
    """当前工程 → 源码文档(纯数据,便于同时输出 YAML 与 JSON)。"""
    sequence_id = sequence_id or default_sequence_id(project)
    sequence = require_sequence(project, sequence_id)
    canvas = sequence.get("canvas") or {}
    rate = sequence_frame_rate_from(project, sequence_id)
    components = {str(item.get("id")): item for item in project.get("components", [])}
    used_components: list[str] = []

    def note_component(component_id: str) -> None:
        if component_id not in used_components:
            used_components.append(component_id)

    project_entry: dict[str, Any] = {
        "id": project.get("id"),
        "title": (project.get("settings") or {}).get("title", ""),
    }
    if project.get("extensions"):
        project_entry["ext"] = _opaque_digest(project["extensions"])
    canvas_entry: dict[str, Any] = {
        "size": f"{canvas.get('width')}x{canvas.get('height')}",
        "fps": str(rate) if rate.denominator != 1 else str(rate.numerator),
    }
    # 画布模式决定画布跟不跟随首个素材(ADR0042);丢了会改变工程行为。
    if sequence.get("canvasMode"):
        canvas_entry["mode"] = sequence["canvasMode"]
    sequence_entry: dict[str, Any] = {"id": sequence_id, "name": sequence.get("name", "")}
    if sequence.get("colorGrading"):
        # 整片调色是已发布功能,不进文件的话调过色的工程重建后会掉色。
        sequence_entry["grade"] = _opaque_digest(sequence["colorGrading"])
    if sequence.get("audio"):
        sequence_entry["audio"] = _opaque_digest(sequence["audio"])
    if sequence.get("markers"):
        sequence_entry["markers"] = _opaque_digest(sequence["markers"])
    if sequence.get("extensions"):
        sequence_entry["ext"] = _opaque_digest(sequence["extensions"])
    document: dict[str, Any] = {
        "schema": SOURCE_SCHEMA,
        "project": project_entry,
        "canvas": canvas_entry,
        "sequence": sequence_entry,
        "assets": [],
        "tracks": [],
        "components": [],
    }

    for asset in project.get("assets", []):
        entry: dict[str, Any] = {
            "id": asset.get("id"),
            "kind": asset.get("kind"),
            "name": asset.get("name"),
        }
        fingerprint = asset.get("fingerprint") or {}
        if fingerprint.get("value"):
            entry["fingerprint"] = f"{fingerprint.get('algorithm', 'sha256')}-{fingerprint['value']}"
        locator = asset.get("locator") or {}
        if locator.get("path"):
            # 导入需要真能找到文件;bundled 资产由服务自带,不写路径。
            entry["path"] = locator["path"]
            entry["locator"] = locator.get("kind", "project-relative")
        document["assets"].append(entry)

    for track in sorted(sequence.get("tracks", []), key=lambda item: item.get("order", 0)):
        track_entry: dict[str, Any] = {
            "id": track.get("id"),
            "kind": track.get("kind"),
            "order": str(track.get("order", 0)),
        }
        for flag in ("muted", "locked"):
            if track.get(flag):
                track_entry[flag] = "true"
        if track.get("role"):
            track_entry["role"] = track["role"]
        # extensions 是别人写进来的带 namespace 的数据(音画联动、轨道来源、
        # 音效关联…),项目模型要求"未知 extension 保留"。文件不展开它们,
        # 但必须带着引用,否则重建出来的工程会悄悄少掉这些不变量。
        if track.get("extensions"):
            track_entry["ext"] = _opaque_digest(track["extensions"])
        clips: list[dict[str, Any]] = []
        for clip in track.get("clips", []):
            source = clip.get("source") or {}
            timeline = clip.get("timelineRange") or {}
            item: dict[str, Any] = {"id": clip.get("id")}
            if source.get("type") == "component" or source.get("componentId"):
                component_id = str(source.get("componentId"))
                note_component(component_id)
                item["source"] = {"component": component_id}
            elif source.get("assetId"):
                asset_source: dict[str, Any] = {"asset": source["assetId"]}
                source_range = clip.get("sourceRange") or {}
                if source_range:
                    asset_source["in"] = _seconds_text(source_range.get("start"))
                    asset_source["out"] = _seconds_text(source_range.get("end"))
                item["source"] = asset_source
            else:
                item["source"] = {"sequence": source.get("sequenceId")}
            item["at"] = _seconds_text(timeline.get("start"))
            span = _rational_of(timeline.get("end")) - _rational_of(timeline.get("start"))
            item["duration"] = _seconds_text({"num": str(span.numerator), "den": str(span.denominator)})
            if clip.get("enabled") is False:
                item["enabled"] = "false"
            for opaque_field in ("transform", "motion", "playback", "visualFit"):
                value = clip.get(opaque_field)
                if value in (None, {}, []):
                    continue
                if opaque_field == "playback" and _is_default_playback(value):
                    continue
                item[opaque_field] = _opaque_digest(value)
            if clip.get("effects"):
                item["effects"] = _opaque_digest(clip["effects"])
            if clip.get("extensions"):
                item["ext"] = _opaque_digest(clip["extensions"])
            clips.append(item)
        if clips:
            track_entry["clips"] = clips
        captions: list[dict[str, Any]] = []
        for caption in track.get("captions", []):
            timeline = caption.get("timelineRange") or {}
            entry = {
                "id": caption.get("id"),
                "at": _seconds_text(timeline.get("start")),
                "end": _seconds_text(timeline.get("end")),
                "text": caption.get("text", ""),
            }
            if caption.get("speaker"):
                entry["speaker"] = caption["speaker"]
            if caption.get("emphases"):
                entry["emphases"] = [
                    {"text": item.get("text", ""), "color": item.get("color", "")}
                    for item in caption["emphases"]
                ]
            if caption.get("styleRef"):
                note_component(str(caption["styleRef"]))
                entry["style"] = caption["styleRef"]
            if caption.get("tokens"):
                entry["tokens"] = _opaque_digest(caption["tokens"])
            if caption.get("motion"):
                entry["motion"] = _opaque_digest(caption["motion"])
            if caption.get("extensions"):
                entry["ext"] = _opaque_digest(caption["extensions"])
            captions.append(entry)
        if captions:
            track_entry["captions"] = captions
        document["tracks"].append(track_entry)

    for component_id in used_components:
        component = components.get(component_id)
        if component is None:
            continue
        entry = {"id": component_id, "type": component.get("componentType")}
        properties = component.get("properties") or {}
        preset_id = (((properties.get("root") or {}).get("attributes")) or {}).get(
            "data-form-preset"
        )
        if preset_id:
            entry["preset"] = preset_id
        # 组件属性是编译产物(DOM/CSS/样式解算),不展开进文件。
        entry["properties"] = _opaque_digest(properties)
        document["components"].append(entry)
    return document


def _is_default_playback(playback: dict[str, Any]) -> bool:
    rate = playback.get("rate")
    normal_rate = (
        isinstance(rate, dict) and int(rate.get("num", 1)) == int(rate.get("den", 1))
    ) or rate is None
    return normal_rate and not playback.get("reverse") and not playback.get("freeze")


# 受控子集的 YAML 读写。CLI 是零依赖契约(pyproject 的 dependencies 为空),
# 不能引 pyyaml;而项目源码就是给人手写的,退回 JSON 会毁掉这件事的意义。
# 因此:导出用自己的 emitter(输出形状完全受控);导入用一个只认块映射、块
# 序列、流式 {}/[]、引号/裸标量与块字面量的 parser,遇到 anchor、别名、多
# 文档等不支持的语法**明确报错并指出行号**,而不是猜。


def _yaml_scalar(value: Any) -> str:
    text = "" if value is None else str(value)
    if text == "":
        return '""'
    needs_quotes = (
        text.strip() != text
        or any(ch in text for ch in ":#{}[],&*!|>'\"%@`")
        or text[0] in "-?"
        or text.lower() in {"true", "false", "null", "yes", "no", "on", "off", "~"}
        or re.match(r"^-?\d+(\.\d+)?$", text) is not None
    )
    if not needs_quotes:
        return text
    escaped = text.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    return f'"{escaped}"'


def dump_source_yaml(document: dict[str, Any]) -> str:
    lines: list[str] = []

    def emit_mapping(mapping: dict[str, Any], indent: int, first_prefix: str = "") -> None:
        prefix = first_prefix
        for key, value in mapping.items():
            pad = " " * (indent - len(prefix))
            if isinstance(value, dict) and value:
                lines.append(f"{pad}{prefix}{key}:")
                emit_mapping(value, indent + 2)
            elif isinstance(value, list) and value:
                lines.append(f"{pad}{prefix}{key}:")
                emit_list(value, indent + 2)
            elif isinstance(value, dict):
                lines.append(f"{pad}{prefix}{key}: {{}}")
            elif isinstance(value, list):
                lines.append(f"{pad}{prefix}{key}: []")
            else:
                lines.append(f"{pad}{prefix}{key}: {_yaml_scalar(value)}")
            prefix = ""

    def emit_list(items: list[Any], indent: int) -> None:
        pad = " " * indent
        for item in items:
            if isinstance(item, dict) and item:
                # 列表项的后续字段与 `- ` 之后的列对齐,这样它们仍属于同一项。
                emit_mapping(item, indent + 2, "- ")
            elif isinstance(item, list) and item:
                lines.append(f"{pad}-")
                emit_list(item, indent + 2)
            else:
                lines.append(f"{pad}- {_yaml_scalar(item)}")

    emit_mapping(document, 0)
    return "\n".join(lines) + "\n"


def _yaml_unquote(text: str, line_number: int) -> Any:
    text = text.strip()
    if text == "" or text == "~" or text == "null":
        return None
    if text.startswith('"') and text.endswith('"') and len(text) >= 2:
        body = text[1:-1]
        return body.replace('\\n', "\n").replace('\\"', '"').replace("\\\\", "\\")
    if text.startswith("'") and text.endswith("'") and len(text) >= 2:
        return text[1:-1].replace("''", "'")
    for unsupported, name in (("&", "anchor"), ("*", "alias"), ("<<", "merge key")):
        if text.startswith(unsupported):
            raise CliFailure(
                "SOURCE_YAML_UNSUPPORTED",
                "validation",
                f"line {line_number}: this file uses a YAML {name}, which the importer does not read",
                remediation="write the value out in full instead of referencing another node",
                exit_code=EXIT_INVALID_INPUT,
            )
    return text


def _yaml_flow(text: str, line_number: int) -> Any:
    """流式 {a: b} / [a, b];只允许一层嵌套的标量,足够表达 source 与 emphases。"""
    body = text.strip()
    if body.startswith("{") and body.endswith("}"):
        result: dict[str, Any] = {}
        inner = body[1:-1].strip()
        if inner == "":
            return result
        for part in _split_flow(inner, line_number):
            key, separator, value = part.partition(":")
            if not separator:
                raise CliFailure(
                    "SOURCE_YAML_INVALID",
                    "validation",
                    f"line {line_number}: {part.strip()!r} inside {{}} is not key: value",
                    exit_code=EXIT_INVALID_INPUT,
                )
            result[key.strip()] = _yaml_unquote(value, line_number)
        return result
    if body.startswith("[") and body.endswith("]"):
        inner = body[1:-1].strip()
        if inner == "":
            return []
        return [_yaml_unquote(part, line_number) for part in _split_flow(inner, line_number)]
    return None


def _split_flow(text: str, line_number: int) -> list[str]:
    parts: list[str] = []
    depth = 0
    quote: str | None = None
    current = ""
    for char in text:
        if quote is not None:
            current += char
            if char == quote:
                quote = None
            continue
        if char in "\"'":
            quote = char
            current += char
            continue
        if char in "{[":
            depth += 1
        elif char in "}]":
            depth -= 1
        if char == "," and depth == 0:
            parts.append(current)
            current = ""
            continue
        current += char
    if current.strip():
        parts.append(current)
    return parts


def parse_source_yaml(text: str) -> dict[str, Any]:
    """块映射/块序列/流式集合/块字面量;其余 YAML 语法明确拒绝而不是猜。"""
    entries = _yaml_entries(text)
    value, index = _yaml_block(entries, 0, -1)
    if index != len(entries):
        raise CliFailure(
            "SOURCE_YAML_INVALID",
            "validation",
            f"line {entries[index][2]}: unexpected indentation",
            exit_code=EXIT_INVALID_INPUT,
        )
    if not isinstance(value, dict):
        raise CliFailure(
            "SOURCE_YAML_INVALID",
            "validation",
            "the source document must start as a mapping",
            exit_code=EXIT_INVALID_INPUT,
        )
    return value


def _yaml_entries(text: str) -> list[tuple[int, str, int]]:
    raw_lines = text.splitlines()
    entries: list[tuple[int, str, int]] = []
    index = 0
    while index < len(raw_lines):
        raw = raw_lines[index]
        stripped = raw.strip()
        if stripped == "" or stripped.startswith("#"):
            index += 1
            continue
        if stripped.startswith("---") or stripped.startswith("..."):
            raise CliFailure(
                "SOURCE_YAML_UNSUPPORTED",
                "validation",
                f"line {index + 1}: multi-document YAML is not read by the importer",
                exit_code=EXIT_INVALID_INPUT,
            )
        indent = len(raw) - len(raw.lstrip(" "))
        if stripped.endswith(": |") or stripped.endswith(": |-"):
            key = stripped.split(":", 1)[0]
            block: list[str] = []
            index += 1
            while index < len(raw_lines):
                follow = raw_lines[index]
                follow_indent = len(follow) - len(follow.lstrip(" "))
                if follow.strip() != "" and follow_indent <= indent:
                    break
                block.append(follow[indent + 2:] if len(follow) > indent + 2 else "")
                index += 1
            entries.append((indent, f"{key}: {_yaml_scalar(chr(10).join(block).rstrip())}", index))
            continue
        entries.append((indent, stripped, index + 1))
        index += 1
    return entries


def _yaml_block(
    entries: list[tuple[int, str, int]], index: int, parent_indent: int
) -> tuple[Any, int]:
    if index >= len(entries):
        return (None, index)
    indent = entries[index][0]
    if indent <= parent_indent:
        return (None, index)
    if entries[index][1].startswith("- "):
        items: list[Any] = []
        while index < len(entries) and entries[index][0] == indent and entries[index][1].startswith("- "):
            body = entries[index][1][2:].strip()
            line_number = entries[index][2]
            if body.startswith("{") or body.startswith("["):
                items.append(_yaml_flow(body, line_number))
                index += 1
                continue
            key, separator, value = body.partition(":")
            if not separator:
                items.append(_yaml_unquote(body, line_number))
                index += 1
                continue
            # `- key: value` 的后续同层字段缩进两格,与列表标记对齐。
            item: dict[str, Any] = {}
            index = _yaml_pair(entries, index, item, key.strip(), value, indent + 2, inline=True)
            while index < len(entries) and entries[index][0] == indent + 2 and not entries[index][1].startswith("- "):
                key2, separator2, value2 = entries[index][1].partition(":")
                if not separator2:
                    raise CliFailure(
                        "SOURCE_YAML_INVALID",
                        "validation",
                        f"line {entries[index][2]}: {entries[index][1]!r} is not `key: value`",
                        exit_code=EXIT_INVALID_INPUT,
                    )
                index = _yaml_pair(entries, index, item, key2.strip(), value2, indent + 2, inline=True)
            items.append(item)
        return (items, index)
    mapping: dict[str, Any] = {}
    while index < len(entries) and entries[index][0] == indent and not entries[index][1].startswith("- "):
        key, separator, value = entries[index][1].partition(":")
        if not separator:
            raise CliFailure(
                "SOURCE_YAML_INVALID",
                "validation",
                f"line {entries[index][2]}: {entries[index][1]!r} is neither `key: value` nor a `- ` item",
                exit_code=EXIT_INVALID_INPUT,
            )
        index = _yaml_pair(entries, index, mapping, key.strip(), value, indent, inline=False)
    return (mapping, index)


def _yaml_pair(
    entries: list[tuple[int, str, int]],
    index: int,
    container: dict[str, Any],
    key: str,
    raw_value: str,
    indent: int,
    inline: bool,
) -> int:
    line_number = entries[index][2]
    value = raw_value.strip()
    if value.startswith("{") or value.startswith("["):
        container[key] = _yaml_flow(value, line_number)
        return index + 1
    if value != "":
        container[key] = _yaml_unquote(value, line_number)
        return index + 1
    nested, next_index = _yaml_block(entries, index + 1, indent)
    container[key] = {} if nested is None else nested
    return next_index


# 导出同时写一份 sidecar:可读文件里的 @opaque 摘要是它的索引键。
# 分工——人和 Agent 编辑可读文件;引擎解算出来的东西(编译后的组件属性、
# transform 矩阵、keyframe、probe)放 sidecar,原样保留、不进人的视野。
# 两个文件合起来才是无损的工程包,单独的可读文件是"整体可见"的那一面。

SOURCE_SIDECAR_SUFFIX = ".opaque.json"


def source_sidecar_path(source_path: Path) -> Path:
    return source_path.with_suffix(source_path.suffix + SOURCE_SIDECAR_SUFFIX)


def project_source_bundle(
    project: dict[str, Any], sequence_id: str | None = None
) -> tuple[dict[str, Any], dict[str, Any]]:
    """(可读文档, sidecar);sidecar 收录文档里出现过的每个 @opaque 摘要的原值。"""
    document = project_source_document(project, sequence_id)
    sidecar: dict[str, Any] = {"schema": SOURCE_SCHEMA, "opaque": {}, "assets": {}}
    components = {str(item.get("id")): item for item in project.get("components", [])}
    sequence = require_sequence(project, sequence_id or default_sequence_id(project))

    def keep(payload: Any) -> None:
        sidecar["opaque"][_opaque_digest(payload)] = payload

    if project.get("extensions"):
        keep(project["extensions"])
    for field in ("colorGrading", "audio", "markers", "extensions"):
        if sequence.get(field):
            keep(sequence[field])

    for track in sequence.get("tracks", []):
        if track.get("extensions"):
            keep(track["extensions"])
        for clip in track.get("clips", []):
            for field in ("transform", "motion", "playback", "visualFit", "effects", "extensions"):
                value = clip.get(field)
                if value in (None, {}, []):
                    continue
                keep(value)
        for caption in track.get("captions", []):
            for field in ("tokens", "motion", "extensions"):
                if caption.get(field):
                    keep(caption[field])
    for component in components.values():
        keep(component.get("properties") or {})
        sidecar["assets"].setdefault("components", {})[str(component.get("id"))] = {
            "componentType": component.get("componentType"),
            "capabilityRequirements": component.get("capabilityRequirements", []),
            "extensions": component.get("extensions", {}),
        }
    for asset in project.get("assets", []):
        sidecar["assets"][str(asset.get("id"))] = {
            "probe": asset.get("probe"),
            "locator": asset.get("locator"),
            "extensions": asset.get("extensions", {}),
        }
    return (document, sidecar)


def _resolve_opaque(value: Any, sidecar: dict[str, Any], field: str) -> Any:
    if not isinstance(value, str) or not value.startswith(OPAQUE_PREFIX):
        return value
    payload = (sidecar.get("opaque") or {}).get(value)
    if payload is None:
        raise CliFailure(
            "SOURCE_OPAQUE_MISSING",
            "validation",
            f"{field} references {value}, which the sidecar does not carry",
            remediation="keep the .opaque.json sidecar next to the source file",
            exit_code=EXIT_INVALID_INPUT,
        )
    return payload


def supported_command_types(capabilities: Any) -> set[str]:
    """capabilities 里服务自报的语义命令名。拿不到就返回空集,调用方据此跳过预检。"""
    entries = (capabilities or {}).get("commands") if isinstance(capabilities, dict) else None
    if not isinstance(entries, list):
        return set()
    return {
        entry["type"]
        for entry in entries
        if isinstance(entry, dict) and isinstance(entry.get("type"), str)
    }


def assert_commands_supported(
    commands: list[dict[str, Any]],
    capabilities: Any,
    *,
    context: str,
    orphan_project_id: str | None = None,
) -> None:
    """服务不认识某条命令时,原始失败是 HTTP_INVALID_JSON（"请求不合法"）——
    那会把"这个 OrangeCut 太旧"误报成调用方拼错了请求。先按 capabilities
    自报的命令表对一遍,缺哪条说哪条,并落在 capability 阶段。

    拿不到命令表时不做预检:宁可让服务自己拒,也不要凭空拦住合法请求。
    """
    supported = supported_command_types(capabilities)
    if not supported:
        return
    missing: list[str] = []
    for command in commands:
        command_type = command.get("type") if isinstance(command, dict) else None
        if isinstance(command_type, str) and command_type not in supported and command_type not in missing:
            missing.append(command_type)
    if not missing:
        return
    raise CliFailure(
        "COMMAND_NOT_SUPPORTED",
        "capability",
        f"{context} needs semantic commands this OrangeCut does not implement: "
        + ", ".join(sorted(missing)),
        remediation=(
            "upgrade OrangeCut (or restart it if the binary was rebuilt since it "
            "started), then retry; `oc capabilities --json` lists what it supports"
            + (
                # capabilities 是工程作用域的,建工程之前拿不到,所以这一步
                # 只能发生在空工程已经建出来之后。别让用户自己去找它。
                f"; the empty project {orphan_project_id} was created before this "
                f"failed and is still open — `oc project close && oc project trash "
                f"{orphan_project_id}` removes it"
                if orphan_project_id
                else ""
            )
        ),
        details={
            "missingCommands": sorted(missing),
            "supportedCount": len(supported),
            **({"orphanProjectId": orphan_project_id} if orphan_project_id else {}),
        },
        exit_code=EXIT_INVALID_INPUT,
    )


def _source_creation_canvas(
    document: dict[str, Any], canvas: dict[str, int] | None, frame_rate: dict[str, str] | None,
) -> tuple[dict[str, int] | None, dict[str, str] | None]:
    entry = document.get("canvas") or {}
    if not isinstance(entry, dict):
        raise CliFailure("SOURCE_CANVAS_INVALID", "validation", "source canvas must be an object",
                         exit_code=EXIT_INVALID_INPUT)
    mode = entry.get("mode", "fixed")
    if mode == "auto":
        return None, None
    try:
        if mode != "fixed":
            raise ValueError("unknown canvas mode")
        if canvas is None:
            match = re.fullmatch(r"(\d+)x(\d+)", str(entry.get("size", "")))
            if match is None:
                raise ValueError("missing canvas size")
            width, height = map(int, match.groups())
            if any(value < 16 or value > 8192 or value % 2 for value in (width, height)):
                raise ValueError("invalid canvas dimensions")
            canvas = {"width": width, "height": height}
        if frame_rate is None:
            rate = Fraction(str(entry.get("fps", "")))
            if not 1 <= rate <= 240:
                raise ValueError("invalid frame rate")
            frame_rate = {"num": str(rate.numerator), "den": str(rate.denominator)}
    except (ValueError, TypeError, ZeroDivisionError) as error:
        raise CliFailure("SOURCE_CANVAS_INVALID", "validation", "source canvas size, mode or frame rate is invalid",
                         exit_code=EXIT_INVALID_INPUT) from error
    return canvas, frame_rate


def _remap_source_asset_references(value: Any, asset_ids: dict[str, str]) -> Any:
    """Remap typed asset references, including editable component recipes.

    Literal text/source strings are not ID references. JSON data-*-config
    attributes are structured recipes and use the same typed assetId fields.
    """
    if isinstance(value, list):
        return [_remap_source_asset_references(item, asset_ids) for item in value]
    if not isinstance(value, dict):
        return value
    remapped: dict[str, Any] = {}
    for key, item in value.items():
        if key.lower().endswith("assetid") and isinstance(item, str):
            remapped[key] = asset_ids.get(item, item)
        elif key.startswith("data-") and (key.endswith("-config") or key == "data-marker-sound") and isinstance(item, str):
            try:
                parsed = json.loads(item)
            except (ValueError, TypeError):
                remapped[key] = item
                continue
            updated = _remap_source_asset_references(parsed, asset_ids)
            remapped[key] = (json.dumps(updated, ensure_ascii=False, separators=(",", ":"))
                             if updated != parsed else item)
        else:
            remapped[key] = _remap_source_asset_references(item, asset_ids)
    if value.get("data-form-kind") == "visual-tool":
        try:
            count = int(value["data-tool-parts"])
            if not 1 <= count <= 40:
                raise ValueError("invalid recipe part count")
            parsed = json.loads("".join(value[f"data-tool-config-{index}"] for index in range(count)))
            updated = _remap_source_asset_references(parsed, asset_ids)
            if updated != parsed:
                serialized = json.dumps(updated, ensure_ascii=False, separators=(",", ":"))
                if len(serialized.encode("utf-8")) > 32000:
                    raise ValueError("recipe exceeds its bound")
                chunks = [serialized[index:index + 900] for index in range(0, len(serialized), 900)]
                remapped = {key: item for key, item in remapped.items() if not key.startswith("data-tool-config-")}
                remapped["data-tool-parts"] = str(len(chunks))
                remapped.update({f"data-tool-config-{index}": chunk for index, chunk in enumerate(chunks)})
        except (ValueError, KeyError, TypeError) as error:
            raise CliFailure("SOURCE_RECIPE_INVALID", "validation", "source visual tool recipe is invalid",
                             exit_code=EXIT_INVALID_INPUT) from error
    return remapped


def source_commands(
    document: dict[str, Any],
    sidecar: dict[str, Any],
    sequence_id: str,
    frame_rate: Fraction,
    asset_ids: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    """源码文档 → 一个 CommandBatch 的命令序列(只对空工程成立)。

    素材不在这里 add:定位符只认工程相对路径,文件必须真的进新工程的媒体
    目录才谈得上自包含,所以调用方先走服务的导入通道,这里只按 asset_ids
    做旧 id → 新 id 的重映射。
    """
    if str(document.get("schema", "")) != SOURCE_SCHEMA:
        raise CliFailure(
            "SOURCE_SCHEMA_UNKNOWN",
            "validation",
            f"source schema {document.get('schema')!r} is not {SOURCE_SCHEMA}",
            exit_code=EXIT_INVALID_INPUT,
        )
    commands: list[dict[str, Any]] = []
    asset_meta = sidecar.get("assets") or {}

    def rational(amount: Fraction) -> dict[str, str]:
        return {"num": str(amount.numerator), "den": str(amount.denominator)}

    def snap(seconds: Fraction) -> Fraction:
        # 时间在文件里是十进制秒,落库前必须对齐到帧,否则半开区间会出现
        # 引擎不认的非整帧边界。
        return Fraction(round(seconds * frame_rate), 1) / frame_rate

    remap = dict(asset_ids or {})

    def asset_ref(asset_id: str) -> str:
        return remap.get(asset_id, asset_id)

    # sequence 层:调色、画布、markers 和目标响度已有语义命令可还原。
    # 非默认采样率/声道布局与 sequence/project extensions 仍须明确拒绝。
    # 与其静默丢掉(linked-av 就是这么丢的),不如在文件确实带着它们时明确
    # 报错,让调用方知道这份工程重建不完整。
    sequence_entry = document.get("sequence") or {}
    grade = _resolve_opaque(sequence_entry.get("grade"), sidecar, "sequence grade") if sequence_entry.get("grade") else None
    if grade:
        commands.append({
            "type": "sequence.color-grading.set",
            "payload": {"sequenceId": sequence_id, "grading": grade},
        })
    # 标记现在有语义命令了(sequence.marker.add)。但它们必须排在所有片段
    # 之后:序列时长由内容撑出来,空时间线上任何标记都"超出序列"而被拒。
    pending_markers = (
        _resolve_opaque(sequence_entry.get("markers"), sidecar, "sequence markers")
        if sequence_entry.get("markers")
        else []
    )
    unrestorable: list[str] = []
    if sequence_entry.get("ext"):
        unrestorable.append("sequence extensions")
    project_ext = (document.get("project") or {}).get("ext")
    if project_ext:
        metadata = _resolve_opaque(project_ext, sidecar, "project extensions")
        if isinstance(metadata, dict) and set(metadata) == {"dev.orangecut.lineage"}:
            lineage = metadata["dev.orangecut.lineage"]
            if isinstance(lineage, dict) and set(lineage) == {"schemaVersion", "data"} and lineage.get("schemaVersion") == "1":
                commands.append({"type":"project.lineage.set","payload":{"lineage":lineage["data"]}})
            else:
                unrestorable.append("invalid project lineage extension")
        else:
            unrestorable.append("project extensions")
    audio = _resolve_opaque(sequence_entry.get("audio"), sidecar, "sequence audio") if sequence_entry.get("audio") else None
    if audio:
        if not isinstance(audio, dict) or {
            key: value for key, value in audio.items() if key not in ("targetLoudnessLufs","markerSoundsEnabled")
        } != {"sampleRate": 48000, "channelLayout": "stereo"}:
            unrestorable.append(f"sequence audio settings {audio}")
        elif audio.get("targetLoudnessLufs") is not None:
            commands.append({
                "type": "sequence.audio.loudness.set",
                "payload": {"sequenceId": sequence_id, "targetLoudnessLufs": audio["targetLoudnessLufs"]},
            })
        if audio.get("markerSoundsEnabled") is not None:
            commands.append({"type":"sequence.audio.marker-sounds.set","payload":{"sequenceId":sequence_id,"enabled":audio["markerSoundsEnabled"]}})
    if unrestorable:
        raise CliFailure(
            "SOURCE_UNRESTORABLE_FIELDS",
            "capability",
            "the source file carries fields no semantic command can rebuild: "
            + ", ".join(unrestorable),
            remediation=(
                "these need new commands in the Core vocabulary; until then such "
                "a project cannot be rebuilt from source without losing them"
            ),
            exit_code=EXIT_INVALID_INPUT,
        )

    component_meta = (asset_meta.get("components") or {})
    for component in document.get("components", []):
        component_id = str(component.get("id"))
        meta = component_meta.get(component_id) or {}
        commands.append({
            "type": "component.add",
            "payload": {
                "component": {
                    "id": component_id,
                    "componentType": component.get("type") or meta.get("componentType"),
                    "properties": _resolve_opaque(
                        component.get("properties"), sidecar, f"component {component_id}"
                    ),
                    "capabilityRequirements": meta.get("capabilityRequirements", []),
                    "extensions": meta.get("extensions", {}),
                }
            },
        })

    for track in document.get("tracks", []):
        track_id = str(track.get("id"))
        commands.append({
            "type": "track.add",
            "payload": {
                "sequenceId": sequence_id,
                "track": {
                    "id": track_id,
                    "kind": track.get("kind"),
                    "order": int(str(track.get("order", "0"))),
                    "muted": str(track.get("muted", "false")).lower() == "true",
                    "locked": str(track.get("locked", "false")).lower() == "true",
                    "clips": [],
                    "captions": [],
                    "extensions": _resolve_opaque(
                        track.get("ext"), sidecar, f"track {track_id} extensions"
                    ) or {},
                    **({"role": track["role"]} if track.get("role") else {}),
                },
            },
        })
        for clip in track.get("clips", []):
            # 起点与终点各自对齐帧,时长由两者相减——而不是"起点对齐 + 时长
            # 对齐"。时间线起点常是无限小数(43/6 秒这类),十进制秒截断后
            # 两个量化误差会叠加,end 落到原区间之外,再叠上引擎的
            # "源时长 == 时间线时长 × 速率" 精确等式就直接导不进来。
            start = snap(_seconds_value(clip.get("at", "0")))
            end = snap(
                _seconds_value(clip.get("at", "0")) + _seconds_value(clip.get("duration", "0"))
            )
            duration = end - start
            source = clip.get("source") or {}
            playback = _resolve_opaque(
                clip.get("playback"), sidecar, f"clip {clip.get('id')} playback"
            )
            if source.get("component"):
                clip_source = {"type": "component", "componentId": source["component"]}
                source_range = None
            elif source.get("asset"):
                clip_source = {"type": "asset", "assetId": asset_ref(str(source["asset"]))}
                # 源区间不按序列帧率量化(0.7x 会漂,1/3 速的单帧会塌成零长)。
                # 起点取文件值,终点按引擎不变量"源时长 == 时间线时长 × 速率"
                # 推出来。速率只认 playback:它缺席就等于 1,绝不能从 in/out 反推
                # ——十进制秒的舍入噪声会造出 993/1000 这种假速率,当场违反不变量。
                # 文件里的 out 是给人读的冗余信息,不参与计算。
                source_start = _seconds_value(source.get("in", "0"))
                clip_rate = Fraction(1)
                if isinstance(playback, dict) and isinstance(playback.get("rate"), dict):
                    clip_rate = _rational_of(playback["rate"])
                elif source.get("out") is not None and duration > 0:
                    # playback 缺席时速率按定义是 1,但文件里的 out 可能确实在表达
                    # 变速。两者要能分开:十进制秒经过帧量化后,时长最多偏一整帧
                    # (起止各半帧),所以差在一帧以内一律当舍入噪声按 1 处理——
                    # 否则 2.848 对 2.8667 会被反推成 993/1000 的假速率,当场
                    # 违反"源时长 == 时间线时长 × 速率"。超过一帧才是真变速,
                    # 这时把速率一并写回 playback,免得两边对不上。
                    written = _seconds_value(source["out"]) - source_start
                    if abs(written - duration) > 1 / frame_rate:
                        clip_rate = written / duration
                        playback = {
                            "rate": rational(clip_rate),
                            "reverse": False,
                            "freeze": False,
                        }
                source_range = {
                    "start": rational(source_start),
                    "end": rational(source_start + duration * clip_rate),
                }
            else:
                clip_source = {"type": "sequence", "sequenceId": source.get("sequence")}
                source_range = {"start": rational(Fraction(0)), "end": rational(duration)}  # 嵌套序列与时间线同基
            entry = {
                "id": clip.get("id"),
                "enabled": str(clip.get("enabled", "true")).lower() != "false",
                "timelineRange": {"start": rational(start), "end": rational(end)},
                "source": clip_source,
                "playback": playback or {"rate": {"num": "1", "den": "1"}, "reverse": False, "freeze": False},
                "effects": _resolve_opaque(
                    clip.get("effects"), sidecar, f"clip {clip.get('id')} effects"
                ) or [],
                "extensions": _resolve_opaque(
                    clip.get("ext"), sidecar, f"clip {clip.get('id')} extensions"
                ) or {},
            }
            if source_range is not None:
                entry["sourceRange"] = source_range
            for field in ("transform", "motion", "visualFit"):
                if clip.get(field):
                    entry[field] = _resolve_opaque(
                        clip[field], sidecar, f"clip {clip.get('id')} {field}"
                    )
            commands.append({
                "type": "clip.add",
                "payload": {"sequenceId": sequence_id, "trackId": track_id, "clip": entry},
            })
        for caption in track.get("captions", []):
            start = snap(_seconds_value(caption.get("at", "0")))
            end = snap(_seconds_value(caption.get("end", "0")))
            entry = {
                "id": caption.get("id"),
                "timelineRange": {"start": rational(start), "end": rational(end)},
                "text": caption.get("text", ""),
                "tokens": _resolve_opaque(
                    caption.get("tokens"), sidecar, f"caption {caption.get('id')} tokens"
                ) or [],
                "extensions": _resolve_opaque(
                    caption.get("ext"), sidecar, f"caption {caption.get('id')} extensions"
                ) or {},
            }
            for key, field in (("speaker", "speaker"), ("style", "styleRef")):
                if caption.get(key):
                    entry[field] = caption[key]
            if caption.get("emphases"):
                entry["emphases"] = caption["emphases"]
            if caption.get("motion"):
                entry["motion"] = _resolve_opaque(
                    caption["motion"], sidecar, f"caption {caption.get('id')} motion"
                )
            commands.append({
                "type": "caption.add",
                "payload": {"sequenceId": sequence_id, "trackId": track_id, "caption": entry},
            })
    for marker in pending_markers or []:
        commands.append({
            "type": "sequence.marker.add",
            "payload": {"sequenceId": sequence_id, "marker": marker},
        })
    return _remap_source_asset_references(commands, remap)


def read_project_source(path: Path) -> dict[str, Any]:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as error:
        raise CliFailure(
            "SOURCE_FILE_UNREADABLE",
            "validation",
            f"cannot read the project source file: {error}",
            exit_code=EXIT_INVALID_INPUT,
        ) from error
    if path.suffix.lower() == ".json":
        return json.loads(text)
    return parse_source_yaml(text)


def read_project_sidecar(path: Path) -> dict[str, Any]:
    sidecar_path = source_sidecar_path(path)
    if not sidecar_path.is_file():
        return {"opaque": {}, "assets": {}}
    return json.loads(sidecar_path.read_text(encoding="utf-8"))


def load_html_presets() -> list[dict[str, Any]]:
    path = html_preset_catalog_path()
    try:
        catalog = json.loads(path.read_text(encoding="utf-8"))
    except OSError as error:
        raise CliFailure(
            "HTML_PRESET_CATALOG_MISSING",
            "validation",
            f"cannot read the HTML preset catalog: {error}",
            remediation=f"set {HTML_PRESET_CATALOG_ENV} to a readable catalog path",
            exit_code=EXIT_INVALID_INPUT,
        ) from error
    except ValueError as error:
        raise CliFailure(
            "HTML_PRESET_CATALOG_INVALID",
            "serialization",
            f"the HTML preset catalog is not valid JSON: {error}",
            exit_code=EXIT_INVALID_INPUT,
        ) from error
    presets = catalog.get("presets") if isinstance(catalog, dict) else None
    if not isinstance(presets, list) or not all(isinstance(item, dict) for item in presets):
        raise CliFailure(
            "HTML_PRESET_CATALOG_INVALID",
            "serialization",
            "the HTML preset catalog must carry a presets array",
            exit_code=EXIT_INVALID_INPUT,
        )
    return presets


def html_preset_by_id(preset_id: str) -> dict[str, Any]:
    presets = load_html_presets()
    for preset in presets:
        if preset.get("id") == preset_id:
            return preset
    known = ", ".join(str(preset.get("id")) for preset in presets)
    raise CliFailure(
        "HTML_PRESET_UNKNOWN",
        "validation",
        f"no HTML preset is named {preset_id}",
        remediation=f"use one of: {known}",
        exit_code=EXIT_INVALID_INPUT,
    )


def escape_html_text(value: str) -> str:
    """Escape a slot value for a text position.

    The fragment parser converts character references back to text, so a title
    containing `&` or `<` round-trips to exactly what the caller passed instead
    of opening a tag the caller did not write.
    """
    return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def named_defaults(preset: dict[str, Any], key: str) -> dict[str, str]:
    entries = preset.get(key)
    if not isinstance(entries, list):
        return {}
    return {
        str(entry["name"]): str(entry["default"])
        for entry in entries
        if isinstance(entry, dict) and "name" in entry and "default" in entry
    }


def expand_preset_list(
    spec: dict[str, Any], raw: str
) -> tuple[str, str, dict[str, str]]:
    """Turn one `--set <list>=<json>` into the markup that replaces a container.

    Returns the container class, the joined item markup, and any CSS variables
    the expansion derives — the total weight, so a bar that must fill exactly
    once over the whole video does not need anybody to add up the chapters by
    hand.
    """
    try:
        entries = json.loads(raw)
    except ValueError as error:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            f"the value for {spec.get('name')} must be a JSON array: {error}",
            remediation="""pass --set chapters='[{"title":"开场","seconds":30}]'""",
            exit_code=EXIT_INVALID_INPUT,
        ) from error
    if not isinstance(entries, list) or not entries:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            f"the value for {spec.get('name')} must be a non-empty JSON array",
            exit_code=EXIT_INVALID_INPUT,
        )
    if not spec.get("minItems", 1) <= len(entries) <= spec.get("maxItems", len(entries)):
        raise CliFailure(
            "CLI_ARGUMENT_INVALID", "validation",
            f"{spec['name']} expects {spec['minItems']}–{spec['maxItems']} entries",
            exit_code=EXIT_INVALID_INPUT,
        )
    weight_field = str(spec.get("weightField", ""))
    weights: list[float] = []
    for entry in entries:
        if not isinstance(entry, dict):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"every entry of {spec.get('name')} must be a JSON object",
                exit_code=EXIT_INVALID_INPUT,
            )
        # Defaulting a missing weight to 1 would lay the bar out wrongly and
        # say nothing about it — the segments would simply not match the video.
        value = entry.get(weight_field, None) if weight_field else 1
        # 数字写成 "9.2" 在 JSON 里同样自然,尤其当同一个字段还要显示成
        # 文本时;只认数字类型会把这种完全合理的写法挡在门外。
        if isinstance(value, str):
            try:
                value = float(value.strip())
            except ValueError:
                value = None
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or (
            value < spec["minWeight"] if "minWeight" in spec else value <= 0
        ) or value > spec.get("maxWeight", math.inf):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"every entry needs a valid {weight_field or 'weight'}"
                + (f" in {spec['minWeight']}–{spec['maxWeight']}" if "maxWeight" in spec else " greater than zero"),
                remediation=(
                    f"give each entry a positive number under {weight_field!r}"
                    if weight_field
                    else "give each entry a positive weight"
                ),
                exit_code=EXIT_INVALID_INPUT,
            )
        weights.append(float(value))
    total = sum(weights)
    if not math.isfinite(total):
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "list weight total must be finite",
                         exit_code=EXIT_INVALID_INPUT)
    peak = max(weights) if weights else 0.0
    template = str(spec.get("item", ""))
    pieces: list[str] = []
    offset = 0.0
    for index, (entry, weight) in enumerate(zip(entries, weights)):
        derived: dict[str, Any] = {
            "index": index,
            # 给人看的序号从 1 起;{{index}} 保持 0 基,动画延迟按它算才对。
            "number": index + 1,
            "count": len(entries),
            # percent 是"占总和多少"——章节条要的就是这个。条形图要的是
            # "相对最大值多长",否则四项数值再悬殊,条长也都挤在 25% 附近。
            "share": f"{weight / peak * 100:g}" if peak else "0",
            "percent": f"{weight / total * 100:g}" if total else "0",
            "offsetPercent": f"{offset / total * 100:g}" if total else "0",
            "offsetSeconds": f"{offset:g}",
            "offsetWeight": f"{offset:g}",
            "itemWeight": f"{weight:g}",
            weight_field or "weight": f"{weight:g}",
        }
        # 调用方给的字段优先:derived 里的 percent 是"这条占总权重多少",
        # 而列表预设的 percent 是用户自己写的百分比,让派生值覆盖它会把
        # 55/30/15 变成 33.3/33.3/33.3。派生值只填补空缺。
        # 预设可以给条目字段缺省值(聊天消息的 kind 缺省是 text),调用方只写必要字段。
        values = {**(spec.get("defaults") or {}), **derived, **entry}
        if spec.get("strictDerived"):
            values.update(derived)
        fields = re.findall(r"\{\{(\w+)\}\}", template)
        if any(field not in values for field in fields):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"entry {index} of {spec.get('name')} leaves a field unfilled",
                remediation="give every entry the fields the preset item names",
                exit_code=EXIT_INVALID_INPUT,
            )
        rendered = re.sub(r"\{\{(\w+)\}\}", lambda match: escape_html_text(str(values[match[1]])), template)
        pieces.append(rendered)
        offset += weight
    variables: dict[str, str] = {}
    total_variable = spec.get("totalVariable")
    if isinstance(total_variable, str) and total_variable != "":
        variables[total_variable] = f"{total:g}{spec.get('totalUnit', 's')}"
    return str(spec.get("container", "")), "".join(pieces), variables


def replace_container_children(
    node: dict[str, Any], container_class: str, children: list[dict[str, Any]]
) -> bool:
    """Put the expanded items where the preset marked their place."""
    if container_class in (node.get("classes") or []):
        node["children"] = children
        return True
    for child in node.get("children") or []:
        if replace_container_children(child, container_class, children):
            return True
    return False


def fill_html_preset(
    preset: dict[str, Any],
    assignments: list[str],
    frame_seconds: Fraction | None = None,
    life_seconds: Fraction | None = None,
    instance_key: str | None = None,
) -> tuple[str, str, list[tuple[str, str]]]:
    """Apply `--set NAME=VALUE` to a preset's markup and stylesheet.

    A text slot is filled by replacing the string the preset ships with, so both
    the editor and this CLI start from markup a person can read rather than from
    a template language only one of them understands. A list slot cannot work
    that way — its structure depends on how many entries there are — so it is
    returned as a pending expansion the caller grafts onto the parsed subtree.
    """
    markup = str(preset.get("markup", ""))
    stylesheet = str(preset.get("stylesheet", ""))
    slots = named_defaults(preset, "slots")
    raw_slots = dict(slots)
    variables = named_defaults(preset, "variables")
    parameters = {
        spec["parameter"]["name"]: (spec["name"], spec["parameter"])
        for spec in preset.get("variables", []) if "parameter" in spec
    }
    lists = {
        str(spec["name"]): spec
        for spec in preset.get("lists", [])
        if isinstance(spec, dict) and "name" in spec
    }
    expansions: list[tuple[str, str]] = []
    derived: dict[str, str] = {}
    assigned: set[str] = set()
    # A sweep that runs for the video's full length is still short of the end on
    # the last frame a renderer draws, which sits one frame earlier — over three
    # seconds at 30fps the bar visibly fails to close. The preset says which
    # variable holds a frame; the Sequence says how long one is.
    frame_variable = preset.get("frameVariable")
    if isinstance(frame_variable, str) and frame_seconds is not None:
        derived[frame_variable] = f"{float(frame_seconds):.6g}s"
    # 退场动画要知道自己活多久:CSS 无从得知 Clip 时长,由放置时写入。
    # 贴纸不做退场就会在片段结束时凭空消失,观感廉价。
    life_variable = preset.get("lifeVariable")
    if isinstance(life_variable, str) and life_seconds is not None:
        derived[life_variable] = f"{float(life_seconds):.6g}s"
    for assignment in assignments:
        name, separator, value = assignment.partition("=")
        if not separator:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"--set expects NAME=VALUE, got {assignment}",
                remediation="pass --set title=开场 style assignments",
                exit_code=EXIT_INVALID_INPUT,
            )
        if name in lists:
            container, items, variables_from_list = expand_preset_list(lists[name], value)
            expansions.append((container, items))
            derived.update(variables_from_list)
            continue
        reel_slots = preset.get("digitReelSlots", [])
        if name in slots and (name == preset.get("digitReelSlot") or name in reel_slots):
            markup = fill_digit_reel(str(preset["id"]), markup, value, name if name in reel_slots else None)
            continue
        if name in slots:
            markup = markup.replace(slots[name], escape_html_text(value), 1)
            slots[name] = escape_html_text(value)
            raw_slots[name] = value
            continue
        if name in parameters:
            variable, parameter = parameters[name]
            value = html_preset_parameter_value(name, value, parameter)
            name = variable
        if name in variables:
            if ";" in value or "}" in value:
                raise CliFailure(
                    "CLI_ARGUMENT_INVALID",
                    "validation",
                    f"the value for {name} must not contain ; or }}",
                    remediation="pass a single CSS value",
                    exit_code=EXIT_INVALID_INPUT,
                )
            stylesheet = stylesheet.replace(
                f"{name}:{variables[name]}", f"{name}:{value}", 1
            )
            variables[name] = value
            assigned.add(name)
            continue
        known = ", ".join(sorted([*lists, *slots, *variables, *parameters])) or "none"
        raise CliFailure(
            "HTML_PRESET_SLOT_UNKNOWN",
            "validation",
            f"preset {preset.get('id')} has no slot, list or variable named {name}",
            remediation=f"use one of: {known}",
            exit_code=EXIT_INVALID_INPUT,
        )
    # 逐字打出来的文字要知道自己有几个字(CSS 量不出来):预设点名哪个槽位、
    # 写进哪个变量,放置时按最终文字算好。
    for spec in preset.get("lengthVariables") or []:
        slot = str(spec.get("slot", ""))
        variable = str(spec.get("variable", ""))
        if slot in raw_slots and variable:
            derived[variable] = str(max(1, len(raw_slots[slot])))
    # What the list implies, unless the caller said otherwise: a bar that must
    # fill exactly once over the whole video should not need its duration typed
    # out a second time.
    for name, value in derived.items():
        if name in assigned or name not in variables:
            continue
        stylesheet = stylesheet.replace(f"{name}:{variables[name]}", f"{name}:{value}", 1)
        variables[name] = value
    return scope_preset_instance(str(preset.get("id", "")), markup, stylesheet, expansions, instance_key)


def html_preset_parameter_value(name: str, value: str, parameter: dict[str, Any]) -> str:
    if "values" in parameter:
        choices = parameter["values"]
        if value in choices:
            return choices[value]
        expected = "one of " + ", ".join(choices)
    elif parameter.get("format") == "hex-color":
        if re.fullmatch(r"#[0-9A-Fa-f]{6}(?:[0-9A-Fa-f]{2})?", value):
            return value
        expected = "a #RRGGBB or #RRGGBBAA color"
    else:
        minimum, maximum = parameter["min"], parameter["max"]
        if re.fullmatch(r"(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)", value) and minimum <= float(value) <= maximum:
            return value
        expected = f"a number from {minimum} to {maximum}"
    raise CliFailure("CLI_ARGUMENT_INVALID", "validation", f"{name} expects {expected}", exit_code=EXIT_INVALID_INPUT)


def fill_digit_reel(preset_id: str, markup: str, value: str, slot: str | None = None) -> str:
    if len(value) > 16 or not re.fullmatch(
        r"[+-]?\$?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?(?:%|[KMBT])?", value, re.ASCII
    ):
        raise CliFailure("HTML_PRESET_NUMBER_INVALID", "validation",
                         "the reel expects a number like +31.48% or +$952B",
                         exit_code=EXIT_INVALID_INPUT)
    prefix = f"oc-{preset_id}"
    classes = f"{prefix}__number" + (f" {prefix}__number-{slot}" if slot else "")
    number = re.compile(rf'<div class="{re.escape(classes)}"[^>]*>.*?</div>', re.DOTALL)
    glyphs = []
    for char in value:
        if char.isdigit():
            stop = 10 + int(char)
            belt = "".join(f"<span>{step % 10}</span>" for step in range(stop + 1))
            glyphs.append(f'<span class="{prefix}__wheel" style="--oc-cinema-stop:{stop}">'
                          f'<span class="{prefix}__belt">{belt}</span></span>')
        else:
            glyphs.append(f"<span>{escape_html_text(char)}</span>")
    replacement = (f'<div class="{classes}" role="img" aria-label="{value}" '
                   f'style="--oc-cinema-length:{len(value)}">{"".join(glyphs)}</div>')
    result, count = number.subn(lambda _: replacement, markup, count=1)
    if not count:
        raise CliFailure("HTML_PRESET_CATALOG_INVALID", "serialization", "missing digit-reel container",
                         exit_code=EXIT_INVALID_INPUT)
    return result


def place_screen_recording(
    arguments: argparse.Namespace, client: "Client", project_id: str
) -> dict[str, Any]:
    """`oc html screen`:录屏 → 一个带设备框、推拉镜头、光标和点击涟漪的组件。

    录屏嵌在组件里(`<video data-asset-id>`),与选配独立原声走同一 Core 批次;
    每次点击可再挂一声点击音效,时间就是点击时间。"""
    from . import screen_wrap

    path = absolute_media_path(arguments.recording)
    probe = require_object(
        client.request("POST", "/v1/media/probe", {"path": str(path)}), "data"
    )
    video_w = int(probe.get("displayWidth") or probe.get("codedWidth") or 0)
    video_h = int(probe.get("displayHeight") or probe.get("codedHeight") or 0)
    duration = float(probe.get("durationSeconds") or 0)
    if video_w <= 0 or video_h <= 0 or not math.isfinite(duration) or duration <= 0:
        raise CliFailure(
            "SCREEN_RECORDING_INVALID", "validation",
            "the recording has no readable picture size or duration",
            remediation="pass a video file; check it with `oc media probe`",
            exit_code=EXIT_INVALID_INPUT,
        )
    try:
        clicks = screen_wrap.parse_clicks(arguments.clicks)
    except ValueError as error:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", str(error), exit_code=EXIT_INVALID_INPUT)

    snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
    project = require_object(require_object(snapshot, "data"), "project")
    sequence_id = arguments.sequence_id or default_sequence_id(project)
    sequence = require_sequence(project, sequence_id)
    canvas = require_object(sequence, "canvas")
    canvas_w, canvas_h = int(canvas.get("width") or 0), int(canvas.get("height") or 0)
    if canvas_w <= 0 or canvas_h <= 0:
        raise CliFailure(
            "CANVAS_NOT_SET", "preconditions",
            "the sequence has no canvas size yet",
            remediation="pin one with `oc canvas set` or create the project with --width/--height",
            exit_code=EXIT_INVALID_INPUT,
        )
    rate = sequence_frame_rate_from(project, sequence_id)

    # Validate every authored option before the import can change the Project.
    if getattr(arguments, "keep_audio", False) and not probe.get("hasAudio"):
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "recording has no original audio track", exit_code=EXIT_INVALID_INPUT)
    if arguments.track_id and not any(track["id"] == arguments.track_id and track["kind"] == "component" and not track.get("locked") for track in sequence["tracks"]):
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "track-id must name an unlocked component track", exit_code=EXIT_INVALID_INPUT)
    source_duration = Fraction(str(probe["durationSeconds"]))
    source_start_frame = getattr(arguments, "source_start_frame", 0)
    source_end_frame = getattr(arguments, "source_end_frame", None)
    if source_end_frame is None:
        source_end_frame = int(source_duration * rate)
    if source_start_frame < 0 or source_end_frame <= source_start_frame or Fraction(source_end_frame, 1) / rate > source_duration:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "source frame range must be non-empty and within the recording", exit_code=EXIT_INVALID_INPUT)
    duration_frames = source_end_frame - source_start_frame
    media_start = Fraction(source_start_frame, 1) / rate
    duration = float(Fraction(duration_frames, 1) / rate)
    device = screen_wrap.pick_device(arguments.device, video_w, video_h)
    try:
        focus_spec = getattr(arguments, "focus", None)
        focus = None if focus_spec is None else screen_wrap.parse_clicks(focus_spec)
        crop_spec = getattr(arguments, "crop", None)
        crop = screen_wrap.Rect(*(float(value) for value in crop_spec.split(","))) if crop_spec else None
        screen_wrap.validate_options(video_w=video_w, video_h=video_h, duration=duration,
            canvas_w=canvas_w, canvas_h=canvas_h, device=device, clicks=clicks, focus=focus,
            zoom=arguments.zoom, hold=arguments.hold, crop=crop, media_start=media_start,
            background=arguments.background or screen_wrap.DEFAULT_BACKGROUND, accent=arguments.accent)
    except (ValueError, TypeError) as error:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", str(error), exit_code=EXIT_INVALID_INPUT)

    payload = {
        "baseRevision": current_revision(client),
        "paths": [str(path)],
        "intent": "导入录屏",
        "idempotencyKey": f"screen-import:{uuid.uuid4()}",
    }
    previous_timeout = client.timeout
    client.timeout = IMPORT_TIMEOUT_SECONDS
    try:
        imported = require_object(client.request(
            "POST", f"/v1/projects/{quote(project_id)}/assets/import", payload), "data")
        asset_id = imported.get("assetId")
        if not isinstance(asset_id, str):
            assets = imported.get("assets") or [{}]
            asset_id = assets[0].get("assetId") or assets[0].get("id")
    except CliFailure as failure:
        asset_id = (failure.details or {}).get("assetId")
        if failure.code != "ASSET_ALREADY_IMPORTED" or not isinstance(asset_id, str):
            raise
    finally:
        client.timeout = previous_timeout

    fragment = screen_wrap.build_fragment(
        asset_id=str(asset_id), video_w=video_w, video_h=video_h, duration=duration,
        canvas_w=canvas_w, canvas_h=canvas_h, device=device, clicks=clicks,
        zoom=arguments.zoom, hold=arguments.hold, cursor=not arguments.no_cursor,
        background=arguments.background or screen_wrap.DEFAULT_BACKGROUND,
        accent=arguments.accent,
        focus=focus, crop=crop, media_start=media_start,
    )
    root, stylesheet = parse_html_fragment(fragment)
    built = screen_wrap.build_operations(root=root, stylesheet=stylesheet, sequence=sequence,
        asset_id=asset_id, at_frame=arguments.at_frame, duration_frames=duration_frames,
        source_start_frame=source_start_frame, keep_audio=getattr(arguments,"keep_audio",False),track_id=arguments.track_id)
    identity = f"screen-place:{uuid.uuid4()}"
    response = client.request("POST", f"/v1/projects/{quote(project_id)}/commands", {
        "commandId":identity,"idempotencyKey":identity,"projectId":project_id,"baseRevision":current_revision(client),
        "actor":{"type":"agent","id":"orangecut-skill"},"intent":arguments.intent,
        "preconditions":[],"mode":"commit","commands":built["operations"],
    })
    data = require_object(response, "data")
    data.update({key:built[key] for key in ("clipId","trackId","componentId")})
    clip_id = built["clipId"]
    sounds: list[dict[str, Any]] = []
    if arguments.sfx != "none":
        for click in clicks:
            if not 0 <= click.t <= duration:
                continue
            try:
                sounds.append(attach_placement_sfx(
                    client, project_id, arguments.sequence_id, arguments.at_frame,
                    arguments.sfx, clip_id, f"{arguments.intent} + 点击音效",
                    Fraction(click.t).limit_denominator(1000), cue="extra"))
            except CliFailure as error:
                data.setdefault("sfxErrors", []).append({"t": click.t, "code": error.code, "message": error.message})
    data["screen"] = {
        "assetId": asset_id, "device": device, "clicks": len(clicks),
        "focus": len(clicks if focus is None else focus), "sourceStartFrame": source_start_frame, "sourceEndFrame": source_end_frame,
        "durationFrames": duration_frames, "recording": {"width": video_w, "height": video_h, "seconds": duration},
    }
    data["sfx"] = sounds
    return response


def scope_preset_instance(
    preset_id: str, markup: str, stylesheet: str, expansions: list[tuple[str, str]],
    instance_key: str | None = None,
) -> tuple[str, str, list[tuple[str, str]]]:
    """Give this placement its own class names.

    A component's stylesheet joins one stylesheet for the whole composition, and
    a preset's classes are fixed (`oc-meme-circle`, `oc-meme-circle__svg`). Two
    placements of the same preset with different variables therefore override
    each other — the later `.oc-meme-circle>*{--oc-meme-x:…}` rule wins for both,
    so a second circle drew itself where the first one was. Suffixing the
    preset's class prefix per placement keeps every instance's rules to itself;
    variable names (`--oc-meme-x`) and `data-form-preset` are untouched, so the
    editor's form and later variable edits work as before.
    """
    if not preset_id:
        return markup, stylesheet, expansions
    prefix = f"oc-{preset_id}"
    instance = uuid.uuid4() if instance_key is None else uuid.uuid5(uuid.NAMESPACE_URL, instance_key)
    scoped = f"{prefix}-i{instance.hex[:12]}"
    pattern = re.compile(rf"(?<![\w-]){re.escape(prefix)}(?=__|[^\w-]|$)")
    # 不带 `--` 前缀、紧跟 `__`/空白/标点的才是类名(及以类名开头的 keyframes);
    # `--oc-meme-x` 这类变量名前面是 `-`,不会被碰到。
    rename = lambda text: pattern.sub(scoped, text)
    return (
        rename(markup),
        rename(stylesheet),
        [(rename(container), rename(items)) for container, items in expansions],
    )


def parse_html_fragment(html: str) -> tuple[dict[str, Any], str]:
    """HTML 字符串 → (root 节点, 抽出的 <style> 样式)。多个顶层元素自动
    包一个全幅 div。"""
    builder = _HtmlTreeBuilder()
    builder.feed(html)
    builder.close()
    roots = builder.roots
    if not roots:
        raise CliFailure(
            "HTML_FRAGMENT_EMPTY",
            "validation",
            "the HTML fragment contains no elements",
            remediation="pass a fragment with at least one element",
            exit_code=EXIT_INVALID_INPUT,
        )
    if len(roots) == 1:
        root = roots[0]
    else:
        root = {"tag": "div", "children": roots}
    return _strip_empty_children(root), "\n".join(builder.styles).strip()


def current_revision(client: "Client") -> int:
    # baseRevision 自动补齐只需要 revision 一个数字:走轻量的
    # /v1/projects/current summary,而不是全量 timeline snapshot——
    # 后者的序列化/传输开销随 clip 数线性增长,会拖慢每一次变更命令。
    # 多开时 current 没有确定含义,带上这条命令已经解析出的工程(ADR 0043);
    # 老服务不认这个查询参数,照旧按唯一打开的那个答。
    summary = client.request("GET", f"/v1/projects/current{project_query(_NAMED_PROJECT)}")
    return require_integer(require_object(summary, "data"), "revision")


def require_documentation_launch_path(payload: dict[str, Any]) -> str:
    launch_path = require_text(payload, "launchPath")
    parsed = urllib.parse.urlsplit(launch_path)
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    valid = (
        not parsed.scheme
        and not parsed.netloc
        and parsed.path == "/api-docs/v1/session"
        and not parsed.fragment
        and len(query) == 1
        and query[0][0] == "ticket"
        and re.fullmatch(r"[0-9a-f]{32}", query[0][1]) is not None
    )
    if not valid:
        raise CliFailure(
            "PROTOCOL_FIELD_INVALID",
            "serialization",
            "the documentation launch path is not a safe one-time local path",
            retryable=True,
            remediation="update OrangeCut and the oc CLI together, then retry",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )
    return launch_path


def documentation_browser_unavailable() -> CliFailure:
    return CliFailure(
        "DOCS_BROWSER_UNAVAILABLE",
        "preconditions",
        "the system browser could not be opened for OrangeCut API documentation",
        remediation="run `oc docs --url` to print the read-only Swagger URL",
        exit_code=EXIT_OPERATION_FAILED,
    )


def wait_media_task(client: Any, task_id: str, timeout_seconds: int) -> dict[str, Any]:
    if timeout_seconds < 1:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "timeout must be positive")
    endpoint = f"/v1/media/tasks/{quote(task_id)}"
    deadline = time.monotonic() + timeout_seconds
    while True:
        response = client.request("GET", endpoint)
        task = require_object(response, "data")
        if task.get("state") == "succeeded":
            return response
        if task.get("state") in ("cancelled", "interrupted", "failed"):
            raise decode_server_failure(task.get("error"), invalid_code="MEDIA_TASK_FAILED", invalid_message="media processing failed")
        if time.monotonic() >= deadline:
            raise CliFailure("MEDIA_TASK_WATCH_TIMEOUT", "job", f"continue watching media task {task_id} or cancel it", retryable=True)
        time.sleep(0.2)


def require_job_state(snapshot: dict[str, Any]) -> str:
    state = snapshot.get("state")
    if not isinstance(state, str) or state not in JOB_STATES:
        raise CliFailure(
            "PROTOCOL_FIELD_INVALID",
            "serialization",
            "the Job snapshot state is not a supported lifecycle value",
            retryable=True,
            remediation="restart or update OrangeCut, then read the Job snapshot again",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )
    return state


PRIVACY_STYLES = ("blur", "mosaic", "solid")


def privacy_box_argument(value: str) -> dict[str, float]:
    """`x,y,w,h` or `x,y,w,h@from-to` (source pixels; seconds) → one manual cover region."""
    text = value.strip()
    span = None
    if "@" in text:
        text, span = text.split("@", 1)
    parts = [part.strip() for part in text.split(",")]
    if len(parts) != 4:
        raise argparse.ArgumentTypeError("expected x,y,w,h[@fromSec-toSec]")
    try:
        x, y, w, h = (float(part) for part in parts)
    except ValueError as error:
        raise argparse.ArgumentTypeError("box values must be numbers") from error
    if w <= 0 or h <= 0 or x < 0 or y < 0:
        raise argparse.ArgumentTypeError("box needs x,y >= 0 and w,h > 0 (source pixels)")
    box: dict[str, float] = {"x": x, "y": y, "w": w, "h": h}
    if span is not None:
        if "-" not in span:
            raise argparse.ArgumentTypeError("time span looks like @from-to in seconds")
        start_text, end_text = span.split("-", 1)
        try:
            start = float(start_text) if start_text.strip() else 0.0
            end = float(end_text) if end_text.strip() else None
        except ValueError as error:
            raise argparse.ArgumentTypeError("time span values must be seconds") from error
        if start < 0 or (end is not None and end <= start):
            raise argparse.ArgumentTypeError("time span must be 0 <= from < to")
        box["fromSec"] = start
        if end is not None:
            box["toSec"] = end
    return box


def add_privacy_tracking_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--every", type=positive_integer, default=None,
        help="detect on one frame every N frames (default 3); boxes in between are interpolated",
    )
    parser.add_argument(
        "--min-face-px", type=non_negative_float, default=None,
        help="ignore faces narrower than this many source pixels (default 0: cover everyone)",
    )
    parser.add_argument(
        "--hold-sec", type=non_negative_float, default=None,
        help="a face that vanishes for at most this long stays the same track (default 0.5)",
    )
    parser.add_argument(
        "--lead-sec", type=non_negative_float, default=None,
        help="extend every track this long before its first and after its last detection (default 0.2): a face that shows for half a second is a face that showed",
    )
    parser.add_argument(
        "--pad-percent", type=non_negative_float, default=None,
        help="grow each box around its centre by this percent (default 30); the top gets 15%% extra for the hairline",
    )


PRIVACY_STRENGTH_PRESETS = {"light": 20, "medium": 40, "strong": 70}
DEFAULT_PRIVACY_STRENGTH = PRIVACY_STRENGTH_PRESETS["medium"]


def privacy_wants_sticker(arguments: argparse.Namespace) -> bool:
    """贴纸路径:点名了 --sticker、要 --clear,或者什么遮挡参数都没给(默认云朵)。"""
    if arguments.clear and (getattr(arguments, "region_mode", None) is not None or getattr(arguments, "strength", None) is not None or getattr(arguments, "strength_preset", None) is not None):
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--clear takes no cover parameters", exit_code=EXIT_INVALID_INPUT)
    if arguments.sticker is not None or arguments.clear:
        return True
    return arguments.style is None and not arguments.boxes and not arguments.no_faces and arguments.region_mode is None and arguments.strength is None and getattr(arguments, "strength_preset", None) is None


def add_privacy_cover_arguments(parser: argparse.ArgumentParser) -> None:
    add_privacy_tracking_arguments(parser)
    parser.add_argument("--region-mode", choices=("inside", "outside"), help="Rectangular regions: blur inside, or keep the union clear and blur everything outside. Outside disables face detection; outside active intervals the whole frame stays blurred")
    strength_group = parser.add_mutually_exclusive_group()
    strength_group.add_argument("--strength", type=float, help="Gaussian blur strength, 1..100 (default 40 for rectangular regions)")
    strength_group.add_argument("--strength-preset", choices=tuple(PRIVACY_STRENGTH_PRESETS), help="Blur strength shortcut: light=20, medium=40, strong=70; --strength allows any custom value")
    parser.add_argument(
        "--style", choices=PRIVACY_STYLES, default=None,
        help="pixel cover on a derived copy: blur, mosaic, or solid. On `timeline privacy` the default is the cloud sticker; passing --style (or --box / --no-faces) switches to this re-encoding path. `media anonymize` defaults to blur",
    )
    parser.add_argument(
        "--no-faces", action="store_true",
        help="skip face detection and cover only the --box regions",
    )
    parser.add_argument(
        "--box", action="append", type=privacy_box_argument, default=None, dest="boxes",
        help="manual region in source pixels, x,y,w,h optionally @fromSec-toSec (repeatable): a missed face, a plate, a screen",
    )
    parser.add_argument(
        "--no-verify", action="store_true",
        help="skip the post-cover recheck (it re-runs detection on the result and reports frames where a face survived)",
    )


def privacy_tracking_payload(arguments: argparse.Namespace) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    for attribute, key in (
        ("every", "every"),
        ("min_face_px", "minFacePx"),
        ("hold_sec", "holdSec"),
        ("lead_sec", "leadSec"),
        ("pad_percent", "padPercent"),
    ):
        value = getattr(arguments, attribute, None)
        if value is not None:
            payload[key] = value
    return payload


def privacy_cover_payload(arguments: argparse.Namespace) -> dict[str, Any]:
    payload = privacy_tracking_payload(arguments)
    if getattr(arguments, "style", None):
        payload["style"] = arguments.style
    if getattr(arguments, "no_faces", False):
        payload["faces"] = False
    mode = getattr(arguments, "region_mode", None)
    strength = getattr(arguments, "strength", None)
    if getattr(arguments, "strength_preset", None):
        strength = PRIVACY_STRENGTH_PRESETS[arguments.strength_preset]
    if mode:
        payload["regionMode"] = mode
        payload["strength"] = DEFAULT_PRIVACY_STRENGTH if strength is None else strength
        if mode == "outside":
            payload["faces"] = False
    if strength is not None:
        if not math.isfinite(strength) or not 1 <= strength <= 100:
            raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--strength must be 1..100", exit_code=EXIT_INVALID_INPUT)
        payload["strength"] = strength
    boxes = getattr(arguments, "boxes", None)
    if mode == "outside" and not boxes:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--region-mode outside requires at least one --box", exit_code=EXIT_INVALID_INPUT)
    if boxes:
        payload["boxes"] = boxes
    if getattr(arguments, "no_faces", False) and not boxes:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            "--no-faces leaves nothing to cover; pass at least one --box",
            exit_code=EXIT_INVALID_INPUT,
        )
    if getattr(arguments, "no_verify", False):
        payload["verify"] = False
    return payload


PRIVACY_EFFECT_TYPE = "dev.orangecut.privacy.apply"
FACE_COVER_EXTENSION = "dev.orangecut.face-cover"
FACE_COVER_MAX_KEYFRAMES = 200
FACE_COVER_MIN_SAMPLES = 3
DEFAULT_COVER_STICKER = "cloud"
COVER_STICKERS = {
    "cloud": ("asset-bundled-cover-cloud-v1", "云朵"),
    "smile": ("asset-bundled-cover-smile-v1", "笑脸"),
    "bear": ("asset-bundled-cover-bear-v1", "小熊"),
    "star": ("asset-bundled-cover-star-v1", "星星"),
    "flower": ("asset-bundled-emote-flower-v1", "小花"),
    "heart": ("asset-bundled-emote-heart-v1", "爱心"),
}


def face_stickers_of(sequence: dict[str, Any], target_clip_id: str) -> list[tuple[dict[str, Any], dict[str, Any]]]:
    """(track, clip) pairs of the face stickers placed for `target_clip_id`."""
    found = []
    for track in sequence.get("tracks", []):
        for clip in track.get("clips", []):
            payload = clip.get("extensions", {}).get(FACE_COVER_EXTENSION)
            data = payload.get("data") if isinstance(payload, dict) else None
            if isinstance(data, dict) and data.get("targetClipId") == target_clip_id:
                found.append((track, clip))
    return found


def decimal_rational_number(value: float) -> dict[str, str]:
    """A float rounded to 1/1000, as an exact reduced rational (Project v0 forbids floats)."""
    numerator = int(round(value * 1000))
    divisor = math.gcd(abs(numerator), 1000) or 1
    return {"num": str(numerator // divisor), "den": str(1000 // divisor)}


def source_to_canvas(point: tuple[float, float], geometry: dict[str, Any]) -> tuple[float, float]:
    """Source pixels → canvas pixels through the clip's visual fit and transform (mirrors face-sticker.ts)."""
    W, H = geometry["canvasWidth"], geometry["canvasHeight"]
    w, h = geometry["sourceWidth"], geometry["sourceHeight"]
    fit = geometry.get("fit") or "contain"
    if fit == "cover":
        sx = sy = max(W / w, H / h)
    elif fit == "fill":
        sx, sy = W / w, H / h
    elif fit == "none":
        sx = sy = 1.0
    else:
        sx = sy = min(W / w, H / h)
    fx = point[0] * sx + (W - w * sx) / 2
    fy = point[1] * sy + (H - h * sy) / 2
    transform = geometry.get("transform") or {}
    scale_x = rational_seconds(transform.get("scaleX")) if transform.get("scaleX") else 1.0
    scale_y = rational_seconds(transform.get("scaleY")) if transform.get("scaleY") else 1.0
    offset_x = rational_seconds(transform.get("positionX")) if transform.get("positionX") else 0.0
    offset_y = rational_seconds(transform.get("positionY")) if transform.get("positionY") else 0.0
    return (W / 2 + (fx - W / 2) * (scale_x or 1.0) + (offset_x or 0.0), H / 2 + (fy - H / 2) * (scale_y or 1.0) + (offset_y or 0.0))


def source_scale_x(geometry: dict[str, Any]) -> float:
    W, H = geometry["canvasWidth"], geometry["canvasHeight"]
    w, h = geometry["sourceWidth"], geometry["sourceHeight"]
    fit = geometry.get("fit") or "contain"
    base = max(W / w, H / h) if fit == "cover" else W / w if fit == "fill" else 1.0 if fit == "none" else min(W / w, H / h)
    transform = geometry.get("transform") or {}
    scale = rational_seconds(transform.get("scaleX")) if transform.get("scaleX") else None
    return base * (scale if scale else 1.0)


def face_sticker_commands(
    sequence: dict[str, Any],
    target_clip: dict[str, Any],
    geometry: dict[str, Any],
    source_fps: float,
    tracks: list[dict[str, Any]],
    sticker_id: str,
    size_factor: float,
    every: int,
) -> tuple[list[dict[str, Any]], int, int]:
    """Commands that put one sticker clip (own track, position/scale keyframes) on every face track
    overlapping the target clip's source range. Returns (commands, placed, keyframes)."""
    asset_id, _ = COVER_STICKERS[sticker_id]
    rate = sequence_frame_rate_from({"sequences": [sequence]}, sequence.get("id"))
    rate_number = float(rate)
    clip_start = int(Fraction(int(target_clip["timelineRange"]["start"]["num"]), int(target_clip["timelineRange"]["start"]["den"])) * rate)
    clip_end = int(Fraction(int(target_clip["timelineRange"]["end"]["num"]), int(target_clip["timelineRange"]["end"]["den"])) * rate)
    source_range = target_clip.get("sourceRange") or {}
    source_start = rational_seconds(source_range.get("start")) or 0.0
    source_end = rational_seconds(source_range.get("end"))
    if source_end is None:
        source_end = source_start + (clip_end - clip_start) / rate_number
    W, H = geometry["canvasWidth"], geometry["canvasHeight"]
    sticker_displayed = min(W, H)
    highest = max((int(track.get("order", 0)) for track in sequence.get("tracks", [])), default=-1)
    commands: list[dict[str, Any]] = []
    placed = 0
    keyframes = 0
    fps = source_fps if source_fps > 0 else rate_number

    def frame_rational(frames: int) -> dict[str, str]:
        value = Fraction(frames) / rate
        return {"num": str(value.numerator), "den": str(value.denominator)}

    for index, track in enumerate(tracks):
        # 只检到一两次的"脸"多半是误检(树叶、花),贴上去只会闪一下。
        if int(track.get("samples", FACE_COVER_MIN_SAMPLES)) < FACE_COVER_MIN_SAMPLES:
            continue
        first_source = max(int(track["firstFrame"]), int(round(source_start * fps)))
        last_source = min(int(track["lastFrame"]), int(round(source_end * fps)) - 1)
        if last_source < first_source:
            continue
        start = clip_start + int(round((first_source / fps - source_start) * rate_number))
        end = clip_start + int(round((last_source / fps - source_start) * rate_number)) + 1
        start = max(start, clip_start)
        end = min(end, clip_end)
        if end <= start:
            continue
        span = end - start
        step = max(every, math.ceil(span / FACE_COVER_MAX_KEYFRAMES))
        suffix = uuid.uuid4().hex[:12]
        track_id = f"track-cover-{suffix}"
        sticker_clip_id = f"clip-cover-{suffix}"
        commands.append({
            "type": "track.add",
            "payload": {
                "sequenceId": sequence["id"],
                "track": {"id": track_id, "kind": "video", "order": highest + 1 + index, "role": "footage", "muted": False, "locked": False, "clips": [], "captions": [], "extensions": {}},
            },
        })
        commands.append({
            "type": "clip.add",
            "payload": {
                "sequenceId": sequence["id"],
                "trackId": track_id,
                "clip": {
                    "id": sticker_clip_id,
                    "source": {"type": "asset", "assetId": asset_id},
                    "timelineRange": {"start": frame_rational(start), "end": frame_rational(end)},
                    "sourceRange": {"start": {"num": "0", "den": "1"}, "end": frame_rational(span)},
                    "playback": {"rate": {"num": "1", "den": "1"}, "reverse": False, "freeze": False},
                    "enabled": True,
                    "effects": [],
                    "extensions": {FACE_COVER_EXTENSION: {"schemaVersion": "1", "data": {"targetClipId": target_clip["id"], "faceTrackId": int(track["id"]), "stickerId": sticker_id, "sizeFactor": str(size_factor)}}},
                },
            },
        })
        target = {"type": "clip", "sequenceId": sequence["id"], "clipId": sticker_clip_id}
        boxes = track.get("boxes", [])
        locals_ = list(range(0, span, step))
        if not locals_ or locals_[-1] != span - 1:
            locals_.append(span - 1)
        for local in locals_:
            source_frame = int(round(((start + local) - clip_start) / rate_number * fps + source_start * fps))
            source_frame = min(last_source, max(first_source, source_frame))
            box = boxes[min(len(boxes) - 1, max(0, source_frame - int(track["firstFrame"])))] if boxes else None
            if box is None:
                continue
            cx, cy = source_to_canvas((box["x"] + box["w"] / 2, box["y"] + box["h"] / 2), geometry)
            size = box["w"] * source_scale_x(geometry) * size_factor
            scale = size / sticker_displayed
            time = frame_rational(local)
            for prop, value, tag in (
                ("position", {"x": decimal_rational_number(cx - W / 2), "y": decimal_rational_number(cy - H / 2)}, "p"),
                ("scale", {"x": decimal_rational_number(scale), "y": decimal_rational_number(scale)}, "s"),
            ):
                commands.append({
                    "type": "visual.keyframe.upsert",
                    "payload": {
                        "target": target,
                        "property": prop,
                        "keyframe": {"id": f"kf-cover-{suffix}-{tag}{local}", "time": time, "value": {"type": "vector", "value": value}, "easing": "linear"},
                    },
                })
                keyframes += 1
        placed += 1
    return commands, placed, keyframes


def submit_privacy_batch(client: Any, project_id: str, commands: list[dict[str, Any]], arguments: argparse.Namespace, key_prefix: str, intent: str) -> dict[str, Any]:
    base_revision = getattr(arguments, "base_revision", None)
    if base_revision is None:
        base_revision = current_revision(client)
    key = getattr(arguments, "idempotency_key", None) or f"{key_prefix}:{uuid.uuid4()}"
    batch = {
        "commandId": key,
        "idempotencyKey": key,
        "projectId": project_id,
        "baseRevision": base_revision,
        "actor": {"type": "agent", "id": "orangecut-skill"},
        "intent": getattr(arguments, "intent", None) or intent,
        "preconditions": [],
        "mode": "commit",
        "commands": commands,
    }
    return client.request("POST", f"/v1/projects/{quote(project_id)}/commands", batch)


def apply_face_sticker_clear(
    client: Any, project_id: str, sequence: dict[str, Any], target_clip_id: str,
    stickers: list[tuple[dict[str, Any], dict[str, Any]]], arguments: argparse.Namespace,
) -> dict[str, Any]:
    commands: list[dict[str, Any]] = []
    emptied: dict[str, dict[str, Any]] = {}
    removed_ids = {clip["id"] for _, clip in stickers}
    for track, clip in stickers:
        commands.append({"type": "clip.remove", "payload": {"sequenceId": sequence["id"], "trackId": track["id"], "clipId": clip["id"]}})
        remaining = [c for c in track.get("clips", []) if c.get("id") not in removed_ids]
        if not remaining and not track.get("captions"):
            emptied[track["id"]] = track
    for track_id in emptied:
        commands.append({"type": "track.remove", "payload": {"sequenceId": sequence["id"], "trackId": track_id}})
    response = submit_privacy_batch(client, project_id, commands, arguments, "face-sticker-clear", "清除遮脸贴纸")
    return {"removedClips": len(stickers), "removedTracks": len(emptied), "revision": require_object(response, "data").get("revision")}


def apply_face_stickers(
    client: Any, project_id: str, project: dict[str, Any], sequence: dict[str, Any],
    arguments: argparse.Namespace, existing: list[tuple[dict[str, Any], dict[str, Any]]],
) -> dict[str, Any]:
    found = find_sequence_clip(sequence, arguments.clip_id)
    if found is None:
        raise CliFailure(
            "CLIP_NOT_FOUND", "preconditions",
            f"clip {arguments.clip_id!r} does not exist in sequence {sequence.get('id')!r}",
            remediation="run `oc timeline snapshot` and pass a video clip id",
            exit_code=EXIT_INVALID_INPUT,
        )
    track, clip = found
    if track.get("kind") != "video":
        raise CliFailure("CLIP_PRIVACY_TARGET_INVALID", "validation", "face stickers go on video clips", exit_code=EXIT_INVALID_INPUT)
    source = clip.get("source", {})
    asset_id = source.get("assetId") if isinstance(source, dict) else None
    asset = next((a for a in project.get("assets", []) if a.get("id") == asset_id), None)
    stream = next((st for st in (asset or {}).get("probe", {}).get("streams", []) if st.get("kind") == "video"), None)
    if asset is None or stream is None or not stream.get("width") or not stream.get("height"):
        raise CliFailure("CLIP_PRIVACY_TARGET_INVALID", "validation", "the clip's asset has no probed video geometry", exit_code=EXIT_INVALID_INPUT)
    source_fps = rational_seconds(stream.get("frameRate")) or 0.0
    size_factor = 1.5 if arguments.size_factor is None else float(arguments.size_factor)
    if not 0.2 < size_factor <= 5:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--size-factor must be between 0.2 and 5", exit_code=EXIT_INVALID_INPUT)
    payload: dict[str, Any] = {"assetId": asset_id, "projectId": project_id}
    payload.update(privacy_tracking_payload(arguments))
    tracks_result = require_object(
        client.request("POST", "/v1/media/face-tracks", payload, timeout_seconds=1800), "data"
    )
    canvas = sequence.get("canvas", {})
    geometry = {
        "canvasWidth": int(canvas.get("width")), "canvasHeight": int(canvas.get("height")),
        "sourceWidth": int(stream["width"]), "sourceHeight": int(stream["height"]),
        "fit": clip.get("visualFit") or "contain", "transform": clip.get("transform"),
    }
    every = arguments.every or 3
    commands, placed, keyframes = face_sticker_commands(
        sequence, clip, geometry, source_fps, tracks_result.get("tracks", []), arguments.sticker, size_factor, every,
    )
    if placed == 0:
        raise CliFailure(
            "FACE_STICKER_NO_FACES", "preconditions",
            "no face track overlaps the source range this clip uses; nothing to cover",
            remediation="check `oc media face-tracks` on the asset, or use --style blur with --box for a manual region",
            exit_code=EXIT_INVALID_INPUT,
        )
    # replacing = clear the old stickers in the same batch
    if existing:
        removed_ids = {c["id"] for _, c in existing}
        emptied = set()
        for t, c in existing:
            commands.insert(0, {"type": "clip.remove", "payload": {"sequenceId": sequence["id"], "trackId": t["id"], "clipId": c["id"]}})
            if not [x for x in t.get("clips", []) if x.get("id") not in removed_ids] and not t.get("captions"):
                emptied.add(t["id"])
        for t_id in emptied:
            commands.insert(len(existing), {"type": "track.remove", "payload": {"sequenceId": sequence["id"], "trackId": t_id}})
    response = submit_privacy_batch(client, project_id, commands, arguments, "face-sticker", f"给片段贴{COVER_STICKERS[arguments.sticker][1]}遮脸")
    data = require_object(response, "data")
    data["stickers"] = {
        "sticker": arguments.sticker, "placed": placed, "keyframes": keyframes, "replaced": len(existing),
        "faceTracks": [{k: t[k] for k in ("id", "firstFrame", "lastFrame", "firstSec", "lastSec", "samples") if k in t} for t in tracks_result.get("tracks", [])],
    }
    return response


FOLLOW_MAX_KEYFRAMES = 600
FOLLOW_DEFAULT_STEP = 2
# 丢失帧超过这个比例,跟出来的叠层多半会在画面上"挂"着不动——结果里点名。
FOLLOW_UNRELIABLE_LOST_RATIO = 0.3


def add_object_track_arguments(parser: argparse.ArgumentParser, *, source_pixels: bool) -> None:
    space = "source pixels" if source_pixels else "canvas pixels as `oc read` shows the frame"
    parser.add_argument(
        "--box", type=box_argument, default=None,
        help=f"the object on the reference frame, x,y,w,h in {space}: draw it snug around something with texture or edges (a flat wall cannot be followed)",
    )
    parser.add_argument(
        "--mask", type=Path, default=None,
        help="follow the white area of a mask video aligned to the source (`oc media segment --output`) instead of the built-in tracker: steadier through occlusion, rotation and shape change",
    )
    parser.add_argument(
        "--smooth", type=positive_integer, default=None,
        help="moving-average window in frames over the tracked boxes (default 5; 1 = raw)",
    )
    parser.add_argument(
        "--min-score", type=float, default=None,
        help="template match score (0..1) below which a frame counts as lost and holds the last position (default 0.5)",
    )


def object_track_payload(arguments: argparse.Namespace) -> dict[str, Any]:
    has_box = getattr(arguments, "box", None) is not None
    has_mask = getattr(arguments, "mask", None) is not None
    if has_box == has_mask:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID", "validation",
            "pass exactly one of --box (built-in tracker) or --mask (segment mask video)",
            exit_code=EXIT_INVALID_INPUT,
        )
    payload: dict[str, Any] = {}
    if has_mask:
        payload["maskPath"] = str(absolute_media_path(arguments.mask))
    if getattr(arguments, "smooth", None) is not None:
        payload["smooth"] = arguments.smooth
    if getattr(arguments, "min_score", None) is not None:
        if not 0 < arguments.min_score < 1:
            raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--min-score must be between 0 and 1", exit_code=EXIT_INVALID_INPUT)
        payload["minScore"] = arguments.min_score
    return payload


def canvas_to_source(point: tuple[float, float], geometry: dict[str, Any]) -> tuple[float, float]:
    """Canvas pixels → source pixels: the exact inverse of `source_to_canvas`."""
    W, H = geometry["canvasWidth"], geometry["canvasHeight"]
    w, h = geometry["sourceWidth"], geometry["sourceHeight"]
    fit = geometry.get("fit") or "contain"
    if fit == "cover":
        sx = sy = max(W / w, H / h)
    elif fit == "fill":
        sx, sy = W / w, H / h
    elif fit == "none":
        sx = sy = 1.0
    else:
        sx = sy = min(W / w, H / h)
    transform = geometry.get("transform") or {}
    scale_x = (rational_seconds(transform.get("scaleX")) if transform.get("scaleX") else None) or 1.0
    scale_y = (rational_seconds(transform.get("scaleY")) if transform.get("scaleY") else None) or 1.0
    offset_x = (rational_seconds(transform.get("positionX")) if transform.get("positionX") else None) or 0.0
    offset_y = (rational_seconds(transform.get("positionY")) if transform.get("positionY") else None) or 0.0
    fx = W / 2 + (point[0] - W / 2 - offset_x) / scale_x
    fy = H / 2 + (point[1] - H / 2 - offset_y) / scale_y
    return ((fx - (W - w * sx) / 2) / sx, (fy - (H - h * sy) / 2) / sy)


def clip_frame_span(clip: dict[str, Any], rate: Fraction) -> tuple[int, int]:
    """[start, end) of a clip on the timeline, in sequence frames."""
    timeline = clip["timelineRange"]
    start = Fraction(int(timeline["start"]["num"]), int(timeline["start"]["den"])) * rate
    end = Fraction(int(timeline["end"]["num"]), int(timeline["end"]["den"])) * rate
    return int(round(start)), int(round(end))


def motion_curve_value(curve: list[dict[str, Any]], local_seconds: float) -> tuple[float, float] | None:
    """A vector curve's value at clip-local seconds (linear between keyframes, held past the ends)."""
    points = []
    for keyframe in curve:
        time = rational_seconds(keyframe.get("time"))
        value = keyframe.get("value") or {}
        x, y = rational_seconds(value.get("x")), rational_seconds(value.get("y"))
        if time is None or x is None or y is None:
            continue
        points.append((time, x, y))
    if not points:
        return None
    points.sort()
    if local_seconds <= points[0][0]:
        return points[0][1], points[0][2]
    for (t0, x0, y0), (t1, x1, y1) in zip(points, points[1:]):
        if t0 <= local_seconds <= t1:
            ratio = 0.0 if t1 == t0 else (local_seconds - t0) / (t1 - t0)
            return x0 + (x1 - x0) * ratio, y0 + (y1 - y0) * ratio
    return points[-1][1], points[-1][2]


def follow_motion_command(
    sequence_id: str, clip_id: str, motion: dict[str, Any] | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {"target": {"type": "clip", "sequenceId": sequence_id, "clipId": clip_id}}
    if motion:
        payload["motion"] = motion
    return {"type": "visual.motion.replace", "payload": payload}


def apply_follow(
    client: Any, project_id: str, project: dict[str, Any], sequence: dict[str, Any], arguments: argparse.Namespace,
) -> dict[str, Any]:
    found = find_sequence_clip(sequence, arguments.clip_id)
    if found is None:
        raise CliFailure(
            "CLIP_NOT_FOUND", "preconditions",
            f"clip {arguments.clip_id!r} does not exist in sequence {sequence.get('id')!r}",
            remediation="run `oc timeline snapshot` (or `oc sticker list` / `oc shape list`) and pass the overlay clip id",
            exit_code=EXIT_INVALID_INPUT,
        )
    overlay_track, overlay = found
    existing_motion = dict(overlay.get("motion") or {})
    if arguments.clear:
        if not (existing_motion.get("position") or existing_motion.get("scale")):
            raise CliFailure(
                "FOLLOW_NOT_PRESENT", "preconditions",
                f"clip {arguments.clip_id!r} has no position or scale keyframes to clear",
                exit_code=EXIT_INVALID_INPUT,
            )
        kept = {k: v for k, v in existing_motion.items() if k not in ("position", "scale")}
        if not (kept.get("rotationDegrees") or kept.get("opacity")):
            kept = {}
        command = follow_motion_command(sequence["id"], overlay["id"], kept or None)
        response = submit_privacy_batch(client, project_id, [command], arguments, "follow-clear", "清除跟随关键帧")
        data = require_object(response, "data")
        data["follow"] = {"clipId": overlay["id"], "cleared": True}
        return response
    if not arguments.target:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--target <video clip id> is required (the clip whose picture holds the object)", exit_code=EXIT_INVALID_INPUT)
    if arguments.target == arguments.clip_id:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "the overlay cannot follow an object inside itself", exit_code=EXIT_INVALID_INPUT)
    track_options = object_track_payload(arguments)
    target_found = find_sequence_clip(sequence, arguments.target)
    if target_found is None:
        raise CliFailure("CLIP_NOT_FOUND", "preconditions", f"target clip {arguments.target!r} does not exist", exit_code=EXIT_INVALID_INPUT)
    target_track, target = target_found
    source = target.get("source") or {}
    asset_id = source.get("assetId") if isinstance(source, dict) else None
    asset = next((a for a in project.get("assets", []) if a.get("id") == asset_id), None)
    stream = next((st for st in (asset or {}).get("probe", {}).get("streams", []) if st.get("kind") == "video"), None)
    if target_track.get("kind") != "video" or asset is None or stream is None or not stream.get("width") or not stream.get("height"):
        raise CliFailure(
            "FOLLOW_TARGET_INVALID", "validation",
            "the target must be a video clip whose asset has probed video geometry",
            exit_code=EXIT_INVALID_INPUT,
        )
    playback = target.get("playback") or {}
    playback_rate = rational_seconds(playback.get("rate")) if playback.get("rate") else 1.0
    if playback.get("reverse") or playback.get("freeze") or (playback_rate is not None and abs(playback_rate - 1.0) > 1e-9):
        raise CliFailure(
            "FOLLOW_TARGET_RETIMED", "validation",
            "the target clip is retimed (speed, reverse or freeze); its picture no longer maps frame for frame onto the source",
            remediation="follow on the clip at 100% speed first, then retime; or place an un-retimed copy to track against",
            exit_code=EXIT_INVALID_INPUT,
        )
    rate = sequence_frame_rate_from({"sequences": [sequence], "settings": {}}, sequence.get("id"))
    rate_number = float(rate)
    source_fps = rational_seconds(stream.get("frameRate")) or rate_number
    target_start, target_end = clip_frame_span(target, rate)
    overlay_start, overlay_end = clip_frame_span(overlay, rate)
    span_start, span_end = max(target_start, overlay_start), min(target_end, overlay_end)
    if span_end <= span_start:
        raise CliFailure(
            "FOLLOW_NO_OVERLAP", "preconditions",
            f"the overlay [{overlay_start}, {overlay_end}) and the target [{target_start}, {target_end}) never share a frame",
            remediation="move the overlay so it sits over the target clip in time",
            exit_code=EXIT_INVALID_INPUT,
        )
    source_range = target.get("sourceRange") or {}
    source_start = rational_seconds(source_range.get("start")) or 0.0

    def source_frame(timeline_frame: int) -> int:
        return int(round((source_start + (timeline_frame - target_start) / rate_number) * source_fps))

    def timeline_frame_of(source_index: int) -> int:
        return target_start + int(round((source_index / source_fps - source_start) * rate_number))

    canvas = sequence.get("canvas", {})
    geometry = {
        "canvasWidth": int(canvas.get("width")), "canvasHeight": int(canvas.get("height")),
        "sourceWidth": int(stream["width"]), "sourceHeight": int(stream["height"]),
        "fit": target.get("visualFit") or "contain", "transform": target.get("transform"),
    }
    W, H = geometry["canvasWidth"], geometry["canvasHeight"]
    warnings: list[dict[str, Any]] = []
    target_motion = target.get("motion") or {}
    if target_motion.get("position") or target_motion.get("scale"):
        warnings.append({
            "code": "FOLLOW_TARGET_ANIMATED",
            "message": "the target clip has its own position/scale keyframes; the follow maps through its static transform only, so the overlay will drift by the target's animation",
        })
    payload: dict[str, Any] = {"assetId": asset_id, "projectId": project_id}
    payload.update(track_options)
    reference_timeline = arguments.at_frame if arguments.at_frame is not None else span_start
    if arguments.box is not None:
        if not span_start <= reference_timeline < span_end:
            raise CliFailure(
                "FOLLOW_REFERENCE_OUTSIDE", "validation",
                f"--at-frame {reference_timeline} must lie where the overlay and the target overlap: [{span_start}, {span_end})",
                exit_code=EXIT_INVALID_INPUT,
            )
        x, y, w, h = arguments.box
        left, top = canvas_to_source((x, y), geometry)
        right, bottom = canvas_to_source((x + w, y + h), geometry)
        left, right = sorted((left, right))
        top, bottom = sorted((top, bottom))
        left, top = max(0.0, left), max(0.0, top)
        right, bottom = min(float(geometry["sourceWidth"]), right), min(float(geometry["sourceHeight"]), bottom)
        if right - left < 4 or bottom - top < 4:
            raise CliFailure(
                "FOLLOW_BOX_OUTSIDE_PICTURE", "validation",
                "the --box does not cover at least 4×4 pixels of the target's picture; draw it on the object as `oc read` shows it",
                exit_code=EXIT_INVALID_INPUT,
            )
        payload["box"] = [round(left, 2), round(top, 2), round(right - left, 2), round(bottom - top, 2)]
        payload["frame"] = source_frame(reference_timeline)
    first_source = source_frame(span_start)
    payload["fromFrame"] = max(0, first_source)
    payload["toFrame"] = max(payload["fromFrame"] + 1, source_frame(span_end - 1) + 1)
    if "frame" in payload:
        payload["frame"] = min(max(payload["frame"], payload["fromFrame"]), payload["toFrame"] - 1)
    track = require_object(client.request("POST", "/v1/media/object-track", payload, timeout_seconds=1800), "data")
    boxes = track.get("boxes") or []
    if not boxes:
        raise CliFailure("FOLLOW_TRACK_EMPTY", "media", "the tracker returned no boxes for this range", exit_code=EXIT_INVALID_INPUT)
    first_box_frame = int(boxes[0]["frame"])

    def box_at(source_index: int) -> dict[str, Any]:
        return boxes[min(len(boxes) - 1, max(0, source_index - first_box_frame))]

    def canvas_box(b: dict[str, Any]) -> tuple[float, float, float, float]:
        cx, cy = source_to_canvas((b["x"] + b["w"] / 2, b["y"] + b["h"] / 2), geometry)
        return cx, cy, b["w"], b["h"]

    reference_source = int(track.get("referenceFrame", payload.get("frame", first_box_frame)))
    ref_cx, ref_cy, ref_w, ref_h = canvas_box(box_at(reference_source))
    reference_local = max(0, timeline_frame_of(reference_source) - overlay_start)
    transform = overlay.get("transform") or {}
    time_offset = rational_seconds(existing_motion.get("timeOffset")) or 0.0
    if arguments.center:
        offset = (0.0, 0.0)
    elif arguments.offset is not None:
        offset = (float(arguments.offset[0]), float(arguments.offset[1]))
    else:
        current = motion_curve_value(existing_motion.get("position") or [], reference_local / rate_number + time_offset)
        if current is None:
            current = (
                rational_seconds(transform.get("positionX")) or 0.0 if transform.get("positionX") else 0.0,
                rational_seconds(transform.get("positionY")) or 0.0 if transform.get("positionY") else 0.0,
            )
        offset = (current[0] - (ref_cx - W / 2), current[1] - (ref_cy - H / 2))
    base_scale_x = (rational_seconds(transform.get("scaleX")) if transform.get("scaleX") else None) or 1.0
    base_scale_y = (rational_seconds(transform.get("scaleY")) if transform.get("scaleY") else None) or 1.0

    overlay_length = overlay_end - overlay_start
    step = max(arguments.step or FOLLOW_DEFAULT_STEP, math.ceil(overlay_length / FOLLOW_MAX_KEYFRAMES))
    locals_ = list(range(0, overlay_length, step))
    if locals_[-1] != overlay_length - 1:
        locals_.append(overlay_length - 1)
    suffix = uuid.uuid4().hex[:8]
    position_curve: list[dict[str, Any]] = []
    scale_curve: list[dict[str, Any]] = []
    for local in locals_:
        timeline_index = min(max(overlay_start + local, span_start), span_end - 1)
        cx, cy, w, h = canvas_box(box_at(source_frame(timeline_index)))
        time_value = Fraction(local) / rate + Fraction(time_offset).limit_denominator(1_000_000)
        time = {"num": str(time_value.numerator), "den": str(time_value.denominator)}
        position_curve.append({
            "id": f"kf-follow-{suffix}-p{local}", "time": time, "easing": "linear",
            "value": {"x": decimal_rational_number(cx - W / 2 + offset[0]), "y": decimal_rational_number(cy - H / 2 + offset[1])},
        })
        if arguments.scale != "none":
            if arguments.scale == "uniform":
                ratio = math.sqrt(max(w * h, 1e-6) / max(ref_w * ref_h, 1e-6))
                sx, sy = base_scale_x * ratio, base_scale_y * ratio
            else:
                sx, sy = base_scale_x * w / max(ref_w, 1e-6), base_scale_y * h / max(ref_h, 1e-6)
            scale_curve.append({
                "id": f"kf-follow-{suffix}-s{local}", "time": time, "easing": "linear",
                "value": {"x": decimal_rational_number(sx), "y": decimal_rational_number(sy)},
            })
    motion = {k: v for k, v in existing_motion.items() if k in ("timeOffset", "rotationDegrees", "opacity") and v}
    motion["position"] = position_curve
    if scale_curve:
        motion["scale"] = scale_curve
    elif existing_motion.get("scale"):
        motion["scale"] = existing_motion["scale"]
    response = submit_privacy_batch(
        client, project_id, [follow_motion_command(sequence["id"], overlay["id"], motion)], arguments,
        "follow", "叠层跟随画面里的物体",
    )
    lost_frames = int(track.get("lostFrames", 0))
    tracked = len(boxes)
    if tracked and lost_frames / tracked > FOLLOW_UNRELIABLE_LOST_RATIO:
        warnings.append({
            "code": "FOLLOW_TRACK_UNRELIABLE",
            "message": f"the object was lost on {lost_frames} of {tracked} frames; the overlay holds still there",
            "remediation": "redraw --box on a clearer frame (--at-frame), lower --min-score, or segment the object (`oc media segment`) and pass --mask",
        })
    data = require_object(response, "data")
    data["follow"] = {
        "clipId": overlay["id"],
        "targetClipId": target["id"],
        "method": track.get("method"),
        "referenceFrame": timeline_frame_of(reference_source),
        "offset": [round(offset[0], 2), round(offset[1], 2)],
        "scale": arguments.scale,
        "positionKeyframes": len(position_curve),
        "scaleKeyframes": len(scale_curve),
        "trackedFrames": tracked,
        "lostFrames": lost_frames,
        "lostSpans": [[timeline_frame_of(int(a)), timeline_frame_of(int(b))] for a, b in track.get("lostSpans", [])],
        "meanScore": track.get("meanScore"),
    }
    if warnings:
        data.setdefault("warnings", []).extend(warnings)
    return response


OVERLAY_DEFAULT_WIDTH_SHARE = Fraction(30, 100)
OVERLAY_SOURCE_SUFFIXES = (".gif", ".png", ".apng", ".webp", ".webm", ".mov", ".mkv", ".mp4")


def overlay_asset_size(asset: dict[str, Any]) -> tuple[int, int] | None:
    for stream in (asset.get("probe") or {}).get("streams") or []:
        if isinstance(stream, dict) and stream.get("kind") == "video" and stream.get("width") and stream.get("height"):
            return int(stream["width"]), int(stream["height"])
    return None


def overlay_asset_frames(asset: dict[str, Any], rate: Fraction) -> int | None:
    duration = rational_seconds((asset.get("probe") or {}).get("duration"))
    return int(Fraction(duration).limit_denominator(1_000_000) * rate) if duration else None


def apply_overlay_add(client: Any, project_id: str, arguments: argparse.Namespace) -> dict[str, Any]:
    snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
    project = require_object(require_object(snapshot, "data"), "project")
    sequence_id = arguments.sequence_id or default_sequence_id(project)
    sequence = require_sequence(project, sequence_id)
    rate = sequence_frame_rate_from(project, sequence_id)
    canvas = sequence.get("canvas") or {}
    canvas_w, canvas_h = int(canvas.get("width")), int(canvas.get("height"))
    conversion: dict[str, Any] | None = None
    source_path = Path(arguments.source).expanduser()
    asset_id: str | None = None
    if source_path.suffix.lower() in OVERLAY_SOURCE_SUFFIXES or source_path.is_file():
        resolved = absolute_media_path(source_path)
        payload: dict[str, Any] = {
            "path": str(resolved),
            "output": str(Path(tempfile.gettempdir()) / f"oc-overlay-{uuid.uuid4().hex[:12]}.webm"),
        }
        if arguments.duration_frames is not None and not arguments.no_loop:
            payload["seconds"] = float(Fraction(arguments.duration_frames) / rate)
        fps = rate.numerator / rate.denominator
        if abs(fps - round(fps)) < 1e-9 and 1 <= round(fps) <= 60:
            payload["fps"] = int(round(fps))
        conversion = require_object(client.request("POST", "/v1/media/overlay", payload, timeout_seconds=900), "data")
        base_revision = current_revision(client)
        try:
            imported = client.request(
                "POST", f"/v1/projects/{quote(project_id)}/assets/import",
                {"baseRevision": base_revision, "paths": [conversion["output"]], "intent": "导入动态贴纸",
                 "idempotencyKey": f"overlay-import:{uuid.uuid4()}", "expectedKind": "video"},
                timeout_seconds=IMPORT_TIMEOUT_SECONDS,
            )
            first = (require_object(imported, "data").get("assets") or [{}])[0]
            asset_id = first.get("assetId") or first.get("id")
        except CliFailure as failure:
            # 同一个贴纸以同样长度再放一次:转出来的字节一样,素材库里已经有了,直接复用。
            if failure.code != "ASSET_ALREADY_IMPORTED":
                raise
            asset_id = (failure.details or {}).get("assetId")
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence = require_sequence(project, sequence_id)
    else:
        asset_id = arguments.source
    asset = next((a for a in project.get("assets", []) if a.get("id") == asset_id), None)
    if asset is None or asset.get("kind") != "video":
        raise CliFailure(
            "OVERLAY_SOURCE_INVALID", "validation",
            f"{arguments.source!r} is neither a readable sticker file nor a video asset of this project",
            remediation="pass an absolute .gif/.png/.webp/.webm/.mov path, or a video asset id from `oc asset list`",
            exit_code=EXIT_INVALID_INPUT,
        )
    size = overlay_asset_size(asset)
    if size is None and conversion is not None:
        size = (int(conversion["width"]), int(conversion["height"]))
    if size is None:
        raise CliFailure("OVERLAY_SOURCE_INVALID", "validation", "the asset has no probed picture size", exit_code=EXIT_INVALID_INPUT)
    available = overlay_asset_frames(asset, rate)
    if available is None and conversion is not None:
        available = int(round(conversion["seconds"] * float(rate)))
    wanted = arguments.duration_frames or available or int(rate * 3)
    length = min(wanted, available) if available else wanted
    if length <= 0:
        raise CliFailure("OVERLAY_SOURCE_INVALID", "validation", "the sticker has no frames to place", exit_code=EXIT_INVALID_INPUT)
    start = Fraction(arguments.at_frame) / rate
    span = Fraction(length) / rate
    commands: list[dict[str, Any]] = []
    track_id = arguments.track_id
    if track_id is None:
        track_id = f"track-overlay-{uuid.uuid4().hex[:12]}"
        commands.extend(visual_track_add_commands(sequence, sequence_id, track_id, "overlay", "overlay"))
    clip_id = f"clip-overlay-{uuid.uuid4().hex[:12]}"
    commands.append({
        "type": "clip.add",
        "payload": {
            "sequenceId": sequence_id,
            "trackId": track_id,
            "clip": {
                "id": clip_id, "enabled": True,
                "timelineRange": {"start": rational_wire(start), "end": rational_wire(start + span)},
                "sourceRange": {"start": rational_wire(Fraction(0)), "end": rational_wire(span)},
                "source": {"type": "asset", "assetId": asset_id},
                "playback": {"rate": {"num": "1", "den": "1"}, "reverse": False, "freeze": False},
                "effects": [], "extensions": {},
            },
        },
    })
    # 资产按 contain 铺满画布再缩放:先算铺满时的宽,再缩到想要的宽。
    contain = min(Fraction(canvas_w, size[0]), Fraction(canvas_h, size[1]))
    target_width = Fraction(arguments.width).limit_denominator(1000) if arguments.width else Fraction(min(canvas_w, canvas_h)) * OVERLAY_DEFAULT_WIDTH_SHARE
    if target_width <= 0:
        raise CliFailure("CLI_ARGUMENT_INVALID", "validation", "--width must be positive", exit_code=EXIT_INVALID_INPUT)
    scale = (target_width / (Fraction(size[0]) * contain)).limit_denominator(100000)
    commands.append({
        "type": "clip.transform.set",
        "payload": {
            "sequenceId": sequence_id, "clipId": clip_id,
            "transform": {
                "positionX": rational_wire(Fraction(arguments.x).limit_denominator(1000)),
                "positionY": rational_wire(Fraction(arguments.y).limit_denominator(1000)),
                "scaleX": rational_wire(scale), "scaleY": rational_wire(scale),
                "rotationDegrees": rational_wire(Fraction(0)), "opacity": rational_wire(Fraction(1)),
            },
        },
    })
    response = submit_privacy_batch(client, project_id, commands, arguments, "overlay-add", arguments.intent)
    data = require_object(response, "data")
    data["overlay"] = {
        "clipId": clip_id, "trackId": track_id, "assetId": asset_id,
        "startFrame": arguments.at_frame, "durationFrames": length,
        "widthPx": float(target_width), "conversion": conversion,
    }
    warnings = []
    if conversion is not None and not conversion.get("hasAlpha"):
        warnings.append({
            "code": "OVERLAY_NOT_TRANSPARENT",
            "message": "the sticker has no transparent pixels, so it will cover the footage as a rectangle",
            "remediation": "use a GIF/APNG/WebP with a transparent background, or cut the subject out first (`oc media matte`)",
        })
    if arguments.duration_frames and length < arguments.duration_frames:
        warnings.append({
            "code": "OVERLAY_SHORTER_THAN_ASKED",
            "message": f"the sticker only has {length} frames; it ends before the {arguments.duration_frames} asked for",
        })
    if warnings:
        data.setdefault("warnings", []).extend(warnings)
    return response


AUDIO_MIX_EFFECT_TYPE = "dev.orangecut.audio.mix"
LOUDNESS_DEFAULT_MAX_BOOST_DB = 12.0
LOUDNESS_MIN_GAIN_DB = -60.0


def find_sequence_clip(
    sequence: dict[str, Any], clip_id: str
) -> tuple[dict[str, Any], dict[str, Any]] | None:
    """The (track, clip) pair carrying `clip_id`, or None."""
    for track in sequence.get("tracks", []):
        if not isinstance(track, dict):
            continue
        for clip in track.get("clips", []):
            if isinstance(clip, dict) and clip.get("id") == clip_id:
                return track, clip
    return None


def rational_seconds(value: Any) -> float | None:
    if not isinstance(value, dict):
        return None
    try:
        return float(Fraction(int(value["num"]), int(value["den"])))
    except (KeyError, TypeError, ValueError, ZeroDivisionError):
        return None


def clip_gain_percent(clip: dict[str, Any]) -> int:
    """The Clip's static mix gain as a whole percent; no mix effect reads as 100."""
    for effect in clip.get("effects", []):
        if not isinstance(effect, dict) or effect.get("effectType") != AUDIO_MIX_EFFECT_TYPE:
            continue
        gain = rational_seconds(effect.get("parameters", {}).get("gain"))
        if gain is not None and gain >= 0:
            return int(round(gain * 100))
    return 100


def gain_percent_db(percent: int) -> float | None:
    """Linear percent → dB; 0 (mute) has no dB figure."""
    if percent <= 0:
        return None
    return 20.0 * math.log10(percent / 100.0)


def loudness_gain_plan(
    measured_lufs: float, target_lufs: float, max_boost_db: float
) -> dict[str, Any]:
    """The static gain that lands `measured_lufs` on `target_lufs`.

    Measured is the source's own loudness (gain not applied), so the answer is
    simply the difference — clamped: never below -60 dB (that is mute), never
    above `max_boost_db` (a source that far under target is noise, boosting it
    brings the hiss up with the voice; say so instead of pretending).
    """
    wanted_db = target_lufs - measured_lufs
    applied_db = min(max(wanted_db, LOUDNESS_MIN_GAIN_DB), max_boost_db)
    percent = int(round(100.0 * 10 ** (applied_db / 20.0)))
    percent = max(0, min(percent, 1000))
    return {
        "gainDb": round(applied_db, 2),
        "gainPercent": percent,
        "wantedDb": round(wanted_db, 2),
        "clamped": abs(applied_db - wanted_db) > 1e-9,
        "maxBoostDb": max_boost_db,
        "expectedLufs": round(measured_lufs + applied_db, 2),
    }


def measure_clip_loudness(
    client: Any, project_id: str, sequence: dict[str, Any], clip_id: str
) -> dict[str, Any]:
    """`oc audio measure`: the Clip's asset over exactly its source range, plus
    what it lands at after the Clip's own static gain."""
    found = find_sequence_clip(sequence, clip_id)
    if found is None:
        raise CliFailure(
            "AUDIO_CLIP_NOT_FOUND",
            "preconditions",
            f"clip {clip_id!r} does not exist in sequence {sequence.get('id')!r}",
            remediation="run `oc timeline snapshot` and pass a sound clip id",
            exit_code=EXIT_INVALID_INPUT,
        )
    track, clip = found
    source = clip.get("source", {})
    asset_id = source.get("assetId") if isinstance(source, dict) else None
    if not isinstance(asset_id, str) or not asset_id:
        raise CliFailure(
            "AUDIO_CLIP_NOT_MEASURABLE",
            "preconditions",
            f"clip {clip_id!r} does not play an asset, so it has no sound to measure",
            exit_code=EXIT_INVALID_INPUT,
        )
    source_range = clip.get("sourceRange") if isinstance(clip.get("sourceRange"), dict) else {}
    from_sec = rational_seconds(source_range.get("start"))
    to_sec = rational_seconds(source_range.get("end"))
    payload: dict[str, Any] = {"assetId": asset_id, "projectId": project_id}
    if from_sec is not None:
        payload["fromSec"] = from_sec
    if to_sec is not None and (from_sec is None or to_sec > from_sec):
        payload["toSec"] = to_sec
    response = client.request("POST", "/v1/media/loudness", payload, timeout_seconds=600)
    data = require_object(response, "data")
    gain_percent = clip_gain_percent(clip)
    gain_db = gain_percent_db(gain_percent)
    integrated = data.get("integratedLufs")
    data["clipId"] = clip_id
    data["trackId"] = track.get("id")
    data["assetId"] = asset_id
    data["gainPercent"] = gain_percent
    data["gainDb"] = None if gain_db is None else round(gain_db, 2)
    data["effectiveLufs"] = (
        None
        if integrated is None or gain_db is None
        else round(float(integrated) + gain_db, 2)
    )
    return response


def default_sequence_id(project: dict[str, Any]) -> str:
    sequences = project.get("sequences")
    if not isinstance(sequences, list) or not sequences:
        raise CliFailure(
            "TIMELINE_SEQUENCE_NOT_FOUND",
            "preconditions",
            "the active Project has no sequence to export",
            remediation="create or open a Project with a timeline sequence",
            exit_code=EXIT_INVALID_INPUT,
        )
    first = sequences[0]
    if not isinstance(first, dict):
        raise CliFailure(
            "PROTOCOL_FIELD_INVALID",
            "serialization",
            "the first Project sequence is invalid",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )
    return require_text(first, "id")


def require_sequence(project: dict[str, Any], sequence_id: str) -> dict[str, Any]:
    sequences = project.get("sequences")
    if isinstance(sequences, list):
        for item in sequences:
            if isinstance(item, dict) and item.get("id") == sequence_id:
                return item
    raise CliFailure(
        "TIMELINE_SEQUENCE_NOT_FOUND",
        "preconditions",
        f"sequence {sequence_id} does not exist in the active Project",
        exit_code=EXIT_INVALID_INPUT,
    )


def split_clips_crossing_gap(
    client: Any,
    project_id: str,
    sequence_id: str,
    at_frame: int,
    at_time: Fraction,
) -> None:
    """`gap-insert --split-crossing` 的前置:把横跨缝位的 clip 逐个切开。

    切分走服务端 timeline/split(联动画音对由它原子处理),视觉零损——
    失败中途留下的切点不改变任何渲染结果。每切一刀重新取快照,直到缝位上
    没有横跨的 clip。字幕没有 split 命令,横跨的字幕明确报错让调用方自己
    调整,不做"一半语义"。
    """
    for _ in range(64):
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        sequence = require_sequence(project, sequence_id)

        def crossing(entity: dict[str, Any]) -> bool:
            wire = entity.get("timelineRange") or {}
            start = _rational_of(wire.get("start"))
            end = _rational_of(wire.get("end"))
            return start < at_time < end

        blocked_captions = [
            str(caption.get("id"))
            for track in sequence.get("tracks", [])
            for caption in track.get("captions", [])
            if crossing(caption)
        ]
        if blocked_captions:
            raise CliFailure(
                "GAP_CAPTION_CROSSING", "preconditions",
                f"captions {', '.join(blocked_captions)} straddle the gap position "
                "and captions cannot be split",
                remediation="shorten or move those captions first, then retry",
                exit_code=EXIT_INVALID_INPUT,
            )
        crossing_clips = [
            clip
            for track in sequence.get("tracks", [])
            for clip in track.get("clips", [])
            if crossing(clip)
        ]
        if not crossing_clips:
            return
        clip = crossing_clips[0]
        # 带效果的片段以前在这里被挡下(clip.split 拒绝效果栈)。现在切分会
        # 把效果按新 ID 复制给右半段,这条前置检查因此取消。
        client.request(
            "POST",
            f"/v1/projects/{quote(project_id)}/timeline/split",
            {
                "baseRevision": require_integer(project, "revision"),
                "clipId": clip.get("id"),
                "sequenceId": sequence_id,
                "timelineFrame": at_frame,
                "intent": "为插入间隙切开横跨缝位的片段",
                "idempotencyKey": f"gap-split:{uuid.uuid4()}",
            },
        )
    raise CliFailure(
        "GAP_SPLIT_DID_NOT_CONVERGE", "runtime",
        "splitting crossing clips did not converge after 64 rounds",
        exit_code=EXIT_SERVICE_UNAVAILABLE,
    )


def filter_snapshot_response(
    response: Any,
    *,
    sequence_id: str | None = None,
    track_ids: str | None = None,
    kinds: str | None = None,
    drop_assets: bool = False,
) -> Any:
    """`timeline snapshot` 的本地投影:大工程整包 JSON 很沉,常常只要某
    一轨的 clips。过滤纯在 CLI 端做,服务照旧返回全量;没给任何过滤参数
    时原样透传。被过滤过的输出带 `snapshotFilter` 说明,免得下游把残缺
    工程当完整的用。
    """
    if not (sequence_id or track_ids or kinds or drop_assets):
        return response
    if not isinstance(response, dict):
        return response
    data = response.get("data")
    project = data.get("project") if isinstance(data, dict) else None
    if not isinstance(project, dict):
        return response
    wanted_tracks = (
        {item.strip() for item in track_ids.split(",") if item.strip()}
        if track_ids else None
    )
    wanted_kinds = (
        {item.strip().lower() for item in kinds.split(",") if item.strip()}
        if kinds else None
    )

    def keep_track(track: Any) -> bool:
        if not isinstance(track, dict):
            return False
        if wanted_tracks is not None and str(track.get("id")) not in wanted_tracks:
            return False
        if wanted_kinds is not None and str(track.get("kind", "")).lower() not in wanted_kinds:
            return False
        return True

    sequences = project.get("sequences")
    if isinstance(sequences, list):
        kept_sequences = []
        for sequence in sequences:
            if not isinstance(sequence, dict):
                continue
            if sequence_id and sequence.get("id") != sequence_id:
                continue
            if wanted_tracks is not None or wanted_kinds is not None:
                sequence = dict(sequence)
                sequence["tracks"] = [
                    track for track in sequence.get("tracks", []) if keep_track(track)
                ]
            kept_sequences.append(sequence)
        project = dict(project)
        project["sequences"] = kept_sequences
    if drop_assets:
        project = dict(project)
        project["assets"] = []
    data = dict(data)
    data["project"] = project
    data["snapshotFilter"] = {
        key: value
        for key, value in (
            ("sequenceId", sequence_id),
            ("tracks", sorted(wanted_tracks) if wanted_tracks else None),
            ("kinds", sorted(wanted_kinds) if wanted_kinds else None),
            ("assetsDropped", True if drop_assets else None),
        )
        if value is not None
    }
    response = dict(response)
    response["data"] = data
    return response


def require_complete_retry_identity(arguments: argparse.Namespace) -> None:
    has_base_revision = arguments.base_revision is not None
    has_idempotency_key = arguments.idempotency_key is not None
    if has_base_revision == has_idempotency_key:
        return
    raise CliFailure(
        "CLI_ARGUMENT_INVALID",
        "validation",
        "--base-revision and --idempotency-key must be provided together",
        remediation="omit both for a new request, or reuse both unchanged for an exact retry",
        exit_code=EXIT_INVALID_INPUT,
    )


def text_style_payload(
    arguments: argparse.Namespace, *, patch: bool = False
) -> dict[str, Any]:
    mappings = (
        ("font_asset_id", "fontAssetId"),
        ("font_size", "fontSizePx"),
        ("color", "color"),
        ("font_weight", "fontWeight"),
        ("font_style", "fontStyle"),
        ("underline", "underline"),
        ("align", "textAlign"),
        ("position", "position"),
        ("x", "positionX"),
        ("y", "positionY"),
        ("scale_percent", "scalePercent"),
        ("rotation", "rotationDegrees"),
        ("outline_color", "outlineColor"),
        ("outline_width", "outlineWidthPx"),
        ("background_color", "backgroundColor"),
        ("background_radius", "backgroundCornerRadiusPx"),
        ("background_padding", "backgroundPaddingPx"),
        ("shadow_color", "shadowColor"),
        ("shadow_x", "shadowOffsetX"),
        ("shadow_y", "shadowOffsetY"),
        ("shadow_blur", "shadowBlurPx"),
        ("highlight", "highlightMode"),
        ("highlight_color", "highlightColor"),
    )
    result = {
        wire_name: getattr(arguments, argument_name)
        for argument_name, wire_name in mappings
        if hasattr(arguments, argument_name)
    }
    if not patch and not result.get("fontAssetId"):
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            "--font-asset-id is required when adding text",
            exit_code=EXIT_INVALID_INPUT,
        )
    return result


def text_sticker_payload(
    arguments: argparse.Namespace,
) -> tuple[dict[str, Any], dict[str, Any]]:
    style_mappings = (
        ("font_asset_id", "fontAssetId"),
        ("font_size", "fontSizePx"),
        ("letter_spacing", "letterSpacingPx"),
        ("line_height_percent", "lineHeightPercent"),
        ("color", "color"),
        ("font_weight", "fontWeight"),
        ("font_style", "fontStyle"),
        ("align", "textAlign"),
        ("outline_color", "outlineColor"),
        ("outline_width", "outlineWidthPx"),
        ("background_color", "backgroundColor"),
        ("background_radius", "backgroundCornerRadiusPx"),
        ("background_padding", "backgroundPaddingPx"),
        ("background_radius", "backgroundCornerRadiusPx"),
        ("shadow_color", "shadowColor"),
        ("shadow_x", "shadowOffsetX"),
        ("shadow_y", "shadowOffsetY"),
        ("shadow_blur", "shadowBlurPx"),
        ("enter", "enterAnimation"),
        ("enter_frames", "enterDurationFrames"),
        ("exit", "exitAnimation"),
        ("exit_frames", "exitDurationFrames"),
    )
    placement_mappings = (
        ("x", "positionX"),
        ("y", "positionY"),
        ("scale_percent", "scalePercent"),
        ("rotation", "rotationDegrees"),
        ("opacity_percent", "opacityPercent"),
    )
    style = {
        wire_name: getattr(arguments, argument_name)
        for argument_name, wire_name in style_mappings
        if hasattr(arguments, argument_name)
    }
    placement = {
        wire_name: getattr(arguments, argument_name)
        for argument_name, wire_name in placement_mappings
        if hasattr(arguments, argument_name)
    }
    return style, placement


def shape_payload(
    arguments: argparse.Namespace,
) -> tuple[dict[str, Any], dict[str, Any]]:
    style_mappings = (
        ("kind", "kind"),
        ("width", "widthPx"),
        ("height", "heightPx"),
        ("fill_color", "fillColor"),
        ("stroke_color", "strokeColor"),
        ("stroke_width", "strokeWidthPx"),
        ("shadow_color", "shadowColor"),
        ("shadow_x", "shadowOffsetX"),
        ("shadow_y", "shadowOffsetY"),
        ("shadow_blur", "shadowBlurPx"),
    )
    placement_mappings = (
        ("x", "positionX"),
        ("y", "positionY"),
        ("scale_percent", "scalePercent"),
        ("rotation", "rotationDegrees"),
        ("opacity_percent", "opacityPercent"),
    )
    style = {
        wire_name: getattr(arguments, argument_name)
        for argument_name, wire_name in style_mappings
        if hasattr(arguments, argument_name)
    }
    placement = {
        wire_name: getattr(arguments, argument_name)
        for argument_name, wire_name in placement_mappings
        if hasattr(arguments, argument_name)
    }
    if arguments.shape_command == "add":
        style.pop("kind", None)
    return style, placement


def keyframe_target_payload(
    arguments: argparse.Namespace, sequence_id: str
) -> dict[str, str]:
    if arguments.target_type == "clip":
        if arguments.track_id is not None:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                "--track-id is only valid for a Caption keyframe target",
                remediation="remove --track-id or pass --target-type caption",
                exit_code=EXIT_INVALID_INPUT,
            )
        return {
            "type": "clip",
            "sequenceId": sequence_id,
            "clipId": arguments.target_id,
        }
    if arguments.track_id is None:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            "a Caption keyframe target requires --track-id",
            remediation="pass the Caption Track ID shown by `oc caption list --json`",
            exit_code=EXIT_INVALID_INPUT,
        )
    return {
        "type": "caption",
        "sequenceId": sequence_id,
        "trackId": arguments.track_id,
        "captionId": arguments.target_id,
    }


def keyframe_value_payload(arguments: argparse.Namespace) -> dict[str, Any]:
    vector_property = arguments.property in ("position", "scale")
    if vector_property:
        if (
            arguments.x is None
            or arguments.y is None
            or arguments.value is not None
        ):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                f"{arguments.property} requires --x and --y, without --value",
                remediation="pass both vector components as ordinary decimals",
                exit_code=EXIT_INVALID_INPUT,
            )
        if arguments.property == "scale" and (
            int(arguments.x["num"]) <= 0 or int(arguments.y["num"]) <= 0
        ):
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                "scale keyframe components must both be greater than zero",
                exit_code=EXIT_INVALID_INPUT,
            )
        return {
            "type": "vector",
            "value": {"x": arguments.x, "y": arguments.y},
        }
    if (
        arguments.value is None
        or arguments.x is not None
        or arguments.y is not None
    ):
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            f"{arguments.property} requires --value, without --x or --y",
            remediation="pass one exact ordinary decimal value",
            exit_code=EXIT_INVALID_INPUT,
        )
    if arguments.property == "opacity":
        numerator = int(arguments.value["num"])
        denominator = int(arguments.value["den"])
        if numerator < 0 or numerator > denominator:
            raise CliFailure(
                "CLI_ARGUMENT_INVALID",
                "validation",
                "opacity keyframes must be between 0 and 1",
                exit_code=EXIT_INVALID_INPUT,
            )
    return {"type": "scalar", "value": arguments.value}


SFX_LINK_EXTENSION = "dev.orangecut.sfx-link"


BUNDLED_SFX_MANIFEST: list[dict[str, str]] = [

    {"id": "xiu", "label": "咻", "kind": "whoosh", "use": "转场、贴纸滑入、标题卡入场(提前一帧)", "assetId": "asset-bundled-sfx-xiu-v1"},
    {"id": "ding", "label": "答对叮", "kind": "ding", "use": "答对了、要点确认、打勾", "assetId": "asset-bundled-sfx-ding-v1"},
    {"id": "bo", "label": "啵", "kind": "pop", "use": "贴纸弹出(pop 入场)、小气泡冒出来", "assetId": "asset-bundled-sfx-bo-v1"},
    {"id": "dong", "label": "咚咚", "kind": "impact", "use": "章节卡、大字落地、节拍重音(zoom 入场)", "assetId": "asset-bundled-sfx-dong-v1"},
    {"id": "deng", "label": "噔噔", "kind": "sting", "use": "揭晓、反转之前顿一下", "assetId": "asset-bundled-sfx-deng-v1"},
    {"id": "boing", "label": "短弹簧", "kind": "boing", "use": "贴纸弹跳入场(bounce)、俏皮一跳", "assetId": "asset-bundled-sfx-boing-v1"},
    {"id": "honk", "label": "喇叭", "kind": "honk", "use": "翻车、犯蠢、搞笑失误", "assetId": "asset-bundled-sfx-honk-v1"},
    {"id": "shock", "label": "震惊", "kind": "shock", "use": "震惊、离谱消息、瞪眼反应", "assetId": "asset-bundled-sfx-shock-v1"},
    {"id": "dangdang", "label": "当当", "kind": "emphasis", "use": "划重点、强调关键词", "assetId": "asset-bundled-sfx-dangdang-v1"},
    {"id": "yiwen", "label": "疑问", "kind": "question", "use": "提问、疑惑、问号冒出来", "assetId": "asset-bundled-sfx-yiwen-v1"},
    {"id": "ganga", "label": "尴尬", "kind": "awkward", "use": "尴尬、冷场、话说错了", "assetId": "asset-bundled-sfx-ganga-v1"},
    {"id": "shangsheng", "label": "上升", "kind": "rise", "use": "涨了、往上走、期待感拉起", "assetId": "asset-bundled-sfx-shangsheng-v1"},
    {"id": "hualuo", "label": "滑落", "kind": "fall", "use": "跌了、往下滑、泄气失败", "assetId": "asset-bundled-sfx-hualuo-v1"},
    {"id": "koushao", "label": "口哨", "kind": "whistle", "use": "调侃、\"哟\"一下、吹口哨起哄", "assetId": "asset-bundled-sfx-koushao-v1"},
    {"id": "guzhang", "label": "故障", "kind": "glitch", "use": "故障、卡顿、画面抽搐式转场", "assetId": "asset-bundled-sfx-guzhang-v1"},
    {"id": "shengli", "label": "胜利提示", "kind": "win", "use": "成功、达成、通关", "assetId": "asset-bundled-sfx-shengli-v1"},
    {"id": "cuowu", "label": "错误", "kind": "error", "use": "错了、否定、打叉", "assetId": "asset-bundled-sfx-cuowu-v1"},
    {"id": "gujiu", "label": "咕啾", "kind": "blip", "use": "极短提示音、小图标点亮", "assetId": "asset-bundled-sfx-gujiu-v1"},
    # 2026-09-19 从小泰音效教程 01 沉淀的十一声;kind 同名时 `--sfx <kind>` 仍取排前面的老条目
    {"id": "xiaoniao", "label": "小鸟叫", "kind": "censor", "use": "说脏话、敏感词处代替消音,配马赛克或哔声字幕", "assetId": "asset-bundled-sfx-xiaoniao-v1"},
    {"id": "kuaiban", "label": "快板", "kind": "clapper", "use": "想骂人、憋着火碎碎念、有节奏的吐槽", "assetId": "asset-bundled-sfx-kuaiban-v1"},
    {"id": "qiangsheng", "label": "枪声", "kind": "gunshot", "use": "超无语、翻脸瞬间、\"一枪崩了\"的夸张收尾", "assetId": "asset-bundled-sfx-qiangsheng-v1"},
    {"id": "niujiao", "label": "牛叫", "kind": "moo", "use": "特生气、发飙、牛脾气上头", "assetId": "asset-bundled-sfx-niujiao-v1"},
    {"id": "yia", "label": "疑问·一啊", "kind": "question", "use": "问问题、反问、\"啊?\"一脸懵(比「疑问」更口语)", "assetId": "asset-bundled-sfx-yia-v1"},
    {"id": "sikao", "label": "思考计算", "kind": "thinking", "use": "在思考、盘算、脑内计算的停顿", "assetId": "asset-bundled-sfx-sikao-v1"},
    {"id": "dazi", "label": "键盘打字", "kind": "typing", "use": "打字幕、文字逐字出现、发消息", "assetId": "asset-bundled-sfx-dazi-v1"},
    {"id": "hu", "label": "呼·转场", "kind": "whoosh", "use": "要转场、场景切换,比「咻」更闷更长", "assetId": "asset-bundled-sfx-hu-v1"},
    {"id": "xuanyi", "label": "悬疑长音", "kind": "suspense", "use": "悬疑感、抛问题、反转前的铺垫,压在旁白停顿处", "assetId": "asset-bundled-sfx-xuanyi-v1"},
    {"id": "kaichang", "label": "开场空咚", "kind": "opener", "use": "做开场、片头第一帧、空旷的开场重音", "assetId": "asset-bundled-sfx-kaichang-v1"},
    {"id": "xintou", "label": "心头震", "kind": "scare", "use": "受惊吓、吓一跳、心头一紧的重音", "assetId": "asset-bundled-sfx-xintou-v1"},
    # 2026-09-19 从小泰音效教程 04/05/07/09/10/11/14/15/19/20 沉淀的十九声;同上,kind 同名时老条目优先
    {"id": "zhuanyun", "label": "转晕", "kind": "dizzy", "use": "头晕、被绕晕、转圈圈", "assetId": "asset-bundled-sfx-zhuanyun-v1"},
    {"id": "yangjiao", "label": "羊叫", "kind": "bleat", "use": "有点尴尬、尬住、干笑两声", "assetId": "asset-bundled-sfx-yangjiao-v1"},
    {"id": "bibibi", "label": "可爱跑步", "kind": "scurry", "use": "得瑟、小碎步跑开、可爱蹦跶", "assetId": "asset-bundled-sfx-bibibi-v1"},
    {"id": "xingguang", "label": "星光叮", "kind": "sparkle", "use": "好期待、闪光亮相、魔法一下", "assetId": "asset-bundled-sfx-xingguang-v1"},
    {"id": "kaichanggu", "label": "开场鼓", "kind": "opener", "use": "片场开头、\"预备——开始\"的鼓点(比「开场空咚」热闹)", "assetId": "asset-bundled-sfx-kaichanggu-v1"},
    {"id": "lashen", "label": "弹簧拉伸", "kind": "stretch", "use": "情绪拉满、慢速放大、拉长的夸张", "assetId": "asset-bundled-sfx-lashen-v1"},
    {"id": "huran", "label": "忽然出现", "kind": "appear", "use": "忽然出现、向上弹入、冒出来", "assetId": "asset-bundled-sfx-huran-v1"},
    {"id": "haoqi", "label": "综艺好奇", "kind": "question", "use": "疑问、好奇、旋转缩放的问号", "assetId": "asset-bundled-sfx-haoqi-v1"},
    {"id": "what", "label": "What?", "kind": "shock", "use": "啥?、不敢相信、震惊反问", "assetId": "asset-bundled-sfx-what-v1"},
    {"id": "shimian", "label": "十面埋伏", "kind": "suspense", "use": "危机四伏、要出事了的紧张(比「悬疑长音」急)", "assetId": "asset-bundled-sfx-shimian-v1"},
    {"id": "meizhao", "label": "没招了", "kind": "defeat", "use": "我没招了、认输、摆烂", "assetId": "asset-bundled-sfx-meizhao-v1"},
    {"id": "sakesi", "label": "浪漫萨克斯", "kind": "romance", "use": "浪漫、暧昧、深情一刻(2.6 秒,给画面留够时间)", "assetId": "asset-bundled-sfx-sakesi-v1"},
    {"id": "dingdong", "label": "紧张叮咚", "kind": "tension", "use": "紧张、倒计时、心跳加速的转场", "assetId": "asset-bundled-sfx-dingdong-v1"},
    {"id": "jishache", "label": "急刹车", "kind": "brake", "use": "急刹车、话说一半停住、突然打断", "assetId": "asset-bundled-sfx-jishache-v1"},
    {"id": "mua", "label": "亲吻 mua", "kind": "kiss", "use": "亲一口、比心、宠溺", "assetId": "asset-bundled-sfx-mua-v1"},
    {"id": "waibibabu", "label": "歪比巴卜", "kind": "gibberish", "use": "很通用:装傻、听不懂、胡说八道", "assetId": "asset-bundled-sfx-waibibabu-v1"},
    {"id": "wuya", "label": "乌鸦飞过", "kind": "awkward", "use": "无话可说、冷场、乌鸦飞过", "assetId": "asset-bundled-sfx-wuya-v1"},
    {"id": "an", "label": "安?", "kind": "question", "use": "很通用:疑问、惊奇、\"啊?\"一声", "assetId": "asset-bundled-sfx-an-v1"},
    {"id": "xiangjiaomao", "label": "香蕉猫哭", "kind": "cry", "use": "很通用:不开心、郁闷、伤心、失望", "assetId": "asset-bundled-sfx-xiangjiaomao-v1"},
    {"id": "dianji", "label": "鼠标点击", "kind": "click", "use": "点按钮、点搜索、点确认、点开链接——鼠标或手机的一下轻点", "assetId": "asset-bundled-sfx-dianji-v1"},
    {"assetId":"asset-bundled-sfx-marker-tick-v2","id":"marker-tick","kind":"marker-tick","label":"标记·软点","use":"短而轻的标记入场提示"},
    {"assetId":"asset-bundled-sfx-marker-sweep-v2","id":"marker-sweep","kind":"marker-sweep","label":"标记·轻扫","use":"短而轻的标记入场提示"},
    {"assetId":"asset-bundled-sfx-marker-glow-v2","id":"marker-glow","kind":"marker-glow","label":"标记·轻落","use":"短而轻的标记入场提示"},
    {"id": "wind-swoosh", "label": "电影宽广风声", "kind": "whoosh", "use": "画中画走位、镜头切换、电影感宽广气流转场", "assetId": "asset-bundled-sfx-wind-swoosh-v1"},
    {"id": "cinema-boom-soft", "label": "电影·柔落", "kind": "sub-drop", "use": "柔和低频落地、电影标题重音", "assetId": "asset-bundled-sfx-cinema-boom-soft-v1"},
    {"id": "paper-highlight", "label": "电影·纸面划线", "kind": "paper", "use": "荧光笔划过纸面重点", "assetId": "asset-bundled-sfx-paper-highlight-v1"},
    {"id": "counter-tick-lock", "label": "电影·滚轮锁定", "kind": "counter", "use": "机械数字滚轮连点与定格", "assetId": "asset-bundled-sfx-counter-tick-lock-v1"},
    {"id": "micro-whoosh", "label": "电影·微风切", "kind": "micro-whoosh", "use": "超短气感扫过、镜头微推进", "assetId": "asset-bundled-sfx-micro-whoosh-v1"},
]


CUTAWAY_EXTENSION = "dev.orangecut.cutaway"
CUTAWAY_MODES = ("overlay", "insert", "pip")
CUTAWAY_PIP_CORNERS = ("top-right", "top-left", "bottom-right", "bottom-left")

# 内置插梗片段(cutaway / 切出镜头):剪映素材库按使用次数筛出的 14 条,随
# OrangeCut 本体分发,打开工程时以 asset-bundled-cutaway-* 视频 asset 装入。
# kind:reaction 反应梗(接在一句话之后当"观众反应"),timecard 时间过渡卡,
# outro 引导关注片尾。use 是给编导看的一句话,不是规则。
BUNDLED_CUTAWAY_MANIFEST: list[dict[str, str]] = [
    {"id": "nice", "label": "nice 大叔", "kind": "reaction", "use": "认可、夸一句之后", "assetId": "asset-bundled-cutaway-nice-v1"},
    {"id": "marmot", "label": "土拨鼠尖叫", "kind": "reaction", "use": "崩溃、惊叫、离谱时刻", "assetId": "asset-bundled-cutaway-marmot-v1"},
    {"id": "laugh", "label": "哈哈哈大笑", "kind": "reaction", "use": "笑点落地之后", "assetId": "asset-bundled-cutaway-laugh-v1"},
    {"id": "goose", "label": "鹅笑", "kind": "reaction", "use": "嘲笑、哭笑不得", "assetId": "asset-bundled-cutaway-goose-v1"},
    {"id": "disgust", "label": "起身嫌弃", "kind": "reaction", "use": "嫌弃、拒绝、翻脸", "assetId": "asset-bundled-cutaway-disgust-v1"},
    {"id": "facepalm", "label": "扶额无语", "kind": "reaction", "use": "无语、心累", "assetId": "asset-bundled-cutaway-facepalm-v1"},
    {"id": "zhenxiang", "label": "真香", "kind": "reaction", "use": "打脸、口是心非", "assetId": "asset-bundled-cutaway-zhenxiang-v1"},
    {"id": "what", "label": "What?!", "kind": "reaction", "use": "震惊、不敢相信", "assetId": "asset-bundled-cutaway-what-v1"},
    {"id": "heart", "label": "笔芯比心", "kind": "reaction", "use": "感谢、可爱收尾(无声)", "assetId": "asset-bundled-cutaway-heart-v1"},
    {"id": "later", "label": "海绵宝宝·然后", "kind": "timecard", "use": "短暂过渡", "assetId": "asset-bundled-cutaway-later-v1"},
    {"id": "moments-later", "label": "海绵宝宝·一会儿后", "kind": "timecard", "use": "跳过等待", "assetId": "asset-bundled-cutaway-moments-later-v1"},
    {"id": "years-later", "label": "海绵宝宝·两千年后", "kind": "timecard", "use": "夸张的漫长等待", "assetId": "asset-bundled-cutaway-years-later-v1"},
    {"id": "follow-outro", "label": "片尾·记得关注再走", "kind": "outro", "use": "片尾引导关注", "assetId": "asset-bundled-cutaway-follow-outro-v1"},
    {"id": "follow-heart", "label": "爱心点击关注", "kind": "outro", "use": "片尾引导关注(简约)", "assetId": "asset-bundled-cutaway-follow-heart-v1"},
]


def resolve_cutaway(token: str, project: dict[str, Any]) -> dict[str, Any]:
    """A bundled id first; otherwise any video asset of the project by id, so
    a clip the user harvested themselves works through the same command."""
    for entry in BUNDLED_CUTAWAY_MANIFEST:
        if entry["id"] == token:
            return dict(entry)
    for asset in project.get("assets", []):
        if asset.get("id") == token:
            if asset.get("kind") != "video":
                raise CliFailure(
                    "CUTAWAY_NOT_VIDEO", "validation",
                    f"asset {token!r} is {asset.get('kind')!r}, and a cutaway must be a video asset",
                    remediation="pass a bundled id from `oc cutaway list` or a video asset id",
                    exit_code=EXIT_INVALID_INPUT,
                )
            return {"id": token, "label": str(asset.get("name") or token), "kind": "custom",
                    "use": "", "assetId": token}
    raise CliFailure(
        "CUTAWAY_NOT_FOUND", "validation",
        f"no bundled cutaway or video asset with id {token!r}",
        remediation="run `oc cutaway list` for the bundled ids, or `oc asset list` for the project's videos",
        exit_code=EXIT_INVALID_INPUT,
    )


def rational_wire(value: Fraction) -> dict[str, str]:
    return {"num": str(value.numerator), "den": str(value.denominator)}


def visual_track_add_commands(sequence: dict[str, Any], sequence_id: str,
                              track_id: str, role: str, origin: str) -> list[dict[str, Any]]:
    """A new visual track directly under the lowest text-class track
    (caption/component) so it never covers subtitles or stickers: the text
    boundary and everything above it is lifted by 10 (highest first, so no
    order collides), and the freed slot goes to the new track. Same rule as
    `timeline place` and the service's own `timeline add`."""
    commands: list[dict[str, Any]] = []
    tracks = sequence.get("tracks", [])
    orders = [int(track.get("order", 0)) for track in tracks]
    new_order = (max(orders) + 1) if orders else 0
    text_orders = [
        int(track.get("order", 0))
        for track in tracks
        if track.get("kind") in ("caption", "component")
    ]
    if text_orders:
        floor = min(text_orders)
        lifted = sorted(
            (track for track in tracks if int(track.get("order", 0)) >= floor),
            key=lambda track: -int(track.get("order", 0)),
        )
        for track in lifted:
            settings = {
                "kind": track.get("kind"),
                "order": int(track.get("order", 0)) + 10,
                "muted": bool(track.get("muted", False)),
                "locked": bool(track.get("locked", False)),
                "extensions": track.get("extensions") or {},
            }
            if track.get("role") is not None:
                settings["role"] = track.get("role")
            commands.append({
                "type": "track.update",
                "payload": {"sequenceId": sequence_id, "trackId": track.get("id"),
                            "settings": settings},
            })
        new_order = floor
    commands.append({
        "type": "track.add",
        "payload": {
            "sequenceId": sequence_id,
            "track": {
                "id": track_id,
                "kind": "video",
                "order": new_order,
                "role": role,
                "muted": False, "locked": False,
                "clips": [], "captions": [],
                "extensions": {
                    "dev.orangecut.track-origin": {
                        "schemaVersion": "1",
                        "data": {"origin": origin},
                    },
                },
            },
        },
    })
    return commands


def main_video_track_id(sequence: dict[str, Any], at_time: Fraction) -> str | None:
    """The picture track a cutaway cuts into: the video track (not a cutaway/sfx
    layer) whose clip is playing at that moment; failing that, the lowest video
    track that has any clip. None when the sequence has no picture yet."""
    candidates = [
        track for track in sequence.get("tracks", [])
        if track.get("kind") == "video" and track.get("role") not in ("cutaway", "sfx")
    ]
    candidates.sort(key=lambda track: int(track.get("order", 0)))
    for track in candidates:
        for clip in track.get("clips", []):
            wire = clip.get("timelineRange") or {}
            start = _rational_of(wire.get("start")); end = _rational_of(wire.get("end"))
            if start <= at_time < end:
                return str(track["id"])
    for track in candidates:
        if track.get("clips"):
            return str(track["id"])
    return None


def cutaway_clip_command(sequence_id: str, track_id: str, clip_id: str, asset_id: str,
                         start: Fraction, length: Fraction, fit: str,
                         volume_percent: int, entry: dict[str, Any], mode: str) -> dict[str, Any]:
    effects: list[dict[str, Any]] = []
    if volume_percent != 100:
        # 与 timeline place --muted 同一种效果,只是增益不为 0:插梗自带的声音
        # 压低到人声之下,或干脆静掉只留画面。
        effects.append({
            "id": f"effect-cutaway-gain-{uuid.uuid4()}",
            "effectType": "dev.orangecut.audio.mix",
            "target": "audio",
            "parameters": {
                "gain": rational_wire(Fraction(volume_percent, 100)),
                "pan": rational_wire(Fraction(0)),
                "fadeIn": rational_wire(Fraction(0)),
                "fadeOut": rational_wire(Fraction(0)),
            },
            "keyframes": [],
            "capabilityRequirements": [],
            "extensions": {},
        })
    clip: dict[str, Any] = {
        "id": clip_id,
        "enabled": True,
        "timelineRange": {"start": rational_wire(start), "end": rational_wire(start + length)},
        "sourceRange": {"start": rational_wire(Fraction(0)), "end": rational_wire(length)},
        "source": {"type": "asset", "assetId": asset_id},
        "playback": {"rate": {"num": "1", "den": "1"}, "reverse": False, "freeze": False},
        "effects": effects,
        "extensions": {
            CUTAWAY_EXTENSION: {
                "schemaVersion": "1",
                "data": {"cutawayId": entry["id"], "kind": entry["kind"], "mode": mode},
            },
        },
    }
    if fit != "contain":
        clip["visualFit"] = fit
    return {"type": "clip.add", "payload": {"sequenceId": sequence_id, "trackId": track_id, "clip": clip}}


def cutaway_pip_transform(sequence: dict[str, Any], sequence_id: str, clip_id: str,
                          asset: dict[str, Any], scale_percent: float,
                          corner: str) -> dict[str, Any] | None:
    """Picture-in-picture: the clip (rendered `contain` by default, so its box
    is the canvas-fitted source) scaled so its width is `scale_percent` of the
    canvas width, tucked into a corner with a 4%-of-short-side margin. Needs
    the source size from the probe; without it the clip stays full-frame."""
    canvas = sequence.get("canvas") or {}
    try:
        canvas_w = int(canvas.get("width")); canvas_h = int(canvas.get("height"))
    except (TypeError, ValueError):
        return None
    width = height = None
    for stream in (asset.get("probe") or {}).get("streams") or []:
        if isinstance(stream, dict) and stream.get("kind") == "video":
            width, height = stream.get("width"), stream.get("height")
            rotation = stream.get("rotationDegrees") or 0
            if rotation in (90, 270, -90):
                width, height = height, width
            break
    if not width or not height or canvas_w <= 0 or canvas_h <= 0:
        return None
    contain = min(Fraction(canvas_w, int(width)), Fraction(canvas_h, int(height)))
    rendered_w = Fraction(int(width)) * contain
    rendered_h = Fraction(int(height)) * contain
    target_w = Fraction(canvas_w) * Fraction(scale_percent).limit_denominator(1000) / 100
    scale = (target_w / rendered_w).limit_denominator(100000)
    target_h = rendered_h * scale
    margin = Fraction(min(canvas_w, canvas_h)) * Fraction(4, 100)
    offset_x = Fraction(canvas_w, 2) - target_w / 2 - margin
    offset_y = Fraction(canvas_h, 2) - target_h / 2 - margin
    position_x = offset_x if corner.endswith("right") else -offset_x
    position_y = offset_y if corner.startswith("bottom") else -offset_y
    return {
        "type": "clip.transform.set",
        "payload": {
            "sequenceId": sequence_id,
            "clipId": clip_id,
            "transform": {
                "positionX": rational_wire(position_x.limit_denominator(1000)),
                "positionY": rational_wire(position_y.limit_denominator(1000)),
                "scaleX": rational_wire(scale),
                "scaleY": rational_wire(scale),
                "rotationDegrees": rational_wire(Fraction(0)),
                "opacity": rational_wire(Fraction(1)),
            },
        },
    }


def sfx_library_dir() -> Path | None:
    root = os.environ.get("ORANGECUT_SFX_DIR")
    return Path(root) if root else None


def load_sfx_library() -> list[dict[str, Any]]:
    """The sound registry: bundled by default, a directory when overridden.

    The bundled sounds ship inside the OrangeCut binary itself and are
    installed into every Project as `asset-bundled-sfx-*` audio assets when it
    opens — so a distributed copy of the app has working sounds on any
    machine, GUI and CLI alike. `ORANGECUT_SFX_DIR` swaps in a custom library
    wholesale (a directory with `sfx.json` naming `{"id","file","kind"}`
    entries, optionally `"label"` and a one-line `"use"` saying what scene the
    sound suits); those files are imported into the Project on first use.

    Every bundled file is loudness-normalised to I=-19 LUFS (TP ≤ -1.5 dBTP),
    the sfx level of the reference mix, so no sound jumps out or vanishes
    next to its neighbours; a custom library should be levelled the same way.
    """
    root = sfx_library_dir()
    if root is None:
        return [dict(entry) for entry in BUNDLED_SFX_MANIFEST]
    manifest = root / "sfx.json"
    try:
        payload = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise CliFailure(
            "SFX_LIBRARY_UNREADABLE",
            "validation",
            f"cannot read {manifest}: {error}",
            remediation='sfx.json must be UTF-8 JSON: {"sfx": [{"id", "file", "kind", "label"?, "use"?}]}',
            exit_code=EXIT_INVALID_INPUT,
        )
    entries = payload.get("sfx")
    if not isinstance(entries, list) or not all(
        isinstance(entry, dict)
        and isinstance(entry.get("id"), str)
        and entry.get("id")
        and isinstance(entry.get("file"), str)
        and isinstance(entry.get("kind"), str)
        for entry in entries
    ):
        raise CliFailure(
            "SFX_LIBRARY_INVALID",
            "validation",
            f'{manifest} must carry a "sfx" array of {{"id", "file", "kind"}} objects',
            exit_code=EXIT_INVALID_INPUT,
        )
    for entry in entries:
        entry["path"] = str(root / entry["file"])
    return entries


def resolve_sfx(token: str) -> dict[str, Any]:
    """An id wins over a kind, so `--sfx ding` means the entry named ding if
    one exists and otherwise the first entry of kind ding."""
    entries = load_sfx_library()
    for entry in entries:
        if entry["id"] == token:
            return entry
    for entry in entries:
        if entry["kind"] == token:
            return entry
    raise CliFailure(
        "SFX_NOT_FOUND",
        "validation",
        f"no sfx with id or kind {token!r} in the library",
        remediation="run `oc sfx list` to see what is registered",
        exit_code=EXIT_INVALID_INPUT,
    )


def file_fingerprint(path: Path) -> str:
    import hashlib

    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def ensure_sfx_asset(client: Any, project_id: str, project: dict[str, Any], entry: dict[str, Any]) -> tuple[str, Fraction]:
    """Resolve the sfx to a project asset and its duration in seconds.

    A bundled entry is already installed in every open Project by the service
    itself, so it resolves without touching the network; a custom-library
    entry is imported once per project (matched by content fingerprint)."""

    def duration_from(asset: dict[str, Any]) -> Fraction | None:
        probe = asset.get("probe")
        duration = probe.get("duration") if isinstance(probe, dict) else None
        if isinstance(duration, dict):
            return Fraction(int(duration["num"]), int(duration["den"]))
        return None

    bundled_asset_id = entry.get("assetId")
    if bundled_asset_id:
        for asset in project.get("assets", []):
            if asset.get("id") == bundled_asset_id:
                return bundled_asset_id, duration_from(asset) or Fraction(1)
        raise CliFailure(
            "SFX_BUNDLED_ASSET_MISSING",
            "preconditions",
            f"the bundled sound asset {bundled_asset_id!r} is not in this project",
            remediation="reopen the project on an OrangeCut build that installs "
            "bundled sounds (they are added automatically on open)",
            exit_code=EXIT_OPERATION_FAILED,
        )
    path = Path(entry["path"])
    if not path.is_file():
        raise CliFailure(
            "SFX_FILE_MISSING",
            "validation",
            f"sfx file does not exist: {path}",
            remediation="fix the file field in sfx.json or restore the file",
            exit_code=EXIT_INVALID_INPUT,
        )
    fingerprint = file_fingerprint(path)
    for asset in project.get("assets", []):
        existing = asset.get("fingerprint")
        value = existing.get("value") if isinstance(existing, dict) else existing
        if value == fingerprint:
            return asset["id"], duration_from(asset) or Fraction(1)
    imported = client.request(
        "POST",
        f"/v1/projects/{quote(project_id)}/assets/import",
        {
            "baseRevision": current_revision(client),
            "paths": [str(path)],
            "expectedKind": "audio",
            "intent": f"导入音效 {entry['id']}",
            "idempotencyKey": f"sfx-import-{fingerprint[:16]}",
        },
    )
    assets = require_object(imported, "data").get("assets") or []
    if not assets:
        raise CliFailure(
            "SFX_IMPORT_EMPTY",
            "store",
            "the sfx import reported no asset",
            exit_code=EXIT_SERVICE_UNAVAILABLE,
        )
    asset = assets[0]
    asset_id = asset.get("assetId") or asset.get("id")
    return asset_id, duration_from(asset) or Fraction(1)


def sfx_placement_commands(
    sequence: dict[str, Any],
    sequence_id: str,
    asset_id: str,
    duration_seconds: Fraction,
    rate: Fraction,
    at_frame: int,
    entry: dict[str, Any],
    target_clip_id: str | None,
    cue: str | None = None,
) -> list[dict[str, Any]]:
    """The atomic tail of every sfx placement: ensure a role=sfx audio track
    (a fresh one if the moment is already occupied) and add the audio clip
    with its link extension. A whoosh leads the visual by one frame — the
    sweep is heard arriving; percussive kinds land on the exact frame."""

    def rational(value: Fraction) -> dict[str, str]:
        return {"num": str(value.numerator), "den": str(value.denominator)}

    frame = at_frame
    if entry["kind"] == "whoosh":
        frame = max(0, frame - 1)
    start = Fraction(frame) / rate
    length_frames = max(1, int(duration_seconds * rate))
    length = Fraction(length_frames) / rate
    end = start + length

    commands: list[dict[str, Any]] = []
    track_id = None
    for track in sequence.get("tracks", []):
        if track.get("kind") != "audio" or track.get("role") != "sfx":
            continue
        occupied = False
        for clip in track.get("clips", []):
            clip_start = Fraction(int(clip["timelineRange"]["start"]["num"]),
                                  int(clip["timelineRange"]["start"]["den"]))
            clip_end = Fraction(int(clip["timelineRange"]["end"]["num"]),
                                int(clip["timelineRange"]["end"]["den"]))
            if clip_start < end and start < clip_end:
                occupied = True
                break
        if not occupied:
            track_id = track["id"]
            break
    if track_id is None:
        orders = [int(track.get("order", 0)) for track in sequence.get("tracks", [])]
        track_id = f"track-sfx-{uuid.uuid4()}"
        commands.append({
            "type": "track.add",
            "payload": {
                "sequenceId": sequence_id,
                "track": {
                    "id": track_id,
                    "kind": "audio",
                    "order": (max(orders) + 1) if orders else 0,
                    "role": "sfx",
                    "muted": False,
                    "locked": False,
                    "clips": [],
                    "captions": [],
                    "extensions": {},
                },
            },
        })
    link_data: dict[str, Any] = {"sfxId": entry["id"], "kind": entry["kind"]}
    if target_clip_id:
        link_data["targetClipId"] = target_clip_id
    if cue:
        # An extra cue (the click after the typing) is not the component's main
        # sound: `oc sfx set --sfx <x>` swaps the main one and leaves it be.
        link_data["cue"] = cue
    commands.append({
        "type": "clip.add",
        "payload": {
            "sequenceId": sequence_id,
            "trackId": track_id,
            "clip": {
                "id": f"clip-sfx-{uuid.uuid4()}",
                "enabled": True,
                "timelineRange": {"start": rational(start), "end": rational(end)},
                "sourceRange": {"start": rational(Fraction(0)), "end": rational(length)},
                "source": {"type": "asset", "assetId": asset_id},
                "playback": {
                    "rate": {"num": "1", "den": "1"},
                    "reverse": False,
                    "freeze": False,
                },
                "effects": [],
                "extensions": {
                    SFX_LINK_EXTENSION: {"schemaVersion": "1", "data": link_data}
                },
            },
        },
    })
    return commands


MICROS = 1_000_000


def timeline_place_plan(cutlist: list[dict[str, Any]], rate: Fraction,
                        asset_durations: dict[str, Fraction | None],
                        warnings: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """剪单 → 时间线放置计划。

    剪单是 OC 自己的通用格式:每条只说"取哪个素材、从源头哪一刻起、放到
    时间线哪一帧、放多长"。这里只做确定性换算与校验——速率 1 时时间线
    与源区间严格等长(引擎不变量);判断该取哪段是调用方(编导)的事。

    超出源长**一帧以内**自动收边并写进 warnings(传了的话):VFR 素材的
    容器时长与平均帧率不自洽,`ceil(duration×fps)` 出来的 durationFrames
    常差 1 帧,以前每条都要撞一次 PLACE_SOURCE_EXHAUSTED 再减 1 重试。
    超出一帧以上照旧报错——那是真的取过头了。
    """
    placements: list[dict[str, Any]] = []
    for index, entry in enumerate(cutlist):
        asset_id = str(entry.get("assetId") or "")
        if asset_id not in asset_durations:
            raise CliFailure(
                "PLACE_ASSET_NOT_FOUND", "validation",
                f"cutlist entry {index} names asset {asset_id!r}, which the project does not have",
                remediation="import the media first with `oc asset import`",
                exit_code=EXIT_INVALID_INPUT,
            )
        at_frame = entry.get("atFrame")
        if not isinstance(at_frame, int) or at_frame < 0:
            raise CliFailure(
                "PLACE_CUTLIST_INVALID", "validation",
                f"cutlist entry {index} needs a non-negative integer atFrame",
                remediation='each entry looks like {"assetId": ..., "atFrame": 0, "durationFrames": 48}',
                exit_code=EXIT_INVALID_INPUT,
            )
        duration = entry.get("durationFrames")
        if not isinstance(duration, int) or duration <= 0:
            raise CliFailure(
                "PLACE_CUTLIST_INVALID", "validation",
                f"cutlist entry {index} needs a positive integer durationFrames",
                remediation='each entry looks like {"assetId": ..., "atFrame": 0, "durationFrames": 48}',
                exit_code=EXIT_INVALID_INPUT,
            )
        source_start_us = entry.get("sourceStartUs", 0)
        if not isinstance(source_start_us, int) or source_start_us < 0:
            raise CliFailure(
                "PLACE_CUTLIST_INVALID", "validation",
                f"cutlist entry {index} needs a non-negative integer sourceStartUs",
                remediation="sourceStartUs is where in the source the clip starts, in microseconds",
                exit_code=EXIT_INVALID_INPUT,
            )
        source_start = Fraction(source_start_us, MICROS)
        length = Fraction(duration, 1) / rate
        limit = asset_durations[asset_id]
        if limit is not None and source_start + length > limit:
            max_frames = int((limit - source_start) * rate)
            overage = source_start + length - limit
            if overage <= Fraction(1, 1) / rate and max_frames >= 1:
                if warnings is not None:
                    warnings.append({
                        "code": "PLACE_CLAMPED_TO_SOURCE",
                        "message": (
                            f"cutlist entry {index} asked for {duration} frames but the "
                            f"source only supports {max_frames}; clamped by "
                            f"{duration - max_frames} frame(s)"
                        ),
                        "assetId": asset_id,
                        "atFrame": at_frame,
                        "requestedFrames": duration,
                        "placedFrames": max_frames,
                    })
                duration = max_frames
                length = Fraction(duration, 1) / rate
            else:
                raise CliFailure(
                    "PLACE_SOURCE_EXHAUSTED", "validation",
                    f"cutlist entry {index} asks for {duration} frames from "
                    f"{float(source_start):.3f}s, but the source only supports {max(0, max_frames)}",
                    remediation="reduce durationFrames or move sourceStartUs earlier",
                    exit_code=EXIT_INVALID_INPUT,
                )
        placements.append({
            "assetId": asset_id,
            "atFrame": at_frame,
            "durationFrames": duration,
            "timelineStart": Fraction(at_frame, 1) / rate,
            "timelineEnd": Fraction(at_frame + duration, 1) / rate,
            "sourceStart": source_start,
            "sourceEnd": source_start + length,
        })
    ordered = sorted(placements, key=lambda item: item["atFrame"])
    for earlier, later in zip(ordered, ordered[1:]):
        if earlier["timelineEnd"] > later["timelineStart"]:
            raise CliFailure(
                "PLACE_OVERLAP", "validation",
                f"entries at frames {earlier['atFrame']} and {later['atFrame']} overlap on the timeline",
                remediation="same-track clips must not overlap; adjust atFrame or durations",
                exit_code=EXIT_INVALID_INPUT,
            )
    return ordered


def asset_source_frame_rate(asset: dict[str, Any]) -> Fraction | None:
    """一份素材自己的帧率,取自 probe 的视频流。没有视频流就没有帧率。"""
    probe = asset.get("probe") or {}
    for stream in probe.get("streams") or []:
        if not isinstance(stream, dict) or stream.get("kind") != "video":
            continue
        wire = stream.get("frameRate")
        if isinstance(wire, dict) and "num" in wire and "den" in wire:
            try:
                rate = Fraction(int(wire["num"]), int(wire["den"]))
            except (TypeError, ValueError, ZeroDivisionError):
                return None
            return rate if rate > 0 else None
    return None


def effective_place_frame_rate(
    sequence: dict[str, Any],
    current: Fraction,
    first_asset: dict[str, Any] | None,
) -> Fraction:
    """放下这一批之后,序列会跑在哪个帧率上。

    自动模式序列的**第一段画面**会把格式钉成素材自己的(core 的 `add_clip`
    就是这么做的),所以在发命令之前吸附范围的人必须按钉完之后的帧率算。
    按切换前的帧率算,第一段就落在旧网格上:24fps 素材进新建的 30fps 工程,
    48 帧 = 1.6 秒,而 1.6 秒在 24fps 下是 38.4 帧——引擎照样导出,编辑器
    一加载就抛"时间不在当前帧网格上"整页空白。`timeline add` 已经在服务端
    修过同一件事(见 `frame_rate_after_first_visual_clip`),`place` 自己拼
    范围,所以这里也要修一遍。
    """
    if sequence.get("canvasMode", "fixed") != "auto":
        return current
    for track in sequence.get("tracks", []):
        if track.get("kind") == "video" and track.get("clips"):
            return current
    if first_asset is None:
        return current
    source = asset_source_frame_rate(first_asset)
    # 与 core 的 `sequence_frame_rate_candidate` 同一条界:只认 1..=240fps。
    if source is None or not (1 <= source <= 240):
        return current
    return source


def frame_rate_mismatch_warnings(
    placements: list[dict[str, Any]],
    sequence_rate: Fraction,
    asset_frame_rates: dict[str, Fraction | None],
) -> list[dict[str, Any]]:
    """素材帧率与画布帧率不整除时的警告。

    24fps 的素材放进 30fps 的画布,渲染只能靠重复帧把时间填满:每 4 帧多出
    1 帧,占比 20%,观感是"卡帧、画面像静止的"。这件事此前零提示,连着做废过
    四条片子,最后是人眼发现的。判断纯确定性——两边帧率都是现成的,重复帧
    比例也只是一道除法,所以这里只报事实,剪不剪由调用方决定。

    整除的情况不报(24→48 每帧正好翻倍,没有节奏上的破绽);画布帧率更低时
    是丢帧而不是重复帧,同样值得说一句。
    """
    warnings: list[dict[str, Any]] = []
    for asset_id in dict.fromkeys(str(item["assetId"]) for item in placements):
        source = asset_frame_rates.get(asset_id)
        if source is None or source == sequence_rate:
            continue
        if sequence_rate > source:
            if (sequence_rate / source).denominator == 1:
                continue
            duplicated = 1 - float(source / sequence_rate)
            warnings.append({
                "code": "PLACE_FRAME_RATE_MISMATCH",
                "message": (
                    f"素材 {asset_id} 是 {format_frame_rate(source)}fps,画布是 "
                    f"{format_frame_rate(sequence_rate)}fps,不整除:渲染要靠重复帧补足,"
                    f"约 {duplicated * 100:.0f}% 的帧是重复的,观感会发卡"
                ),
                "assetId": asset_id,
                "sourceFrameRate": format_frame_rate(source),
                "sequenceFrameRate": format_frame_rate(sequence_rate),
                "duplicatedFrameRatio": round(duplicated, 4),
                "remediation": (
                    "把画布帧率设成素材帧率(新建工程时第一段素材会自动带着走),"
                    "或改用整数倍的帧率"
                ),
            })
            continue
        if (source / sequence_rate).denominator == 1:
            continue
        dropped = 1 - float(sequence_rate / source)
        warnings.append({
            "code": "PLACE_FRAME_RATE_MISMATCH",
            "message": (
                f"素材 {asset_id} 是 {format_frame_rate(source)}fps,画布是 "
                f"{format_frame_rate(sequence_rate)}fps,不整除:渲染会丢帧,"
                f"约 {dropped * 100:.0f}% 的源帧不会出现在成片里"
            ),
            "assetId": asset_id,
            "sourceFrameRate": format_frame_rate(source),
            "sequenceFrameRate": format_frame_rate(sequence_rate),
            "droppedFrameRatio": round(dropped, 4),
            "remediation": "把画布帧率设成素材帧率,或改用整数倍的帧率",
        })
    return warnings


def clip_slow_motion_warnings(
    client: Any,
    project_id: str,
    sequence_id: str | None,
    clip_id: str,
    rate: Fraction,
) -> list[dict[str, Any]]:
    """恒定变速那条路的取数:多取一次快照,拿画布帧率与这个 Clip 的素材帧率。

    守门不该因为取不到数就把命令拦下来,所以任何一步读不出来就安静返回空——
    真正的校验在服务端,这里只是替调用方把可预判的观感问题说出来。
    """
    try:
        snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
        project = require_object(require_object(snapshot, "data"), "project")
        resolved = sequence_id or default_sequence_id(project)
        sequence_rate = sequence_frame_rate_from(project, resolved)
        sequence = require_sequence(project, resolved)
        clip = next(
            (
                candidate
                for track in sequence.get("tracks", [])
                for candidate in track.get("clips", [])
                if candidate.get("id") == clip_id
            ),
            None,
        )
        if clip is None:
            return []
        asset_id = (clip.get("source") or {}).get("assetId")
        asset = next(
            (
                item
                for item in project.get("assets", [])
                if item.get("id") == asset_id
            ),
            None,
        )
        if asset is None:
            return []
        return slow_motion_warnings(
            clip_id, rate, sequence_rate, asset_source_frame_rate(asset)
        )
    except Exception:
        return []


# 慢放段里多少比例的重复帧算"看得出来"。低于这个数不开口——59.94fps 的素材
# 慢到 40%(下限 40.04%)只差千分之一帧,报出来纯属噪音。
SLOW_MOTION_JUDDER_TOLERANCE = 0.02


def slow_motion_floor(sequence_rate: Fraction, source_rate: Fraction) -> Fraction:
    """慢放的下限速率:低于它,渲染只能靠重复帧填满时间。

    慢放到 r 倍时,每一秒时间线要 `sequence_rate` 帧,而源这一秒只供得起
    `source_rate * r` 帧。两边相等的那个 r 就是下限 `sequence_rate / source_rate`。
    """
    return sequence_rate / source_rate


def slow_motion_warnings(
    clip_id: str,
    min_rate: Fraction,
    sequence_rate: Fraction,
    source_rate: Fraction | None,
) -> list[dict[str, Any]]:
    """慢放到素材帧率撑不住的档位时的警告。

    引擎既没有光流也没有帧混合,补不出中间帧,所以这条线是硬的:低于下限,
    多出来的那些帧全是上一帧的复制,观感一顿一顿。解药在自己家里——
    `oc media interp` 先把源插到更高帧率,再回来变速。

    **只报事实,不拦人。** 抖不抖是审美判断不是正确性判断:定格动画风格就是
    要抖,轻微越线(40% 撞 40.04% 的下限)也完全能用。拒渲留给"渲出来必然
    是错的"那一类;这一条不属于。

    实测:1440x832 的 24fps 素材在 24fps 画布上慢到 25%,慢放段 108 帧里
    66 帧是重复的(61%);同一条曲线先 `interp --factor 4` 插到 96fps,重复帧
    归零。
    """
    if source_rate is None or source_rate <= 0 or min_rate <= 0:
        return []
    floor = slow_motion_floor(sequence_rate, source_rate)
    if min_rate >= floor:
        return []
    duplicated = 1 - float(source_rate * min_rate / sequence_rate)
    # 擦着下限过去不值得开口:59.94fps 的素材慢到 40%,下限是 40.04%,
    # 差出来的重复帧是千分之一。守门要是连这种都报,就会被当成噪音划过去,
    # 真正该看的那条也跟着被无视。
    if duplicated < SLOW_MOTION_JUDDER_TOLERANCE:
        return []
    # 插到多少倍才够:源帧率翻 f 倍,下限就降到 floor / f。
    needed = math.ceil(floor / min_rate)
    if needed <= 2:
        remedy = (
            f"先插帧再变速:oc media interp <源素材> --output <新素材> --factor 2 "
            f"({format_frame_rate(source_rate)} → {format_frame_rate(source_rate * 2)}fps),"
            f"用新素材重新入轨"
        )
    elif needed <= 4:
        remedy = (
            f"先插帧再变速:oc media interp <源素材> --output <新素材> --factor 4 "
            f"({format_frame_rate(source_rate)} → {format_frame_rate(source_rate * 4)}fps),"
            f"用新素材重新入轨"
        )
    else:
        remedy = (
            f"要到这个档位得把源插到 {format_frame_rate(sequence_rate / min_rate)}fps "
            f"(约 {needed} 倍):interp 单次只做 2x/4x,得连跑两次(4x 再 4x = 16 倍)"
        )
        # 下限已经是 100% 时,"放宽速率"等于叫人别慢放,不是建议。
        if floor < 1:
            remedy += f",或者把速率放宽到 {float(floor) * 100:.0f}% 以上"
    warning = {
        "code": "SPEED_BELOW_SOURCE_FRAME_RATE",
        "message": (
            f"画布 {format_frame_rate(sequence_rate)}fps ÷ 素材 "
            f"{format_frame_rate(source_rate)}fps = 慢放下限 "
            f"{float(floor) * 100:.0f}%,本次最慢到 {float(min_rate) * 100:.0f}%:"
            f"引擎没有光流也没有帧混合,差的帧只能重复,"
            f"慢放段约 {duplicated * 100:.0f}% 是重复帧,观感会一顿一顿"
        ),
        "clipId": clip_id,
        "sequenceFrameRate": format_frame_rate(sequence_rate),
        "sourceFrameRate": format_frame_rate(source_rate),
        "floorRatePercent": round(float(floor) * 100, 1),
        "requestedRatePercent": round(float(min_rate) * 100, 1),
        "duplicatedFrameRatio": round(duplicated, 4),
        "remediation": remedy,
    }
    if floor >= 1:
        # 画布帧率追平或超过素材帧率时,下限就是 100%——**任何**慢放都会重复帧,
        # 而这一步最常是自动画布造成的:60fps 的源建工程,画布也跟着变 60fps,
        # 慢放余量一次性归零,而且毫无察觉。
        warning["canvasMatchesSource"] = True
        # 但"把画布降下来"只有在真降得动、而且降完够用时才是解药。画布本来就是
        # 24fps 的话,叫人把它设成 24fps 是句废话——那时只剩插帧一条路。
        lowered = Fraction(24)
        if sequence_rate > lowered and lowered / source_rate <= min_rate:
            warning["remediation"] = (
                f"画布帧率不低于素材帧率,所以任何慢放都会重复帧。"
                f"要么把画布降下来(`oc canvas set --fps 24`,慢放下限随之降到 "
                f"{float(lowered / source_rate) * 100:.0f}%),要么{remedy}"
            )
        else:
            warning["remediation"] = (
                f"画布帧率不低于素材帧率,所以任何慢放都会重复帧;"
                f"降画布帧率也救不回来,只能{remedy}"
            )
    return [warning]


def attach_warnings(
    response: Any, warnings: list[dict[str, Any]]
) -> Any:
    """把警告挂到一个已经成形的信封上。

    `place` 那条路自己拼裸 payload,`wrap_envelope` 会替它把 warnings 提到顶层;
    变速这条路直接把服务的信封原样返回,所以要在这里追加(而不是覆盖——
    自动拉起的那条 SERVICE_RESTART_LOOP 也住在这里)。
    """
    if not warnings or not isinstance(response, dict):
        return response
    response.setdefault("warnings", []).extend(warnings)
    return response


def format_frame_rate(rate: Fraction) -> str:
    return str(rate.numerator) if rate.denominator == 1 else f"{float(rate):.3f}"


def timeline_place_commands(sequence_id: str, track_id: str,
                        placements: list[dict[str, Any]],
                        muted: bool = False) -> list[dict[str, Any]]:
    def rational(value: Fraction) -> dict[str, str]:
        return {"num": str(value.numerator), "den": str(value.denominator)}
    # 静音随 Clip 一起建:放置与静音属于同一次编辑,拆成两次请求就会留下
    # "画面已放好、声音还在响"的中间态(见 timeline place 处理器的注释)。
    def silence_effect() -> list[dict[str, Any]]:
        # 每条 Clip 一个自己的效果 ID:实体 ID 全工程唯一,共用一个会被拒。
        if not muted:
            return []
        return [{
            "id": f"effect-place-mute-{uuid.uuid4()}",
            "effectType": "dev.orangecut.audio.mix",
            "target": "audio",
            "parameters": {
                "gain": {"num": "0", "den": "1"},
                "pan": {"num": "0", "den": "1"},
                "fadeIn": {"num": "0", "den": "1"},
                "fadeOut": {"num": "0", "den": "1"},
            },
            "keyframes": [],
            "capabilityRequirements": [],
            "extensions": {},
        }]
    commands: list[dict[str, Any]] = []
    for item in placements:
        clip_id = f"clip-place-{uuid.uuid4()}"
        item["clipId"] = clip_id
        commands.append({
            "type": "clip.add",
            "payload": {
                "sequenceId": sequence_id,
                "trackId": track_id,
                "clip": {
                    "id": clip_id,
                    "enabled": True,
                    "timelineRange": {
                        "start": rational(item["timelineStart"]),
                        "end": rational(item["timelineEnd"]),
                    },
                    "sourceRange": {
                        "start": rational(item["sourceStart"]),
                        "end": rational(item["sourceEnd"]),
                    },
                    "source": {"type": "asset", "assetId": item["assetId"]},
                    "playback": {
                        "rate": {"num": "1", "den": "1"},
                        "reverse": False,
                        "freeze": False,
                    },
                    "effects": silence_effect(),
                    "extensions": {},
                },
            },
        })
    return commands


GRID_MIN = 2
GRID_MAX = 9


def _grid_bands(count: int, portrait: bool) -> tuple[list[tuple[int, bool]], bool]:
    """(带列表[(格数, 是否撑满整条短边)], 带是否按行排)。与 GUI 的 grid-layout.ts 同一张表:
    竖屏一律按行;横屏 2、3 个按列(并排 / 左一大右两小),4 个起按行;3 个是一大两小。"""
    plain = lambda cells: [(n, False) for n in cells]  # noqa: E731
    if count == 1:
        return [(1, True)], True
    if count == 2:
        return [(1, True), (1, True)], portrait
    if count == 3:
        return [(1, True), (2, False)], portrait
    if count == 4:
        return plain([2, 2]), True
    if count == 5:
        return plain([2, 2, 1] if portrait else [3, 2]), True
    if count == 6:
        return plain([2, 2, 2] if portrait else [3, 3]), True
    if count == 7:
        return plain([3, 3, 1]), True
    if count == 8:
        return plain([3, 3, 2]), True
    if count == 9:
        return plain([3, 3, 3]), True
    raise ValueError(f"grid supports {GRID_MIN} to {GRID_MAX} clips")


def grid_cells(count: int, width: int, height: int, gap: int = 0) -> list[tuple[Fraction, Fraction, Fraction, Fraction]]:
    """宫格格子 (x, y, w, h),画布像素、左上角原点、精确分数,按阅读顺序(先上后下、先左后右)。
    与 GUI 的 grid-layout.ts 逐字节一致:4 个、gap 0 就是老的 2×2 象限。"""
    if not 1 <= count <= GRID_MAX:
        raise ValueError(f"grid supports {GRID_MIN} to {GRID_MAX} clips")
    if gap < 0:
        raise ValueError("gap must be a non-negative pixel count")
    portrait = height > width
    bands, rows = _grid_bands(count, portrait)
    long_side = height if rows else width
    short_side = width if rows else height
    max_cells = max(cells for cells, _ in bands)
    if long_side <= gap * (len(bands) + 1) or short_side <= gap * (max_cells + 1):
        raise ValueError("gap too large for the canvas")
    band_size = Fraction(long_side - gap * (len(bands) + 1), len(bands))
    cells: list[tuple[Fraction, Fraction, Fraction, Fraction]] = []
    for index, (count_in_band, stretch) in enumerate(bands):
        band_start = gap + index * (band_size + gap)
        columns = count_in_band if stretch else max_cells
        cell_size = Fraction(short_side - gap * (columns + 1), columns)
        used = count_in_band * cell_size + gap * (count_in_band - 1)
        offset = Fraction(gap) if count_in_band == columns else (short_side - used) / 2
        for j in range(count_in_band):
            cell_start = offset + j * (cell_size + gap)
            if rows:
                cells.append((cell_start, band_start, cell_size, band_size))
            else:
                cells.append((band_start, cell_start, band_size, cell_size))
    cells.sort(key=lambda cell: (cell[1], cell[0]))
    return cells


def sfx_command_batch(project_id: str, base_revision: int, intent: str,
                      idempotency_key: str | None, prefix: str,
                      commands: list[dict[str, Any]]) -> dict[str, Any]:
    command_id = idempotency_key or f"{prefix}-{uuid.uuid4()}"
    return {
        "commandId": command_id,
        "idempotencyKey": command_id,
        "projectId": project_id,
        "baseRevision": base_revision,
        "actor": {"type": "agent", "id": "orangecut-skill"},
        "intent": intent,
        "preconditions": [],
        "mode": "commit",
        "commands": commands,
    }


def sticker_preset_enter_animation(preset_id: str | None) -> str | None:
    """The entrance animation a sticker preset ships with, from the same
    catalog file the service embeds (located next to this installation)."""
    if not preset_id:
        return None
    for parent in Path(__file__).resolve().parents:
        candidate = parent / "schemas" / "v0" / "text-sticker-presets.json"
        if candidate.is_file():
            try:
                catalog = json.loads(candidate.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                return None
            for preset in catalog.get("presets", []):
                if preset.get("id") == preset_id:
                    value = preset.get("enterAnimation")
                    return value if isinstance(value, str) else None
            return None
    return None


ENTRANCE_SFX_KINDS = {
    "pop": "pop",
    "zoom": "impact",
    "bounce": "boing",
}


def entrance_sfx_token(enter_animation: str | None) -> str | None:
    """The sound kind an entrance animation implies; silent styles get none."""
    if enter_animation is None:
        return None
    if enter_animation.startswith("slide"):
        return "whoosh"
    return ENTRANCE_SFX_KINDS.get(enter_animation)


def preset_sfx_delay(preset: dict[str, Any] | None) -> Fraction:
    """When the preset's sound should start, counted from the component's
    first frame. Most presets sound on entry (0); one whose sounding action
    comes later — the search box types only after it has slid in — declares
    `sfxDelaySeconds` so the keys are heard with the letters, not before."""
    if not preset:
        return Fraction(0)
    value = preset.get("sfxDelaySeconds")
    if value in (None, ""):
        return Fraction(0)
    return Fraction(str(value))


def css_time_seconds(value: str) -> Fraction | None:
    """`1.4s` / `.7s` / `350ms` as exact seconds; anything else (calc, var) is None."""
    match = re.fullmatch(r"\s*(\d*\.?\d+)(ms|s)\s*", value or "")
    if not match:
        return None
    number = Fraction(match.group(1))
    return number / 1000 if match.group(2) == "ms" else number


def preset_extra_sfx(preset: dict[str, Any], stylesheet: str) -> list[tuple[str, Fraction]]:
    """A preset's sounds beyond its main one, each with when it lands.

    `sfxExtra` entries are `{sfx, delaySeconds, plusVariable?}`. `plusVariable`
    names a time variable the moment depends on — the search button is pressed
    once the typing is done, so lengthening `--oc-ui-type` must move the click
    with it. The variable is read from the filled stylesheet (what the caller
    set), falling back to the preset default when that is not a plain time."""
    cues: list[tuple[str, Fraction]] = []
    for cue in preset.get("sfxExtra") or []:
        if not isinstance(cue, dict) or not cue.get("sfx"):
            continue
        delay = Fraction(str(cue.get("delaySeconds", 0)))
        variable = cue.get("plusVariable")
        if variable:
            seconds = None
            match = re.search(re.escape(variable) + r":([^;}]+)", stylesheet or "")
            if match:
                seconds = css_time_seconds(match.group(1))
            if seconds is None:
                seconds = css_time_seconds(named_defaults(preset, "variables").get(variable, ""))
            delay += seconds or Fraction(0)
        cues.append((str(cue["sfx"]), delay))
    return cues


def html_preset_cue_payload(
    preset: dict[str, Any], override: str | None, rate: Fraction,
    duration_frames: int, project: dict[str, Any],
) -> list[dict[str, Any]]:
    if override == "none":
        return []
    result = []
    for index, cue in enumerate(preset["sfxCues"] or ([{"sfx": override}] if override else [])):
        token = override if index == 0 and override is not None else cue["sfx"]
        try:
            offset = Fraction(str(cue.get("offsetSeconds", 0))) * rate
            offset += Fraction(str(cue.get("offsetRatio", 0))) * duration_frames
            lead = cue.get("leadFrames", 0)
            if type(lead) is not int or lead < 0:
                raise ValueError("leadFrames must be a non-negative integer")
        except (ValueError, ZeroDivisionError) as error:
            raise CliFailure("HTML_PRESET_CATALOG_INVALID", "validation", str(error),
                             exit_code=EXIT_INVALID_INPUT) from error
        entry = resolve_sfx(token)
        asset_id = entry.get("assetId")
        if asset_id is None:
            try:
                fingerprint = file_fingerprint(Path(entry["path"]))
            except OSError as error:
                raise CliFailure("SFX_FILE_MISSING", "validation", str(error),
                                 exit_code=EXIT_INVALID_INPUT) from error
            asset_id = next((asset["id"] for asset in project.get("assets", [])
                             if (asset.get("fingerprint") or {}).get("value") == fingerprint), None)
            if asset_id is None:
                raise CliFailure("SFX_ASSET_NOT_IMPORTED", "preconditions",
                                 f"import custom sound {token!r} before atomic HTML placement",
                                 exit_code=EXIT_OPERATION_FAILED)
        result.append({"assetId": asset_id, "sfxId": entry["id"], "kind": entry["kind"],
                       "offsetFrames": round(offset) - lead})
    return result


def component_preset_id(project: dict[str, Any], clip: dict[str, Any]) -> str | None:
    """The preset an HTML component clip was placed from, if any."""
    source = clip.get("source") or {}
    if source.get("type") != "component":
        return None
    for component in project.get("components") or []:
        if component.get("id") == source.get("componentId"):
            root = (component.get("properties") or {}).get("root") or {}
            preset_id = (root.get("attributes") or {}).get("data-form-preset")
            return preset_id if isinstance(preset_id, str) else None
    return None


def attach_placement_sfx(
    client: Any,
    project_id: str,
    sequence_id_argument: str | None,
    at_frame: int,
    token: str,
    target_clip_id: str | None,
    intent: str,
    delay_seconds: Fraction = Fraction(0),
    cue: str | None = None,
) -> dict[str, Any]:
    """Place one linked sound for a component/sticker that just landed.

    `delay_seconds` is how far into the component its sounding action
    happens (see `preset_sfx_delay`); the sound lands that many frames later."""
    entry = resolve_sfx(token)
    snapshot = client.request("GET", f"/v1/projects/{quote(project_id)}/snapshot")
    project = require_object(require_object(snapshot, "data"), "project")
    sequence_id = sequence_id_argument or default_sequence_id(project)
    sequence = require_sequence(project, sequence_id)
    rate = sequence_frame_rate_from(project, sequence_id)
    asset_id, duration_seconds = ensure_sfx_asset(client, project_id, project, entry)
    commands = sfx_placement_commands(
        sequence, sequence_id, asset_id, duration_seconds, rate,
        at_frame + round(delay_seconds * rate), entry, target_clip_id, cue)
    batch = sfx_command_batch(
        project_id, current_revision(client), intent, None, "attach-sfx", commands)
    client.request("POST", f"/v1/projects/{quote(project_id)}/commands", batch)
    return {"id": entry["id"], "kind": entry["kind"],
            **({"targetClipId": target_clip_id} if target_clip_id else {}),
            **({"cue": cue} if cue else {})}


def percent_0_100(value: str) -> int:
    number = int(value)
    if number < 0 or number > 100:
        raise argparse.ArgumentTypeError("expected an integer percent in 0..100")
    return number


EXPOSURE_EFFECT_TYPE = "dev.orangecut.visual.exposure"
EXPOSURE_PARAMETERS = ("brightness", "saturation")


def exposure_percent(value: str) -> int:
    """Brightness deliberately reaches past 100: a flash is an overexposure."""
    number = int(value)
    if number < 0 or number > 1000:
        raise argparse.ArgumentTypeError("expected an integer percent in 0..1000")
    return number


LAYER_STYLE_EFFECT_TYPE = "dev.orangecut.visual.layer-style"
LAYER_STYLE_MAX_BLUR = 200
LAYER_STYLE_MAX_GLOW = 400
LAYER_STYLE_KEYFRAME_PARAMETERS = {"blur": "blur", "glow": "glowRadius", "glowRadius": "glowRadius"}


def style_invalid(message: str) -> CliFailure:
    return CliFailure("CLI_ARGUMENT_INVALID", "validation", message, exit_code=EXIT_INVALID_INPUT)


def layer_style_length(value: float, maximum: int, name: str) -> dict[str, str]:
    if not math.isfinite(value) or value < 0 or value > maximum:
        raise style_invalid(f"--{name} must be between 0 and {maximum} canvas pixels")
    return decimal_rational_number(value)


def layer_style_color(text: str) -> str:
    if re.fullmatch(r"#[0-9A-Fa-f]{6}", text):
        return text.upper() + "FF"
    if re.fullmatch(r"#[0-9A-Fa-f]{8}", text):
        return text.upper()
    raise style_invalid("--glow-color must be #RRGGBB or #RRGGBBAA")


def parse_layer_style_keyframe(spec: str, rate: Fraction) -> dict[str, Any]:
    """`PARAM@FRAME=PX[:EASE]` → one Core keyframe (Clip-local exact time)."""
    shape = "expected PARAM@FRAME=PX[:EASE], e.g. glow@12=40 or blur@30=0:hold"
    parameter, separator, rest = spec.partition("@")
    if not separator:
        raise style_invalid(shape)
    if parameter not in LAYER_STYLE_KEYFRAME_PARAMETERS:
        raise style_invalid(f"unknown layer-style parameter {parameter!r}; expected blur or glow")
    frame_text, separator, rest = rest.partition("=")
    if not separator:
        raise style_invalid(shape)
    value_text, _, easing = rest.partition(":")
    easing = easing or "linear"
    if easing not in ("hold", "linear"):
        raise style_invalid(f"unknown easing {easing!r}; expected hold or linear")
    try:
        frame = int(frame_text)
        value = float(value_text)
    except ValueError:
        raise style_invalid(shape) from None
    if frame < 0:
        raise style_invalid("a keyframe frame cannot be negative")
    name = LAYER_STYLE_KEYFRAME_PARAMETERS[parameter]
    maximum = LAYER_STYLE_MAX_BLUR if name == "blur" else LAYER_STYLE_MAX_GLOW
    at = Fraction(frame) / rate
    return {
        "parameter": name,
        "time": {"num": str(at.numerator), "den": str(at.denominator)},
        "value": layer_style_length(value, maximum, parameter),
        "interpolation": easing,
    }


def layer_style_commands(sequence_id: str, clip: dict[str, Any], rate: Fraction, arguments: argparse.Namespace) -> list[dict[str, Any]]:
    """Patch the Clip's layer look: flags left out keep their current values."""
    existing = next((e for e in clip.get("effects", []) if e.get("effectType") == LAYER_STYLE_EFFECT_TYPE), None)
    if arguments.clear:
        if existing is None:
            raise CliFailure(
                "STYLE_NOT_PRESENT", "preconditions",
                f"clip {clip['id']!r} carries no layer look to clear",
                remediation="drop --clear, or pass a clip that has one", exit_code=EXIT_INVALID_INPUT,
            )
        return [{"type": "effect.remove", "payload": {"sequenceId": sequence_id, "clipId": clip["id"], "effectId": existing["id"]}}]
    if arguments.keyframe is not None and arguments.clear_keyframes:
        raise style_invalid("--keyframe and --clear-keyframes contradict each other")
    touched = any(
        value is not None for value in (arguments.blur, arguments.glow, arguments.glow_color, arguments.glow_strength, arguments.keyframe)
    ) or arguments.clear_keyframes
    if not touched:
        raise style_invalid("nothing to change: pass --blur, --glow, --glow-color, --glow-strength, --keyframe, --clear-keyframes or --clear")
    parameters = dict((existing or {}).get("parameters") or {
        "blur": {"num": "0", "den": "1"},
        "glowRadius": {"num": "0", "den": "1"},
        "glowColor": "#FFFFFFFF",
        "glowStrength": {"num": "2", "den": "1"},
    })
    if arguments.blur is not None:
        parameters["blur"] = layer_style_length(arguments.blur, LAYER_STYLE_MAX_BLUR, "blur")
    if arguments.glow is not None:
        parameters["glowRadius"] = layer_style_length(arguments.glow, LAYER_STYLE_MAX_GLOW, "glow")
    if arguments.glow_color is not None:
        parameters["glowColor"] = layer_style_color(arguments.glow_color)
    if arguments.glow_strength is not None:
        parameters["glowStrength"] = {"num": str(arguments.glow_strength), "den": "1"}
    keyframes = list((existing or {}).get("keyframes") or [])
    if arguments.clear_keyframes:
        keyframes = []
    elif arguments.keyframe is not None:
        keyframes = [parse_layer_style_keyframe(spec, rate) for spec in arguments.keyframe]
        # Core wants one strictly increasing run per parameter; the CLI is the last place
        # that still knows the author's typing order, so it sorts.
        keyframes.sort(key=lambda entry: (entry["parameter"], Fraction(int(entry["time"]["num"]), int(entry["time"]["den"]))))
    effect = {
        "id": existing["id"] if existing else f"layer-style-{uuid.uuid4()}",
        "effectType": LAYER_STYLE_EFFECT_TYPE,
        "target": "visual",
        "parameters": parameters,
        "keyframes": keyframes,
        "capabilityRequirements": [],
        "extensions": {},
    }
    return [{
        "type": "effect.update" if existing else "effect.add",
        "payload": {"sequenceId": sequence_id, "clipId": clip["id"], "effect": effect},
    }]


def parse_exposure_keyframe(spec: str) -> tuple[str, int, int, str]:
    """`PARAM@FRAME=PERCENT[:EASE]` into its four exact parts."""
    shape = "expected PARAM@FRAME=PERCENT[:EASE], e.g. brightness@94=190:hold"
    parameter, separator, rest = spec.partition("@")
    if not separator:
        raise argparse.ArgumentTypeError(shape)
    if parameter not in EXPOSURE_PARAMETERS:
        raise argparse.ArgumentTypeError(
            f"unknown exposure parameter {parameter!r}; expected brightness or saturation"
        )
    frame_text, separator, rest = rest.partition("=")
    if not separator:
        raise argparse.ArgumentTypeError(shape)
    percent_text, separator, easing = rest.partition(":")
    easing = easing or "linear"
    if easing not in ("hold", "linear"):
        raise argparse.ArgumentTypeError(
            f"unknown easing {easing!r}; expected hold or linear"
        )
    try:
        frame = int(frame_text)
        percent = int(percent_text)
    except ValueError:
        raise argparse.ArgumentTypeError(shape) from None
    if frame < 0:
        raise argparse.ArgumentTypeError("a keyframe frame cannot be negative")
    if percent < 0 or percent > 1000:
        raise argparse.ArgumentTypeError("expected an integer percent in 0..1000")
    return parameter, frame, percent, easing


def percent_rational(percent: int) -> dict[str, str]:
    """An integer percent as the canonical (reduced) wire Rational.

    The wire rejects non-normalized fractions, so 80% must travel as 4/5,
    never as 80/100.
    """
    fraction = Fraction(percent, 100)
    return {"num": str(fraction.numerator), "den": str(fraction.denominator)}


def parse_adjust_arguments(pairs: list[str]) -> list[tuple[str, int]]:
    parsed: list[tuple[str, int]] = []
    for pair in pairs:
        key, separator, raw = pair.partition("=")
        try:
            value = int(raw)
        except ValueError:
            value = 101
        if not separator or not key or value < -100 or value > 100:
            raise CliFailure(
                "GRADE_ADJUST_INVALID",
                "validation",
                f"--adjust expects KEY=PERCENT with percent in -100..100, got {pair!r}",
                remediation="e.g. --adjust temperature=20 --adjust contrast=-10",
                exit_code=EXIT_INVALID_INPUT,
            )
        parsed.append((key, value))
    return parsed


def parse_caption_emphases(pairs: list[str]) -> list[dict[str, str]]:
    """`TEXT=#RRGGBB` pairs as the wire's emphasis objects.

    The split is on the last `=` so keyword text may itself contain one; the
    colour side is shape-checked here so a typo is named locally instead of
    surfacing as a whole-batch rejection.
    """
    emphases: list[dict[str, str]] = []
    for pair in pairs:
        text, separator, color = pair.rpartition("=")
        valid_color = (
            len(color) in (7, 9)
            and color.startswith("#")
            and all(character in "0123456789abcdefABCDEF" for character in color[1:])
        )
        if not separator or not text or not valid_color:
            raise CliFailure(
                "CAPTION_EMPHASIS_INVALID",
                "validation",
                f"--emphasis expects TEXT=#RRGGBB (or #RRGGBBAA), got {pair!r}",
                remediation="e.g. --emphasis 抢着买=#3DDC84",
                exit_code=EXIT_INVALID_INPUT,
            )
        emphases.append({"text": text, "color": color})
    return emphases


def positive_frame_rate(value: str) -> Fraction:
    try:
        rate = Fraction(value)
    except (ValueError, ZeroDivisionError) as error:
        raise argparse.ArgumentTypeError("FPS must be a positive number or rational") from error
    if rate <= 0 or max(rate.numerator, rate.denominator) > 2**63 - 1:
        raise argparse.ArgumentTypeError("FPS must be a positive rational within signed 64-bit limits")
    return rate


def positive_integer(value: str) -> int:
    parsed = int(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return parsed


def canvas_dimension(value: str) -> int:
    parsed = int(value)
    if parsed < 16 or parsed > 8192 or parsed % 2 != 0:
        raise argparse.ArgumentTypeError(
            "must be an even pixel dimension between 16 and 8192"
        )
    return parsed


def absolute_media_path(path: Path) -> Path:
    resolved = path.expanduser().resolve()
    if not resolved.is_file():
        raise CliFailure(
            "MEDIA_PATH_INVALID",
            "validation",
            f"no readable file at {resolved}",
            remediation="pass an absolute path to an existing media file",
            exit_code=EXIT_INVALID_INPUT,
        )
    return resolved


def matched_source_canvas(client: "Client", source: Path) -> tuple[dict[str, int], dict[str, str]]:
    """Canvas and frame rate that reproduce a source video exactly.

    Burning an overlay into somebody's finished video means re-encoding it. The
    one thing that must not change is its shape: a canvas that differs by a
    pixel rescales every frame, and a frame rate that differs by a thousandth
    resamples time. Both are silent, and both are what a person would notice.
    """
    response = client.request(
        "POST", "/v1/media/probe", {"path": str(absolute_media_path(source))}
    )
    probe = response.get("data") if isinstance(response, dict) else None
    if not isinstance(probe, dict):
        raise CliFailure(
            "MEDIA_PROBE_UNREADABLE",
            "serialization",
            "the service did not return a probe for the source video",
            exit_code=EXIT_INVALID_INPUT,
        )
    width, height = probe.get("displayWidth"), probe.get("displayHeight")
    if not isinstance(width, int) or not isinstance(height, int):
        raise CliFailure(
            "MEDIA_PROBE_UNREADABLE",
            "validation",
            f"{source.name} reports no video size to match",
            remediation="pass a file that carries a video stream",
            exit_code=EXIT_INVALID_INPUT,
        )
    num, den = probe.get("frameRateNum"), probe.get("frameRateDen")
    if not isinstance(num, int) or not isinstance(den, int) or num <= 0 or den <= 0:
        raise CliFailure(
            "MEDIA_PROBE_UNREADABLE",
            "validation",
            f"{source.name} reports no usable frame rate to match",
            exit_code=EXIT_INVALID_INPUT,
        )
    # A variable frame rate has no single number to match, so matching it would
    # be a guess that shifts every later frame. Say so instead of guessing.
    if probe.get("frameRateMode") == "variable":
        raise CliFailure(
            "MEDIA_FRAME_RATE_VARIABLE",
            "preconditions",
            f"{source.name} is variable frame rate, so no single canvas rate matches it",
            remediation="convert the source to constant frame rate first, then retry",
            exit_code=EXIT_INVALID_INPUT,
        )
    return snapped_canvas_dimensions(width, height), {"num": str(num), "den": str(den)}


def snapped_canvas_dimensions(width: int, height: int) -> dict[str, int]:
    """The nearest canvas the service accepts: [16, 8192] and even.

    An odd-sized source cannot be reproduced exactly under the H.264 even-pixel
    rule; flooring one dimension by a single pixel is the least-bad match and
    beats rejecting the file outright.
    """
    if width <= 0 or height <= 0:
        raise CliFailure(
            "MEDIA_PROBE_UNREADABLE",
            "validation",
            "the source video reports a non-positive display size",
            exit_code=EXIT_INVALID_INPUT,
        )
    longest = max(width, height)
    if longest > 8192:
        width = width * 8192 // longest
        height = height * 8192 // longest

    def snap(value: int) -> int:
        return max(16, min(8192, value)) // 2 * 2

    return {"width": snap(width), "height": snap(height)}


def requested_project_canvas(arguments: argparse.Namespace) -> dict[str, int] | None:
    has_width = arguments.width is not None
    has_height = arguments.height is not None
    if has_width != has_height:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            "--width and --height must be provided together",
            remediation="provide both concrete canvas dimensions, or use --aspect-ratio",
            exit_code=EXIT_INVALID_INPUT,
        )
    if has_width and arguments.aspect_ratio is not None:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            "--width/--height cannot be combined with --aspect-ratio",
            remediation="choose concrete dimensions or one legacy ratio shortcut",
            exit_code=EXIT_INVALID_INPUT,
        )
    if has_width:
        return {"width": arguments.width, "height": arguments.height}
    presets = {
        "9:16": {"width": 1080, "height": 1920},
        "16:9": {"width": 1920, "height": 1080},
        "1:1": {"width": 1080, "height": 1080},
    }
    if arguments.aspect_ratio is not None:
        return presets[arguments.aspect_ratio]
    # No canvas request at all: the project is created in auto mode and the
    # canvas follows the first visual clip placed on the timeline.
    return None


def non_negative_float(value: str) -> float:
    """0 是合法的:羽化 0 就是不羽化,那是硬边,不是错误输入。"""
    parsed = float(value)
    if not math.isfinite(parsed) or parsed < 0 or parsed > 64:
        raise argparse.ArgumentTypeError("must be between 0 and 64")
    return parsed


def positive_float(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed) or parsed <= 0 or parsed > 300:
        raise argparse.ArgumentTypeError("must be greater than zero and at most 300")
    return parsed


def read_timeout_seconds(value: str) -> float:
    """How long to wait for a read.

    Deliberately not `positive_float`: that caps at 300 seconds, which suits
    watching one Job but not a read that may legitimately composite up to 256
    frames. A ceiling below the work's real cost would cancel a render that was
    about to succeed."""
    parsed = float(value)
    if not math.isfinite(parsed) or parsed <= 0 or parsed > 3600:
        raise argparse.ArgumentTypeError("must be greater than zero and at most 3600")
    return parsed


def matte_outline_width(value: str) -> int:
    if re.fullmatch(r"[+-]?[0-9]{1,2}", value) is not None and 0 <= int(value) <= 32:
        return int(value)
    raise argparse.ArgumentTypeError("outline width must be an integer from 0 to 32 pixels")


def matte_outline_color(value: str) -> str:
    if re.fullmatch(r"#[0-9A-Fa-f]{6}(?:[0-9A-Fa-f]{2})?", value) is None:
        raise argparse.ArgumentTypeError("outline color must be #RRGGBB or #RRGGBBAA")
    return value


def non_negative_integer(value: str) -> int:
    parsed = int(value)
    if parsed < 0:
        raise argparse.ArgumentTypeError("must be non-negative")
    return parsed


def box_argument(value: str) -> list[float]:
    parts = value.split(",")
    if len(parts) != 4:
        raise argparse.ArgumentTypeError("box must be x,y,w,h")
    try:
        parsed = [float(part) for part in parts]
    except ValueError:
        raise argparse.ArgumentTypeError("box must be four numbers: x,y,w,h")
    if parsed[2] <= 0 or parsed[3] <= 0:
        raise argparse.ArgumentTypeError("box width and height must be positive")
    return parsed


def size_argument(value: str) -> tuple[int, int]:
    parts = value.lower().split("x")
    if len(parts) != 2:
        raise argparse.ArgumentTypeError("size must be WxH, e.g. 1920x1080")
    try:
        width, height = int(parts[0]), int(parts[1])
    except ValueError:
        raise argparse.ArgumentTypeError("size must be two integers: WxH")
    if width <= 0 or height <= 0:
        raise argparse.ArgumentTypeError("size must be positive")
    return (width, height)


def pair_argument(value: str) -> list[float]:
    parts = value.split(",")
    if len(parts) != 2:
        raise argparse.ArgumentTypeError("must be two numbers: x,y")
    try:
        return [float(parts[0]), float(parts[1])]
    except ValueError:
        raise argparse.ArgumentTypeError("must be two numbers: x,y")


def radius_argument(value: str) -> list[float]:
    parts = value.split(",")
    if len(parts) not in (1, 2):
        raise argparse.ArgumentTypeError("radius must be r or rx,ry")
    try:
        numbers = [float(part) for part in parts]
    except ValueError:
        raise argparse.ArgumentTypeError("radius must be numeric")
    if any(number <= 0 for number in numbers):
        raise argparse.ArgumentTypeError("radius must be positive")
    return numbers if len(numbers) == 2 else [numbers[0], numbers[0]]


def point_argument(value: str) -> tuple[float, float, int]:
    """`x,y` is a positive (foreground) prompt point; `neg:x,y` a negative one."""
    label = 1
    body = value
    if value.startswith("neg:"):
        label = 0
        body = value[4:]
    parts = body.split(",")
    if len(parts) != 2:
        raise argparse.ArgumentTypeError("point must be x,y or neg:x,y")
    try:
        x, y = float(parts[0]), float(parts[1])
    except ValueError:
        raise argparse.ArgumentTypeError("point must be two numbers: x,y")
    return (x, y, label)


def export_crf(value: str) -> int:
    parsed = int(value)
    if not 0 <= parsed <= 63:
        raise argparse.ArgumentTypeError("must be between 0 and 63")
    return parsed


def export_frame_rate(value: str) -> dict[str, str]:
    """An export frame rate as an exact ratio on the wire.

    Accepts `30` or `30000/1001` and never a decimal: 29.97 is not the NTSC
    rate, and a rounded rate drifts a long export by whole frames before it
    ends.
    """
    text = value.strip()
    numerator, separator, denominator = text.partition("/")
    try:
        num = int(numerator)
        den = int(denominator) if separator else 1
    except ValueError:
        raise argparse.ArgumentTypeError(
            "must be an integer or an exact `numerator/denominator` ratio"
        ) from None
    if num <= 0 or den <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    if not den <= num <= den * 240:
        raise argparse.ArgumentTypeError("must be between 1 and 240")
    return {"num": str(num), "den": str(den)}


def audio_gain_percent(value: str) -> int:
    """A linear gain as a whole percent — 100 keeps the recorded level."""
    parsed = int(value)
    if not 0 <= parsed <= 1000:
        raise argparse.ArgumentTypeError("must be between 0 and 1000")
    return parsed


def audio_pan_percent(value: str) -> int:
    """Stereo placement as a whole percent — -100 hard left, 100 hard right."""
    parsed = int(value)
    if not -100 <= parsed <= 100:
        raise argparse.ArgumentTypeError("must be between -100 and 100")
    return parsed


def speed_curve_rate_at(curve: list[tuple[Fraction, Fraction]], at: Fraction) -> Fraction:
    """曲线在某一时刻的速率。首帧之前取首值,末帧之后取末值,中间线性。"""
    if at <= curve[0][0]:
        return curve[0][1]
    for (left_time, left_rate), (right_time, right_rate) in zip(curve, curve[1:]):
        if at < right_time:
            span = right_time - left_time
            if span <= 0:
                return left_rate
            return left_rate + (right_rate - left_rate) * (at - left_time) / span
    return curve[-1][1]


def speed_curve_consumed(
    curve: list[tuple[Fraction, Fraction]], start: Fraction, end: Fraction
) -> Fraction:
    """曲线在 [start, end] 上消耗的源时长——速率对时间的积分。

    分段线性函数的积分是有理数封闭的(每段一个梯形),所以全程用 Fraction
    精确算,不碰浮点。**端点带上无法复现的尾数,工程就再也对不上第二次**,
    而这个值正是要写进 sourceRange 的那个端点。

    求值契约与引擎共用 `fixtures/rendering/speed-curve.json`——两处实现没法
    共享代码,只能靠那份向量对齐。
    """
    total = Fraction(0)
    cursor = start
    if cursor < curve[0][0]:
        edge = min(end, curve[0][0])
        total += curve[0][1] * (edge - cursor)
        cursor = edge
    for (left_time, _), (right_time, _) in zip(curve, curve[1:]):
        if cursor >= end:
            break
        if right_time <= cursor:
            continue
        span_start = max(cursor, left_time)
        span_end = min(end, right_time)
        if span_end <= span_start:
            continue
        mean = (
            speed_curve_rate_at(curve, span_start) + speed_curve_rate_at(curve, span_end)
        ) / 2
        total += mean * (span_end - span_start)
        cursor = span_end
    if cursor < end:
        total += curve[-1][1] * (end - cursor)
    return total


def speed_rate_percent(value: str) -> int:
    """A retime rate as a whole percent — 200 is twice as fast, 50 is half.

    Percent rather than a decimal so the rate stays an exact ratio: 150% is
    3/2, which a float can only approximate, and an approximate rate drifts
    picture out of sync with the sound it is linked to.
    """
    parsed = int(value)
    if not 1 <= parsed <= 10000:
        raise argparse.ArgumentTypeError("must be between 1 and 10000")
    return parsed


def frame_index_list(value: str) -> list[int]:
    entries = [entry.strip() for entry in value.split(",") if entry.strip()]
    if not entries:
        raise argparse.ArgumentTypeError("must name at least one frame index")
    if len(entries) > 256:
        raise argparse.ArgumentTypeError("must name at most 256 frame indices")
    frames = []
    for entry in entries:
        try:
            frames.append(int(entry))
        except ValueError as error:
            raise argparse.ArgumentTypeError(
                f"{entry!r} is not a frame index"
            ) from error
    return frames


def exact_decimal_range(value: str) -> dict[str, dict[str, str]]:
    parts = value.split(":")
    if len(parts) != 2:
        raise argparse.ArgumentTypeError("must be START:END in seconds")
    start = exact_decimal_rational(parts[0])
    end = exact_decimal_rational(parts[1])
    if int(start["num"]) * int(end["den"]) >= int(end["num"]) * int(start["den"]):
        raise argparse.ArgumentTypeError("END must be strictly after START")
    return {"start": start, "end": end}


def exact_decimal_rational(value: str) -> dict[str, str]:
    match = re.fullmatch(r"([+-]?)([0-9]+)(?:\.([0-9]+))?", value.strip())
    if match is None:
        raise argparse.ArgumentTypeError(
            "must be an ordinary finite decimal without exponent or unit"
        )
    sign, integer, fractional = match.groups()
    fractional = fractional or ""
    denominator = 10 ** len(fractional)
    numerator = int(integer) * denominator + int(fractional or "0")
    if sign == "-":
        numerator = -numerator
    divisor = math.gcd(abs(numerator), denominator)
    return {
        "num": str(numerator // divisor),
        "den": str(denominator // divisor),
    }


def text_color(value: str) -> str:
    normalized = value.upper()
    if (
        len(normalized) not in (7, 9)
        or not normalized.startswith("#")
        or any(character not in "0123456789ABCDEF" for character in normalized[1:])
    ):
        raise argparse.ArgumentTypeError("must use #RRGGBB or #RRGGBBAA")
    return normalized


def reject_non_json_constant(value: str) -> NoReturn:
    raise ValueError(f"non-JSON numeric constant: {value}")


def reject_duplicate_object_names(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON object name: {key}")
        result[key] = value
    return result


def strict_json_loads(source: str) -> Any:
    value = json.loads(
        source,
        parse_constant=reject_non_json_constant,
        object_pairs_hook=reject_duplicate_object_names,
    )
    validate_json_depth(value)
    return value


def validate_json_depth(value: Any) -> None:
    pending = [(value, 0)]
    while pending:
        current, depth = pending.pop()
        if depth > MAX_STRICT_JSON_DEPTH:
            raise ValueError("JSON value exceeds the nesting-depth limit")
        if isinstance(current, dict):
            pending.extend((item, depth + 1) for item in current.values())
        elif isinstance(current, list):
            pending.extend((item, depth + 1) for item in current)


def is_v0_json_object(value: Any) -> bool:
    try:
        return isinstance(value, dict) and all(
            isinstance(key, str) and is_v0_json_value(item)
            for key, item in value.items()
        )
    except RecursionError:
        return False


def is_v0_json_value(value: Any) -> bool:
    if value is None or isinstance(value, (bool, str)):
        return True
    if isinstance(value, int):
        return -MAX_SAFE_INTEGER <= value <= MAX_SAFE_INTEGER
    if isinstance(value, list):
        return all(is_v0_json_value(item) for item in value)
    if isinstance(value, dict):
        return all(
            isinstance(key, str) and is_v0_json_value(item)
            for key, item in value.items()
        )
    return False


def quote(value: str) -> str:
    return urllib.parse.quote(value, safe="")


def safe_error_details(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    return {
        key: safe_error_detail_value(item)
        for key, item in value.items()
        if isinstance(key, str) and not sensitive_detail_key(key)
    }


def event_stream_progress_details(
    server_details: Any, received_events: int, reconnect_cursor: str | None
) -> dict[str, Any]:
    details = safe_error_details(server_details)
    details["receivedEvents"] = received_events
    if reconnect_cursor is not None:
        details["reconnectCursor"] = reconnect_cursor
    return details


def event_stream_timeout(
    received_events: int, reconnect_cursor: str | None
) -> CliFailure:
    return CliFailure(
        "EVENT_STREAM_TIMEOUT",
        "preconditions",
        "the requested event count did not arrive before the timeout",
        retryable=True,
        remediation="retry with the returned cursor or a longer timeout",
        exit_code=EXIT_SERVICE_UNAVAILABLE,
        details=event_stream_progress_details(
            None, received_events, reconnect_cursor
        ),
    )


def add_event_stream_progress(
    error: CliFailure, received_events: int, reconnect_cursor: str | None
) -> CliFailure:
    return CliFailure(
        code=error.code,
        stage=error.stage,
        message=error.message,
        retryable=error.retryable,
        remediation=error.remediation,
        current_revision=error.current_revision,
        exit_code=error.exit_code,
        details=event_stream_progress_details(
            error.details, received_events, reconnect_cursor
        ),
    )


def safe_error_detail_value(value: Any) -> Any:
    if isinstance(value, dict):
        return safe_error_details(value)
    if isinstance(value, list):
        return [safe_error_detail_value(item) for item in value]
    return value


def sensitive_detail_key(key: str) -> bool:
    normalized = key.casefold()
    return any(
        fragment in normalized
        for fragment in ("path", "root", "token", "input", "output", "stderr")
    )


def normalize_arguments(arguments: Iterable[str]) -> list[str]:
    """剥掉 `--json`(输出永远是 JSON),摘出 `--project <id>` / `--project=<id>`。
    两者都允许写在子命令后面,所以不能交给 argparse 的根解析器。"""
    global _REQUESTED_PROJECT
    kept: list[str] = []
    pending_project = False
    for argument in arguments:
        if pending_project:
            _REQUESTED_PROJECT = argument
            pending_project = False
            continue
        if argument == "--json":
            continue
        if argument == "--project":
            pending_project = True
            continue
        if argument.startswith("--project="):
            _REQUESTED_PROJECT = argument[len("--project=") :]
            continue
        kept.append(argument)
    if pending_project:
        raise CliFailure(
            "CLI_ARGUMENT_INVALID",
            "validation",
            "--project requires a Project id",
            exit_code=EXIT_INVALID_INPUT,
        )
    return kept


def emit(payload: dict[str, Any], stream: Any) -> None:
    json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    stream.write("\n")
    stream.flush()


def fail(error: CliFailure) -> NoReturn:
    # 成功与失败共用 stdout 这一条机器可读通道:调用方无需再猜错误信封
    # 落在哪个流上(此前错误走 stderr、stdout 为空,所有调用方都要踩一次
    # 解析坑)。退出码不变,`ok:false` 即失败。stderr 同步一份给人眼与
    # 只看 stderr 的旧调用方。
    payload = attach_project_id(error.wire())
    emit(payload, sys.stdout)
    emit(payload, sys.stderr)
    raise SystemExit(error.exit_code)


def use_utf8_streams() -> None:
    """把 stdout/stderr 钉到 UTF-8。

    中文 Windows 控制台的默认编码是 GBK,而这条通道运的是 JSON——里面随时会
    出现 GBK 编不出来的字符(实测一个 `✗` 就让整条命令以 UnicodeEncodeError
    崩掉,而那时工作**已经做完了**,只是结果发不出来)。调用方拿到的是一段
    Python traceback 而不是错误信封,比失败本身更难查。

    `errors="replace"` 是最后一道保险:宁可某个字符显示成问号,也不能因为
    一个字符丢掉整个结果。
    """
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            reconfigure(encoding="utf-8", errors="replace")
        except (OSError, ValueError):
            # 重定向到不支持重配的对象上就算了,不值得为它失败。
            continue


def attach_project_id(payload: dict[str, Any]) -> dict[str, Any]:
    """信封顶层回显这条命令打到的工程(ADR 0043),让调用方每一步都能核对。"""
    if _RESOLVED_PROJECT is not None:
        payload.setdefault("projectId", _RESOLVED_PROJECT)
    return payload


def main(argv: Iterable[str] | None = None) -> int:
    use_utf8_streams()
    global _REQUESTED_PROJECT, _RESOLVED_PROJECT, _NAMED_PROJECT
    _REQUESTED_PROJECT = None
    _RESOLVED_PROJECT = None
    _NAMED_PROJECT = None
    try:
        raw = list(sys.argv[1:] if argv is None else argv)
        arguments = normalize_arguments(raw)
        parsed = parser().parse_args(arguments)
        if getattr(parsed, "no_autostart", False):
            suppress_autostart()
        result = execute(parsed)
        if parsed.command == "layout" and getattr(parsed, "human", False) and "--json" not in raw:
            print(render_layout_human(result))
        else:
            emit(attach_project_id(attach_autostart_warning(envelope(result))), sys.stdout)
        return 0
    except CliFailure as error:
        fail(error)
    return EXIT_OPERATION_FAILED


if __name__ == "__main__":
    raise SystemExit(main())
