"""Presenter PiP: one semantic batch; no project files or renderer state are written.

oc html presenter '{"assetId":"camera","durationFrames":300,"cues":[
  {"atFrame":0,"pose":"center"},{"atFrame":90,"pose":"br"}]}'

Cue frames are clip-local; startFrame places the whole composition. Source audio
is a separate editable clip. Sfx volume is linear gain (default 0.5, about -6dB).
Explicit sfx="none" disables movement sounds. Replacements are bundled IDs only.
Close cues truncate the preceding transition at the next changed pose. All
geometry is canvas-relative; Windows/macOS use the same HTML/CSS contract.
This does not infer poses from faces or content; the caller supplies semantic cues.
"""
from __future__ import annotations

from fractions import Fraction
import json
import math
import re
import uuid

from .dual_view import _fields, _frame, _number, _rat, _wire
from .screen_wrap import build_operations

POSES = ("full", "center", "left", "right", "br", "tr", "tl", "bl", "off")
DEFAULTS = dict(startFrame=0, sourceStartFrame=0, transitionSec=.38,
                borderColor="#fb923c", dimOnCenter=True, faceX=50, faceY=38,
                fit="cover", includeAudio=True, sfx="wind-swoosh", sfxVolume=.5)


def validate(config, assets, sequence):
    from .cli import BUNDLED_SFX_MANIFEST
    _fields(config, (*DEFAULTS, "assetId", "durationFrames", "cues"), "presenter")
    resolved = dict(DEFAULTS, **config)
    if resolved["fit"] not in ("cover", "contain"):
        raise ValueError("Invalid presenter fit: expected cover or contain")
    for key in ("startFrame", "sourceStartFrame", "durationFrames"):
        _frame(resolved.get(key), key, 1 if key == "durationFrames" else 0)
        if resolved[key] > 9007199254740991:
            raise ValueError("presenter frame exceeds safe range")
    for key, low, high in (("transitionSec", .001, 10), ("faceX", 0, 100),
                           ("faceY", 0, 100), ("sfxVolume", 0, 2)):
        _number(resolved[key], key, low, high)
    if any(type(resolved[key]) is not bool for key in ("dimOnCenter", "includeAudio")) or not isinstance(resolved["borderColor"], str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", resolved["borderColor"]):
        raise ValueError("invalid presenter appearance")
    cues = resolved.get("cues")
    if not isinstance(cues, list) or not 1 <= len(cues) <= 128:
        raise ValueError("expected 1..128 presenter cues")
    previous = -1
    for cue in cues:
        _fields(cue, ("atFrame", "pose"), "cue")
        frame = _frame(cue.get("atFrame"), "atFrame")
        if frame <= previous or frame >= resolved["durationFrames"] or cue.get("pose") not in POSES:
            raise ValueError("presenter cues must be ordered, unique and inside the clip")
        previous = frame
    if cues[0]["atFrame"] != 0:
        raise ValueError("first presenter cue must start at local frame 0")
    rate = _wire(sequence["frameRate"])
    if rate <= 0:
        raise ValueError("invalid presenter frame rate")
    for key in ("width", "height"):
        _frame(sequence["canvas"][key], key, 1)
        if sequence["canvas"][key] > 32768:
            raise ValueError("invalid presenter canvas")
    source = next((asset for asset in assets if asset["id"] == resolved.get("assetId")), None)
    probe = (source or {}).get("probe") or {}
    duration = probe.get("duration")
    if not source or source["kind"] != "video" or not any(stream["kind"] == "video" for stream in probe.get("streams", [])) or not duration or Fraction(resolved["sourceStartFrame"] + resolved["durationFrames"]) / rate > _wire(duration):
        raise ValueError("presenter exceeds an imported video source")
    if resolved["includeAudio"] and not any(stream["kind"] == "audio" for stream in probe.get("streams", [])):
        raise ValueError("presenter source has no audio; set includeAudio to false")
    entry = next((item for item in BUNDLED_SFX_MANIFEST if item["id"] == resolved["sfx"]), None)
    if resolved["sfx"] != "none" and entry is None:
        raise ValueError("unknown bundled presenter sfx")
    sound = next((asset for asset in assets if entry and asset["id"] == entry["assetId"]), None)
    if entry and (not sound or sound["kind"] != "audio" or not (sound.get("probe") or {}).get("duration") or _wire(sound["probe"]["duration"]) <= 0):
        raise ValueError("missing bundled presenter sfx asset")
    return resolved, source, entry, sound


def fragment(config, assets, sequence, instance):
    resolved, *_ = validate(config, assets, sequence)
    if not re.fullmatch(r"[A-Za-z0-9_-]+", instance):
        raise ValueError("invalid presenter instance")
    prefix = "oc-presenter-" + instance
    width, height = sequence["canvas"]["width"], sequence["canvas"]["height"]
    short, portrait = min(width, height), height > width
    box_width = width * (.82 if portrait else .4)
    box_height = height * (.5 if portrait else .8)
    fixed = lambda value: f"{math.floor(value * 1e6 + .5) / 1e6:.6f}"

    def geometry(pose):
        if pose == "full":
            return "left:50cqw;top:50cqh;width:100cqw;height:100cqh;border-radius:0%;transform:translate(-50%,-50%) translateX(0cqw);box-shadow:0 0 0 0 transparent;"
        circle = pose in ("br", "tr", "tl", "bl")
        pane_width = short * .26 if circle else box_width
        pane_height = short * .26 if circle else box_height
        center_x = (width - short * .05 - pane_width / 2 if pose.endswith("r") else short * .05 + pane_width / 2) if circle else short * .05 + pane_width / 2 if pose == "left" else width - short * .05 - pane_width / 2 if pose == "right" else width / 2
        center_y = (height - short * .05 - pane_height / 2 if pose.startswith("b") else short * .05 + pane_height / 2) if circle else height / 2
        return "left:" + fixed(center_x / width * 100) + "cqw;top:" + fixed(center_y / height * 100) + "cqh;width:" + fixed(pane_width / width * 100) + "cqw;height:" + fixed(pane_height / height * 100) + "cqh;border-radius:" + ("50%" if circle else "6%") + ";transform:translate(-50%,-50%) translateX(" + ("120cqw" if pose == "off" else "0cqw") + ");box-shadow:0 1cqh 3cqw 0 rgba(0,0,0,.35),0 0 1cqw .25cqw " + resolved["borderColor"] + ";"

    changes = [cue for index, cue in enumerate(resolved["cues"]) if index == 0 or cue["pose"] != resolved["cues"][index - 1]["pose"]]
    rate = float(_wire(sequence["frameRate"]))
    total = resolved["durationFrames"]
    stops = [(0, changes[0]["pose"])]
    for index in range(1, len(changes)):
        cue = changes[index]
        start = cue["atFrame"]
        next_frame = changes[index + 1]["atFrame"] if index + 1 < len(changes) else total
        stops.extend([(start, changes[index - 1]["pose"]), (min(start + resolved["transitionSec"] * rate, next_frame), cue["pose"])])
    stops.append((total, changes[-1]["pose"]))
    keys = "".join(fixed(frame / total * 100) + "%{" + geometry(pose) + "}" for frame, pose in stops)
    dim = "".join(fixed(frame / total * 100) + "%{opacity:" + ("1" if resolved["dimOnCenter"] and pose == "center" else "0") + "}" for frame, pose in stops)
    animation = fixed(total / rate) + "s cubic-bezier(0.22, 1.12, 0.36, 1) both;animation-delay:var(--oc-clip-start, 0s);"
    is_circle = lambda pose: pose in ("br", "tr", "tl", "bl")
    fit_style = lambda circle: "object-fit:contain;object-position:50% 50%" if resolved["fit"] == "contain" and not circle else "object-fit:cover;object-position:" + fixed(resolved["faceX"]) + "% " + fixed(resolved["faceY"]) + "%"
    initial_fit = fit_style(is_circle(changes[0]["pose"]))
    mixed_fit = resolved["fit"] == "contain" and any(is_circle(cue["pose"]) for cue in changes) and any(not is_circle(cue["pose"]) for cue in changes)
    fit_stops = [(0, is_circle(changes[0]["pose"]))]
    if mixed_fit:
        for index, cue in enumerate(changes[1:], 1):
            start = cue["atFrame"]
            next_frame = changes[index + 1]["atFrame"] if index + 1 < len(changes) else total
            fit_stops.extend([(start, is_circle(changes[index - 1]["pose"]) or is_circle(cue["pose"])), (min(start + resolved["transitionSec"] * rate, next_frame), is_circle(cue["pose"]))])
    fit_stops.append((total, is_circle(changes[-1]["pose"])))
    fit_keys = "@keyframes " + prefix + "-fit{" + "".join(fixed(frame / total * 100) + "%{" + fit_style(circle) + "}" for frame, circle in fit_stops) + "}" if mixed_fit else ""
    video_animation = ";animation:" + prefix + "-fit " + fixed(total / rate) + "s step-end both;animation-delay:var(--oc-clip-start, 0s);" if mixed_fit else ""
    media = _rat(Fraction(resolved["sourceStartFrame"]) / _wire(sequence["frameRate"]))
    escaped_asset = resolved["assetId"].replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")
    return "<style>." + prefix + "{container-type:size;position:relative;width:100%;height:100%;background:transparent;pointer-events:none}." + prefix + "-dim{position:absolute;inset:0;background:radial-gradient(ellipse at center,rgba(0,0,0,.12),rgba(0,0,0,.65));animation:" + prefix + "-dim " + animation + "}." + prefix + "-pane{position:absolute;overflow:hidden;box-sizing:border-box;border:0;" + ("background:#090b10;" if resolved["fit"] == "contain" else "") + geometry(changes[0]["pose"]) + "animation:" + prefix + "-move " + animation + "}." + prefix + "-pane video{width:100%;height:100%;" + initial_fit + "}" + ("." + prefix + "-video{" + initial_fit + video_animation + "}" if mixed_fit else "") + "@keyframes " + prefix + "-move{" + keys + "}@keyframes " + prefix + "-dim{" + dim + "}" + fit_keys + "</style>\n<div class=\"" + prefix + "\"><div class=\"" + prefix + "-dim\"></div><div class=\"" + prefix + "-pane\"><video" + (" class=\"" + prefix + "-video\"" if mixed_fit else "") + " data-asset-id=\"" + escaped_asset + "\" data-media-start=\"" + media["num"] + "/" + media["den"] + "\" muted style=\"" + initial_fit + "\"></video></div></div>"


def build_presenter_pip(project, sequence, config, id_factory=None):
    from .cli import parse_html_fragment
    fresh = id_factory or (lambda: uuid.uuid4().hex)
    resolved, source, entry, sound = validate(config, project["assets"], sequence)
    root, css = parse_html_fragment(fragment(resolved, project["assets"], sequence, fresh()))
    metadata = dict(resolved, cues=[dict(cue, atFrame=str(cue["atFrame"])) for cue in resolved["cues"]])
    for key in ("startFrame", "sourceStartFrame", "durationFrames"):
        metadata[key] = str(metadata[key])
    root["attributes"] = {"data-form-kind": "presenter-pip", "data-presenter-config": json.dumps(metadata, separators=(",", ":"), ensure_ascii=False)}
    built = build_operations(root=root, stylesheet=css, sequence=sequence,
        asset_id=resolved["assetId"], at_frame=resolved["startFrame"],
        duration_frames=resolved["durationFrames"], source_start_frame=resolved["sourceStartFrame"],
        keep_audio=resolved["includeAudio"] and any(stream["kind"] == "audio" for stream in source["probe"]["streams"]), id_factory=fresh)
    operations = built["operations"]
    for operation in operations:
        if operation["type"] == "track.add":
            track = operation["payload"]["track"]
            track["role"] = "presenter-pip" if track["kind"] == "component" else "presenter-audio"
    rate = _wire(sequence["frameRate"])
    order = max((operation["payload"]["track"]["order"] for operation in operations if operation["type"] == "track.add"), default=-1)
    if entry and sound:
        length = max(1, int(_wire(sound["probe"]["duration"]) * rate))
        for index, cue in enumerate(resolved["cues"]):
            if index == 0 or cue["pose"] == resolved["cues"][index - 1]["pose"]:
                continue
            start = max(0, resolved["startFrame"] + cue["atFrame"] - 1)
            track_id, clip_id, effect_id = "track-" + fresh(), "clip-" + fresh(), "effect-" + fresh()
            order += 1
            clip = {"id": clip_id, "source": {"type": "asset", "assetId": sound["id"]},
                "sourceRange": {"start": _rat(0), "end": _rat(Fraction(length) / rate)},
                "timelineRange": {"start": _rat(Fraction(start) / rate), "end": _rat(Fraction(start + length) / rate)},
                "enabled": True, "playback": {"rate": _rat(1), "reverse": False, "freeze": False},
                "extensions": {"dev.orangecut.sfx-link": {"schemaVersion": "1", "data": {"kind": entry["kind"], "sfxId": entry["id"], "targetClipId": built["clipId"]}}},
                "effects": [{"id": effect_id, "effectType": "dev.orangecut.audio.mix", "capabilityRequirements": ["dev.orangecut.audio.mix"], "extensions": {}, "keyframes": [],
                    "parameters": {"gain": _rat(Fraction(math.floor(resolved["sfxVolume"] * 1e6 + .5), 1000000)), "pan": _rat(0), "fadeIn": _rat(0), "fadeOut": _rat(0)}}]}
            operations.extend([
                {"type": "track.add", "payload": {"sequenceId": sequence["id"], "track": {"id": track_id, "kind": "audio", "role": "sfx", "order": order, "locked": False, "muted": False, "clips": [], "captions": [], "extensions": {}}}},
                {"type": "clip.add", "payload": {"sequenceId": sequence["id"], "trackId": track_id, "clip": clip}},
            ])
    existing = {track["id"]: track for track in sequence["tracks"]}
    additions = [operation["payload"]["track"] for operation in operations if operation["type"] == "track.add"]
    offsets = {existing[track["id"]]["order"] - track["order"] for track in additions if track["id"] in existing}
    if len(offsets) > 1:
        raise ValueError("presenter tracks were reordered; use the original request or a new idempotency key")
    if offsets:
        offset = offsets.pop()
        for track in additions:
            track["order"] += offset
    built["clips"] = [{key: built[key] for key in ("clipId", "trackId", "componentId")}]
    return built
