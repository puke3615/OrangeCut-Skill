"""Bounded, offline geometry for alpha images and statically positioned HTML."""

from __future__ import annotations

import math
import re
from typing import Any

Box = tuple[float, float, float, float]
Point = tuple[float, float]


def image_region(data: dict[str, Any], fit: str, width: float, height: float) -> Box | None:
    if not data.get("hasTransparency") or not data.get("bounds"):
        return None
    source_w, source_h = data["width"], data["height"]
    left, top, box_w, box_h = data["bounds"]
    if fit == "fill":
        scale_x, scale_y = width / source_w, height / source_h
    else:
        ratios = (width / source_w, height / source_h)
        scale_x = scale_y = 1 if fit == "none" else (max(ratios) if fit == "cover" else min(ratios))
    origin_x, origin_y = (width - source_w * scale_x) / 2, (height - source_h * scale_y) / 2
    x1, y1 = max(0, origin_x + left * scale_x), max(0, origin_y + top * scale_y)
    x2 = min(width, origin_x + (left + box_w) * scale_x)
    y2 = min(height, origin_y + (top + box_h) * scale_y)
    return (x1, y1, x2 - x1, y2 - y1) if x2 > x1 and y2 > y1 else None


def transformed_region(box: Box, canvas: tuple[float, float], pose: tuple[float, ...]) -> list[Point]:
    width, height = canvas
    dx, dy, scale_x, scale_y, rotation = pose
    angle = math.radians(rotation)
    cosine, sine = math.cos(angle), math.sin(angle)
    x, y, box_w, box_h = box
    result = []
    for corner_x, corner_y in ((x, y), (x + box_w, y), (x + box_w, y + box_h), (x, y + box_h)):
        local_x, local_y = corner_x - width / 2, corner_y - height / 2
        result.append((width / 2 + dx + scale_x * (local_x * cosine - local_y * sine),
                       height / 2 + dy + scale_y * (local_x * sine + local_y * cosine)))
    return result


def polygon_box(points: list[Point]) -> Box:
    left, right = min(p[0] for p in points), max(p[0] for p in points)
    top, bottom = min(p[1] for p in points), max(p[1] for p in points)
    return left, top, right - left, bottom - top


def polygon_area(points: list[Point]) -> float:
    return abs(sum(a[0] * b[1] - a[1] * b[0] for a, b in zip(points, points[1:] + points[:1]))) / 2


def polygon_overlap(points: list[Point], box: Box) -> tuple[float, Box] | None:
    x, y, width, height = box
    for axis, edge, direction in ((0, x, 1), (0, x + width, -1), (1, y, 1), (1, y + height, -1)):
        if not points:
            return None
        clipped = []
        previous = points[-1]
        for current in points:
            old_inside = (previous[axis] - edge) * direction >= 0
            new_inside = (current[axis] - edge) * direction >= 0
            if old_inside != new_inside:
                fraction = (edge - previous[axis]) / (current[axis] - previous[axis])
                clipped.append(tuple(a + fraction * (b - a) for a, b in zip(previous, current)))
            if new_inside:
                clipped.append(current)
            previous = current
        points = clipped
    if not points:
        return None
    bounds = polygon_box(points)
    area = polygon_area(points)
    return (area, bounds) if area >= 16 and min(bounds[2:]) >= 3 else None


_SIMPLE_SELECTOR = re.compile(r"(?:[\w-]+|\*)?(?:[.#][\w-]+)*\Z")
_LENGTH = re.compile(r"([+-]?(?:\d+(?:\.\d*)?|\.\d+))(px|%|cqw|cqh|cqmin|cqmax|vw|vh|em)?\Z")
_VAR = re.compile(r"var\(\s*(--[\w-]+)(?:\s*,\s*([^()]+))?\s*\)")


def _matches(selector: str, node: dict[str, Any]) -> bool:
    if not selector or not _SIMPLE_SELECTOR.fullmatch(selector):
        return False
    tag = re.match(r"[\w-]+", selector)
    return ((tag is None or tag[0] == node.get("tag"))
            and all(name in node.get("classes", []) for name in re.findall(r"\.([\w-]+)", selector))
            and all(name == (node.get("attributes") or {}).get("id") for name in re.findall(r"#([\w-]+)", selector)))


def color_visible(value: Any) -> bool:
    text = str(value or "").strip().lower()
    if text in ("", "none", "transparent", "initial", "unset"):
        return False
    if re.fullmatch(r"#[0-9a-f]{4}", text):
        return int(text[4], 16) > 0
    if re.fullmatch(r"#[0-9a-f]{8}", text):
        return int(text[-2:], 16) > 16
    alpha = re.fullmatch(r"(?:rgba?|hsla?)\(.*(?:/|,\s*)([\d.]+)(%)?\s*\)", text)
    if alpha and ("/" in text or text.count(",") == 3):
        try:
            return float(alpha[1]) > (16 / 255 * (100 if alpha[2] else 1))
        except ValueError:
            return False
    return True


def html_regions(properties: dict[str, Any], width: float, height: float) -> tuple[list[Box], bool]:
    """Estimate simple DOM boxes; the second value flags layouts needing rendered review."""
    stylesheet = str(properties.get("stylesheet") or "")
    if len(stylesheet) > 131_072:
        return [], True
    rules = []
    uncertain = False
    for selectors, body in re.findall(r"([^{}]+)\{([^{}]*)\}", re.sub(r"/\*.*?\*/", "", stylesheet, flags=re.S)):
        declarations = dict((key.strip().lower(), value.strip()) for key, sep, value in
                            (entry.partition(":") for entry in body.split(";")) if sep)
        for selector in selectors.split(","):
            selector = selector.strip()
            if not _SIMPLE_SELECTOR.fullmatch(selector):
                uncertain = True
                continue
            priority = (selector.count("#"), selector.count("."), int(selector[0:1].isalnum()))
            rules.append((priority, selector, declarations))
    rules.sort(key=lambda rule: rule[0])
    if len(rules) > 256:
        return [], True
    regions: list[Box] = []
    count = 0

    def visit(node: dict[str, Any], parent: Box, inherited: dict[str, str], depth: int,
              flow_y: float, positioned: Box) -> float:
        nonlocal count, uncertain
        count += 1
        if depth > 24 or count > 256:
            uncertain = True
            return 0
        styles = inherited.copy()
        for _, selector, declarations in rules:
            if _matches(selector, node):
                styles.update(declarations)
        styles.update(node.get("styles") or {})

        def resolve(key: str) -> str:
            value = str(styles.get(key, ""))
            for _ in range(4):
                replaced = _VAR.sub(lambda match: str(styles.get(match[1], match[2] or "")), value)
                if replaced == value:
                    break
                value = replaced
            return value.strip().lower()

        opacity = resolve("opacity")
        try:
            transparent = bool(opacity) and float(opacity.rstrip("%")) <= (6.27 if opacity.endswith("%") else 16 / 255)
        except ValueError:
            transparent = False
            uncertain = True
        if transparent or resolve("display") == "none" or resolve("visibility") == "hidden":
            return 0
        if resolve("transform") not in ("", "none") or resolve("animation") or resolve("animation-name"):
            uncertain = True

        def length(value: str, basis: float, em: float = 16) -> float | None:
            match = _LENGTH.fullmatch(value)
            if not match:
                return None
            unit = match[2]
            multiplier = {"%": basis / 100, "cqw": width / 100, "vw": width / 100,
                          "cqh": height / 100, "vh": height / 100, "cqmin": min(width, height) / 100,
                          "cqmax": max(width, height) / 100, "em": em}.get(unit, 1)
            result = float(match[1]) * multiplier
            return result if math.isfinite(result) and abs(result) < 100_000 else None

        absolute = resolve("position") in ("absolute", "fixed")
        base_x, base_y, base_w, base_h = positioned if absolute else parent
        font = length(resolve("font-size"), 16) or 16
        inset = resolve("inset").split()
        if len(inset) in (1, 2, 3, 4):
            top_v, right_v, bottom_v, left_v = (inset * 4 if len(inset) == 1 else
                inset * 2 if len(inset) == 2 else inset + [inset[1]] if len(inset) == 3 else inset)[:4]
        else:
            top_v = right_v = bottom_v = left_v = ""
        left = length(resolve("left") or left_v, base_w)
        right = length(resolve("right") or right_v, base_w)
        top = length(resolve("top") or top_v, base_h)
        bottom = length(resolve("bottom") or bottom_v, base_h)
        text = str(node.get("text") or "").strip()
        lines = text.splitlines()
        text_w = max((sum(0.6 if char.isascii() else 1 for char in line) for line in lines), default=0) * font
        text_h = len(lines) * font * 1.3
        box_w = length(resolve("width"), base_w)
        box_h = length(resolve("height"), base_h)
        padding = length(resolve("padding"), base_w) or 0
        if box_w is None:
            box_w = base_w - left - right if absolute and left is not None and right is not None else (
                min(base_w, text_w + padding * 2) if absolute and text else base_w)
        if box_h is None:
            box_h = base_h - top - bottom if absolute and top is not None and bottom is not None else (
                base_h if depth == 0 else text_h + padding * 2 if text else 0)
        x = base_x + (left if left is not None else base_w - right - box_w if absolute and right is not None else 0)
        y = base_y + (top if top is not None else base_h - bottom - box_h if absolute and bottom is not None else flow_y)
        own = (x, y, box_w, box_h)
        media = node.get("tag") in ("img", "video", "svg")
        paint = any(color_visible(resolve(key)) for key in ("background", "background-color", "background-image", "border", "box-shadow"))
        full = box_w >= width * .95 and box_h >= height * .95
        if box_w > 0 and box_h > 0 and (media or (paint and not full)):
            regions.append(own)
        if text and color_visible(resolve("color") or "black") and box_w > 0:
            ink_w = min(box_w, text_w)
            ink_x = x + (box_w - ink_w) / 2 if resolve("text-align") == "center" else x + padding
            regions.append((ink_x, y + padding, ink_w, min(box_h or text_h, text_h)))
        children = node.get("children") or []
        if children and resolve("display") in ("grid", "flex", "inline-flex", "inline-grid"):
            uncertain = True
        child_styles = {key: value for key, value in styles.items() if key.startswith("--") or key in {"font-size", "color", "text-align"}}
        child_parent = (x, y, box_w, box_h or base_h)
        next_positioned = child_parent if resolve("position") not in ("", "static") or depth == 0 else positioned
        offset = padding
        for child in children[:256]:
            offset += visit(child, child_parent, child_styles, depth + 1, offset, next_positioned)
        return 0 if absolute else box_h or offset

    root = properties.get("root")
    if isinstance(root, dict):
        visit(root, (0, 0, width, height), {}, 0, 0, (0, 0, width, height))
    return regions, uncertain
