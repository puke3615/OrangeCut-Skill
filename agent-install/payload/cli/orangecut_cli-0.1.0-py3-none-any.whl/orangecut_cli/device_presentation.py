"""Devices.css-backed transparent device composition; shared with Desktop."""
from __future__ import annotations
from fractions import Fraction
import json
import math
import re
from ._device_template import TEMPLATE as template
from .dual_view import _fields, _frame, _number, _wire
from .screen_wrap import build_operations

DEFAULTS = dict(color="silver", pose="front", cutout="none", xPercent=20, yPercent=50, heightPercent=82, shadow=60)
FIELDS = ("assetId", "startFrame", "sourceStartFrame", "durationFrames", *DEFAULTS)

def validate(config, assets, sequence):
    _fields(config, FIELDS, "device config")
    c = dict(DEFAULTS, startFrame=0, sourceStartFrame=0, **{k:v for k,v in config.items() if k not in ("startFrame", "sourceStartFrame")})
    c["startFrame"] = config.get("startFrame", 0)
    c["sourceStartFrame"] = config.get("sourceStartFrame", 0)
    for name in ("startFrame", "sourceStartFrame", "durationFrames"):
        _frame(c.get(name), name, 1 if name == "durationFrames" else 0)
    asset = next((a for a in assets if a["id"] == c.get("assetId")), None)
    stream = next((s for s in (asset or {}).get("probe", {}).get("streams", []) if s["kind"] == "video"), {})
    width, height = stream.get("width"), stream.get("height")
    if not asset or asset["kind"] != "video" or any(isinstance(v,bool) or not isinstance(v,int) or not 1 <= v <= 32768 for v in (width,height)):
        raise ValueError("device presentation needs an imported, probed video asset")
    if c["color"] not in template["colors"] or c["pose"] not in template["poses"] or c["cutout"] not in template["cutouts"]:
        raise ValueError("invalid device appearance option")
    for name, low, high in (("xPercent",0,100),("yPercent",0,100),("heightPercent",10,94),("shadow",0,100)):
        _number(c[name], name, low, high)
    rate = _wire(sequence["frameRate"])
    duration = asset.get("probe", {}).get("duration")
    if not duration or Fraction(c["sourceStartFrame"] + c["durationFrames"]) / rate > _wire(duration):
        raise ValueError("device presentation exceeds the source duration")
    screen_h = template["screenWidth"] * template["screenAspect"][1] / template["screenAspect"][0]
    body_h = template["bodyWidth"] * template["bodyAspect"][1] / template["bodyAspect"][0]
    scale = sequence["canvas"]["height"] * c["heightPercent"] / 100 / body_h
    half_w = template["bodyWidth"] * scale / sequence["canvas"]["width"] * 50
    half_h = c["heightPercent"] / 2
    if c["xPercent"]-half_w < 1 or c["xPercent"]+half_w > 99 or c["yPercent"]-half_h < 1 or c["yPercent"]+half_h > 99:
        raise ValueError("device extends beyond the canvas; reduce its size or move it inward")
    return c, screen_h, body_h, scale

def fragment(config, assets, sequence, instance):
    c, screen_h, body_h, scale = validate(config, assets, sequence)
    p = "oc-device-" + instance
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]*", p):
        raise ValueError("invalid device instance identifier")
    fixed = lambda n: f"{math.floor(n * 1e6 + .5) / 1e6:.6f}"
    media = Fraction(c["sourceStartFrame"]) / _wire(sequence["frameRate"])
    values = dict(p=p, assetId=c["assetId"], x=fixed(c["xPercent"]), y=fixed(c["yPercent"]), bodyHeight=fixed(body_h), screenHeight=fixed(screen_h), screenTop=fixed((body_h-screen_h)/2), screenRadius=fixed(min(49,screen_h/5)), scale="1",
        color=c["color"],pose=template["poses"][c["pose"]],cutoutDisplay="block" if c["cutout"] == "island" else "none",
        metalShadow="inset 0 0 4px 2px white,inset 0 0 0 6px #e2e3e4" if c["color"] == "silver" else "inset 0 0 4px 2px #e2e2e2,inset 0 0 0 6px #76726f",
        shadowAlpha=fixed(c["shadow"]/100*.42), contactAlpha=fixed(c["shadow"]/100*.25), mediaStart=f"{media.numerator}/{media.denominator}")
    render = lambda text: re.sub(r"\{\{(\w+)\}\}", lambda m: values[m[1]], text)
    css = re.sub(r"(-?\d*\.?\d+)px", lambda m:fixed(float(m[1])*scale/sequence["canvas"]["width"]*100)+"cqw",render(template["upstreamCss"]+template["css"]))
    return "<style>" + css + "</style>\n" + render(template["markup"])

def build_device_presentation(project, sequence, config, id_factory):
    from .cli import parse_html_fragment
    c, *_ = validate(config, project["assets"], sequence)
    root, css = parse_html_fragment(fragment(c, project["assets"], sequence, id_factory()))
    metadata = dict(c)
    for key in ("startFrame", "sourceStartFrame", "durationFrames"):
        metadata[key] = str(metadata[key])
    root["attributes"] = {"data-form-kind":"device-presentation", "data-device-config":json.dumps(metadata, separators=(",",":"),ensure_ascii=False)}
    built = build_operations(root=root,stylesheet=css,sequence=sequence,asset_id=c["assetId"],at_frame=c["startFrame"],duration_frames=c["durationFrames"],source_start_frame=c["sourceStartFrame"],id_factory=id_factory)
    # Stable IDs and original track order allow exact retries after unrelated edits.
    for op in built["operations"]:
        if op["type"] == "track.add":
            track=op["payload"]["track"]
            track["role"]="device-presentation"
            previous=next((t for t in sequence["tracks"] if t["id"] == track["id"]),None)
            if previous: track["order"]=previous["order"]
    built["clips"] = [{key:built[key] for key in ("clipId","trackId","componentId")}]
    return built
