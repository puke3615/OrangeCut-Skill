"""Source-aligned target emphasis using the Desktop's shared native definition."""
from __future__ import annotations
import copy
import json
import re
import uuid
from fractions import Fraction
from ._focus_template import TEMPLATE
from .dual_view import _fields, _frame, _number, _rat, _wire


def source_size(asset, supplied=None):
    stream = next((s for s in (asset.get("probe") or {}).get("streams", []) if s.get("kind") == "video"), {})
    width, height = stream.get("width") or (supplied or {}).get("width"), stream.get("height") or (supplied or {}).get("height")
    if any(isinstance(v,bool) or not isinstance(v,int) or not 1 <= v <= 32768 for v in (width,height)):
        raise ValueError("source needs probed width and height")
    return width, height


def focus_properties(project, sequence, config, instance):
    _fields(config, ("assetId", "sourceWidth", "sourceHeight", "alphaWidth", "alphaHeight", "mode", "shape", "box", "startFrame", "sourceStartFrame", "durationFrames", "enterFrames", "exitFrames", "dimPercent", "feather", "halo", "alphaAssetId", "alphaStartFrame", "alphaOffset", "sound"), "focus")
    assets = {a["id"]: a for a in project["assets"]}
    source = assets.get(config.get("assetId"))
    if not source or source["kind"] not in ("image", "video"):
        raise ValueError("focus needs an imported image or video")
    sw, sh = source_size(source,{"width":config.get("sourceWidth"),"height":config.get("sourceHeight")})
    cfg = {"mode": "region", "shape": "rect", "startFrame": 0, "sourceStartFrame": 0, "enterFrames": 12, "exitFrames": 9, "dimPercent": 65, "feather": 8, "halo": 0, "alphaAssetId": "", "alphaStartFrame": 0, **config}
    for field in ("startFrame", "sourceStartFrame", "alphaStartFrame", "enterFrames", "exitFrames"):
        _frame(cfg[field], field)
    duration = _frame(cfg.get("durationFrames"), "durationFrames", 3)
    if cfg["enterFrames"] + cfg["exitFrames"] >= duration:
        raise ValueError("entrance and exit must leave at least one hold frame")
    if cfg["mode"] not in ("region", "object") or cfg["shape"] not in ("rect", "ellipse"):
        raise ValueError("mode must be region/object and shape rect/ellipse")
    _number(cfg["dimPercent"], "dimPercent", 0, 90)
    _number(cfg["feather"], "feather", 0, 64)
    _number(cfg["halo"], "halo", 0, 24)
    box = cfg.get("box")
    if not isinstance(box, list) or len(box) != 4:
        raise ValueError("box needs [x,y,width,height] in source pixels")
    x, y, w, h = box
    for value, name, low, high in ((x,"x",0,sw),(y,"y",0,sh),(w,"width",1,sw),(h,"height",1,sh)):
        _number(value, name, low, high)
    if x+w > sw or y+h > sh:
        raise ValueError("target box exceeds the source")
    rate = _wire(sequence["frameRate"])
    def check_range(asset, start, offset=Fraction(0)):
        if offset < 0: raise ValueError("alpha offset must be non-negative")
        if asset["kind"] == "image":
            if start or offset: raise ValueError("image source start must be zero")
        else:
            d = (asset.get("probe") or {}).get("duration")
            if not d or Fraction(start+duration)/rate+offset > _wire(d):
                raise ValueError("focus exceeds source duration")
    check_range(source, cfg["sourceStartFrame"])
    alpha = None
    if cfg["mode"] == "object":
        alpha = assets.get(cfg["alphaAssetId"])
        if not alpha or alpha["kind"] not in ("image", "video") or source_size(alpha,{"width":cfg.get("alphaWidth"),"height":cfg.get("alphaHeight")}) != (sw,sh):
            raise ValueError("object focus needs an aligned alpha image/video of identical dimensions")
        check_range(alpha, cfg["alphaStartFrame"], _wire(cfg["alphaOffset"]) if cfg.get("alphaOffset") else Fraction(0))
    cw, ch = sequence["canvas"]["width"], sequence["canvas"]["height"]
    scale = min(cw/sw, ch/sh)
    width, height = sw*scale, sh*scale
    p = "oc-focus-" + re.sub("[^a-zA-Z0-9-]", "", instance)
    last = duration-1
    f = lambda v: format(v, ".15g")
    variables = {"class":p,"sourceTag":"img" if source["kind"] == "image" else "video","sourceId":source["id"],"alphaTag":"img" if alpha and alpha["kind"] == "image" else "video","alphaId":alpha["id"] if alpha else "","sourceWidth":str(sw),"sourceHeight":str(sh),"left":f((cw-width)/2/cw*100),"top":f((ch-height)/2/ch*100),"width":f(width/cw*100),"height":f(height/ch*100),"seconds":f(last/float(rate)),"enterPercent":f(cfg["enterFrames"]/last*100),"exitPercent":f((last-cfg["exitFrames"])/last*100),"initial":"1" if cfg["enterFrames"] == 0 else "0","final":"1" if cfg["exitFrames"] == 0 else "0","dim":f(cfg["dimPercent"]/100),"feather":f(cfg["feather"]),"halo":f(cfg["halo"]/cw*100),"shapeTag":cfg["shape"]}
    def sub(value):
        return json.loads(re.sub(r"\{\{(\w+)\}\}", lambda m: variables[m[1]], json.dumps(value)))
    def bind(node, asset, start):
        if asset["kind"] == "video": node.update(attributes={"muted":""}, mediaStart=_rat(Fraction(start)/rate))
    root, media, paint = sub(TEMPLATE["root"]), sub(TEMPLATE["source"]), sub(TEMPLATE["paint"])
    bind(media, source, cfg["sourceStartFrame"])
    if alpha:
        paint["children"] = sub(TEMPLATE["object"])
        bind(paint["children"][1], alpha, cfg["alphaStartFrame"])
        if alpha["kind"] == "video" and cfg.get("alphaOffset"):
            paint["children"][1]["mediaStart"] = _rat(Fraction(cfg["alphaStartFrame"])/rate+_wire(cfg["alphaOffset"]))
    else:
        paint["children"] = sub(TEMPLATE["region"])
        hole = paint["children"][0]["children"][0]["children"][1]["children"][1]
        shape = {"cx":x+w/2,"cy":y+h/2,"rx":w/2,"ry":h/2} if cfg["shape"] == "ellipse" else {"x":x,"y":y,"width":w,"height":h,"rx":min(w,h)*.025}
        hole["attributes"].update({k:f(v) for k,v in shape.items()})
    root["children"][0]["children"] = [media, paint]
    meta = copy.deepcopy(cfg)
    for key in ("startFrame","sourceStartFrame","durationFrames","enterFrames","exitFrames","alphaStartFrame"): meta[key] = str(meta[key])
    root["attributes"]["data-focus-config"] = json.dumps(meta, separators=(",",":"))
    from .marker_sound import attach
    return attach({"root":root,"stylesheet":sub(TEMPLATE["stylesheet"])},config.get("sound"),[{"frame":0,"kind":"focus"}],project["assets"],sequence,duration)


def build_target_focus(project, sequence, config, id_factory=None):
    fresh = id_factory or (lambda: uuid.uuid4().hex)
    from .marker_sound import DEFAULT_SOUND
    config={"sound":dict(DEFAULT_SOUND),**config}
    properties = focus_properties(project, sequence, config, fresh())
    track_id, component_id, clip_id = "track-"+fresh(), "component-"+fresh(), "clip-"+fresh()
    existing = next((t for t in sequence["tracks"] if t["id"] == track_id), None)
    order = existing["order"] if existing else max((t["order"] for t in sequence["tracks"]), default=-1)+1
    start, duration = config.get("startFrame",0), config["durationFrames"]
    rate = _wire(sequence["frameRate"])
    return {"operations":[
        {"type":"track.add","payload":{"sequenceId":sequence["id"],"track":{"id":track_id,"kind":"component","role":"target-focus","order":order,"locked":False,"muted":False,"clips":[],"captions":[],"extensions":{}}}},
        {"type":"component.add","payload":{"component":{"id":component_id,"componentType":"dev.orangecut.html","capabilityRequirements":["dev.orangecut.component.html"],"extensions":{},"properties":properties}}},
        {"type":"clip.add","payload":{"sequenceId":sequence["id"],"trackId":track_id,"clip":{"id":clip_id,"source":{"type":"component","componentId":component_id},"timelineRange":{"start":_rat(Fraction(start)/rate),"end":_rat(Fraction(start+duration)/rate)},"playback":{"freeze":False,"reverse":False,"rate":_rat(1)},"enabled":True,"effects":[],"extensions":{}}}}
    ],"clips":[{"trackId":track_id,"clipId":clip_id}]}
