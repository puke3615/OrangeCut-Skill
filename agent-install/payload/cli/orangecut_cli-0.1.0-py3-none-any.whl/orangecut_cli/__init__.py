"""OrangeCut local control CLI."""

__version__ = "0.1.0"
