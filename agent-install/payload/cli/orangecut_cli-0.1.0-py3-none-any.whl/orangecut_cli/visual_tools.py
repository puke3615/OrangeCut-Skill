"""Five shared-template visual compositions using the existing Core command path."""
from fractions import Fraction
import json
import math
import re
from ._visual_tools_template import TEMPLATE as T
from .dual_view import _fields, _frame, _number, _wire
from .screen_wrap import build_operations

DEFAULTS = dict(color='#F28C28', xPercent=50, yPercent=50, widthPercent=76, zoom=2,
    secondAssetId='', secondStartFrame=0, wipeFrom=100, wipeTo=0, wipeStartFrame=15, wipeEndFrame=75,
    beforeLabel='修改前', afterLabel='修改后', title='作品展示', text='持续创造', textX=50, textY=38,
    fontSize=8, alphaAssetId='', alphaStartFrame=0, showSource=True, marks=[])
FRAME_KEYS = ('startFrame','sourceStartFrame','durationFrames','secondStartFrame','alphaStartFrame')
FIELDS = ('kind','assetId',*FRAME_KEYS,'sourceWidth','sourceHeight','secondWidth','secondHeight',
    'alphaWidth','alphaHeight','alphaOffset','box',*DEFAULTS)
FIELDS = (*FIELDS, "sound")
MARK_FIELDS = ('kind','box','points','color','width','startFrame','drawFrames','endFrame')
f = lambda n: f'{math.floor(n*1e6+.5)/1e6:.6f}'
escape = lambda s: s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
def render(s, values):
    return re.sub(r'\{\{(\w+)\}\}', lambda m: values[m[1]], s)
def color(value):
    if not isinstance(value,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', value):
        raise ValueError('accent must be a six-digit hex color')
def size(asset, width=None, height=None):
    stream = next((s for s in asset.get('probe',{}).get('streams',[]) if s['kind']=='video'),{})
    w,h = stream.get('width',width),stream.get('height',height)
    if any(isinstance(v,bool) or not isinstance(v,int) or not 1<=v<=32768 for v in (w,h)):
        raise ValueError('source image dimensions are required')
    return w,h
def check_box(box, W,H):
    if not isinstance(box,list) or len(box)!=4: raise ValueError('box must contain x,y,width,height')
    x,y,w,h=box
    for value,name,low,high in ((x,'box x',0,W),(y,'box y',0,H),(w,'box width',1,W),(h,'box height',1,H)):
        _number(value,name,low,high)
    if x+w>W or y+h>H: raise ValueError('box exceeds source')
def check_range(asset,start,duration,seq,offset=None):
    _frame(start,'source inpoint')
    extra = Fraction(0)
    if offset is not None:
        _fields(offset,('num','den'),'alpha offset')
        if any(not isinstance(offset.get(k),str) or not re.fullmatch(r'\d+',offset[k]) for k in ('num','den')) or int(offset['den'])<=0:
            raise ValueError('alpha offset requires nonnegative num and positive den strings')
        extra = _wire(offset)
    if asset['kind']=='image':
        if start or extra: raise ValueError('image inpoint must be zero')
    elif not asset.get('probe',{}).get('duration') or Fraction(start+duration)/_wire(seq['frameRate'])+extra>_wire(asset['probe']['duration']):
        raise ValueError('composition exceeds source duration')
def validate(config,assets,seq):
    _fields(config,FIELDS,'visual tool')
    c=dict(DEFAULTS,startFrame=0,sourceStartFrame=0,**{k:v for k,v in config.items() if k not in ('startFrame','sourceStartFrame')})
    c['startFrame']=config.get('startFrame',0); c['sourceStartFrame']=config.get('sourceStartFrame',0)
    if c.get('kind') not in T['labels']: raise ValueError('unknown visual tool')
    for key in FRAME_KEYS: _frame(c.get(key),key,3 if key=='durationFrames' else 0)
    if c['durationFrames']>1000000: raise ValueError('composition is too long')
    asset=next((a for a in assets if a['id']==c.get('assetId')),None)
    if not asset or asset['kind'] not in ('image','video'): raise ValueError('import a video or image first')
    W,H=size(asset,c.get('sourceWidth'),c.get('sourceHeight'))
    check_range(asset,c['sourceStartFrame'],c['durationFrames'],seq)
    c.setdefault('box',[round(W*.25),round(H*.3),round(W*.28),round(H*.18)])
    color(c['color'])
    for key,lo,hi in (('xPercent',0,100),('yPercent',0,100),('widthPercent',10,96),('zoom',1.1,5),('textX',0,100),('textY',0,100),('fontSize',1,20)):
        _number(c[key],key,lo,hi)
    for key in ('title','text','beforeLabel','afterLabel'):
        if not isinstance(c[key],str) or len(c[key])>200: raise ValueError('text must not exceed 200 characters')
    if not isinstance(c['showSource'],bool): raise ValueError('showSource must be boolean')
    second,alpha=None,None
    if c['kind']=='magnify': check_box(c['box'],W,H)
    if c['kind']=='wipe':
        second=next((a for a in assets if a['id']==c['secondAssetId']),None)
        if not second or second['kind'] not in ('image','video'): raise ValueError('choose the comparison media')
        size(second,c.get('secondWidth'),c.get('secondHeight'))
        check_range(second,c['secondStartFrame'],c['durationFrames'],seq)
        _number(c['wipeFrom'],'wipeFrom',0,100);_number(c['wipeTo'],'wipeTo',0,100)
        _frame(c['wipeStartFrame'],'wipeStartFrame');_frame(c['wipeEndFrame'],'wipeEndFrame')
        if not c['wipeStartFrame']<c['wipeEndFrame']<c['durationFrames']: raise ValueError('wipe timing is outside clip')
    if c['kind']=='layers':
        alpha=next((a for a in assets if a['id']==c['alphaAssetId']),None)
        if not alpha or alpha['kind'] not in ('image','video'): raise ValueError('choose an aligned transparent foreground')
        if size(alpha,c.get('alphaWidth'),c.get('alphaHeight'))!=(W,H): raise ValueError('foreground size must match source')
        check_range(alpha,c['alphaStartFrame'],c['durationFrames'],seq,c.get('alphaOffset'))
        if not c['text'].strip(): raise ValueError('layer text must not be empty')
    if c['kind']=='markup':
        if not isinstance(c['marks'],list) or not 1<=len(c['marks'])<=16: raise ValueError('draw 1..16 marks')
        for m in c['marks']:
            _fields(m,MARK_FIELDS,'mark')
            if m.get('kind') not in ('highlight','underline','circle','box','arrow','pen'): raise ValueError('unknown mark kind')
            color(m['color']);_number(m['width'],'pen width',1,min(W,H)/8);check_box(m['box'],W,H)
            for key in ('startFrame','drawFrames','endFrame'): _frame(m[key],key,1 if key=='drawFrames' else 0)
            if not m['startFrame']+m['drawFrames']<m['endFrame']<=c['durationFrames']: raise ValueError('mark needs a hold frame after drawing')
            if not isinstance(m['points'],list) or len(m['points'])>64 or (m['kind'] in ('arrow','pen') and len(m['points'])<2): raise ValueError('path needs 2..64 points')
            for point in m['points']:
                if not isinstance(point,list) or len(point)!=2: raise ValueError('path point must contain x,y')
                _number(point[0],'path x',0,W);_number(point[1],'path y',0,H)
    scale=min(seq['canvas']['width']/W,seq['canvas']['height']/H)
    return c,asset,second,alpha,W,H,scale
def spaced_arrow_points(mark, marks, short_side):
    points = [p[:] for i,p in enumerate(mark['points']) if i == 0 or p != mark['points'][i-1]]
    guard = lambda width: width + max(2, width*.7)
    boxes = []
    for m in marks:
        if m['kind'] not in ('box','circle') or m['startFrame'] >= mark['endFrame'] or mark['startFrame'] >= m['endFrame']: continue
        margin = (guard(mark['width'])+guard(m['width']))/2 + max(12,short_side*.014)
        x,y,w,h = m['box']; boxes.append([x-margin,y-margin,x+w+margin,y+h+margin])
    def entry(a,b,box):
        lo,hi = 0,1
        for axis in range(2):
            delta = b[axis]-a[axis]
            if abs(delta)<1e-10:
                if a[axis]<box[axis] or a[axis]>box[axis+2]: return None
            else:
                t1,t2 = (box[axis]-a[axis])/delta,(box[axis+2]-a[axis])/delta
                lo,hi = max(lo,min(t1,t2)),min(hi,max(t1,t2))
                if lo>hi: return None
        return lo
    for i in range(1,len(points)):
        a,b = points[i-1:i+1]
        hits = [t for box in boxes if (t:=entry(a,b,box)) is not None]
        if not hits: continue
        t = min(hits)
        if i==1 and t==0: raise ValueError('arrow starts too close to a frame; move its start outside')
        points = points[:i]+[[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]]
        break
    for _ in range(512):
        if len(points)<2: raise ValueError('not enough space for arrow; lengthen it or move its start')
        a,b = points[-2:]; length = math.hypot(b[0]-a[0],b[1]-a[1])
        if length<1e-8: points.pop(); continue
        angle = math.atan2(b[1]-a[1],b[0]-a[0])
        wings = [[b[0]-mark['width']*4*math.cos(angle+turn),b[1]-mark['width']*4*math.sin(angle+turn)] for turn in (-.5,.5)]
        if not any(entry(b,wing,box) is not None for box in boxes for wing in wings): return points
        step = max(1,mark['width']*.5)
        if length<=step: points.pop()
        else: points[-1]=[b[0]-(b[0]-a[0])/length*step,b[1]-(b[1]-a[1])/length*step]
    raise ValueError('not enough clearance for arrow head; move the arrow away from the frame')

def mark_path(m,marks=(),short_side=1080):
    x,y,w,h=m['box']
    if m['kind']=='highlight': return f'M{f(x)} {f(y+h/2)}H{f(x+w)}'
    if m['kind']=='underline': return f'M{f(x)} {f(y+h)}H{f(x+w)}'
    if m['kind']=='box': return f'M{f(x)} {f(y)}H{f(x+w)}V{f(y+h)}H{f(x)}Z'
    if m['kind']=='circle': return f'M{f(x+w)} {f(y+h/2)}A{f(w/2)} {f(h/2)} 0 1 1 {f(x)} {f(y+h/2)}A{f(w/2)} {f(h/2)} 0 1 1 {f(x+w)} {f(y+h/2)}'
    points=spaced_arrow_points(m,marks,short_side) if m['kind']=='arrow' else m['points']
    d=''.join(f'{"L" if i else "M"}{f(a)} {f(b)}' for i,(a,b) in enumerate(points))
    if m['kind']=='arrow':
        (a,b),(c,dest)=points[-2:];angle=math.atan2(dest-b,c-a);length=m['width']*4
        d+=f'M{f(c-length*math.cos(angle-.5))} {f(dest-length*math.sin(angle-.5))}L{f(c)} {f(dest)}L{f(c-length*math.cos(angle+.5))} {f(dest-length*math.sin(angle+.5))}'
    return d
def fragment(config,assets,seq,instance):
    c,asset,second,alpha,sw,sh,scale=validate(config,assets,seq)
    p='oc-tools-'+instance
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*',p): raise ValueError('invalid instance identifier')
    W,H=seq['canvas']['width'],seq['canvas']['height'];rate=float(_wire(seq['frameRate']));last=c['durationFrames']-1
    gw,gh=sw*scale,sh*scale;gx,gy=(W-gw)/2,(H-gh)/2
    v=dict(p=p,canvasW=f(W),canvasH=f(H),sourceW=f(sw),sourceH=f(sh),fitX=f(gx/W*100),fitY=f(gy/H*100),fitW=f(gw/W*100),fitH=f(gh/H*100),color=c['color'],lastSeconds=f(last/rate),enterSeconds=f(min(12,last/3)/rate),x='0',y='0',width='100',height='100')
    def media(a,start,cls=None,offset=None):
        time=Fraction(start)/_wire(seq['frameRate'])+(_wire(offset) if offset else 0)
        classes=(cls or p+'-media')+(' clip' if a['kind']=='image' else '')
        return render(T['media'],dict(tag='img' if a['kind']=='image' else 'video',mediaClass=classes,asset=escape(a['id']),mediaStart=f' data-media-start="{time.numerator}/{time.denominator}"' if a['kind']=='video' else '')).replace('</img>','')
    css=''
    if c['kind']=='magnify':
        x,y,w,h=c['box'];dw,dh=w*scale*c['zoom'],h*scale*c['zoom'];left,top=c['xPercent']/100*W-dw/2,c['yPercent']/100*H-dh/2
        if left<0 or top<0 or left+dw>W or top+dh>H: raise ValueError('magnifier extends beyond canvas')
        v.update(x=f(left/W*100),y=f(top/H*100),width=f(dw/W*100),height=f(dh/H*100),source=f'<div class="{p}-fit">{media(asset,c["sourceStartFrame"])}</div>',zoomSource=media(asset,c['sourceStartFrame']),roiX=f(gx+x*scale),roiY=f(gy+y*scale),roiW=f(w*scale),roiH=f(h*scale),stroke=f(min(W,H)*.005),guard=f(min(W,H)*.009),cropLeft=f(-x/w*100),cropTop=f(-y/h*100),cropWidth=f(sw/w*100),cropHeight=f(sh/h*100))
    elif c['kind']=='wipe':
        before=f'<div style="position:absolute;inset:0">{media(asset,c["sourceStartFrame"])}<span class="{p}-label" style="left:2%;top:3%">{escape(c["beforeLabel"])}</span></div>'
        after=f'{media(second,c["secondStartFrame"])}<span class="{p}-label" style="right:2%;top:3%">{escape(c["afterLabel"])}</span>'
        v.update(before=before,after=after,beforeLabel=escape(c['beforeLabel']),afterLabel=escape(c['afterLabel']),wipeStart=f(c['wipeStartFrame']/last*100),wipeEnd=f(c['wipeEndFrame']/last*100),**{'from':f(c['wipeFrom']),'to':f(c['wipeTo'])},fromLeft=f(c['wipeFrom']),toLeft=f(c['wipeTo']),fromRight='0',toRight='0')
    elif c['kind']=='window':
        dw=W*c['widthPercent']/100;bar=min(W,H)*.042;dh=dw*sh/sw+bar;left,top=c['xPercent']/100*W-dw/2,c['yPercent']/100*H-dh/2
        if left<0 or top<0 or left+dw>W or top+dh>H: raise ValueError('desktop window extends beyond canvas')
        v.update(x=f(left/W*100),y=f(top/H*100),width=f(dw/W*100),height=f(dh/H*100),chrome=f(bar/dh*100),title=escape(c['title']),screen=media(asset,c['sourceStartFrame']))
    elif c['kind']=='layers':
        v.update(background=media(asset,c['sourceStartFrame']),foreground=media(alpha,c['alphaStartFrame'],p+'-media '+p+'-foreground',c.get('alphaOffset')),text=escape(c['text']),textX=f(c['textX']),textY=f(c['textY']),fontSize=f(c['fontSize']))
    else:
        marks=''
        for index,m in enumerate(c['marks']):
            start=m['startFrame']/last*100;end=min(last,m['endFrame']-1)/last*100
            mv=dict(v,id=f'{p}-m{index}',d=mark_path(m,c['marks'],min(sw,sh)),markColor=m['color'],markWidth=f(m['box'][3] if m['kind']=='highlight' else m['width']),guardWidth=f(m['width']+max(2,m['width']*.7)),guardOpacity='0' if m['kind']=='highlight' else '1',cap='butt' if m['kind']=='highlight' else 'round',opacity='0.3' if m['kind']=='highlight' else '1',drawSeconds=f(m['drawFrames']/rate),delaySeconds=f(m['startFrame']/rate),initialOpacity='1' if m['startFrame']==0 else '0',finalOpacity='1' if m['endFrame']>=c['durationFrames'] else '0',gateStart=f(start),gateOn=f(min(end,start+.001)),gateEnd=f(end),gateOff=f(min(100,end+.001)))
            marks+=render(T['mark']['markup'],mv);css+=render(T['mark']['css'],mv)
        v.update(source=media(asset,c['sourceStartFrame']) if c['showSource'] else '',marks=marks)
    entry=T[c['kind']]
    return '<style>'+render(T['baseCss']+entry['css'],v)+css+'</style>\n'+f'<div class="{p}">'+render(entry['markup'],v)+'</div>'
def build_visual_tool(project,sequence,config,id_factory):
    from .cli import parse_html_fragment
    c,*_=validate(config,project['assets'],sequence)
    root,css=parse_html_fragment(fragment(c,project['assets'],sequence,id_factory()))
    metadata=dict(c)
    for key in FRAME_KEYS: metadata[key]=str(metadata[key])
    serialized=json.dumps(metadata,ensure_ascii=False,separators=(',',':'))
    if len(serialized.encode())>32000: raise ValueError('too many annotation points; split the composition')
    chunks=[serialized[i:i+900] for i in range(0,len(serialized),900)]
    root['attributes']={'data-form-kind':'visual-tool','data-tool-kind':c['kind'],'data-tool-parts':str(len(chunks)),**{f'data-tool-config-{i}':s for i,s in enumerate(chunks)}}
    if c['kind']=='markup':
        from .marker_sound import attach, DEFAULT_SOUND
        c['sound']=config.get('sound',dict(DEFAULT_SOUND))
        properties=attach({'root':root,'stylesheet':css},c['sound'],[{'frame':m['startFrame'],'kind':m['kind']} for m in c['marks']],project['assets'],sequence,c['durationFrames'])
        root=properties['root']
        # Store the resolved setting so reopening never loses an explicit silent choice.
        metadata=dict(c)
        for key in FRAME_KEYS:metadata[key]=str(metadata[key])
        serialized=json.dumps(metadata,ensure_ascii=False,separators=(',',':'))
        if len(serialized.encode())>32000:raise ValueError('annotation recipe is too large')
        chunks=[serialized[i:i+900] for i in range(0,len(serialized),900)]
        root['attributes']={k:v for k,v in root['attributes'].items() if not k.startswith('data-tool-config-')}
        root['attributes'].update({'data-tool-parts':str(len(chunks)),**{f'data-tool-config-{i}':s for i,s in enumerate(chunks)}})
    built=build_operations(root=root,stylesheet=css,sequence=sequence,asset_id=c['assetId'],at_frame=c['startFrame'],duration_frames=c['durationFrames'],source_start_frame=c['sourceStartFrame'],id_factory=id_factory)
    for op in built['operations']:
        if op['type']=='track.add':
            track=op['payload']['track'];track['role']='visual-'+c['kind']
            previous=next((t for t in sequence['tracks'] if t['id']==track['id']),None)
            if previous: track['order']=previous['order']
    built['clips']=[{key:built[key] for key in ('clipId','trackId','componentId')}]
    return built
