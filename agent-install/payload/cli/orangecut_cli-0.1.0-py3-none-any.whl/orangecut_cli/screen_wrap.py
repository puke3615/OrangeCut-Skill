"""录屏包装:背景 + 设备框 + 跟着点击推拉的镜头 + 光标 + 点击涟漪。

产物是一段 HTML 片段,由 `oc html screen` 解析为 typed 节点并提交 Core 语义批次。
录屏本身作为 `<video data-asset-id>` 嵌在组件里,所以镜头推拉、光标和涟漪
都在同一个坐标系里,跟着画面一起缩放,不会和录屏错位。

坐标约定:点击坐标用录屏源文件的像素(`x,y`),时间用相对组件起点的秒。
内部一律换算成画布份额(0..1),再写成百分比——组件没有一个像素单位。
"""

from __future__ import annotations

import secrets
import math
import re
from fractions import Fraction
from ._screen_template import SCREEN_TEMPLATE
from dataclasses import dataclass

DEVICES = ("window", "laptop", "phone", "none")

DEFAULT_BACKGROUND = SCREEN_TEMPLATE["defaults"]["background"]


def fixed(value: float, digits: int = 3) -> str:
    """Identical to Desktop: ties away from zero, no negative zero."""
    scale = 10 ** digits
    rounded = math.floor(abs(value) * scale + .5)
    sign = "-" if value < 0 and rounded else ""
    return f"{sign}{rounded // scale}.{str(rounded % scale).zfill(digits)}"


@dataclass(frozen=True)
class Click:
    t: float  # 秒,相对组件起点
    x: float  # 录屏源像素
    y: float


@dataclass(frozen=True)
class Rect:
    x: float  # 画布份额
    y: float
    w: float
    h: float


def parse_clicks(spec: str | None) -> list[Click]:
    """`"1.9:594,229;4.6:636,205"` → 按时间排好的点击列表。"""
    if not spec:
        return []
    clicks: list[Click] = []
    for part in spec.split(";"):
        part = part.strip()
        if not part:
            continue
        time_text, _, point = part.partition(":")
        x_text, _, y_text = point.partition(",")
        try:
            clicks.append(Click(float(time_text), float(x_text), float(y_text)))
        except ValueError as error:
            raise ValueError(f"cannot read click {part!r}; write t:x,y such as 1.9:594,229") from error
    return sorted(clicks, key=lambda click: click.t)


def pick_device(device: str | None, video_w: int, video_h: int) -> str:
    if device and device != "auto":
        return device
    return "phone" if video_h > video_w else "window"


def screen_rect(device: str, video_w: int, video_h: int, canvas_w: int, canvas_h: int) -> tuple[Rect, Rect]:
    """录屏画面在画布里的位置,以及包住它的设备外框(都是画布份额)。"""
    canvas_aspect = canvas_w / canvas_h
    video_aspect = video_w / video_h
    # 每种设备留给屏幕的最大区域(画布份额)与外框加出来的边
    max_w, max_h = SCREEN_TEMPLATE["layouts"][device]
    # 先按宽放,再按高收
    w = max_w
    h = w * canvas_aspect / video_aspect
    if h > max_h:
        h = max_h
        w = h * video_aspect / canvas_aspect
    if device == "window":
        bar = 0.036
        x = (1 - w) / 2
        y = (1 - (h + bar)) / 2 + bar
        return Rect(x, y, w, h), Rect(x, y - bar, w, h + bar)
    if device == "laptop":
        pad_x, pad_y = 0.010, 0.010 * canvas_aspect
        base = 0.030
        x = (1 - w) / 2
        y = (1 - (h + 2 * pad_y + base)) / 2 + pad_y
        return Rect(x, y, w, h), Rect(x - pad_x, y - pad_y, w + 2 * pad_x, h + 2 * pad_y)
    if device == "phone":
        pad_x = 0.012
        pad_y = pad_x * canvas_aspect
        x = (1 - w) / 2
        y = (1 - h) / 2
        return Rect(x, y, w, h), Rect(x - pad_x, y - pad_y, w + 2 * pad_x, h + 2 * pad_y)
    x = (1 - w) / 2
    y = (1 - h) / 2
    return Rect(x, y, w, h), Rect(x, y, w, h)


def to_canvas(click: Click, screen: Rect, video_w: int, video_h: int) -> tuple[float, float]:
    return screen.x + click.x / video_w * screen.w, screen.y + click.y / video_h * screen.h


def camera_keys(
    points: list[tuple[float, float, float]],
    duration: float,
    zoom: float,
    hold: float,
    lead: float = 0.55,
    release: float = 0.7,
) -> list[tuple[float, float, float, float]]:
    """点击 (t, cx, cy) → 镜头关键帧 (t, scale, cx, cy)。

    每次点击前 `lead` 秒推近到点击处,停 `hold` 秒,再用 `release` 秒拉回全景;
    下一次点击来得早于拉回完成,就保持推近、直接平移过去,而不是拉远再推近。
    """
    keys: list[tuple[float, float, float, float]] = [(0.0, 1.0, 0.5, 0.5)]
    for index, (t, cx, cy) in enumerate(points):
        start = max(0.0, t - lead)
        end = min(duration, t + hold)
        next_t = points[index + 1][0] if index + 1 < len(points) else None
        if next_t is not None:
            end = min(end, max(t, next_t - lead))
        previous = keys[-1]
        if previous[1] == 1.0:
            # 从全景出发:先把全景停到推近开始的那一刻
            if start > previous[0]:
                keys.append((start, 1.0, 0.5, 0.5))
        else:
            # 已经推近着:平移到新点,用推近的时长
            keys.append((max(previous[0], start), zoom, previous[2], previous[3]))
        keys.append((min(duration, t), zoom, cx, cy))
        if end > t:
            keys.append((end, zoom, cx, cy))
        if end < duration and (next_t is None or next_t - lead > end + release):
            keys.append((min(duration, end + release), 1.0, 0.5, 0.5))
    if keys[-1][0] < duration:
        keys.append((duration, keys[-1][1], keys[-1][2], keys[-1][3]))
    # 同一时刻只留最后一条,时间严格递增
    cleaned: list[tuple[float, float, float, float]] = []
    for key in keys:
        if cleaned and key[0] <= cleaned[-1][0] + 1e-6:
            cleaned[-1] = (cleaned[-1][0], key[1], key[2], key[3])
        else:
            cleaned.append(key)
    return cleaned


def _clamp_axis(scale: float, center: float, lo: float, size: float) -> float:
    """一个轴上的平移:把 center 搬到画面中心,但推近后设备框盖得住画面时
    不让框边露进来;盖不住时就让框在这个轴上居中。"""
    if scale * size >= 1:
        return min(-scale * lo, max(1 - scale * (lo + size), 0.5 - scale * center))
    return 0.5 - scale * (lo + size / 2)


def camera_transform(scale: float, cx: float, cy: float, frame: Rect | None = None) -> str:
    """原点在左上:把 (cx, cy) 搬到画面中心。全景(scale=1)不动。"""
    if scale <= 1.0001:
        return "translate(0%,0%) scale(1)"
    bounds = frame or Rect(0, 0, 1, 1)
    tx = _clamp_axis(scale, cx, bounds.x, bounds.w)
    ty = _clamp_axis(scale, cy, bounds.y, bounds.h)
    return f"translate({fixed(tx * 100)}%,{fixed(ty * 100)}%) scale({fixed(scale, 4)})"


def percent(t: float, duration: float) -> str:
    return fixed(max(0.0, min(100.0, t / duration * 100))) + "%"


def validate_options(*, video_w, video_h, duration, canvas_w, canvas_h, device,
                     clicks, focus=None, zoom=1.8, hold=1.4, crop=None,
                     background=DEFAULT_BACKGROUND, accent="#F28C28", media_start=Fraction(0)):
    """Fail before any asset import. Coordinates are source pixels; events are clip-local."""
    for name, value in (("video width", video_w), ("video height", video_h),
                        ("canvas width", canvas_w), ("canvas height", canvas_h), ("duration", duration)):
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be finite and positive")
    if device not in DEVICES:
        raise ValueError(f"device must be one of {', '.join(DEVICES)}")
    if not math.isfinite(zoom) or not 1 <= zoom <= 6:
        raise ValueError("zoom must be between 1 and 6")
    if not math.isfinite(hold) or not 0 <= hold <= 10:
        raise ValueError("hold must be between 0 and 10 seconds")
    if media_start < 0:
        raise ValueError("media start must be non-negative")
    crop = crop or Rect(0, 0, video_w, video_h)
    if not all(math.isfinite(v) for v in (crop.x, crop.y, crop.w, crop.h)) or crop.x < 0 or crop.y < 0 or crop.w <= 0 or crop.h <= 0 or crop.x + crop.w > video_w + 1e-6 or crop.y + crop.h > video_h + 1e-6:
        raise ValueError("crop must be a positive rectangle inside the source video")
    for label, events in (("click", clicks), ("focus", clicks if focus is None else focus)):
        if len(events) > 128:
            raise ValueError(f"at most 128 {label} points are supported")
        for point in events:
            if not all(math.isfinite(v) for v in (point.t, point.x, point.y)) or not 0 <= point.t < duration:
                raise ValueError(f"{label} time must be finite and within [0, duration)")
            if not crop.x <= point.x <= crop.x + crop.w or not crop.y <= point.y <= crop.y + crop.h:
                raise ValueError(f"{label} point must be inside the cropped source picture")
    if not isinstance(background, str) or not background.strip() or len(background) > 1024 or re.search(r"[;{}<>]|url\s*\(|@|expression\s*\(", background, re.I):
        raise ValueError("background must be a local CSS colour or gradient")
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", accent):
        raise ValueError("accent must be a six-digit hex colour")
    return crop


def _render(template: str, values: dict) -> str:
    return re.sub(r"\{\{([A-Za-z]+)\}\}", lambda match: str(values[match[1]]), template)


def build_fragment(
    *, asset_id: str, video_w: int, video_h: int, duration: float,
    canvas_w: int, canvas_h: int, device: str, clicks: list[Click],
    zoom: float = 1.8, hold: float = 1.4, cursor: bool = True,
    background: str = DEFAULT_BACKGROUND, accent: str = "#F28C28",
    focus: list[Click] | None = None, crop: Rect | None = None,
    media_start: Fraction = Fraction(0), instance_id: str | None = None,
) -> str:
    """Shared native template; no source URL or file path enters the component."""
    crop = validate_options(video_w=video_w, video_h=video_h, duration=duration,
        canvas_w=canvas_w, canvas_h=canvas_h, device=device, clicks=clicks, focus=focus,
        zoom=zoom, hold=hold, crop=crop, background=background, accent=accent, media_start=media_start)
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]*", asset_id):
        raise ValueError("asset_id must be an opaque project Asset ID")
    p = instance_id or f"oc-screen-{secrets.token_hex(6)}"
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]*", p):
        raise ValueError("instance_id must be a CSS-safe identifier")
    screen, frame = screen_rect(device, crop.w, crop.h, canvas_w, canvas_h)
    def points(events):
        return [(c.t, screen.x + (c.x-crop.x)/crop.w*screen.w,
                 screen.y + (c.y-crop.y)/crop.h*screen.h) for c in sorted(events, key=lambda c: c.t)]
    taps = points(clicks)
    targets = points(clicks if focus is None else focus)
    keys = camera_keys(targets, duration, zoom, hold)
    def box(r):
        return f"left:{fixed(r.x*100)}%;top:{fixed(r.y*100)}%;width:{fixed(r.w*100)}%;height:{fixed(r.h*100)}%"
    base = Rect(frame.x-frame.w*.08, frame.y+frame.h, frame.w*1.16, .026)
    video = Rect(-crop.x/crop.w, -crop.y/crop.h, video_w/crop.w, video_h/crop.h)
    values = dict(p=p, background=background, accent=accent, duration=fixed(duration),
        screenBox=box(screen), frameBox=box(frame), baseBox=box(base), videoBox=box(video),
        assetId=asset_id, mediaStart=f"{media_start.numerator}/{media_start.denominator}")
    t = SCREEN_TEMPLATE
    css = _render(t["baseCss"] + t["devices"][device]["css"], values)
    frames = "".join(_render(t["cameraKey"], dict(percent=percent(time,duration)[:-1],
        transform=camera_transform(scale,cx,cy,frame))) for time,scale,cx,cy in keys)
    css += f"@keyframes {p}-cam{{{frames}}}"
    values["deviceMarkup"] = _render(t["devices"][device]["markup"], values)
    values["clickMarkup"] = "".join(_render(t["tapMarkup"], dict(values,
        x=fixed(x*100),y=fixed(y*100),t=fixed(time))) for time,x,y in taps)
    values["cursorMarkup"] = ""
    if cursor and taps:
        path = [(0.0, taps[0][1], taps[0][2])]
        for time,x,y in taps:
            previous = path[-1]
            depart = max(previous[0], time-.5)
            if depart > previous[0]:
                path.append((depart,previous[1],previous[2]))
            if time > path[-1][0]:
                path.append((time,x,y))
            else:
                path[-1] = (time,x,y)
        path.append((duration,path[-1][1],path[-1][2]))
        cursor_frames = "".join(_render(t["cursorKey"], dict(percent=percent(time,duration)[:-1],
            x=fixed(x*100),y=fixed(y*100))) for time,x,y in path)
        css += f"@keyframes {p}-cursor{{{cursor_frames}}}"
        values["cursorMarkup"] = _render(t["cursorMarkup"], values)
    return "<style>" + css + "</style>\n" + _render(t["markup"], values)


def build_operations(*, root, stylesheet, sequence, asset_id, at_frame,
                     duration_frames, source_start_frame, keep_audio=False,
                     track_id=None, id_factory=None):
    """One reversible semantic placement batch, including optional independent audio."""
    fresh = id_factory or (lambda: secrets.token_hex(12))
    rate = Fraction(int(sequence["frameRate"]["num"]), int(sequence["frameRate"]["den"]))
    if at_frame < 0 or duration_frames <= 0 or source_start_frame < 0 or rate <= 0:
        raise ValueError("invalid screen recording time range")
    wire = lambda value: {"num": str(value.numerator), "den": str(value.denominator)}
    timeline = {"start": wire(Fraction(at_frame)/rate), "end": wire(Fraction(at_frame+duration_frames)/rate)}
    order = max((track["order"] for track in sequence["tracks"]), default=-1)
    operations = []
    def add_track(kind, role):
        nonlocal order
        order += 1
        identifier = "track-" + fresh()
        operations.append({"type":"track.add","payload":{"sequenceId":sequence["id"],"track":{
            "id":identifier,"kind":kind,"role":role,"order":order,"muted":False,"locked":False,"extensions":{},"clips":[],"captions":[]}}})
        return identifier
    if track_id is None:
        track_id = add_track("component", "html")
    elif not any(track["id"] == track_id and track["kind"] == "component" and not track.get("locked") for track in sequence["tracks"]):
        raise ValueError("track-id must name an unlocked component track")
    component_id, clip_id = "screen-" + fresh(), "clip-" + fresh()
    operations.append({"type":"component.add","payload":{"component":{
        "id":component_id,"componentType":"dev.orangecut.html","capabilityRequirements":["dev.orangecut.component.html"],"extensions":{},"properties":{"root":root,"stylesheet":stylesheet}}}})
    def clip(identifier, source):
        return {"id":identifier,"source":source,"timelineRange":timeline,"enabled":True,"effects":[],"extensions":{},"playback":{"rate":{"num":"1","den":"1"},"reverse":False,"freeze":False}}
    operations.append({"type":"clip.add","payload":{"sequenceId":sequence["id"],"trackId":track_id,"clip":clip(clip_id,{"type":"component","componentId":component_id})}})
    if keep_audio:
        audio_track=add_track("audio","screen-recording-audio")
        audio=clip("clip-"+fresh(),{"type":"asset","assetId":asset_id})
        audio["sourceRange"]={"start":wire(Fraction(source_start_frame)/rate),"end":wire(Fraction(source_start_frame+duration_frames)/rate)}
        operations.append({"type":"clip.add","payload":{"sequenceId":sequence["id"],"trackId":audio_track,"clip":audio}})
    return {"operations":operations,"clipId":clip_id,"trackId":track_id,"componentId":component_id}
