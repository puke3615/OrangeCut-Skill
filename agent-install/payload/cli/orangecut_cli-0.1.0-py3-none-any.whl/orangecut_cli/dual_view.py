"""Two generic media windows, authored as one reversible semantic batch.

The CSS is generated from the same template the Desktop imports. Neither this
module nor the Desktop writes Project files or renders a second visual model.
"""
from __future__ import annotations

from fractions import Fraction
import math
import uuid

from ._dual_pane_template import TEMPLATE


def _number(value, name, low, high):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{name} must be finite and within {low}..{high}")
    return value


def _frame(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _fields(value, allowed, name):
    if not isinstance(value, dict):
        raise ValueError(f"{name} must be an object")
    unknown = set(value) - set(allowed)
    if unknown:
        raise ValueError(f"unknown {name} fields: {', '.join(sorted(unknown))}")


def _rat(value):
    value = Fraction(value)
    return {"num": str(value.numerator), "den": str(value.denominator)}


def _wire(value):
    return Fraction(int(value["num"]), int(value["den"]))


def pair_rects(width, height, layout="horizontal", gap=16, split=50):
    _number(gap, "gapPx", 0, min(width, height) / 5)
    _number(split, "splitPercent", 35, 75)
    if layout not in ("horizontal", "vertical", "primary"):
        raise ValueError("layout must be horizontal, vertical or primary")
    rect = lambda x, y, w, h: {"x": x, "y": y, "width": w, "height": h}
    if layout == "primary":
        w = math.floor(width * .32 + .5)
        h = math.floor(w * height / width + .5)
        return [rect(gap, gap, width - gap * 2, height - gap * 2), rect(width - w - gap * 2, height - h - gap * 2, w, h)]
    horizontal = layout == "horizontal"
    available = (width if horizontal else height) - gap * 3
    first = available / 2 if split == 50 else math.floor(available * split / 100 + .5)
    second = available - first
    if horizontal:
        return [rect(gap, gap, first, height - gap * 2), rect(gap * 2 + first, gap, second, height - gap * 2)]
    return [rect(gap, gap, width - gap * 2, first), rect(gap, gap * 2 + first, width - gap * 2, second)]


def build_dual_view(project, sequence, config, id_factory=None):
    """Validate fully before returning track/component/clip Commands; no I/O."""
    _fields(config, ("layout", "gapPx", "splitPercent", "panes"), "config")
    panes = config.get("panes")
    if not isinstance(panes, list) or len(panes) != 2:
        raise ValueError("panes must contain exactly two windows")
    fresh = id_factory or (lambda: uuid.uuid4().hex)
    width, height = sequence["canvas"]["width"], sequence["canvas"]["height"]
    rate = _wire(sequence["frameRate"])
    rects = pair_rects(width, height, config.get("layout", "horizontal"), config.get("gapPx", 16), config.get("splitPercent", 50))
    assets = {asset["id"]: asset for asset in project["assets"]}
    operations, clips = [], []
    order = max((track["order"] for track in sequence["tracks"]), default=-1)

    def append_clip(kind, role, clip):
        nonlocal order
        order += 1
        track_id = "track-" + fresh()
        operations.extend([
            {"type": "track.add", "payload": {"sequenceId": sequence["id"], "track": {"id": track_id, "kind": kind, "role": role, "order": order, "locked": False, "muted": False, "clips": [], "captions": [], "extensions": {}}}},
            {"type": "clip.add", "payload": {"sequenceId": sequence["id"], "trackId": track_id, "clip": clip}},
        ])
        return track_id

    for index, pane in enumerate(panes):
        _fields(pane, ("assetId", "sourceStartFrame", "startFrame", "durationFrames", "fit", "cropX", "cropY", "audio", "rect"), f"panes[{index}]")
        asset = assets.get(pane.get("assetId"))
        if not asset or asset["kind"] not in ("video", "image"):
            raise ValueError(f"pane {index + 1} needs an imported video or image assetId")
        source = _frame(pane.get("sourceStartFrame", 0), "sourceStartFrame")
        start = _frame(pane.get("startFrame", 0), "startFrame")
        duration = _frame(pane.get("durationFrames"), "durationFrames", 1)
        if asset["kind"] == "image" and source:
            raise ValueError("images must use sourceStartFrame 0")
        if asset["kind"] == "video":
            asset_duration = (asset.get("probe") or {}).get("duration")
            if not asset_duration or Fraction(source + duration) / rate > _wire(asset_duration):
                raise ValueError(f"pane {index + 1} exceeds its source duration")
        fit = pane.get("fit", "contain")
        if fit not in ("contain", "cover"):
            raise ValueError("fit must be contain or cover")
        crop_x = _number(pane.get("cropX", 50), "cropX", 0, 100)
        crop_y = _number(pane.get("cropY", 50), "cropY", 0, 100)
        audio = pane.get("audio", False)
        if not isinstance(audio, bool):
            raise ValueError("audio must be boolean (adds a separate audio track)")
        if audio and (asset["kind"] != "video" or not any(stream.get("kind") == "audio" for stream in (asset.get("probe") or {}).get("streams", []))):
            raise ValueError(f"pane {index + 1} has no source audio")
        rect = pane.get("rect", rects[index])
        _fields(rect, ("x", "y", "width", "height"), "rect")
        for key, maximum in (("x", width), ("width", width), ("y", height), ("height", height)):
            _number(rect.get(key), "rect." + key, 1 if key in ("width", "height") else 0, maximum)
        if rect["x"] + rect["width"] > width or rect["y"] + rect["height"] > height:
            raise ValueError("window must remain inside the canvas")
        instance = "oc-pane-" + fresh()
        stylesheet = TEMPLATE["stylesheet"].replace("{{class}}", instance)
        for key in ("x", "y", "width", "height"):
            percent = rect[key] / (width if key in ("x", "width") else height) * 100
            stylesheet = stylesheet.replace("{{" + key + "}}", format(percent, ".15g"))
        media = {"tag": "img" if asset["kind"] == "image" else "video", "assetId": asset["id"], "styles": {**TEMPLATE["mediaStyle"], "object-fit": fit, "object-position": f"{crop_x:g}% {crop_y:g}%"}}
        if asset["kind"] == "video":
            media.update(mediaStart=_rat(Fraction(source) / rate), attributes={"muted": ""})
        component_id, clip_id = "component-" + fresh(), "clip-" + fresh()
        root = {"tag": "div", "classes": [instance], "attributes": {"data-form-kind": "media-pane"}, "children": [{"tag": "div", "classes": [instance + "-window"], "children": [media]}]}
        operations.append({"type": "component.add", "payload": {"component": {"id": component_id, "componentType": "dev.orangecut.html", "capabilityRequirements": ["dev.orangecut.component.html"], "extensions": {}, "properties": {"root": root, "stylesheet": stylesheet}}}})
        clip = {"id": clip_id, "enabled": True, "effects": [], "extensions": {}, "playback": {"freeze": False, "reverse": False, "rate": _rat(1)}, "source": {"type": "component", "componentId": component_id}, "timelineRange": {"start": _rat(Fraction(start) / rate), "end": _rat(Fraction(start + duration) / rate)}}
        track_id = append_clip("component", "media-pane", clip)
        clips.append({"clipId": clip_id, "trackId": track_id, "assetId": asset["id"]})
        if audio:
            audio_clip = {**clip, "id": "clip-audio-" + fresh(), "source": {"type": "asset", "assetId": asset["id"]}, "sourceRange": {"start": _rat(Fraction(source) / rate), "end": _rat(Fraction(source + duration) / rate)}}
            clips[-1]["audioTrackId"] = append_clip("audio", "source-audio", audio_clip)
    # An exact retry must reconstruct the original batch even if another edit
    # subsequently added a higher-order track. Deterministic own IDs anchor the
    # original contiguous order sequence; using current maxOrder would change
    # the payload hash and turn a safe retry into an idempotency conflict.
    existing = {track["id"]: track for track in sequence["tracks"]}
    additions = [op["payload"]["track"] for op in operations if op["type"] == "track.add"]
    offsets = {existing[track["id"]]["order"] - track["order"] for track in additions if track["id"] in existing}
    if len(offsets) > 1:
        raise ValueError("the original dual-view tracks were reordered; exact retry cannot reconstruct their original order; use the original request or a new idempotency key")
    if offsets:
        offset = offsets.pop()
        for track in additions:
            track["order"] += offset
    return {"operations": operations, "clips": clips}
