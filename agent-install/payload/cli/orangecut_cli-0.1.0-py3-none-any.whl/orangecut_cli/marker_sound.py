"""Component-owned short cues, sharing the Desktop's catalog and exact timing."""
import copy, json
from fractions import Fraction
from ._marker_sound_presets import PRESETS as CATALOG
DEFAULT_SOUND={'preset':'none','volumePercent':CATALOG['defaultVolumePercent']}
def wire(v):
    return {'num':str(v.numerator),'den':str(v.denominator)}
def fraction(v):
    return Fraction(int(v['num']),int(v['den']))
def attach(properties,sound,events,assets,sequence,duration_frames):
    if sound is None:return properties
    if not isinstance(sound,dict) or set(sound)-{'preset','volumePercent','assetId'} or sound.get('preset') not in ('auto','none','tick','sweep','glow','custom') or isinstance(sound.get('volumePercent'),bool) or not isinstance(sound.get('volumePercent'),int) or not 0<=sound['volumePercent']<=100 or ('assetId' in sound and not isinstance(sound['assetId'],str)) or sound['preset']=='custom' and not sound.get('assetId'):
        raise ValueError('invalid marker sound or volume (0..100)')
    nodes=[];next_time=Fraction(0);rate=fraction(sequence['frameRate'])
    for event in sorted(events,key=lambda e:e['frame']):
        frame=event['frame']
        if isinstance(frame,bool) or not isinstance(frame,int) or not 0<=frame<duration_frames:raise ValueError('cue outside component')
        at=Fraction(frame)/rate
        if at<next_time:continue
        preset=sound['preset'];kind=event['kind']
        if preset=='none' or sound['volumePercent']==0:continue
        if preset=='auto':preset='glow' if kind in ('highlight','focus') else 'sweep' if kind in ('pen','underline','circle') else 'tick'
        asset_id=sound.get('assetId') if preset=='custom' else next(p['assetId'] for p in CATALOG['presets'] if p['id']==preset)
        asset=next((a for a in assets if a['id']==asset_id),None)
        if not asset or asset['kind']!='audio' or not any(s['kind']=='audio' for s in (asset.get('probe') or {}).get('streams',[])):raise ValueError('marker sound needs a probed audio Asset')
        duration=min(fraction(asset['probe']['duration']),Fraction(3),Fraction(duration_frames-frame)/rate)
        if duration<=0:raise ValueError('invalid audio duration')
        nodes.append({'tag':'audio','assetId':asset_id,'audioCue':{'offset':wire(at),'duration':wire(duration),'volume':wire(Fraction(sound['volumePercent'],100))}})
        next_time=at+max(Fraction(CATALOG['minimumGapMs'],1000),duration)
    result=copy.deepcopy(properties);root=result['root'];root.setdefault('attributes',{})['data-marker-sound']=json.dumps(sound,ensure_ascii=False,separators=(',',':'))
    root['children']=[n for n in root.get('children',[]) if 'audioCue' not in n]+nodes
    return result

def update_component_sound(project,sequence,clip_id,preset=None,asset_id=None,volume=None):
    clip=next((c for t in sequence['tracks'] for c in t['clips'] if c['id']==clip_id),None)
    if not clip or clip['source']['type']!='component':raise ValueError('select a marker component clip')
    component=next(c for c in project['components'] if c['id']==clip['source']['componentId'])
    if component['componentType']!='dev.orangecut.html':raise ValueError('not an HTML marker component')
    properties=component['properties'];attrs=properties['root'].get('attributes',{});kind=attrs.get('data-form-kind')
    sound=json.loads(attrs['data-marker-sound']) if 'data-marker-sound' in attrs else dict(DEFAULT_SOUND,preset='none')
    if preset is not None:sound['preset']=preset
    if asset_id is not None:sound.update(preset='custom',assetId=asset_id)
    if volume is not None:sound['volumePercent']=volume
    if kind=='visual-tool' and attrs.get('data-tool-kind')=='markup':
        config=json.loads(''.join(attrs[f'data-tool-config-{i}'] for i in range(int(attrs['data-tool-parts']))))
        events=[{'frame':m['startFrame'],'kind':m['kind']} for m in config['marks']]
    elif kind in ('anchor','focus'):events=[{'frame':0,'kind':kind}]
    else:raise ValueError('this component is not a supported marker')
    duration=(fraction(clip['timelineRange']['end'])-fraction(clip['timelineRange']['start']))*fraction(sequence['frameRate'])
    if duration.denominator!=1:raise ValueError('component needs frame-aligned timing')
    events=[e for e in events if e['frame']<duration]
    next_properties=attach(properties,sound,events,project['assets'],sequence,int(duration))
    next_component={**component,'properties':next_properties}
    return [{'type':'component.update','payload':{'component':next_component}}]
