# Generated from schemas/v0/dual-pane-template.json; checked by test_dual_view.py.
import json
TEMPLATE = json.loads(r'''{
  "version": 1,
  "description": "One independently timed media window. Class and numeric percent placeholders are replaced by the authoring client; the typed media node carries assetId and mediaStart.",
  "stylesheet": ".{{class}}{position:relative;width:100%;height:100%;container-type:size;pointer-events:none}.{{class}}-window{position:absolute;left:{{x}}%;top:{{y}}%;width:{{width}}%;height:{{height}}%;overflow:hidden;background:#111318;border-radius:.5cqmin}",
  "mediaStyle": {"width":"100%","height":"100%"}
}''')
